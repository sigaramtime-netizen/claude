/* D015-B: Ctrl+K global arama + ? kısayollar (<2KB) */
(function(){var k=document.getElementById('kk'),q=document.getElementById('kk-q'),r=document.getElementById('kk-r'),h=document.getElementById('kk-h');
function sh(e){e.style.display='flex'}function hd(e){e.style.display='none'}
function esc(x){return String(x==null?'':x).replace(/&/g,'&amp;').replace(/</g,'&lt;')}
document.addEventListener('keydown',function(e){
if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();sh(k);q.value='';r.innerHTML='';q.focus()}
else if(e.key==='?'&&!/INPUT|TEXTAREA|SELECT/.test((document.activeElement||{}).tagName||'')){sh(h)}
else if(e.key==='Escape'){hd(k);hd(h)}});
k.addEventListener('click',function(e){if(e.target===k)hd(k)});
h.addEventListener('click',function(e){if(e.target===h)hd(h)});
var t=null;
q.addEventListener('input',function(){clearTimeout(t);var s=q.value.trim();if(s.length<2){r.innerHTML='';return}
t=setTimeout(function(){Promise.all([fetch('/api/ara?tip=stok&q='+encodeURIComponent(s)).then(function(x){return x.json()}),fetch('/api/ara?tip=cari&q='+encodeURIComponent(s)).then(function(x){return x.json()})]).then(function(d){var o='';
(d[0]||[]).slice(0,5).forEach(function(i){o+='<a class="kk-i" href="/stok/'+i.id+'">📦 '+esc(i.kod)+' — '+esc(i.ad)+'</a>'});
(d[1]||[]).slice(0,5).forEach(function(i){o+='<a class="kk-i" href="/cari/'+i.id+'">👥 '+esc(i.kod)+' — '+esc(i.unvan)+'</a>'});
r.innerHTML=o||'<div class="kk-i">Sonuç yok</div>'})},200)});
q.addEventListener('keydown',function(e){if(e.key==='Enter'){var a=r.querySelector('a');if(a)location.href=a.href}})})();
