# -*- coding: utf-8 -*-
"""Tam regresyon koşucusu: tüm test_*.py dosyalarını sırayla çalıştırır,
özet satırını yakalar; hem ekrana hem (verilirse) kanıt dosyasına yazar.

Kullanım: python3 regresyon_runner.py [kanıt_dosyası]
"""
import re
import subprocess
import sys
import glob


def parse(line):
    ok = fail = None
    m = re.search(r"(\d+)\s*(?:başarılı|✅|geçti|adet)", line)
    if m:
        ok = int(m.group(1))
    f = re.search(r"(\d+)\s*(?:başarısız|❌)", line)
    if f:
        fail = int(f.group(1))
    return ok, fail


tests = sorted(glob.glob("test_*.py"))
rows = []
total_checks = 0
total_fail = 0
bad = 0

for t in tests:
    p = subprocess.run([sys.executable, t], capture_output=True, text=True, timeout=600)
    out = p.stdout + p.stderr
    exitc = p.returncode
    lines = [l.strip() for l in out.splitlines() if ("başarılı" in l or "başarısız" in l
             or ("geçti" in l and re.search(r"\d", l)) or "✅" in l or "❌" in l)]
    # kanonik özet: "SONUÇ" içeren SON satır; yoksa sayılı ✅/❌ satırı; yoksa son satır
    sonuc = [l for l in lines if "SONUÇ" in l]
    if sonuc:
        summary = sonuc[-1]
    else:
        numbered = [l for l in lines if re.search(r"\d", l)]
        summary = numbered[-1] if numbered else (lines[-1] if lines else "(özet yok)")
    ok, fail = parse(summary)
    if ok is None and fail is None:
        ok = 0
    fail = fail or 0
    total_checks += (ok or 0)
    total_fail += fail
    if exitc != 0 or fail > 0:
        bad += 1
    rows.append((t, exitc, summary))

report = []
report.append(f"===== D016 (v1.47.0) — TAM REGRESYON =====")
report.append(f"Tarih: (canlı) | Sunucu: 127.0.0.1:8080 | SURUM: 1.47.0")
report.append("")
for t, e, s in rows:
    report.append(f"[{t:<32}] exit={e} | {s}")
report.append("")
report.append(f"TOPLAM: {len(tests)} dosya, {total_checks} kontrol, {total_fail} başarısız (exit!=0 veya fail: {bad})")
txt = "\n".join(report)
print(txt)
if len(sys.argv) > 1:
    with open(sys.argv[1], "w", encoding="utf-8") as fh:
        fh.write(txt + "\n")
    print(f"\n[kaydedildi] {sys.argv[1]}")
if bad:
    sys.exit(1)
