# -*- coding: utf-8 -*-
"""Kasa modülü (Faz 1): çoklu kasa, nakit giriş/çıkış, açılış-kapanış, fiş, günlük rapor,
kasa ↔ banka transferi ve CARİ BAĞLANTISI.

- "Nakit Girişi" / "Nakit Çıkışı" hareketinde opsiyonel cari seçilirse, TEK işlemle
  karşılık gelen cari_hareket (Nakit Girişi → Tahsilat/alacak, Nakit Çıkışı → Ödeme/borç)
  otomatik oluşturulur (ilgili_modul='Kasa'). Cari seçilmezse sadece kasa kaydı yazılır.
- "Kasa → Banka" / "Banka → Kasa" transferlerinde opsiyonel banka hesabı seçilirse
  banka tarafına da otomatik karşı hareket yazılır (ilgili_modul='Transfer').
"""
import datetime
import urllib.parse

import db
import cari
import muhasebe
from core import route, render_template, redirect, flash, audit, izole_sube, Response
from config import PARA_BIRIMLERI

KASA_WRITE = ("Admin", "Muhasebe", "Satis")
GIRIS = ["Açılış Bakiyesi", "Nakit Girişi", "Banka → Kasa", "Kasa Transferi (Giriş)"]
CIKIS = ["Nakit Çıkışı", "Kasa → Banka", "Kasa Transferi (Çıkış)"]
TRANSFER_TIPLERI = ("Kasa → Banka", "Banka → Kasa", "Kasa Transferi (Çıkış)", "Kasa Transferi (Giriş)")
CARI_TIPLERI = ("Nakit Girişi", "Nakit Çıkışı")


def _f(v, default=0.0):
    try:
        return float(v if v not in (None, "") else default)
    except (TypeError, ValueError):
        return default


def _i(v):
    try:
        return int(v) if v not in (None, "") else None
    except (TypeError, ValueError):
        return None


def islem_yonu(tip):
    return 1 if tip in GIRIS else -1


def _bakiye_doviz(conn, kasa_id=None, tarih=None, sid=None):
    """K18 — para birimi bazında net bakiye: {para_birimi: net_tutar}. Karışık para
    birimleri ASLA tek sayıya toplanmaz; her birim kendi cinsinden netlenir."""
    where, params = ["1=1"], []
    if kasa_id:
        where.append("kasa_id=?")
        params.append(kasa_id)
    if tarih:
        where.append("tarih <= ?")
        params.append(tarih)
    if sid is not None:
        where.append("sirket_id=?")
        params.append(sid)
    rows = conn.execute(
        "SELECT islem_tipi, tutar, para_birimi FROM kasa_hareket WHERE " + " AND ".join(where),
        params,
    ).fetchall()
    out = {}
    for r in rows:
        pb = r["para_birimi"] or "TRY"
        out[pb] = out.get(pb, 0.0) + islem_yonu(r["islem_tipi"]) * (r["tutar"] or 0)
    return out


def _bakiye(conn, kasa_id=None, tarih=None, sid=None):
    """K18 — TL karşılık toplam bakiye (her hareketin kayıt kurundan: tutar × doviz_kur).
    TRY hareketlerinde doviz_kur=1 kabul edilir; döviz hareketleri TL'ye çevrilir."""
    where, params = ["1=1"], []
    if kasa_id:
        where.append("kasa_id=?")
        params.append(kasa_id)
    if tarih:
        where.append("tarih <= ?")
        params.append(tarih)
    if sid is not None:
        where.append("sirket_id=?")
        params.append(sid)
    rows = conn.execute(
        "SELECT islem_tipi, tutar, doviz_kur FROM kasa_hareket WHERE " + " AND ".join(where),
        params,
    ).fetchall()
    return round(sum(islem_yonu(r["islem_tipi"]) * (r["tutar"] or 0) * (r["doviz_kur"] or 1.0)
                     for r in rows), 2)


def _kasalar(conn, sube_id=None, sid=None):
    where = "WHERE aktif=1"
    args = []
    if sube_id:
        where += " AND sube_id=?"
        args.append(sube_id)
    if sid is not None:
        where += " AND sirket_id=?"
        args.append(sid)
    return [dict(r) for r in conn.execute(f"SELECT * FROM kasa {where} ORDER BY ad", args).fetchall()]


def _cariler(conn, sid=None):
    extra = " AND sirket_id=?" if sid is not None else ""
    args = [sid] if sid is not None else []
    return conn.execute("SELECT id, unvan, kod FROM cari_kart WHERE aktif=1" + extra +
                        " ORDER BY unvan", args).fetchall()


def _onayli_faturalar(conn, sid=None):
    extra = " AND f.sirket_id=?" if sid is not None else ""
    args = [sid] if sid is not None else []
    return conn.execute(
        "SELECT f.id, f.fatura_no, f.genel_toplam, c.unvan AS cari_unvan FROM fatura f "
        "LEFT JOIN cari_kart c ON c.id=f.cari_id WHERE f.durum='Onaylandı'" + extra +
        " ORDER BY f.id DESC", args
    ).fetchall()


def kasa_hareket_olustur(conn, kasa_id, tarih, islem_tipi, tutar, aciklama=None, belge_no=None,
                         cari_id=None, ilgili_modul="Kasa", ilgili_kayit_id=None, created_by=None,
                         para_birimi="TRY", doviz_kur=None, sirket_id=None):
    """Tek noktadan kasa hareketi yazma (Banka modülü transfer karşılığında da kullanılır)."""
    if sirket_id is None:
        sirket_id = (conn.execute("SELECT sirket_id FROM kasa WHERE id=?", (kasa_id,)).fetchone()
                     or {"sirket_id": 1})["sirket_id"]
    cur = conn.execute(
        "INSERT INTO kasa_hareket(kasa_id, tarih, islem_tipi, tutar, cari_id, aciklama, belge_no, "
        "ilgili_modul, ilgili_kayit_id, created_by, para_birimi, doviz_kur, sirket_id) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (kasa_id, tarih, islem_tipi, tutar, cari_id, aciklama, belge_no,
         ilgili_modul, ilgili_kayit_id, created_by, para_birimi, doviz_kur, sirket_id),
    )
    return cur.lastrowid


def _hareketler(conn, kasa_id=None, tarih=None, limit=200, sid=None):
    where, params = ["1=1"], []
    if sid is not None:
        where.append("h.sirket_id=?")
        params.append(sid)
    if kasa_id:
        where.append("h.kasa_id=?")
        params.append(kasa_id)
    if tarih:
        where.append("h.tarih=?")
        params.append(tarih)
    rows = [dict(r) for r in conn.execute(
        "SELECT h.*, k.ad AS kasa_ad, k.kod AS kasa_kod, c.unvan AS cari_unvan, c.kod AS cari_kod "
        "FROM kasa_hareket h JOIN kasa k ON k.id=h.kasa_id "
        "LEFT JOIN cari_kart c ON c.id=h.cari_id WHERE " + " AND ".join(where) +
        " ORDER BY h.tarih DESC, h.id DESC LIMIT ?",
        params + [limit],
    ).fetchall()]
    for r in rows:
        r["yon"] = islem_yonu(r["islem_tipi"])
    return rows


@route(r"/kasa", roles=())
def kasa_liste(req):
    conn = db.get_conn()
    kasalar = _kasalar(conn, izole_sube(req), db.sirket_id(req))
    for k in kasalar:
        bd = _bakiye_doviz(conn, k["id"])
        k["bakiye_doviz"] = [(pb, bd[pb]) for pb in PARA_BIRIMLERI if abs(bd.get(pb, 0.0)) >= 0.005]
        k["bakiye"] = _bakiye(conn, k["id"])
        k["giris"] = _bakiye_giris(conn, k["id"])
        k["cikis"] = _bakiye_cikis(conn, k["id"])
    toplam = sum(k["bakiye"] for k in kasalar)
    kasa_id = _i(req.q("kasa_id"))
    hareketler = _hareketler(conn, kasa_id=kasa_id, sid=db.sirket_id(req))
    conn.close()
    return render_template("kasa/liste.html", kasalar=kasalar, toplam=toplam,
                           hareketler=hareketler, filtro_kasa=kasa_id,
                           bugun=datetime.date.today().isoformat())


def _bakiye_giris(conn, kasa_id=None):
    rows = conn.execute(
        "SELECT tutar, doviz_kur FROM kasa_hareket WHERE kasa_id=? AND islem_tipi IN ('Açılış Bakiyesi','Nakit Girişi','Banka → Kasa')",
        (kasa_id,),
    ).fetchall()
    return round(sum((r["tutar"] or 0) * (r["doviz_kur"] or 1.0) for r in rows), 2)


def _bakiye_cikis(conn, kasa_id=None):
    rows = conn.execute(
        "SELECT tutar, doviz_kur FROM kasa_hareket WHERE kasa_id=? AND islem_tipi IN ('Nakit Çıkışı','Kasa → Banka')",
        (kasa_id,),
    ).fetchall()
    return round(sum((r["tutar"] or 0) * (r["doviz_kur"] or 1.0) for r in rows), 2)


@route(r"/kasa/yeni", methods=("GET", "POST"), roles=KASA_WRITE)
def kasa_yeni(req):
    conn = db.get_conn()
    if req.method == "POST":
        ad = (req.form.get("ad") or "").strip()
        kod = (req.form.get("kod") or "").strip()
        if ad:
            sid = db.sirket_id(req)
            if not kod:
                nxt = conn.execute(
                    "SELECT COALESCE(MAX(CAST(substr(kod,5) AS INTEGER)),0)+1 AS n FROM kasa WHERE sirket_id=?",
                    (sid,)).fetchone()["n"]
                kod = f"KAS-{nxt:02d}"
                while conn.execute("SELECT 1 FROM kasa WHERE sirket_id=? AND kod=?", (sid, kod)).fetchone():
                    nxt += 1
                    kod = f"KAS-{nxt:02d}"
            cur = conn.execute("INSERT INTO kasa(kod, ad, sube_id, sirket_id) VALUES(?,?,?,?)",
                               (kod, ad, izole_sube(req), sid))
            conn.commit()
            audit(req, "kasa", cur.lastrowid, "olustur", {"ad": ad, "kod": kod})
            flash(req, f"Kasa eklendi: {ad}", "ok")
        conn.close()
        return redirect("/kasa")
    conn.close()
    return render_template("kasa/form.html")


@route(r"/kasa/hareket", methods=("GET", "POST"), roles=KASA_WRITE)
def kasa_hareket(req):
    conn = db.get_conn()
    kasalar = _kasalar(conn, izole_sube(req), db.sirket_id(req))
    if req.method == "POST":
        kasa_id = _i(req.form.get("kasa_id"))
        islem_tipi = req.form.get("islem_tipi")
        tutar = _f(req.form.get("tutar"))
        tarih = req.form.get("tarih") or datetime.date.today().isoformat()
        cari_id = _i(req.form.get("cari_id"))
        banka_hesap_id = _i(req.form.get("banka_hesap_id"))
        aciklama = (req.form.get("aciklama") or "").strip()
        belge_no = (req.form.get("belge_no") or "").strip() or None
        if not kasa_id or not islem_tipi or tutar <= 0:
            flash(req, "Kasa, işlem tipi ve tutar (0'dan büyük) zorunludur.", "danger")
            conn.close()
            return redirect("/kasa/hareket")

        # İstek 3 — çapraz şirket hedef ID koruması
        if not conn.execute("SELECT id FROM kasa WHERE id=? AND sirket_id=?",
                            (kasa_id, db.sirket_id(req))).fetchone():
            conn.close()
            return Response("Bu kasa için yetkiniz yok.", "403 Forbidden")
        if cari_id and islem_tipi in CARI_TIPLERI and not conn.execute(
                "SELECT id FROM cari_kart WHERE id=? AND sirket_id=?",
                (cari_id, db.sirket_id(req))).fetchone():
            conn.close()
            flash(req, "Geçersiz cari seçimi (başka şirkete ait).", "danger")
            return redirect("/kasa/hareket")
        if banka_hesap_id and islem_tipi in TRANSFER_TIPLERI and not conn.execute(
                "SELECT id FROM banka_hesap WHERE id=? AND sirket_id=?",
                (banka_hesap_id, db.sirket_id(req))).fetchone():
            conn.close()
            flash(req, "Geçersiz banka hesabı (başka şirkete ait).", "danger")
            return redirect("/kasa/hareket")

        # K1/Faz 6 — şubeli kullanıcı yalnız kendi şubesinin kasasına işlem yazabilir.
        if izole_sube(req):
            k = conn.execute("SELECT sube_id FROM kasa WHERE id=? AND sirket_id=?",
                             (kasa_id, db.sirket_id(req))).fetchone()
            if not k or k["sube_id"] != izole_sube(req):
                conn.close()
                return Response("Bu kasa için yetkiniz yok.", "403 Forbidden")

        # K18 — döviz: yalnız cari bağlantılı işlemlerde anlamlı; transfer/açılış TRY kalır
        para_birimi = "TRY"
        doviz_kur = None
        if islem_tipi in CARI_TIPLERI:
            para_birimi = req.form.get("para_birimi") if req.form.get("para_birimi") in db.para_birimleri(sid=db.sirket_id(req)) else "TRY"
            doviz_kur = _f(req.form.get("doviz_kur"), None)
            if para_birimi == "TRY":
                doviz_kur = None
            elif not doviz_kur or doviz_kur <= 0:
                doviz_kur = db.guncel_kur(conn, para_birimi, db.sirket_id(req))

        # yetersiz bakiye kontrolü (çıkış yönlü işlemler) — K18: ilgili para biriminde
        if islem_tipi in CIKIS and _bakiye_doviz(conn, kasa_id).get(para_birimi, 0.0) < tutar:
            flash(req, f"Kasa bakiyesi bu işlem için yetersiz ({para_birimi}).", "danger")
            conn.close()
            return redirect("/kasa/hareket")

        # karşı taraf (banka) bakiyesi kontrolü — HİÇBİR kayıt yazılmadan önce (transferler TRY)
        if banka_hesap_id and islem_tipi in TRANSFER_TIPLERI:
            import banka
            if islem_tipi == "Banka → Kasa" and banka._bakiye_doviz(conn, banka_hesap_id).get("TRY", 0.0) < tutar:
                flash(req, "Banka bakiyesi bu transfer için yetersiz.", "danger")
                conn.close()
                return redirect("/kasa/hareket")

        # --- Kasa → Kasa transferi (kasalar arası, 1.18) ---
        if islem_tipi == "Kasa Transferi (Çıkış)":
            hedef_kasa_id = _i(req.form.get("hedef_kasa_id"))
            if not hedef_kasa_id or hedef_kasa_id == kasa_id:
                flash(req, "Kasa → Kasa transferinde farklı bir hedef kasa seçin.", "danger")
                conn.close()
                return redirect("/kasa/hareket")
            hedef = conn.execute("SELECT id FROM kasa WHERE id=? AND aktif=1 AND sirket_id=?",
                                 (hedef_kasa_id, db.sirket_id(req))).fetchone()
            if not hedef:
                # Atomiklik: hedef geçersizse HİÇBİR bacak yazılmaz (çıkış dahil).
                flash(req, "Hedef kasa bulunamadı.", "danger")
                conn.close()
                return redirect("/kasa/hareket")
            # Kaynak kasa (çıkış) + hedef kasa (giriş) — GM'de fiş ÜRETİLMEZ (kasa içi net sıfır).
            # Tek commit: iki bacak birlikte yazılır ya da hiç yazılmaz.
            hid = kasa_hareket_olustur(conn, kasa_id, tarih, "Kasa Transferi (Çıkış)", tutar,
                                       aciklama, belge_no, None, "Transfer", None, req.user["id"])
            kasa_hareket_olustur(conn, hedef_kasa_id, tarih, "Kasa Transferi (Giriş)", tutar,
                                 aciklama, belge_no, None, "Transfer", hid, req.user["id"])
            conn.commit()
            audit(req, "kasa_hareket", hid, "Kasa → Kasa",
                  {"kaynak": kasa_id, "hedef": hedef_kasa_id, "tutar": tutar})
            conn.close()
            flash(req, "Kasa → Kasa transferi kaydedildi.", "ok")
            return redirect("/kasa")

        fatura_id = _i(req.form.get("fatura_id"))
        ilgili_modul = "Transfer" if islem_tipi in TRANSFER_TIPLERI else "Kasa"
        ilgili_kayit_id = None
        if fatura_id and islem_tipi in CARI_TIPLERI:
            f = conn.execute("SELECT id FROM fatura WHERE id=? AND durum='Onaylandı' AND sirket_id=?",
                             (fatura_id, db.sirket_id(req))).fetchone()
            if not f:
                conn.close()
                flash(req, "Bağlı fatura bulunamadı veya onaylı değil.", "danger")
                return redirect("/kasa/hareket")
            ilgili_modul, ilgili_kayit_id = "Fatura", fatura_id
        hid = kasa_hareket_olustur(conn, kasa_id, tarih, islem_tipi, tutar,
                                   aciklama, belge_no, cari_id, ilgili_modul, ilgili_kayit_id,
                                   req.user["id"], para_birimi, doviz_kur)
        muhasebe.fis_uret(conn, "Kasa", hid)   # K26: otomatik yevmiye (transfer karşı kaydı atlanır)

        # --- Cari karşılığı (tek işlemle, manuel ikinci kayıt yok) ---
        if cari_id and islem_tipi in CARI_TIPLERI:
            tutar_tl = round(tutar * (doviz_kur or 1.0), 2)   # K18: cariye TL karşılığı
            if islem_tipi == "Nakit Girişi":
                cari.hareket_ekle(conn, cari_id, tarih, "Tahsilat", belge_no, aciklama,
                                  alacak=tutar_tl, ilgili_modul="Kasa", ilgili_kayit_id=hid,
                                  created_by=req.user["id"], para_birimi=para_birimi,
                                  doviz_kur=doviz_kur)
            else:  # Nakit Çıkışı
                cari.hareket_ekle(conn, cari_id, tarih, "Ödeme", belge_no, aciklama,
                                  borc=tutar_tl, ilgili_modul="Kasa", ilgili_kayit_id=hid,
                                  created_by=req.user["id"], para_birimi=para_birimi,
                                  doviz_kur=doviz_kur)

        # --- Banka karşılığı (transfer, opsiyonel) ---
        if banka_hesap_id and islem_tipi in TRANSFER_TIPLERI:
            import banka  # döngüyü önlemek için lazy import
            banka.banka_hareket_olustur(conn, banka_hesap_id, tarih, islem_tipi, tutar,
                                        aciklama, belge_no, ilgili_modul="Transfer",
                                        ilgili_kayit_id=hid, created_by=req.user["id"])

        conn.commit()
        audit(req, "kasa_hareket", hid, islem_tipi, {"kasa_id": kasa_id, "tutar": tutar,
                                                    "cari_id": cari_id, "banka_hesap_id": banka_hesap_id})
        conn.close()
        flash(req, "Kasa hareketi kaydedildi.", "ok")
        return redirect("/kasa")

    cariler = _cariler(conn, db.sirket_id(req))
    faturalar = _onayli_faturalar(conn, db.sirket_id(req))
    try:
        import banka
        banka_hesaplari = banka._hesaplar(conn, sid=db.sirket_id(req))
    except Exception:  # noqa: BLE001
        banka_hesaplari = []
    conn.close()
    return render_template("kasa/hareket_form.html", kasalar=kasalar, giris=GIRIS, cikis=CIKIS,
                           cariler=cariler, banka_hesaplari=banka_hesaplari,
                           faturalar=faturalar, para_birimleri=db.para_birimleri(sid=db.sirket_id(req)),
                           bugun=datetime.date.today().isoformat())


@route(r"/kasa/hareket/(?P<sid>\d+)/iptal", methods=("POST",), roles=KASA_WRITE)
def kasa_hareket_iptal(req, sid):
    """K15 — kasa hareketi iptali: varsa cari karşılığı (Tahsilat/Ödeme) da geri alınır."""
    conn = db.get_conn()
    h = conn.execute("SELECT * FROM kasa_hareket WHERE id=? AND sirket_id=?",
                     (int(sid), db.sirket_id(req))).fetchone()
    if not h:
        conn.close()
        flash(req, "Kasa hareketi bulunamadı.", "danger")
        return redirect("/kasa")
    if h["islem_tipi"] in TRANSFER_TIPLERI or h["islem_tipi"] == "Açılış Bakiyesi":
        conn.close()
        flash(req, "Transfer ve açılış bakiyesi hareketleri tek başına iptal edilemez.", "danger")
        return redirect("/kasa")
    conn.execute("DELETE FROM cari_hareket WHERE ilgili_modul='Kasa' AND ilgili_kayit_id=?",
                 (int(sid),))
    muhasebe.fis_sil(conn, "Kasa", int(sid))   # K26: fiş geri alınır
    conn.execute("DELETE FROM kasa_hareket WHERE id=?", (int(sid),))
    conn.commit()
    audit(req, "kasa_hareket", int(sid), "iptal",
          {"islem_tipi": h["islem_tipi"], "tutar": h["tutar"]})
    conn.close()
    flash(req, "Kasa hareketi iptal edildi (varsa cari karşılığı geri alındı).", "ok")
    return redirect("/kasa")


@route(r"/kasa/rapor", roles=())
def kasa_rapor(req):
    tarih = req.q("tarih") or datetime.date.today().isoformat()
    conn = db.get_conn()
    kasalar = _kasalar(conn, izole_sube(req), db.sirket_id(req))
    sonuc = []
    genel = {"acilis": 0.0, "giris": 0.0, "cikis": 0.0}
    for k in kasalar:
        acilis = _bakiye(conn, k["id"], tarih=tarih) - _bakiye_gun(conn, k["id"], tarih)
        gun_hareket = _hareketler(conn, kasa_id=k["id"], tarih=tarih, limit=500, sid=db.sirket_id(req))
        giris = sum(h["tutar"] * (h["doviz_kur"] or 1.0) for h in gun_hareket if h["yon"] > 0)
        cikis = sum(h["tutar"] * (h["doviz_kur"] or 1.0) for h in gun_hareket if h["yon"] < 0)
        kapanis = acilis + giris - cikis
        sonuc.append({"kasa": k, "acilis": acilis, "giris": giris, "cikis": cikis,
                      "kapanis": kapanis, "hareket": gun_hareket})
        genel["acilis"] += acilis
        genel["giris"] += giris
        genel["cikis"] += cikis
    genel["kapanis"] = genel["acilis"] + genel["giris"] - genel["cikis"]
    conn.close()
    return render_template("kasa/rapor.html", sonuc=sonuc, genel=genel, tarih=tarih)


def _bakiye_gun(conn, kasa_id, tarih):
    rows = conn.execute(
        "SELECT islem_tipi, tutar, doviz_kur FROM kasa_hareket WHERE kasa_id=? AND tarih=?",
        (kasa_id, tarih),
    ).fetchall()
    return sum(islem_yonu(r["islem_tipi"]) * (r["tutar"] or 0) * (r["doviz_kur"] or 1.0) for r in rows)


@route(r"/kasa/hareket/(?P<hid>\d+)/fis", roles=())
def kasa_fis(req, hid):
    conn = db.get_conn()
    h = conn.execute(
        "SELECT h.*, k.ad AS kasa_ad, k.kod AS kasa_kod, c.unvan AS cari_unvan "
        "FROM kasa_hareket h JOIN kasa k ON k.id=h.kasa_id "
        "LEFT JOIN cari_kart c ON c.id=h.cari_id WHERE h.id=? AND h.sirket_id=?",
        (int(hid), db.sirket_id(req))
    ).fetchone()
    if not h:
        conn.close()
        flash(req, "Hareket bulunamadı.", "danger")
        return redirect("/kasa")
    h = dict(h)
    h["yon"] = islem_yonu(h["islem_tipi"])
    conn.close()
    return render_template("kasa/fis.html", h=h, bugun=datetime.date.today().isoformat())


def register():
    return "kasa"
