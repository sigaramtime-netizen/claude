# -*- coding: utf-8 -*-
"""Alınan Teklif + Teklif Değerlendirme modülü (B2 — Satın Alma Yönetimi).

Akış: Taslak → Alındı → Kazanan / Elendi → (Kazanan'dan) Siparişe Dönüştü.
- K8: alinan_teklif.donusen_siparis_id → siparis.id (nullable); kazanan tekliften tek seferlik
  Satın Alma Siparişi (SAP) üretilir. Talep bağlıysa talep de Siparişe Dönüştü olur (tek dönüşüm).
- K13: teklif_no = "ALT-{YYYY}-{NNN}", şirket başına bağımsız sayaç.
- Döviz (B2 orta kapsam): para_birimi + doviz_kur saklanır; toplamlar para birimi cinsinden,
  TRY karşılığı = genel_toplam × doviz_kur (karşılaştırma + SAP'ye sabitlenerek taşınır).
- K1: sube izolasyonu; çoklu şirket (sirket_id); çapraz-şirket referans koruması.
"""
import datetime

import db
import stok
from config import PARA_BIRIMLERI
from core import route, render_template, redirect, flash, audit, notify, \
    izole_sube, sube_koruma, Response, yazdir_belge

TEKLIF_WRITE = ("Admin", "Muhasebe", "Satis", "Depo")
TEKLIF_KARAR = ("Admin", "Muhasebe")

DURUMLAR = ["Taslak", "Alındı", "Kazanan", "Elendi", "Siparişe Dönüştü"]
DURUM_BADGE = {
    "Taslak": "b-muted",
    "Alındı": "b-warn",
    "Kazanan": "b-ok",
    "Elendi": "b-danger",
    "Siparişe Dönüştü": "b-info",
}


def _f(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _i(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _tedarikciler(conn, sid=None):
    where, args = ["aktif=1 AND tip IN ('Tedarikci','HerIkisi')"], []
    if sid is not None:
        where.append("sirket_id=?")
        args.append(sid)
    return conn.execute(
        f"SELECT id, kod, unvan FROM cari_kart WHERE {' AND '.join(where)} ORDER BY unvan",
        args).fetchall()


def _depolar(conn, sid=None):
    where, args = ["1=1"], []
    if sid is not None:
        where.append("sirket_id=?")
        args.append(sid)
    return conn.execute(
        f"SELECT id, ad FROM depo WHERE {' AND '.join(where)} ORDER BY ad", args).fetchall()


def _stoklar(conn, sid=None):
    where, args = ["aktif=1"], []
    if sid is not None:
        where.append("sirket_id=?")
        args.append(sid)
    rows = conn.execute(
        f"SELECT * FROM stok_kart WHERE {' AND '.join(where)} ORDER BY ad", args).fetchall()
    return {r["id"]: dict(r) for r in rows}


def _satirlar_from_form(req):
    stok_ids = req.form_list.get("k_stok_id", [])
    varyantlar = req.form_list.get("k_varyant_id", [])
    manuel_adlar = req.form_list.get("k_manuel_ad", [])
    birimler = req.form_list.get("k_birim", [])
    miktarlar = req.form_list.get("k_miktar", [])
    bf = req.form_list.get("k_birim_fiyat", [])
    isk = req.form_list.get("k_iskonto", [])
    kdv = req.form_list.get("k_kdv", [])
    n = max(len(stok_ids), len(manuel_adlar), len(miktarlar))
    rows = []
    for i in range(n):
        sid_raw = (stok_ids[i] if i < len(stok_ids) else "").strip()
        sid = int(sid_raw) if sid_raw.isdigit() else None
        manuel_ad = (manuel_adlar[i] if i < len(manuel_adlar) else "").strip()
        rows.append({
            "stok_id": sid,
            "varyant_id": _i(varyantlar[i]) or 0 if i < len(varyantlar) else 0,
            "miktar": _f(miktarlar[i] if i < len(miktarlar) else 0, 0),
            "birim_fiyat": _f(bf[i] if i < len(bf) else 0, 0),
            "iskonto_orani": _f(isk[i] if i < len(isk) else 0, 0),
            "kdv_orani": _f(kdv[i] if i < len(kdv) else 20, 20),
            "manuel_ad": manuel_ad,
            "birim": (birimler[i] if i < len(birimler) else "").strip() or None,
        })
    return rows


def _toplamlar(rows):
    ara = isk = kdv = 0.0
    for r in rows:
        brut = (r["miktar"] or 0.0) * (r["birim_fiyat"] or 0.0)
        isk_t = brut * (r["iskonto_orani"] or 0.0) / 100.0
        net = brut - isk_t
        r["tutar"] = round(net, 2)
        ara += net
        isk += isk_t
        kdv += net * (r["kdv_orani"] or 0.0) / 100.0
    return {"ara_toplam": round(ara, 2), "iskonto_toplam": round(isk, 2),
            "kdv_toplam": round(kdv, 2), "genel_toplam": round(ara + kdv, 2)}


def _teklif_detay(conn, tid, sirket_id=None):
    where = "t.id=?"
    args = [int(tid)]
    if sirket_id is not None:
        where += " AND t.sirket_id=?"
        args.append(sirket_id)
    t = conn.execute(
        f"SELECT t.*, c.unvan AS tedarikci_unvan, c.kod AS tedarikci_kod, "
        f"d.ad AS depo_ad, sp.siparis_no AS donusen_siparis_no, "
        f"sat.talep_no AS talep_no "
        f"FROM alinan_teklif t "
        f"LEFT JOIN cari_kart c ON c.id=t.tedarikci_id "
        f"LEFT JOIN depo d ON d.id=t.depo_id "
        f"LEFT JOIN siparis sp ON sp.id=t.donusen_siparis_id "
        f"LEFT JOIN satin_alma_talebi sat ON sat.id=t.talep_id "
        f"WHERE {where}", args).fetchone()
    if not t:
        return None, []
    kalemler = conn.execute(
        "SELECT k.*, s.kod AS stok_kod, s.ad AS stok_ad FROM alinan_teklif_kalem k "
        "LEFT JOIN stok_kart s ON s.id=k.stok_id WHERE k.teklif_id=? ORDER BY k.id",
        (int(tid),)).fetchall()
    return t, kalemler


@route(r"/satin-alma/teklifler", roles=())
def teklif_liste(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    durum = req.q("durum") if req.q("durum") in DURUMLAR else ""
    talep_id = _i(req.q("talep_id"))
    q = (req.q("q") or "").strip()

    where, params = ["t.sirket_id=?"], [sid]
    if izole_sube(req):
        where.append("t.sube_id=?")
        params.append(izole_sube(req))
    if durum:
        where.append("t.durum=?")
        params.append(durum)
    if talep_id:
        where.append("t.talep_id=?")
        params.append(talep_id)
    if q:
        where.append("(t.teklif_no LIKE ? OR t.aciklama LIKE ? OR c.unvan LIKE ? OR c.kod LIKE ?)")
        like = f"%{q}%"
        params += [like, like, like, like]
    w = " AND ".join(where)

    rows = conn.execute(
        f"SELECT t.*, c.unvan AS tedarikci_unvan, c.kod AS tedarikci_kod, "
        f"sat.talep_no AS talep_no, "
        f"(SELECT COUNT(*) FROM alinan_teklif_kalem k WHERE k.teklif_id=t.id) AS kalem_sayisi, "
        f"ROUND(t.genel_toplam * COALESCE(t.doviz_kur,1), 2) AS try_toplam "
        f"FROM alinan_teklif t "
        f"LEFT JOIN cari_kart c ON c.id=t.tedarikci_id "
        f"LEFT JOIN satin_alma_talebi sat ON sat.id=t.talep_id "
        f"WHERE {w} ORDER BY t.id DESC LIMIT 200", params).fetchall()
    ozet = {d: conn.execute(
        "SELECT COUNT(*) c FROM alinan_teklif WHERE durum=? AND sirket_id=?",
        (d, sid)).fetchone()["c"] for d in DURUMLAR}
    conn.close()
    return render_template("satin_alma/teklif_liste.html", rows=rows, ozet=ozet,
                           durumlar=DURUMLAR, durum_badge=DURUM_BADGE,
                           filtro={"durum": durum, "talep_id": talep_id or "", "q": q})


@route(r"/satin-alma/teklifler/karsilastir", roles=())
def teklif_karsilastir(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    talep_id = _i(req.q("talep_id"))
    if not talep_id:
        # Talep seçici: teklif gelen talepler önce, kalanı sonra
        talepler = conn.execute(
            "SELECT sat.id, sat.talep_no, sat.gerekce, sat.durum, "
            "(SELECT COUNT(*) FROM alinan_teklif t WHERE t.talep_id=sat.id) AS teklif_sayisi "
            "FROM satin_alma_talebi sat WHERE sat.sirket_id=? "
            "ORDER BY teklif_sayisi DESC, sat.id DESC", (sid,)).fetchall()
        conn.close()
        return render_template("satin_alma/teklif_karsilastir_sec.html", talepler=talepler)
    talep = conn.execute("SELECT * FROM satin_alma_talebi WHERE id=? AND sirket_id=?",
                         (talep_id, sid)).fetchone()
    if not talep:
        conn.close()
        flash(req, "Talep bulunamadı.", "danger")
        return redirect("/satin-alma/teklifler")
    rows = conn.execute(
        "SELECT t.*, c.unvan AS tedarikci_unvan, c.kod AS tedarikci_kod, "
        "ROUND(t.genel_toplam * COALESCE(t.doviz_kur,1), 2) AS try_toplam, "
        "(SELECT ROUND(AVG(birim_fiyat),2) FROM alinan_teklif_kalem k WHERE k.teklif_id=t.id) AS ort_birim_fiyat, "
        "(SELECT SUM(miktar) FROM alinan_teklif_kalem k WHERE k.teklif_id=t.id) AS toplam_miktar "
        "FROM alinan_teklif t LEFT JOIN cari_kart c ON c.id=t.tedarikci_id "
        "WHERE t.talep_id=? AND t.sirket_id=? ORDER BY try_toplam ASC",
        (talep_id, sid)).fetchall()
    # talep için geçmiş teklifler de (bağımsız? hepsi talep bağlı — talep_id filtresi yeterli)
    conn.close()
    return render_template("satin_alma/teklif_karsilastir.html", talep=talep, rows=rows,
                           durum_badge=DURUM_BADGE)


@route(r"/satin-alma/teklifler/yeni", methods=("GET", "POST"), roles=TEKLIF_WRITE)
def teklif_yeni(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    talep_id = _i(req.q("talep_id"))
    talep = None
    if talep_id:
        talep = conn.execute("SELECT * FROM satin_alma_talebi WHERE id=? AND sirket_id=?",
                             (talep_id, sid)).fetchone()
    if req.method == "POST":
        tid, hata = _kaydet(req, conn, mevcut=None)
        if hata:
            conn.close()
            return _form_render(req, mevcut=None, satirlar=_satirlar_from_form(req),
                                hata=hata, talep=talep)
        conn.close()
        return redirect(f"/satin-alma/teklifler/{tid}")
    satirlar = []
    if talep:
        for k in conn.execute("SELECT * FROM satin_alma_talebi_kalem WHERE talep_id=? ORDER BY id",
                              (talep_id,)).fetchall():
            d = dict(k)
            d["manuel_ad"] = k["aciklama"]
            d["birim_fiyat"] = k["tahmini_fiyat"]
            d["iskonto_orani"] = 0.0
            d["kdv_orani"] = 20.0
            satirlar.append(d)
    conn.close()
    return _form_render(req, mevcut=None, satirlar=satirlar, hata=None, talep=talep)


@route(r"/satin-alma/teklifler/(?P<tid>\d+)", roles=())
def teklif_detay(req, tid):
    conn = db.get_conn()
    t, kalemler = _teklif_detay(conn, tid, db.sirket_id(req))
    conn.close()
    if not t:
        flash(req, "Teklif bulunamadı.", "danger")
        return redirect("/satin-alma/teklifler")
    rol_karar = req.user["rol"] in TEKLIF_KARAR
    try_toplam = round((t["genel_toplam"] or 0.0) * (t["doviz_kur"] or 1.0), 2)
    return render_template("satin_alma/teklif_detay.html", teklif=t, kalemler=kalemler,
                           durum_badge=DURUM_BADGE, rol_karar=rol_karar, try_toplam=try_toplam)


@route(r"/satin-alma/teklifler/(?P<tid>\d+)/yazdir", roles=())
def teklif_yazdir(req, tid):
    """D014-A2 — alınan teklif çıktısı (ortak `yazdir/belge.html`)."""
    conn = db.get_conn()
    t, kalemler = _teklif_detay(conn, tid, db.sirket_id(req))
    if not t:
        conn.close()
        flash(req, "Teklif bulunamadı.", "danger")
        return redirect("/satin-alma/teklifler")
    if not sube_koruma(req, t["sube_id"]):
        conn.close()
        return Response("Bu kayıt başka bir şubeye aittir.", "403 Forbidden")
    t = dict(t)
    t["cari_unvan"] = t.get("tedarikci_unvan") or "—"
    t["cari_kod"] = t.get("tedarikci_kod") or ""
    rows = []
    for k in kalemler:
        k = dict(k)
        k["gorunen_ad"] = k.get("stok_ad") or k.get("aciklama") or "—"
        k["varyant_ad"] = ""
        k["manuel"] = 0 if k.get("stok_id") else 1
        k["birim_goster"] = k.get("birim") or "Adet"
        rows.append(k)
    belge = yazdir_belge(t, rows, "teklif_no", "Alınan Teklif")
    conn.close()
    return render_template("yazdir/belge.html", belge=belge)


@route(r"/satin-alma/teklifler/(?P<tid>\d+)/duzenle", methods=("GET", "POST"), roles=TEKLIF_WRITE)
def teklif_duzenle(req, tid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    mevcut = conn.execute("SELECT * FROM alinan_teklif WHERE id=? AND sirket_id=?",
                          (int(tid), sid)).fetchone()
    if not mevcut:
        conn.close()
        flash(req, "Teklif bulunamadı.", "danger")
        return redirect("/satin-alma/teklifler")
    if not sube_koruma(req, mevcut["sube_id"]):
        conn.close()
        return Response("Bu kayıt başka bir şubeye aittir.", "403 Forbidden")
    if mevcut["durum"] != "Taslak":
        conn.close()
        flash(req, "Yalnızca 'Taslak' teklifler düzenlenebilir.", "danger")
        return redirect(f"/satin-alma/teklifler/{mevcut['id']}")
    if req.method == "POST":
        satirlar = _satirlar_from_form(req)
        tid2, hata = _kaydet(req, conn, mevcut=mevcut)
        if hata:
            conn.close()
            return _form_render(req, mevcut=mevcut, satirlar=satirlar, hata=hata, talep=None)
        conn.close()
        return redirect(f"/satin-alma/teklifler/{mevcut['id']}")
    kalemler = conn.execute("SELECT * FROM alinan_teklif_kalem WHERE teklif_id=? ORDER BY id",
                            (mevcut["id"],)).fetchall()
    stok_map = _stoklar(conn, sid)
    satirlar = []
    for k in kalemler:
        d = dict(k)
        sk = stok_map.get(k["stok_id"])
        d["stok_ad"] = sk["ad"] if sk else None
        d["manuel_ad"] = k["aciklama"]
        satirlar.append(d)
    conn.close()
    return _form_render(req, mevcut=mevcut, satirlar=satirlar, hata=None, talep=None)


@route(r"/satin-alma/teklifler/(?P<tid>\d+)/sil", methods=("POST",), roles=TEKLIF_WRITE)
def teklif_sil(req, tid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    t = conn.execute("SELECT * FROM alinan_teklif WHERE id=? AND sirket_id=?",
                     (int(tid), sid)).fetchone()
    if not t:
        conn.close()
        return redirect("/satin-alma/teklifler")
    if not sube_koruma(req, t["sube_id"]):
        conn.close()
        return Response("Bu kayıt başka bir şubeye aittir.", "403 Forbidden")
    if t["durum"] != "Taslak":
        conn.close()
        flash(req, "Yalnızca 'Taslak' teklifler silinebilir.", "danger")
        return redirect(f"/satin-alma/teklifler/{t['id']}")
    audit(req, "alinan_teklif", t["id"], "sil", {"teklif_no": t["teklif_no"]})
    conn.execute("DELETE FROM alinan_teklif_kalem WHERE teklif_id=?", (t["id"],))
    conn.execute("DELETE FROM alinan_teklif WHERE id=?", (t["id"],))
    conn.commit()
    conn.close()
    flash(req, "Teklif silindi.", "ok")
    return redirect("/satin-alma/teklifler")


@route(r"/satin-alma/teklifler/(?P<tid>\d+)/durum", methods=("POST",), roles=TEKLIF_WRITE)
def teklif_durum(req, tid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    t = conn.execute("SELECT * FROM alinan_teklif WHERE id=? AND sirket_id=?",
                     (int(tid), sid)).fetchone()
    if not t:
        conn.close()
        return redirect("/satin-alma/teklifler")
    if not sube_koruma(req, t["sube_id"]):
        conn.close()
        return Response("Bu kayıt başka bir şubeye aittir.", "403 Forbidden")
    hedef = (req.form.get("hedef") or "").strip()

    def _calem_var():
        return conn.execute("SELECT COUNT(*) c FROM alinan_teklif_kalem WHERE teklif_id=?",
                            (t["id"],)).fetchone()["c"] > 0

    if hedef == "alindi" and t["durum"] == "Taslak":
        if not _calem_var():
            conn.close()
            flash(req, "Kalemsiz teklif 'Alındı' yapılamaz.", "danger")
            return redirect(f"/satin-alma/teklifler/{t['id']}")
        conn.execute("UPDATE alinan_teklif SET durum='Alındı', "
                     "updated_at=datetime('now','localtime') WHERE id=?", (t["id"],))
        conn.commit()
        audit(req, "alinan_teklif", t["id"], "alindi", {"teklif_no": t["teklif_no"]})
        flash(req, "Teklif alındı olarak işaretlendi.", "ok")
    elif hedef == "geri_taslak" and t["durum"] == "Alındı":
        conn.execute("UPDATE alinan_teklif SET durum='Taslak', "
                     "updated_at=datetime('now','localtime') WHERE id=?", (t["id"],))
        conn.commit()
        audit(req, "alinan_teklif", t["id"], "geri_taslak", {"teklif_no": t["teklif_no"]})
        flash(req, "Teklif taslağa geri alındı.", "ok")
    elif hedef in ("kazanan", "ele") and t["durum"] == "Alındı":
        if req.user["rol"] not in TEKLIF_KARAR:
            conn.close()
            flash(req, "Kazanan seçme yetkiniz yok.", "danger")
            return redirect(f"/satin-alma/teklifler/{t['id']}")
        if hedef == "kazanan" and t["talep_id"]:
            # Aynı talep için başka kazanan varsa geri al (tek kazanan kuralı)
            conn.execute(
                "UPDATE alinan_teklif SET durum='Alındı', updated_at=datetime('now','localtime') "
                "WHERE talep_id=? AND durum='Kazanan' AND id!=?", (t["talep_id"], t["id"]))
        hedef_durum = {"kazanan": "Kazanan", "ele": "Elendi"}[hedef]
        conn.execute("UPDATE alinan_teklif SET durum=?, "
                     "updated_at=datetime('now','localtime') WHERE id=?", (hedef_durum, t["id"]))
        conn.commit()
        audit(req, "alinan_teklif", t["id"], hedef, {"teklif_no": t["teklif_no"]})
        notify("bilgi", "Teklif değerlendirmesi",
               f"{t['teklif_no']} nolu teklif {hedef} olarak işaretlendi.",
               "alinan_teklif", t["id"], sirket_id=sid)
        flash(req, "Teklif " + hedef + " olarak işaretlendi.", "ok")
    else:
        conn.close()
        flash(req, "Bu durum geçişine izin verilmiyor.", "danger")
        return redirect(f"/satin-alma/teklifler/{t['id']}")
    conn.close()
    return redirect(f"/satin-alma/teklifler/{t['id']}")


@route(r"/satin-alma/teklifler/(?P<tid>\d+)/siparise-donustur",
       methods=("GET", "POST"), roles=TEKLIF_KARAR)
def teklif_donustur(req, tid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    t, kalemler = _teklif_detay(conn, tid, sid)
    if not t:
        conn.close()
        flash(req, "Teklif bulunamadı.", "danger")
        return redirect("/satin-alma/teklifler")
    if not sube_koruma(req, t["sube_id"]):
        conn.close()
        return Response("Bu kayıt başka bir şubeye aittir.", "403 Forbidden")
    if t["durum"] != "Kazanan" or t["donusen_siparis_id"]:
        conn.close()
        flash(req, "Yalnızca 'Kazanan' durumundaki, dönüştürülmemiş teklifler siparişe dönüştürülebilir.",
              "danger")
        return redirect(f"/satin-alma/teklifler/{t['id']}")
    if t["talep_id"]:
        talep = conn.execute("SELECT * FROM satin_alma_talebi WHERE id=?", (t["talep_id"],)).fetchone()
        if talep and talep["donusen_siparis_id"]:
            conn.close()
            flash(req, "Bu talepten zaten bir satın alma siparişi üretilmiş.", "danger")
            return redirect(f"/satin-alma/teklifler/{t['id']}")
    if req.method == "POST":
        hata = _sap_uret(conn, req, t, kalemler)
        if hata:
            conn.close()
            flash(req, hata, "danger")
            return redirect(f"/satin-alma/teklifler/{t['id']}/siparise-donustur")
        conn.commit()
        conn.close()
        return redirect(f"/satin-alma/teklifler/{t['id']}")
    conn.close()
    return render_template("satin_alma/teklif_donustur.html", teklif=t, kalemler=kalemler)


# ---------------------------------------------------------------------------
# Yardımcılar
# ---------------------------------------------------------------------------
def _sap_uret(conn, req, teklif, kalemler):
    if not kalemler:
        return "Kalemsiz teklif siparişe dönüştürülemez."
    bugun = datetime.date.today().isoformat()
    no = db.sonraki_belge_no(conn, "siparis", "siparis_no", "SAP", bugun[:4], db.sirket_id(req))
    teslim = None
    if teklif["teslim_suresi_gun"]:
        teslim = (datetime.date.today() +
                  datetime.timedelta(days=int(teklif["teslim_suresi_gun"]))).isoformat()
    aciklama = (f"{teklif['teklif_no']} teklifinden üretildi" +
                (f" — {teklif['aciklama']}" if teklif["aciklama"] else ""))
    cur = conn.execute(
        "INSERT INTO siparis(siparis_no, tip, cari_id, depo_id, kaynak_teklif_id, tarih, "
        "teslim_tarihi, durum, para_birimi, doviz_kur, ara_toplam, iskonto_toplam, kdv_toplam, "
        "genel_toplam, aciklama, sube_id, created_by, sirket_id) "
        "VALUES(?,?,?,?,?,?,?, 'Bekliyor', ?,?,?,?,?,?,?,?,?,?)",
        (no, "Alis", teklif["tedarikci_id"], teklif["depo_id"], None, bugun, teslim,
         teklif["para_birimi"] or "TRY", teklif["doviz_kur"] or 1.0,
         teklif["ara_toplam"], teklif["iskonto_toplam"], teklif["kdv_toplam"],
         teklif["genel_toplam"], aciklama, teklif["sube_id"], req.user["id"],
         db.sirket_id(req)))
    sid = cur.lastrowid
    for k in kalemler:
        conn.execute(
            "INSERT INTO siparis_kalem(siparis_id, stok_id, varyant_id, miktar, teslim_edilen, "
            "birim_fiyat, iskonto_orani, kdv_orani, tutar, aciklama, birim, goruntu_adi, sirket_id) "
            "VALUES(?,?,?,?,0,?,?,?,?,?,?,NULL,?)",
            (sid, k["stok_id"], k["varyant_id"] or 0, k["miktar"], k["birim_fiyat"],
             k["iskonto_orani"], k["kdv_orani"], k["tutar"], k["aciklama"], k["birim"],
             db.sirket_id(req)))
    conn.execute(
        "UPDATE alinan_teklif SET durum='Siparişe Dönüştü', donusen_siparis_id=?, "
        "updated_at=datetime('now','localtime') WHERE id=?", (sid, teklif["id"]))
    if teklif["talep_id"]:
        conn.execute(
            "UPDATE satin_alma_talebi SET durum='Siparişe Dönüştü', donusen_siparis_id=?, "
            "updated_at=datetime('now','localtime') "
            "WHERE id=? AND donusen_siparis_id IS NULL",
            (sid, teklif["talep_id"]))
    conn.commit()
    audit(req, "alinan_teklif", teklif["id"], "siparise_donustur",
          {"teklif_no": teklif["teklif_no"], "siparis_no": no})
    audit(req, "siparis", sid, "olustur", {"siparis_no": no, "kaynak": teklif["teklif_no"]})
    notify("bilgi", "Tekliften satın alma siparişi üretildi",
           f"{teklif['teklif_no']} teklifinden {no} nolu satın alma siparişi üretildi.",
           "alinan_teklif", teklif["id"], sirket_id=db.sirket_id(req))
    flash(req, f"Satın alma siparişi üretildi: {no}", "ok")
    return None


def _kaydet(req, conn, mevcut):
    satirlar = _satirlar_from_form(req)
    gecerli = []
    for s in satirlar:
        if s["stok_id"] or (s["manuel_ad"] and s["manuel_ad"].strip()):
            if (s["miktar"] or 0) <= 0:
                return None, "Satır miktarları sıfırdan büyük olmalı."
            if (s["birim_fiyat"] or 0) <= 0:
                return None, "Satır birim fiyatları sıfırdan büyük olmalı."
            gecerli.append(s)
    if not gecerli:
        return None, "En az bir kalem ekleyin."

    sid = db.sirket_id(req)
    tedarikci_id = _i(req.form.get("tedarikci_id"))
    if not tedarikci_id:
        return None, "Teklif için tedarikçi seçmelisiniz."
    tedarikci = conn.execute(
        "SELECT 1 FROM cari_kart WHERE id=? AND sirket_id=? AND tip IN ('Tedarikci','HerIkisi')",
        (tedarikci_id, sid)).fetchone()
    if not tedarikci:
        return None, "Geçerli bir tedarikçi seçin."
    talep_id = _i(req.form.get("talep_id"))
    if talep_id and not conn.execute(
            "SELECT 1 FROM satin_alma_talebi WHERE id=? AND sirket_id=?", (talep_id, sid)).fetchone():
        return None, "Seçilen satın alma talebi geçersiz."
    depo_id = _i(req.form.get("depo_id"))
    tarih = req.form.get("tarih") or datetime.date.today().isoformat()
    gecerlilik = req.form.get("gecerlilik_tarihi") or None
    teslim_suresi = _i(req.form.get("teslim_suresi_gun"))
    odeme_vadesi = _i(req.form.get("odeme_vadesi_gun"))
    para_birimi = req.form.get("para_birimi") if req.form.get("para_birimi") in db.para_birimleri(sid=sid) else "TRY"
    aciklama = (req.form.get("aciklama") or "").strip() or None

    kur = _f(req.form.get("doviz_kur"), None)
    if para_birimi == "TRY":
        kur = 1.0
    elif not kur or kur <= 0:
        kur = db.guncel_kur(conn, para_birimi, sid)

    # Çapraz şirket koruması
    for s in gecerli:
        if s["stok_id"] and not conn.execute(
                "SELECT 1 FROM stok_kart WHERE id=? AND sirket_id=? AND aktif=1",
                (s["stok_id"], sid)).fetchone():
            return None, "Satırdaki bir stok kartı bu şirkete ait değil."
    if depo_id and not conn.execute("SELECT 1 FROM depo WHERE id=? AND sirket_id=?",
                                    (depo_id, sid)).fetchone():
        return None, "Seçilen depo bu şirkete ait değil."

    top = _toplamlar(gecerli)

    if mevcut:
        conn.execute(
            "UPDATE alinan_teklif SET talep_id=?, tedarikci_id=?, depo_id=?, tarih=?, "
            "gecerlilik_tarihi=?, teslim_suresi_gun=?, odeme_vadesi_gun=?, para_birimi=?, "
            "doviz_kur=?, ara_toplam=?, iskonto_toplam=?, kdv_toplam=?, genel_toplam=?, "
            "aciklama=?, updated_at=datetime('now','localtime') WHERE id=?",
            (talep_id, tedarikci_id, depo_id, tarih, gecerlilik, teslim_suresi, odeme_vadesi,
             para_birimi, kur, top["ara_toplam"], top["iskonto_toplam"], top["kdv_toplam"],
             top["genel_toplam"], aciklama, mevcut["id"]))
        conn.execute("DELETE FROM alinan_teklif_kalem WHERE teklif_id=?", (mevcut["id"],))
        tid = mevcut["id"]
        islem = ("guncelle", {"teklif_no": mevcut["teklif_no"]}, "Teklif güncellendi.")
    else:
        no = db.sonraki_belge_no(conn, "alinan_teklif", "teklif_no", "ALT",
                                 datetime.date.today().strftime("%Y"), sid)
        cur = conn.execute(
            "INSERT INTO alinan_teklif(teklif_no, talep_id, tedarikci_id, sube_id, depo_id, tarih, "
            "gecerlilik_tarihi, teslim_suresi_gun, odeme_vadesi_gun, para_birimi, doviz_kur, "
            "durum, ara_toplam, iskonto_toplam, kdv_toplam, genel_toplam, aciklama, created_by, "
            "sirket_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,'Taslak',?,?,?,?,?,?,?)",
            (no, talep_id, tedarikci_id, izole_sube(req), depo_id, tarih, gecerlilik,
             teslim_suresi, odeme_vadesi, para_birimi, kur, top["ara_toplam"],
             top["iskonto_toplam"], top["kdv_toplam"], top["genel_toplam"], aciklama,
             req.user["id"], sid))
        tid = cur.lastrowid
        islem = ("olustur", {"teklif_no": no}, f"Teklif oluşturuldu: {no}")

    stok_birim = {}
    _stok_ids = {s["stok_id"] for s in gecerli if s["stok_id"]}
    if _stok_ids:
        ph = ",".join("?" * len(_stok_ids))
        stok_birim = {r["id"]: r["birim"] for r in conn.execute(
            f"SELECT id, birim FROM stok_kart WHERE id IN ({ph})", tuple(_stok_ids)).fetchall()}
    for s in gecerli:
        birim = s.get("birim") or None
        if not birim:
            birim = (stok_birim.get(s["stok_id"]) or "Adet") if s["stok_id"] else "Adet"
        conn.execute(
            "INSERT INTO alinan_teklif_kalem(teklif_id, stok_id, varyant_id, miktar, birim, "
            "birim_fiyat, iskonto_orani, kdv_orani, tutar, aciklama, sirket_id) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (tid, s["stok_id"], s["varyant_id"] or 0, s["miktar"], birim, s["birim_fiyat"],
             s["iskonto_orani"], s["kdv_orani"], s["tutar"],
             (s["manuel_ad"] or "").strip() or None, sid))
    conn.commit()
    audit(req, "alinan_teklif", tid, islem[0], islem[1])
    flash(req, islem[2], "ok")
    return tid, None


def _form_render(req, mevcut, satirlar, hata, talep):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    ctx = {
        "mevcut": mevcut,
        "satirlar": satirlar,
        "hata": hata,
        "talep": talep,
        "tedarikciler": _tedarikciler(conn, sid),
        "depolar": _depolar(conn, sid),
        "birimler": db.birimler(sid=sid),
        "para_birimleri": db.para_birimleri(sid=sid),
        "stoklar": [dict(s) for s in _stoklar(conn, sid).values()],
        "guncel_usd": db.guncel_kur(conn, "USD", sid),
        "guncel_eur": db.guncel_kur(conn, "EUR", sid),
        "guncel_gbp": db.guncel_kur(conn, "GBP", sid),
    }
    conn.close()
    return render_template("satin_alma/teklif_form.html", **ctx)


def register():
    pass
