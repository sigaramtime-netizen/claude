# -*- coding: utf-8 -*-
"""İstek 3 — Adım 5 kanıtı: Şirket CRUD + otomatik seed + N-N üyelik (e2e).

Kapsam:
  1. Admin yeni şirket oluşturur → hesap planı (27) + demirbaş kategorileri (5) + depo (1) seed edilir.
  2. Admin şirkete N-N üye yapılır ve şirkete geçebilir.
  3. Şirket düzenleme (güncelle) çalışır.
  4. Admin olmayan kullanıcı üyeliksiz şirkete GEÇEMEZ; üyelik verilince geçebilir.
  5. Pasifleştirme: aktif şirket sayısı 1'ken pasifleştirme ENGELLENİR; diğer durumda çalışır (round-trip).
  6. Temizlik (test verisi kaldırılır).

Çalıştırma: sunucu 8080'de çalışırken  python3 test_sirket_yonetimi.py
"""
import sqlite3
import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"

KOD = "TST5"
USER = "test5user"

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else ""))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris(kadi="admin", sifre="1234"):
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": kadi, "sifre": sifre},
               allow_redirects=False)
    assert r.status_code == 302, f"giriş başarısız ({kadi})"
    return s


def aktif_sirket():
    return db1("SELECT sirket_id FROM sessionler ORDER BY rowid DESC LIMIT 1")["sirket_id"]


def main():
    admin = giris()

    # --- 0. Temizlik: önceki koşu kalıntısı ---
    eski = db1("SELECT id FROM sirket WHERE kod=?", KOD,)
    if eski:
        sid = eski["id"]
        for t, col in (("hesap", "sirket_id"), ("demirbas_kategori", "sirket_id"),
                       ("depo", "sirket_id"), ("kullanici_sirket", "sirket_id")):
            dbx(f"DELETE FROM {t} WHERE {col}=?", sid,)
        dbx("DELETE FROM sirket WHERE id=?", sid,)
    dbx("DELETE FROM kullanici_sirket WHERE kullanici_id IN (SELECT id FROM kullanici WHERE kullanici_adi=?)",
        USER)
    dbx("DELETE FROM sessionler WHERE kullanici_id IN (SELECT id FROM kullanici WHERE kullanici_adi=?)",
        USER)
    dbx("DELETE FROM kullanici WHERE kullanici_adi=?", USER,)

    # --- 1. Yeni şirket oluştur (POST /ayarlar/sirketler) ---
    r = admin.post(BASE + "/ayarlar/sirketler", data={
        "kod": KOD, "unvan": "Test Şirketi A.Ş.", "kisa_ad": "TST",
        "vergi_dairesi": "Batman VD", "vergi_no": "9990001112",
        "adres": "Test Mah.", "telefon": "0555 000 00 00", "email": "tst@example.com",
    }, allow_redirects=False)
    check("yeni şirket POST → 302", r.status_code == 302, f"status={r.status_code}")

    srow = db1("SELECT id, kod, unvan, aktif FROM sirket WHERE kod=?", KOD,)
    check("şirket kaydı oluştu", srow is not None)
    yeni_id = srow["id"] if srow else None

    # --- 2. Otomatik seed doğrulaması ---
    hesap = db("SELECT COUNT(*) c FROM hesap WHERE sirket_id=?", yeni_id,)[0]["c"] if yeni_id else 0
    kat = db("SELECT COUNT(*) c FROM demirbas_kategori WHERE sirket_id=?", yeni_id,)[0]["c"] if yeni_id else 0
    depo = db("SELECT COUNT(*) c FROM depo WHERE sirket_id=?", yeni_id,)[0]["c"] if yeni_id else 0
    check("hesap planı seed (27)", hesap == 27, f"{hesap} kayıt")
    check("demirbaş kategorileri seed (5)", kat == 5, f"{kat} kayıt")
    check("varsayılan depo seed (1)", depo == 1, f"{depo} kayıt")

    # seed idempotentliği (tekrar çağrı bozmasın)
    import db as dbmod
    conn = dbmod.get_conn()
    dbmod.sirket_seed(conn, yeni_id)
    conn.commit(); conn.close()
    hesap2 = db("SELECT COUNT(*) c FROM hesap WHERE sirket_id=?", yeni_id,)[0]["c"]
    check("seed idempotent (tekrar çağrı 27 kalır)", hesap2 == 27, f"{hesap2} kayıt")

    # --- 3. Admin N-N üyeliği + şirkete geçiş ---
    uye = db1("SELECT 1 x FROM kullanici_sirket WHERE kullanici_id=? AND sirket_id=?",
              1, yeni_id) if yeni_id else None
    check("admin yeni şirkete N-N üye", uye is not None)

    r = admin.post(BASE + "/sirket/gec", data={"sirket_id": str(yeni_id), "next": "/"},
                   allow_redirects=False)
    check("admin şirkete geçebildi", r.status_code == 302 and aktif_sirket() == yeni_id,
          f"aktif={aktif_sirket()}")

    # --- 4. Şirket sayfası + düzenleme ---
    r = admin.get(BASE + "/ayarlar/sirketler")
    check("sirketler sayfası 200 + yeni şirket listeleniyor",
          r.status_code == 200 and KOD in r.text)

    r = admin.post(BASE + f"/ayarlar/sirket/{yeni_id}/guncelle",
                   data={"unvan": "Test Şirketi A.Ş. (güncel)", "vergi_no": "9990001112"},
                   allow_redirects=False)
    g = db1("SELECT unvan FROM sirket WHERE id=?", yeni_id,)
    check("şirket güncelleme çalışıyor", r.status_code == 302 and g and "güncel" in g["unvan"])

    # --- 5. Admin olmayan kullanıcı: üyelik kuralı ---
    admin.post(BASE + "/ayarlar/kullanicilar", data={
        "kullanici_adi": USER, "ad_soyad": "Test Kullanıcı", "rol": "Depo",
        "sifre": "test12345", "sirketler": "1",
    }, allow_redirects=False)
    urow = db1("SELECT id, rol FROM kullanici WHERE kullanici_adi=?", USER,)
    check("test kullanıcı oluştu (üyelik: yalnız şirket 1)", urow is not None)
    uid = urow["id"] if urow else None
    uye1 = db1("SELECT 1 x FROM kullanici_sirket WHERE kullanici_id=? AND sirket_id=?",
               uid, 1) if uid else None
    uye2 = db1("SELECT 1 x FROM kullanici_sirket WHERE kullanici_id=? AND sirket_id=?",
               uid, yeni_id) if uid else None
    check("üyelik yalnız şirket 1 (yeni şirket YOK)", uye1 is not None and uye2 is None)

    u = giris(USER, "test12345")
    # test kullanıcı varsayılan şirketi 1'e düşmeli
    check("kullanıcı varsayılan şirketi = 1", aktif_sirket() == 1, f"aktif={aktif_sirket()}")
    r = u.post(BASE + "/sirket/gec", data={"sirket_id": str(yeni_id), "next": "/"},
               allow_redirects=False)
    check("üyeliksiz şirkete geçiş ENGELLENDİ", aktif_sirket() == 1,
          f"aktif={aktif_sirket()} (302={r.status_code})")

    # Admin üyelik verir
    admin.post(BASE + f"/ayarlar/kullanici/{uid}/sirketler",
               data={"sirketler": ["1", str(yeni_id)]}, allow_redirects=False)
    uye2b = db1("SELECT 1 x FROM kullanici_sirket WHERE kullanici_id=? AND sirket_id=?",
                uid, yeni_id)
    check("üyelik eklendi (şirket 2)", uye2b is not None)

    u = giris(USER, "test12345")
    r = u.post(BASE + "/sirket/gec", data={"sirket_id": str(yeni_id), "next": "/"},
               allow_redirects=False)
    check("üyelik sonrası şirkete geçebildi", aktif_sirket() == yeni_id,
          f"aktif={aktif_sirket()}")

    # --- 6. Pasifleştirme guard + round-trip ---
    admin = giris()
    admin.post(BASE + "/sirket/gec", data={"sirket_id": "1", "next": "/"}, allow_redirects=False)
    r = admin.post(BASE + f"/ayarlar/sirket/{yeni_id}/durum", data={}, allow_redirects=False)
    aktif_yn = db1("SELECT aktif FROM sirket WHERE id=?", yeni_id,)["aktif"]
    check("şirket pasifleştirildi (2 aktif varken)", r.status_code == 302 and aktif_yn == 0)

    r = admin.post(BASE + "/ayarlar/sirket/1/durum", data={}, allow_redirects=False)
    aktif_1 = db1("SELECT aktif FROM sirket WHERE id=1")["aktif"]
    check("son aktif şirket pasifleştirme ENGELLENDİ", aktif_1 == 1,
          f"şirket1 aktif={aktif_1}")

    r = admin.post(BASE + f"/ayarlar/sirket/{yeni_id}/durum", data={}, allow_redirects=False)
    aktif_yn2 = db1("SELECT aktif FROM sirket WHERE id=?", yeni_id,)["aktif"]
    check("şirket yeniden aktifleştirildi", aktif_yn2 == 1)

    # --- 7. Temizlik ---
    for t in ("kullanici_sirket",):
        dbx(f"DELETE FROM {t} WHERE kullanici_id=?", uid,)
    dbx("DELETE FROM sessionler WHERE kullanici_id=?", uid,)
    dbx("DELETE FROM kullanici WHERE kullanici_adi=?", USER,)
    for t, col in (("hesap", "sirket_id"), ("demirbas_kategori", "sirket_id"),
                   ("depo", "sirket_id"), ("kullanici_sirket", "sirket_id")):
        dbx(f"DELETE FROM {t} WHERE {col}=?", yeni_id,)
    dbx("DELETE FROM sirket WHERE id=?", yeni_id,)
    dbx("UPDATE sessionler SET sirket_id=1 WHERE sirket_id=?", yeni_id,)

    print(f"\nSONUÇ: {len(ok)} başarılı / {len(fail)} başarısız")
    if fail:
        print("BAŞARISIZ:", fail)
        raise SystemExit(1)
    print("ŞİRKET YÖNETİMİ (ADIM 5) TESTİ GEÇTİ ✅")


if __name__ == "__main__":
    main()
