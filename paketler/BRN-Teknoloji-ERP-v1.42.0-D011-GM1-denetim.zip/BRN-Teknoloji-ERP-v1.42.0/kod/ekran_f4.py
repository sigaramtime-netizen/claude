# -*- coding: utf-8 -*-
"""F4 — e-Dönüşüm ekran görüntüleri.

Çıktı: /home/user/indirme/f4-*.png
Çalıştırma: sunucu 8080'de çalışırken  python3 ekran_f4.py
"""
import os
import requests
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8080"
OUT = "/home/user/indirme"


def main():
    os.makedirs(OUT, exist_ok=True)
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": "admin", "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, "giriş başarısız"
    cookies = {c.name: c.value for c in s.cookies}

    with sync_playwright() as p:
        browser = p.chromium.launch()
        ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        ctx.add_cookies([{"name": k, "value": v, "url": BASE} for k, v in cookies.items()])
        page = ctx.new_page()

        shots = [
            ("/e-fatura", "f4-efatura-giden", "e-Fatura/e-Arşiv giden listesi"),
            ("/e-fatura/gelen", "f4-efatura-gelen", "e-Fatura gelen kutusu"),
            ("/e-irsaliye", "f4-eirsaliye-giden", "e-İrsaliye giden listesi"),
            ("/e-irsaliye/gelen", "f4-eirsaliye-gelen", "e-İrsaliye gelen kutusu"),
            ("/ayarlar/edonusum", "f4-ayarlar-entegrator", "e-Dönüşüm entegratör ayarları"),
        ]
        for path, name, _ in shots:
            page.goto(BASE + path, wait_until="networkidle")
            page.wait_for_timeout(500)
            page.screenshot(path=f"{OUT}/{name}.png", full_page=False)
            print("çekildi:", name)

        # e-belge detay (seed EF-2026-001)
        page.goto(BASE + "/edonusum/1", wait_until="networkidle")
        page.wait_for_timeout(500)
        page.screenshot(path=f"{OUT}/f4-ebelge-detay.png", full_page=False)
        print("çekildi: f4-ebelge-detay")

        browser.close()


if __name__ == "__main__":
    main()
