# -*- coding: utf-8 -*-
"""F2 — KDV Dahil / Hariç fiyat girişi e2e testi.

Kural: DB'de HER ZAMAN NET (KDV hariç) tutulur; KDV dahil girilen fiyat
core.kdv_ayikla ile geriye ayrıştırılır. Mizan/kar-zarar bozulmaz.

Çalıştırma: sunucu 8080'de çalışırken  python3 test_f2_kdv.py
"""
import datetime
import re
import sqlite3

import requests

import core

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
MARK = "F2TEST"

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else ""))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris():
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": "admin", "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, "giriş başarısız"
    return s


def satir(kdv_dahil, fiyat, kdv="20", stok_id="", manuel_ad="F2TEST hizmet"):
    """Tek satırlık form verisi (manuel satır — stok/rezervasyona dokunmaz)."""
    return [("k_stok_id", stok_id), ("k_varyant_id", "0"),
            ("k_manuel_ad", manuel_ad if not stok_id else ""),
            ("k_birim", "Adet"), ("k_goruntu_ad", ""),
            ("k_miktar", "1"), ("k_birim_fiyat", str(fiyat)),
            ("k_iskonto", "0"), ("k_kdv", str(kdv))] + \
           ([("kdv_dahil", "1")] if kdv_dahil else [])


def fatura_olustur(s, kdv_dahil, fiyat, kdv="20", aciklama=MARK):
    data = [("tip", "Satis"), ("cari_id", "1"), ("tarih", datetime.date.today().isoformat()),
            ("para_birimi", "TRY"), ("doviz_kur", ""), ("vade", ""),
            ("aciklama", aciklama), ("action", "kaydet")] + satir(kdv_dahil, fiyat, kdv)
    r = s.post(BASE + "/fatura/yeni", data=data, allow_redirects=False)
    loc = r.headers.get("Location") or ""
    assert "/fatura/" in loc, f"fatura oluşmadı: {r.status_code} {loc}"
    return int(loc.rstrip("/").split("/")[-1])


def temizle_fatura(fid):
    dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN "
        "(SELECT id FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?)", fid)
    dbx("DELETE FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?", fid)
    dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
    dbx("DELETE FROM audit_log WHERE tablo='fatura' AND kayit_id=?", fid)
    dbx("DELETE FROM fatura_kalem WHERE fatura_id=?", fid)
    dbx("DELETE FROM fatura WHERE id=?", fid)


def temizle_irsaliye(iid):
    dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN "
        "(SELECT id FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id=?)", iid)
    dbx("DELETE FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id=?", iid)
    dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", iid)
    dbx("DELETE FROM stok_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", iid)
    dbx("DELETE FROM audit_log WHERE tablo='irsaliye' AND kayit_id=?", iid)
    dbx("DELETE FROM irsaliye_kalem WHERE irsaliye_id=?", iid)
    dbx("DELETE FROM irsaliye WHERE id=?", iid)


def temizle_teklif(tid):
    dbx("DELETE FROM audit_log WHERE tablo='teklif' AND kayit_id=?", tid)
    dbx("DELETE FROM teklif_kalem WHERE teklif_id=?", tid)
    dbx("DELETE FROM teklif WHERE id=?", tid)


def temizle_siparis(sid):
    dbx("DELETE FROM audit_log WHERE tablo='siparis' AND kayit_id=?", sid)
    dbx("DELETE FROM siparis_kalem WHERE siparis_id=?", sid)
    dbx("DELETE FROM siparis WHERE id=?", sid)


def temizle_pos(fid):
    dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN (SELECT id FROM yevmiye WHERE "
        "(kaynak_modul='Fatura' AND kaynak_id=?) OR "
        "(kaynak_modul='Kasa' AND kaynak_id IN (SELECT id FROM kasa_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?)) OR "
        "(kaynak_modul='Banka' AND kaynak_id IN (SELECT id FROM banka_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?)))",
        fid, fid, fid)
    dbx("DELETE FROM yevmiye WHERE (kaynak_modul='Fatura' AND kaynak_id=?) OR "
        "(kaynak_modul='Kasa' AND kaynak_id IN (SELECT id FROM kasa_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?)) OR "
        "(kaynak_modul='Banka' AND kaynak_id IN (SELECT id FROM banka_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?))",
        fid, fid, fid)
    dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
    dbx("DELETE FROM kasa_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
    dbx("DELETE FROM banka_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
    dbx("DELETE FROM stok_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
    dbx("DELETE FROM audit_log WHERE tablo='pos_satis' AND kayit_id IN (SELECT id FROM pos_satis WHERE fatura_id=?)", fid)
    dbx("DELETE FROM audit_log WHERE tablo='fatura' AND kayit_id=?", fid)
    dbx("DELETE FROM pos_satis_odeme WHERE pos_satis_id IN (SELECT id FROM pos_satis WHERE fatura_id=?)", fid)
    dbx("DELETE FROM pos_satis WHERE fatura_id=?", fid)
    dbx("DELETE FROM fatura_kalem WHERE fatura_id=?", fid)
    dbx("DELETE FROM fatura WHERE id=?", fid)


def yevmiye_ozet(modul, kid):
    yv = db1("SELECT id FROM yevmiye WHERE kaynak_modul=? AND kaynak_id=?", modul, kid)
    if not yv:
        return None
    kalem = db("SELECT h.kod, ROUND(k.borc,2) b, ROUND(k.alacak,2) a "
               "FROM yevmiye_kalem k JOIN hesap h ON h.id=k.hesap_id "
               "WHERE k.yevmiye_id=? ORDER BY k.id", yv["id"])
    return [(x["kod"], x["b"], x["a"]) for x in kalem]


print("== F2 / KDV Dahil-Hariç — e2e testi ==")
s = giris()

# --- 1/2: Saf fonksiyon doğrulukları ---
check("1.1 kdv_ayikla(120,20)==100", core.kdv_ayikla(120, 20) == 100.0)
check("1.2 kdv_ayikla(118,18)==100", core.kdv_ayikla(118, 18) == 100.0)
check("1.3 kdv_ayikla(110,10)==100", core.kdv_ayikla(110, 10) == 100.0)
check("2.1 kdv_hesapla(100,20)==20", core.kdv_hesapla(100, 20) == 20.0)
check("2.2 kdv_hesapla(97.46,18)==17.54", core.kdv_hesapla(97.46, 18) == 17.54)

# --- 3: Fatura KDV DAHİL → DB net ---
fid1 = fatura_olustur(s, kdv_dahil=True, fiyat=120, kdv=20, aciklama=MARK + " dahil")
kalem = db1("SELECT birim_fiyat, tutar FROM fatura_kalem WHERE fatura_id=?", fid1)
bas = db1("SELECT ara_toplam, kdv_toplam, genel_toplam, kdv_dahil FROM fatura WHERE id=?", fid1)
check("3.1 dahil fatura kalem net=100", abs(kalem["birim_fiyat"] - 100.0) < 1e-9, str(kalem["birim_fiyat"]))
check("3.2 dahil fatura genel=120", abs(bas["genel_toplam"] - 120.0) < 1e-9, str(bas["genel_toplam"]))
check("3.3 dahil fatura kdv_dahil=1", bas["kdv_dahil"] == 1)

# --- 4: Fatura KDV HARİÇ → aynı net ---
fid2 = fatura_olustur(s, kdv_dahil=False, fiyat=100, kdv=20, aciklama=MARK + " haric")
kalem2 = db1("SELECT birim_fiyat FROM fatura_kalem WHERE fatura_id=?", fid2)
bas2 = db1("SELECT genel_toplam, kdv_dahil FROM fatura WHERE id=?", fid2)
check("4.1 hariç fatura kalem net=100", abs(kalem2["birim_fiyat"] - 100.0) < 1e-9)
check("4.2 dahil/hariç aynı net", abs(kalem["birim_fiyat"] - kalem2["birim_fiyat"]) < 1e-9)
check("4.3 hariç fatura kdv_dahil=0", bas2["kdv_dahil"] == 0)

# --- 10: Düzenlemede toggle korunuyor + net veride (Taslak iken) ---
sayfa = s.get(BASE + f"/fatura/{fid1}/duzenle").text
check("10.1 düzenlemede kdv-dahil select 'value=1 selected' (D007 madde 1)",
      'name="kdv_dahil"' in sayfa and 'value="1" selected' in sayfa)
check("10.2 satır verisi NET (100) — JS brüt gösterir", '"birim_fiyat": 100.0' in sayfa)
sayfa2 = s.get(BASE + f"/fatura/{fid2}/duzenle").text
check("10.3 hariç faturada select value=0 selected",
      'name="kdv_dahil"' in sayfa2 and 'value="0" selected' in sayfa2)

# --- 5: Mizan etkisi aynı (yevmiye) ---
s.post(BASE + f"/fatura/{fid1}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
s.post(BASE + f"/fatura/{fid2}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
y1 = yevmiye_ozet("Fatura", fid1)
y2 = yevmiye_ozet("Fatura", fid2)
check("5.1 dahil fiş = 120/600(100)/391(20)", y1 == [("120", 120.0, 0.0), ("600", 0.0, 100.0), ("391", 0.0, 20.0)], str(y1))
check("5.2 hariç fiş aynı", y1 == y2, str(y2))

# --- 6: İrsaliye KDV DAHİL (F1 ile çakışmaz) ---
data = [("tip", "Satis"), ("cari_id", "1"), ("depo_id", "1"),
        ("tarih", datetime.date.today().isoformat()), ("aciklama", MARK + " irsaliye"),
        ("action", "kaydet")] + satir(kdv_dahil=True, fiyat=120)
r = s.post(BASE + "/irsaliye/yeni", data=data, allow_redirects=False)
iid = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
ikal = db1("SELECT birim_fiyat FROM irsaliye_kalem WHERE irsaliye_id=?", iid)
ibas = db1("SELECT genel_toplam, kdv_dahil FROM irsaliye WHERE id=?", iid)
check("6.1 irsaliye kalem net=100", abs(ikal["birim_fiyat"] - 100.0) < 1e-9)
check("6.2 irsaliye genel=120", abs(ibas["genel_toplam"] - 120.0) < 1e-9)
check("6.3 irsaliye kdv_dahil=1", ibas["kdv_dahil"] == 1)
s.post(BASE + f"/irsaliye/{iid}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
ch = db1("SELECT borc FROM cari_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", iid)
iyv = yevmiye_ozet("Irsaliye", iid)
check("6.4 F1: irsaliye cari BORÇ=120", ch and abs(ch["borc"] - 120.0) < 1e-9, str(dict(ch) if ch else None))
check("6.5 F1: irsaliye fişi 120/600/391", iyv == [("120", 120.0, 0.0), ("600", 0.0, 100.0), ("391", 0.0, 20.0)], str(iyv))

# --- 7: Sipariş KDV DAHİL ---
data = [("tip", "Musteri"), ("cari_id", "1"), ("depo_id", "1"),
        ("tarih", datetime.date.today().isoformat()), ("teslim_tarihi", ""),
        ("aciklama", MARK + " siparis"), ("action", "kaydet")] + satir(kdv_dahil=True, fiyat=120)
r = s.post(BASE + "/siparis/yeni", data=data, allow_redirects=False)
sid = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
skal = db1("SELECT birim_fiyat FROM siparis_kalem WHERE siparis_id=?", sid)
sbas = db1("SELECT genel_toplam, kdv_dahil FROM siparis WHERE id=?", sid)
check("7.1 sipariş kalem net=100", abs(skal["birim_fiyat"] - 100.0) < 1e-9)
check("7.2 sipariş genel=120 + bayrak", abs(sbas["genel_toplam"] - 120.0) < 1e-9 and sbas["kdv_dahil"] == 1)

# --- 8: Teklif KDV DAHİL ---
data = [("cari_id", "1"), ("tarih", datetime.date.today().isoformat()),
        ("gecerlilik_tarihi", ""), ("aciklama", MARK + " teklif"),
        ("action", "kaydet")] + satir(kdv_dahil=True, fiyat=120)
r = s.post(BASE + "/teklif/yeni", data=data, allow_redirects=False)
tid = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
tkal = db1("SELECT birim_fiyat FROM teklif_kalem WHERE teklif_id=?", tid)
tbas = db1("SELECT genel_toplam, kdv_dahil FROM teklif WHERE id=?", tid)
check("8.1 teklif kalem net=100", abs(tkal["birim_fiyat"] - 100.0) < 1e-9)
check("8.2 teklif genel=120 + bayrak", abs(tbas["genel_toplam"] - 120.0) < 1e-9 and tbas["kdv_dahil"] == 1)

# --- 9: POS KDV DAHİL ---
data = [("terminal_id", "1"), ("cari_id", ""), ("taksit", "1"), ("vade", ""),
        ("kdv_dahil", "1"),
        ("k_stok_id", ""), ("k_varyant_id", "0"), ("k_manuel_ad", "F2TEST POS hizmet"),
        ("k_miktar", "1"), ("k_birim_fiyat", "120"), ("k_iskonto", "0"), ("k_kdv", "20"),
        ("p_tip", "Nakit"), ("p_tutar", "120"), ("p_vade", "")]
r = s.post(BASE + "/pos/satis", data=data, allow_redirects=False)
pfid = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
pkal = db1("SELECT birim_fiyat FROM fatura_kalem WHERE fatura_id=?", pfid)
pbas = db1("SELECT genel_toplam FROM fatura WHERE id=?", pfid)
check("9.1 POS fatura kalem net=100", abs(pkal["birim_fiyat"] - 100.0) < 1e-9, str(pkal["birim_fiyat"]))
check("9.2 POS fatura genel=120", abs(pbas["genel_toplam"] - 120.0) < 1e-9)

# --- 11: KDV %0 — dahil/hariç fark etmez ---
fid3 = fatura_olustur(s, kdv_dahil=True, fiyat=100, kdv=0, aciklama=MARK + " sifir-dahil")
fid4 = fatura_olustur(s, kdv_dahil=False, fiyat=100, kdv=0, aciklama=MARK + " sifir-haric")
k3 = db1("SELECT birim_fiyat FROM fatura_kalem WHERE fatura_id=?", fid3)
k4 = db1("SELECT birim_fiyat FROM fatura_kalem WHERE fatura_id=?", fid4)
check("11.1 KDV %0 dahil==hariç==100", abs(k3["birim_fiyat"] - 100.0) < 1e-9 and abs(k4["birim_fiyat"] - 100.0) < 1e-9)

# --- 12: Yuvarlama (115 brüt %18 → net 97.46 + kdv 17.54 = 115.00) ---
net = core.kdv_ayikla(115, 18)
kdv_t = core.kdv_hesapla(net, 18)
check("12.1 115 brüt %18 → net 97.46", net == 97.46, str(net))
check("12.2 kdv 17.54", kdv_t == 17.54, str(kdv_t))
check("12.3 toplam 115.00 (kuruş kaybı yok)", round(net + kdv_t, 2) == 115.00, str(round(net + kdv_t, 2)))

# --- Temizlik + bütünlük ---
for f in (fid1, fid2, fid3, fid4):
    temizle_fatura(f)
temizle_irsaliye(iid)
temizle_siparis(sid)
temizle_teklif(tid)
temizle_pos(pfid)
fk = db("PRAGMA foreign_key_check")
check("13.1 FK bütünlüğü", len(fk) == 0, str([tuple(r) for r in fk][:5]))
src = {"Fatura": "fatura", "Kasa": "kasa_hareket", "Banka": "banka_hareket",
       "CekSenet": "cek_senet", "Demirbas": "demirbas", "Irsaliye": "irsaliye"}
bad = [r["fis_no"] for r in db("SELECT fis_no, kaynak_modul, kaynak_id FROM yevmiye")
       if src.get(r["kaynak_modul"]) and not db("SELECT 1 FROM " + src[r["kaynak_modul"]] + " WHERE id=?", r["kaynak_id"])]
check("13.2 yetim yevmiye yok", len(bad) == 0, str(bad[:5]))
check("13.3 F2TEST kalıntısı yok",
      db("SELECT COUNT(*) c FROM fatura WHERE aciklama LIKE ?", MARK + "%")[0]["c"] == 0
      and db("SELECT COUNT(*) c FROM irsaliye WHERE aciklama LIKE ?", MARK + "%")[0]["c"] == 0
      and db("SELECT COUNT(*) c FROM teklif WHERE aciklama LIKE ?", MARK + "%")[0]["c"] == 0
      and db("SELECT COUNT(*) c FROM siparis WHERE aciklama LIKE ?", MARK + "%")[0]["c"] == 0)

print(f"\n=== SONUÇ: {len(ok)} başarılı / {len(fail)} başarısız ===")
if fail:
    print("BAŞARISIZ:", fail)
    raise SystemExit(1)
print("TÜM F2 KDV TESTLERİ GEÇTİ ✅")
