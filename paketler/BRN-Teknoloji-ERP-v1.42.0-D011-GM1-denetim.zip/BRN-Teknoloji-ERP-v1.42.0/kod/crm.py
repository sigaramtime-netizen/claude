# -*- coding: utf-8 -*-
"""CRM — Aktivite / Görev takibi modülü (E paketi).

- Müşteri ilişkileri aktiviteleri: Arama · Toplantı · Görev · Takip.
- Cari + sorumlu kullanıcı + tarih/saat + hatırlatma + durum (Planlandı/Tamamlandı/İptal) + öncelik.
- Hatırlatma: app.py'deki `_crm_aktivite_tarama` günü gelen hatırlatmayı bildirime çevirir
  (dashboard + bildirim merkezinde görünür); `db.bildirim_yetim_temizle` silinen aktiviteye
  işaret eden bildirimleri temizler.
- K1 şube izolasyonu (sube_id) + çoklu şirket (sirket_id) + çapraz-şirket koruması.
"""
import datetime

import db
from core import route, render_template, redirect, flash, audit, izole_sube

YAZMA = ("Admin", "Satis", "Servis")
TIPLER = ["Arama", "Toplanti", "Gorev", "Takip"]
TIP_LABEL = {"Arama": "Arama", "Toplanti": "Toplantı", "Gorev": "Görev", "Takip": "Takip"}
DURUMLAR = ["Planlandı", "Tamamlandı", "İptal"]
ONCELIKLER = ["Dusuk", "Normal", "Yuksek"]
ONCELIK_LABEL = {"Dusuk": "Düşük", "Normal": "Normal", "Yuksek": "Yüksek"}
DURUM_BADGE = {"Planlandı": "b-warn", "Tamamlandı": "b-ok", "İptal": "b-muted"}
ONCELIK_BADGE = {"Dusuk": "b-muted", "Normal": "b-info", "Yuksek": "b-danger"}
TIP_IKON = {"Arama": "📞", "Toplanti": "🤝", "Gorev": "📋", "Takip": "🔍"}


def _d(v):
    return (v or "").strip()


def _i(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def _akt(conn, sid, akt_id):
    return conn.execute(
        "SELECT a.*, c.unvan AS cari_unvan, c.kod AS cari_kod, u.kullanici_adi AS sorumlu_ad, "
        "u.ad_soyad AS sorumlu_soyad "
        "FROM crm_aktivite a LEFT JOIN cari_kart c ON c.id=a.cari_id "
        "LEFT JOIN kullanici u ON u.id=a.sorumlu_id "
        "WHERE a.id=? AND a.sirket_id=?", (int(akt_id), sid)).fetchone()


def _detay_ekle(conn, rows, bugun):
    for r in rows:
        r["gecmis"] = bool(r["durum"] == "Planlandı" and r["tarih"] and r["tarih"] < bugun)
        r["hat_gecmis"] = bool(r["hatirlatma_tarihi"] and r["hatirlatma_tarihi"] < bugun
                               and r["durum"] == "Planlandı")
    return rows


@route(r"/crm", roles=())
def crm_liste(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    q = _d(req.q("q"))
    tip = req.q("tip") or ""
    durum = req.q("durum") or ""
    where, params = ["a.sirket_id=?"], [sid]
    if q:
        where.append("(a.baslik LIKE ? OR a.aktivite_no LIKE ? OR c.unvan LIKE ?)")
        like = f"%{q}%"
        params += [like, like, like]
    if tip in TIPLER:
        where.append("a.tip=?")
        params.append(tip)
    if durum in DURUMLAR:
        where.append("a.durum=?")
        params.append(durum)
    w = " AND ".join(where)
    rows = [dict(r) for r in conn.execute(
        f"SELECT a.*, c.unvan AS cari_unvan, c.kod AS cari_kod, u.kullanici_adi AS sorumlu_ad "
        f"FROM crm_aktivite a LEFT JOIN cari_kart c ON c.id=a.cari_id "
        f"LEFT JOIN kullanici u ON u.id=a.sorumlu_id "
        f"WHERE {w} ORDER BY a.tarih DESC, a.id DESC LIMIT 300", params).fetchall()]
    bugun = datetime.date.today().isoformat()
    _detay_ekle(conn, rows, bugun)
    conn.close()
    return render_template("crm/liste.html", rows=rows, tipler=TIPLER, durumlar=DURUMLAR,
                           tip_label=TIP_LABEL, durum_badge=DURUM_BADGE,
                           oncelik_label=ONCELIK_LABEL, oncelik_badge=ONCELIK_BADGE,
                           tip_ikon=TIP_IKON, filtro={"q": q, "tip": tip, "durum": durum})


@route(r"/crm/yeni", methods=("GET", "POST"), roles=YAZMA)
def crm_yeni(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    if req.method == "POST":
        tip = req.form.get("tip") or "Gorev"
        baslik = _d(req.form.get("baslik"))
        cari_id = _i(req.form.get("cari_id"))
        sorumlu_id = _i(req.form.get("sorumlu_id"))
        tarih = _d(req.form.get("tarih"))
        hatirlatma = _d(req.form.get("hatirlatma_tarihi"))
        durum = req.form.get("durum") or "Planlandı"
        oncelik = req.form.get("oncelik") or "Normal"
        if not baslik or not tarih:
            conn.close()
            flash(req, "Başlık ve tarih zorunludur.", "danger")
            return redirect("/crm/yeni")
        if hatirlatma and hatirlatma > tarih:
            conn.close()
            flash(req, "Hatırlatma tarihi aktivite tarihinden sonra olamaz.", "danger")
            return redirect("/crm/yeni")
        if tip not in TIPLER or durum not in DURUMLAR or oncelik not in ONCELIKLER:
            conn.close()
            flash(req, "Geçersiz tip/durum/öncelik.", "danger")
            return redirect("/crm/yeni")
        if cari_id and not conn.execute("SELECT 1 FROM cari_kart WHERE id=? AND sirket_id=? AND aktif=1",
                                        (cari_id, sid)).fetchone():
            conn.close()
            flash(req, "Geçersiz müşteri.", "danger")
            return redirect("/crm/yeni")
        if sorumlu_id and not conn.execute("SELECT 1 FROM kullanici WHERE id=? AND aktif=1",
                                           (sorumlu_id,)).fetchone():
            conn.close()
            flash(req, "Geçersiz sorumlu.", "danger")
            return redirect("/crm/yeni")
        yil = datetime.date.today().year
        no = db.sonraki_belge_no(conn, "crm_aktivite", "aktivite_no", "AKT", yil, sid)
        cur = conn.execute(
            "INSERT INTO crm_aktivite(aktivite_no, tip, baslik, aciklama, cari_id, sorumlu_id, "
            "tarih, saat, hatirlatma_tarihi, hatirlatildi, durum, oncelik, sube_id, created_by, "
            "sirket_id) VALUES(?,?,?,?,?,?,?,?,?,0,?,?,?,?,?)",
            (no, tip, baslik, _d(req.form.get("aciklama")) or None, cari_id or None,
             sorumlu_id or None, tarih, _d(req.form.get("saat")) or None, hatirlatma or None,
             durum, oncelik, izole_sube(req), req.user["id"], sid))
        conn.commit()
        audit(req, "crm_aktivite", cur.lastrowid, "olustur", {"aktivite_no": no, "tip": tip})
        flash(req, f"Aktivite oluşturuldu: {no}", "ok")
        conn.close()
        return redirect(f"/crm/{cur.lastrowid}")
    cariler = conn.execute(
        "SELECT id, kod, unvan FROM cari_kart WHERE aktif=1 AND sirket_id=? ORDER BY unvan",
        (sid,)).fetchall()
    sorumlular = conn.execute(
        "SELECT id, kullanici_adi, ad_soyad FROM kullanici WHERE aktif=1 ORDER BY kullanici_adi").fetchall()
    conn.close()
    return render_template("crm/form.html", mevcut=None, cariler=cariler, sorumlular=sorumlular,
                           tipler=TIPLER, tip_label=TIP_LABEL, durumlar=DURUMLAR,
                           oncelikler=ONCELIKLER, oncelik_label=ONCELIK_LABEL,
                           bugun=datetime.date.today().isoformat())


@route(r"/crm/(?P<aid>\d+)", roles=())
def crm_detay(req, aid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    a = _akt(conn, sid, aid)
    if not a:
        conn.close()
        flash(req, "Aktivite bulunamadı.", "danger")
        return redirect("/crm")
    bugun = datetime.date.today().isoformat()
    conn.close()
    return render_template("crm/detay.html", a=a, tip_label=TIP_LABEL, durum_badge=DURUM_BADGE,
                           oncelik_label=ONCELIK_LABEL, oncelik_badge=ONCELIK_BADGE,
                           tip_ikon=TIP_IKON, bugun=bugun)


@route(r"/crm/(?P<aid>\d+)/duzenle", methods=("GET", "POST"), roles=YAZMA)
def crm_duzenle(req, aid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    a = _akt(conn, sid, aid)
    if not a:
        conn.close()
        flash(req, "Aktivite bulunamadı.", "danger")
        return redirect("/crm")
    if req.method == "POST":
        tip = req.form.get("tip") or a["tip"]
        baslik = _d(req.form.get("baslik"))
        cari_id = _i(req.form.get("cari_id"))
        sorumlu_id = _i(req.form.get("sorumlu_id"))
        tarih = _d(req.form.get("tarih"))
        hatirlatma = _d(req.form.get("hatirlatma_tarihi"))
        durum = req.form.get("durum") or a["durum"]
        oncelik = req.form.get("oncelik") or a["oncelik"]
        if not baslik or not tarih:
            conn.close()
            flash(req, "Başlık ve tarih zorunludur.", "danger")
            return redirect(f"/crm/{aid}/duzenle")
        if hatirlatma and hatirlatma > tarih:
            conn.close()
            flash(req, "Hatırlatma tarihi aktivite tarihinden sonra olamaz.", "danger")
            return redirect(f"/crm/{aid}/duzenle")
        if cari_id and not conn.execute("SELECT 1 FROM cari_kart WHERE id=? AND sirket_id=? AND aktif=1",
                                        (cari_id, sid)).fetchone():
            conn.close()
            flash(req, "Geçersiz müşteri.", "danger")
            return redirect(f"/crm/{aid}/duzenle")
        if sorumlu_id and not conn.execute("SELECT 1 FROM kullanici WHERE id=? AND aktif=1",
                                           (sorumlu_id,)).fetchone():
            conn.close()
            flash(req, "Geçersiz sorumlu.", "danger")
            return redirect(f"/crm/{aid}/duzenle")
        conn.execute(
            "UPDATE crm_aktivite SET tip=?, baslik=?, aciklama=?, cari_id=?, sorumlu_id=?, "
            "tarih=?, saat=?, hatirlatma_tarihi=?, hatirlatildi=0, durum=?, oncelik=?, "
            "updated_at=datetime('now','localtime') WHERE id=?",
            (tip, baslik, _d(req.form.get("aciklama")) or None, cari_id or None,
             sorumlu_id or None, tarih, _d(req.form.get("saat")) or None, hatirlatma or None,
             durum, oncelik, int(aid)))
        conn.commit()
        audit(req, "crm_aktivite", int(aid), "duzenle", {"aktivite_no": a["aktivite_no"]})
        flash(req, "Aktivite güncellendi.", "ok")
        conn.close()
        return redirect(f"/crm/{aid}")
    cariler = conn.execute(
        "SELECT id, kod, unvan FROM cari_kart WHERE aktif=1 AND sirket_id=? ORDER BY unvan",
        (sid,)).fetchall()
    sorumlular = conn.execute(
        "SELECT id, kullanici_adi, ad_soyad FROM kullanici WHERE aktif=1 ORDER BY kullanici_adi").fetchall()
    conn.close()
    return render_template("crm/form.html", mevcut=a, cariler=cariler, sorumlular=sorumlular,
                           tipler=TIPLER, tip_label=TIP_LABEL, durumlar=DURUMLAR,
                           oncelikler=ONCELIKLER, oncelik_label=ONCELIK_LABEL,
                           bugun=datetime.date.today().isoformat())


@route(r"/crm/(?P<aid>\d+)/durum", methods=("POST",), roles=YAZMA)
def crm_durum(req, aid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    a = _akt(conn, sid, aid)
    if not a:
        conn.close()
        flash(req, "Aktivite bulunamadı.", "danger")
        return redirect("/crm")
    yeni = "Tamamlandı" if a["durum"] != "Tamamlandı" else "Planlandı"
    conn.execute("UPDATE crm_aktivite SET durum=?, hatirlatildi=0, "
                 "updated_at=datetime('now','localtime') WHERE id=?", (yeni, int(aid)))
    conn.commit()
    audit(req, "crm_aktivite", int(aid), "durum", {"yeni": yeni})
    flash(req, f"Aktivite durumu: {yeni}", "ok")
    conn.close()
    return redirect(f"/crm/{aid}")


@route(r"/crm/(?P<aid>\d+)/iptal", methods=("POST",), roles=YAZMA)
def crm_iptal(req, aid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    a = _akt(conn, sid, aid)
    if not a:
        conn.close()
        flash(req, "Aktivite bulunamadı.", "danger")
        return redirect("/crm")
    conn.execute("UPDATE crm_aktivite SET durum='İptal', updated_at=datetime('now','localtime') "
                 "WHERE id=?", (int(aid),))
    conn.commit()
    audit(req, "crm_aktivite", int(aid), "iptal", {})
    flash(req, "Aktivite iptal edildi.", "ok")
    conn.close()
    return redirect(f"/crm/{aid}")


@route(r"/crm/(?P<aid>\d+)/sil", methods=("POST",), roles=YAZMA)
def crm_sil(req, aid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    a = _akt(conn, sid, aid)
    if not a:
        conn.close()
        flash(req, "Aktivite bulunamadı.", "danger")
        return redirect("/crm")
    db.bildirim_sil(conn, "crm_aktivite", int(aid))
    conn.execute("DELETE FROM crm_aktivite WHERE id=?", (int(aid),))
    conn.commit()
    audit(req, "crm_aktivite", int(aid), "sil", {"aktivite_no": a["aktivite_no"]})
    flash(req, "Aktivite silindi.", "ok")
    conn.close()
    return redirect("/crm")


@route(r"/crm/rapor", roles=())
def crm_rapor(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    bugun = datetime.date.today()
    yarin = (bugun + datetime.timedelta(days=1)).isoformat()
    esik3 = (bugun + datetime.timedelta(days=3)).isoformat()
    sayi = {
        "bugun": conn.execute(
            "SELECT COUNT(*) c FROM crm_aktivite WHERE sirket_id=? AND tarih=? AND durum='Planlandı'",
            (sid, bugun.isoformat())).fetchone()["c"],
        "yaklasan": conn.execute(
            "SELECT COUNT(*) c FROM crm_aktivite WHERE sirket_id=? AND durum='Planlandı' "
            "AND tarih > ? AND tarih <= ?",
            (sid, bugun.isoformat(), esik3)).fetchone()["c"],
        "gecen": conn.execute(
            "SELECT COUNT(*) c FROM crm_aktivite WHERE sirket_id=? AND durum='Planlandı' AND tarih < ?",
            (sid, bugun.isoformat())).fetchone()["c"],
        "planlanan": conn.execute(
            "SELECT COUNT(*) c FROM crm_aktivite WHERE sirket_id=? AND durum='Planlandı'",
            (sid,)).fetchone()["c"],
        "tamamlanan": conn.execute(
            "SELECT COUNT(*) c FROM crm_aktivite WHERE sirket_id=? AND durum='Tamamlandı'",
            (sid,)).fetchone()["c"],
    }
    tip_dagilim = {t: conn.execute(
        "SELECT COUNT(*) c FROM crm_aktivite WHERE sirket_id=? AND tip=?", (sid, t)).fetchone()["c"]
        for t in TIPLER}
    sorumlu_acik = [dict(r) for r in conn.execute(
        "SELECT u.ad_soyad, u.kullanici_adi, COUNT(a.id) c FROM crm_aktivite a "
        "LEFT JOIN kullanici u ON u.id=a.sorumlu_id WHERE a.sirket_id=? AND a.durum='Planlandı' "
        "GROUP BY a.sorumlu_id ORDER BY c DESC", (sid,)).fetchall()]
    # Yaklaşan aktiviteler (≤ 3 gün)
    yaklasan_liste = [dict(r) for r in conn.execute(
        "SELECT a.id, a.aktivite_no, a.tip, a.baslik, a.tarih, c.unvan AS cari_unvan "
        "FROM crm_aktivite a LEFT JOIN cari_kart c ON c.id=a.cari_id "
        "WHERE a.sirket_id=? AND a.durum='Planlandı' AND a.tarih >= ? AND a.tarih <= ? "
        "ORDER BY a.tarih LIMIT 20", (sid, yarin, esik3)).fetchall()]
    conn.close()
    return render_template("crm/rapor.html", sayi=sayi, tip_dagilim=tip_dagilim,
                           sorumlu_acik=sorumlu_acik, yaklasan_liste=yaklasan_liste,
                           tip_label=TIP_LABEL, tip_ikon=TIP_IKON)
