# -*- coding: utf-8 -*-
"""Silme/pasifleştirme kuralları testleri (İstek 2).

Çalıştırma: sunucu 8080'de çalışırken  python3 test_silme_kurallari.py
Kapsam: belge silme (Taslak/Bekliyor serbest, onaylı engelli), cari/stok koşullu silme,
transfer/sayım Taslak silme, demirbaş + servis engelleri, referans tarayıcı.
"""
import sqlite3
import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"


def q1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def db_exec(q, *a):
    c = sqlite3.connect(DB)
    cur = c.execute(q, a)
    c.commit(); c.close()
    return cur


def giris():
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": "admin", "sifre": "1234"}, allow_redirects=False)
    assert r.status_code == 302 and "erp_session" in s.cookies.get_dict()
    return s


ok = []
fail = []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else ""))


admin = giris()
musteri = q1("SELECT id FROM cari_kart WHERE aktif=1 AND tip IN ('Musteri','HerIkisi') ORDER BY id LIMIT 1")["id"]
stok = q1("SELECT id, satis_fiyat FROM stok_kart WHERE aktif=1 ORDER BY id LIMIT 1")
depo = q1("SELECT id FROM depo WHERE aktif=1 ORDER BY id LIMIT 1")["id"]

# ============ 1) Teklif ============
print("\n" + "=" * 70)
print("TEST 1 — Teklif silme + düzenleme kilidi")
print("=" * 70)
admin.post(BASE + "/teklif/yeni", data=[("cari_id", str(musteri)), ("tarih", "2026-09-08"),
    ("gecerlilik_tarihi", ""), ("aciklama", "TST-SIL-T"), ("action", "kaydet"),
    ("k_stok_id", str(stok["id"])), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
    ("k_miktar", "1"), ("k_birim_fiyat", "1000"), ("k_iskonto", "0"), ("k_kdv", "20")],
    allow_redirects=False)
tid = q1("SELECT id, teklif_no FROM teklif WHERE aciklama='TST-SIL-T' ORDER BY id DESC")["id"]
r = admin.post(BASE + f"/teklif/{tid}/sil", allow_redirects=False)
check("T1 taslak teklif silindi", q1("SELECT id FROM teklif WHERE id=?", tid) is None,
      f"status={r.status_code}")
check("T1b silme audit izi kaldı", q1("SELECT COUNT(*) c FROM audit_log WHERE tablo='teklif' AND kayit_id=? AND islem='sil'", tid)["c"] == 1)

# onaylı teklif silinemez
admin.post(BASE + "/teklif/yeni", data=[("cari_id", str(musteri)), ("tarih", "2026-09-08"),
    ("gecerlilik_tarihi", ""), ("aciklama", "TST-SIL-T2"), ("action", "kaydet"),
    ("k_stok_id", str(stok["id"])), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
    ("k_miktar", "1"), ("k_birim_fiyat", "1000"), ("k_iskonto", "0"), ("k_kdv", "20")],
    allow_redirects=False)
tid2 = q1("SELECT id FROM teklif WHERE aciklama='TST-SIL-T2' ORDER BY id DESC")["id"]
db_exec("UPDATE teklif SET durum='Onaylandı' WHERE id=?", tid2)
r = admin.post(BASE + f"/teklif/{tid2}/sil", allow_redirects=False)
check("T2 onaylı teklif silinemedi", q1("SELECT id FROM teklif WHERE id=?", tid2) is not None)
r = admin.post(BASE + f"/teklif/{tid2}/duzenle", data={"cari_id": str(musteri), "tarih": "2026-09-08", "action": "kaydet"}, allow_redirects=False)
check("T3 onaylı teklif düzenlenemedi (sunucu kilidi)",
      q1("SELECT updated_at FROM teklif WHERE id=?", tid2)["updated_at"] is None)
db_exec("DELETE FROM teklif_kalem WHERE teklif_id=?", tid2)
db_exec("DELETE FROM audit_log WHERE tablo='teklif' AND kayit_id=?", tid2)
db_exec("DELETE FROM teklif WHERE id=?", tid2)

# ============ 2) Sipariş ============
print("\n" + "=" * 70)
print("TEST 2 — Sipariş silme")
print("=" * 70)
admin.post(BASE + "/siparis/yeni", data=[("tip", "Musteri"), ("cari_id", str(musteri)),
    ("depo_id", str(depo)), ("tarih", "2026-09-08"), ("teslim_tarihi", ""),
    ("aciklama", "TST-SIL-S"), ("action", "kaydet"),
    ("k_stok_id", str(stok["id"])), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
    ("k_miktar", "1"), ("k_birim_fiyat", "1000"), ("k_iskonto", "0"), ("k_kdv", "20")],
    allow_redirects=False)
sid = q1("SELECT id FROM siparis WHERE aciklama='TST-SIL-S' ORDER BY id DESC")["id"]
admin.post(BASE + f"/siparis/{sid}/sil", allow_redirects=False)
check("S1 bekleyen sipariş silindi", q1("SELECT id FROM siparis WHERE id=?", sid) is None)

admin.post(BASE + "/siparis/yeni", data=[("tip", "Musteri"), ("cari_id", str(musteri)),
    ("depo_id", str(depo)), ("tarih", "2026-09-08"), ("teslim_tarihi", ""),
    ("aciklama", "TST-SIL-S2"), ("action", "kaydet"),
    ("k_stok_id", str(stok["id"])), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
    ("k_miktar", "1"), ("k_birim_fiyat", "1000"), ("k_iskonto", "0"), ("k_kdv", "20")],
    allow_redirects=False)
sid2 = q1("SELECT id FROM siparis WHERE aciklama='TST-SIL-S2' ORDER BY id DESC")["id"]
db_exec("UPDATE siparis SET durum='Onaylandı' WHERE id=?", sid2)
admin.post(BASE + f"/siparis/{sid2}/sil", allow_redirects=False)
check("S2 onaylı sipariş silinemedi", q1("SELECT id FROM siparis WHERE id=?", sid2) is not None)
db_exec("DELETE FROM siparis_kalem WHERE siparis_id=?", sid2)
db_exec("DELETE FROM audit_log WHERE tablo='siparis' AND kayit_id=?", sid2)
db_exec("DELETE FROM siparis WHERE id=?", sid2)

# ============ 3) İrsaliye ============
print("\n" + "=" * 70)
print("TEST 3 — İrsaliye silme")
print("=" * 70)
admin.post(BASE + "/irsaliye/yeni", data=[("tip", "Satis"), ("cari_id", str(musteri)),
    ("depo_id", str(depo)), ("tarih", "2026-09-08"), ("aciklama", "TST-SIL-I"), ("action", "kaydet"),
    ("k_stok_id", str(stok["id"])), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
    ("k_miktar", "1"), ("k_birim_fiyat", "1000"), ("k_iskonto", "0"), ("k_kdv", "20")],
    allow_redirects=False)
iid = q1("SELECT id FROM irsaliye WHERE aciklama='TST-SIL-I' ORDER BY id DESC")["id"]
admin.post(BASE + f"/irsaliye/{iid}/sil", allow_redirects=False)
check("I1 taslak irsaliye silindi", q1("SELECT id FROM irsaliye WHERE id=?", iid) is None)

admin.post(BASE + "/irsaliye/yeni", data=[("tip", "Satis"), ("cari_id", str(musteri)),
    ("depo_id", str(depo)), ("tarih", "2026-09-08"), ("aciklama", "TST-SIL-I2"), ("action", "kaydet"),
    ("k_stok_id", str(stok["id"])), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
    ("k_miktar", "1"), ("k_birim_fiyat", "1000"), ("k_iskonto", "0"), ("k_kdv", "20")],
    allow_redirects=False)
iid2 = q1("SELECT id FROM irsaliye WHERE aciklama='TST-SIL-I2' ORDER BY id DESC")["id"]
db_exec("UPDATE irsaliye SET durum='Onaylandı' WHERE id=?", iid2)
admin.post(BASE + f"/irsaliye/{iid2}/sil", allow_redirects=False)
check("I2 onaylı irsaliye silinemedi", q1("SELECT id FROM irsaliye WHERE id=?", iid2) is not None)
db_exec("DELETE FROM irsaliye_kalem WHERE irsaliye_id=?", iid2)
db_exec("DELETE FROM audit_log WHERE tablo='irsaliye' AND kayit_id=?", iid2)
db_exec("DELETE FROM irsaliye WHERE id=?", iid2)

# ============ 4) Fatura ============
print("\n" + "=" * 70)
print("TEST 4 — Fatura silme")
print("=" * 70)
admin.post(BASE + "/fatura/yeni", data=[("tip", "Satis"), ("cari_id", str(musteri)),
    ("tarih", "2026-09-08"), ("para_birimi", "TRY"), ("doviz_kur", ""), ("vade", ""),
    ("aciklama", "TST-SIL-F"), ("action", "kaydet"),
    ("k_stok_id", str(stok["id"])), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
    ("k_miktar", "1"), ("k_birim_fiyat", "1000"), ("k_iskonto", "0"), ("k_kdv", "20")],
    allow_redirects=False)
fid = q1("SELECT id FROM fatura WHERE aciklama='TST-SIL-F' ORDER BY id DESC")["id"]
admin.post(BASE + f"/fatura/{fid}/sil", allow_redirects=False)
check("F1 taslak fatura silindi", q1("SELECT id FROM fatura WHERE id=?", fid) is None)

admin.post(BASE + "/fatura/yeni", data=[("tip", "Satis"), ("cari_id", str(musteri)),
    ("tarih", "2026-09-08"), ("para_birimi", "TRY"), ("doviz_kur", ""), ("vade", ""),
    ("aciklama", "TST-SIL-F2"), ("action", "kaydet"),
    ("k_stok_id", str(stok["id"])), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
    ("k_miktar", "1"), ("k_birim_fiyat", "1000"), ("k_iskonto", "0"), ("k_kdv", "20")],
    allow_redirects=False)
fid2 = q1("SELECT id FROM fatura WHERE aciklama='TST-SIL-F2' ORDER BY id DESC")["id"]
db_exec("UPDATE fatura SET durum='Onaylandı' WHERE id=?", fid2)
admin.post(BASE + f"/fatura/{fid2}/sil", allow_redirects=False)
check("F2 onaylı fatura silinemedi", q1("SELECT id FROM fatura WHERE id=?", fid2) is not None)
db_exec("DELETE FROM fatura_kalem WHERE fatura_id=?", fid2)
db_exec("DELETE FROM audit_log WHERE tablo='fatura' AND kayit_id=?", fid2)
db_exec("DELETE FROM fatura WHERE id=?", fid2)

# ============ 5) Çek/Senet ============
print("\n" + "=" * 70)
print("TEST 5 — Çek/Senet silme")
print("=" * 70)
admin.post(BASE + "/cek_senet/yeni", data=[("no", "TST-SIL-CEK"), ("tip", "Alinan"),
    ("tur", "Cek"), ("cari_id", str(musteri)), ("banka", "X"), ("sube_ad", "Y"),
    ("tutar", "5000"), ("para_birimi", "TRY"), ("keside_tarihi", "2026-09-08"),
    ("vade", "2026-10-08"), ("aciklama", ""), ("action", "kaydet")], allow_redirects=False)
cid = q1("SELECT id FROM cek_senet WHERE no='TST-SIL-CEK' ORDER BY id DESC")["id"]
admin.post(BASE + f"/cek_senet/{cid}/sil", allow_redirects=False)
check("C1 bekleyen çek silindi", q1("SELECT id FROM cek_senet WHERE id=?", cid) is None)
check("C1b mali iz geri alındı (cari_hareket)",
      q1("SELECT COUNT(*) c FROM cari_hareket WHERE ilgili_modul='CekSenet' AND ilgili_kayit_id=?", cid)["c"] == 0)
check("C1c mali iz geri alındı (yevmiye)",
      q1("SELECT COUNT(*) c FROM yevmiye WHERE kaynak_modul='CekSenet' AND kaynak_id=?", cid)["c"] == 0)

admin.post(BASE + "/cek_senet/yeni", data=[("no", "TST-SIL-CEK2"), ("tip", "Alinan"),
    ("tur", "Cek"), ("cari_id", str(musteri)), ("banka", "X"), ("sube_ad", "Y"),
    ("tutar", "5000"), ("para_birimi", "TRY"), ("keside_tarihi", "2026-09-08"),
    ("vade", "2026-10-08"), ("aciklama", ""), ("action", "kaydet")], allow_redirects=False)
cid2 = q1("SELECT id FROM cek_senet WHERE no='TST-SIL-CEK2' ORDER BY id DESC")["id"]
db_exec("UPDATE cek_senet SET durum='Tahsil Edildi' WHERE id=?", cid2)
admin.post(BASE + f"/cek_senet/{cid2}/sil", allow_redirects=False)
check("C2 tahsil edilmiş çek silinemedi", q1("SELECT id FROM cek_senet WHERE id=?", cid2) is not None)
# test temizliği: çekin mali izi + kayıt birlikte silinir
db_exec("DELETE FROM cari_hareket WHERE ilgili_modul='CekSenet' AND ilgili_kayit_id=?", cid2)
db_exec("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN (SELECT id FROM yevmiye WHERE kaynak_modul='CekSenet' AND kaynak_id=?)", cid2)
db_exec("DELETE FROM yevmiye WHERE kaynak_modul='CekSenet' AND kaynak_id=?", cid2)
db_exec("DELETE FROM audit_log WHERE tablo='cek_senet' AND kayit_id=?", cid2)
db_exec("DELETE FROM cek_senet WHERE id=?", cid2)

# ============ 6) Cari koşullu silme ============
print("\n" + "=" * 70)
print("TEST 6 — Cari silme (tüm referanslar taranır)")
print("=" * 70)
# 6a: taslak teklife bağlı cari silinemez
admin.post(BASE + "/teklif/yeni", data=[("cari_id", str(musteri)), ("tarih", "2026-09-08"),
    ("gecerlilik_tarihi", ""), ("aciklama", "TST-SIL-CARIT"), ("action", "kaydet"),
    ("k_stok_id", str(stok["id"])), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
    ("k_miktar", "1"), ("k_birim_fiyat", "1000"), ("k_iskonto", "0"), ("k_kdv", "20")],
    allow_redirects=False)
tref = q1("SELECT id FROM teklif WHERE aciklama='TST-SIL-CARIT' ORDER BY id DESC")["id"]
r = admin.post(BASE + f"/cari/{musteri}/sil", allow_redirects=False)
check("Cari1 (taslak teklife bağlı) silinemedi", q1("SELECT id FROM cari_kart WHERE id=?", musteri) is not None)
db_exec("DELETE FROM teklif_kalem WHERE teklif_id=?", tref)
db_exec("DELETE FROM audit_log WHERE tablo='teklif' AND kayit_id=?", tref)
db_exec("DELETE FROM teklif WHERE id=?", tref)
# 6b: temiz cari silinebilir
db_exec("INSERT INTO cari_kart(unvan, kod, tip, aktif) VALUES('TST-SIL CARI','TST-SIL-99','Musteri',1)")
yeni_cari = q1("SELECT id FROM cari_kart WHERE kod='TST-SIL-99'")["id"]
admin.post(BASE + f"/cari/{yeni_cari}/sil", allow_redirects=False)
check("Cari2 (referanssız) silindi", q1("SELECT id FROM cari_kart WHERE id=?", yeni_cari) is None)

# ============ 7) Stok koşullu silme ============
print("\n" + "=" * 70)
print("TEST 7 — Stok silme")
print("=" * 70)
r = admin.post(BASE + f"/stok/{stok['id']}/sil", allow_redirects=False)
check("Stok1 (seviyeli) silinemedi", q1("SELECT id FROM stok_kart WHERE id=?", stok["id"]) is not None)
db_exec("INSERT INTO stok_kart(kod, ad, birim, kdv_orani, alis_fiyat, satis_fiyat, aktif) VALUES('TST-SIL-STK','TST Sil Stok','Adet',20,1,2,1)")
yeni_stok = q1("SELECT id FROM stok_kart WHERE kod='TST-SIL-STK'")["id"]
admin.post(BASE + f"/stok/{yeni_stok}/sil", allow_redirects=False)
check("Stok2 (referanssız) silindi", q1("SELECT id FROM stok_kart WHERE id=?", yeni_stok) is None)

# ============ 8) Transfer + Sayım Taslak silme ============
print("\n" + "=" * 70)
print("TEST 8 — Transfer ve sayım (Taslak silinebilir)")
print("=" * 70)
db_exec("INSERT INTO depo_transfer(kaynak_depo_id, hedef_depo_id, tarih, durum, aciklama) VALUES(?,?, '2026-09-08','Taslak','TST-SIL-TR')", depo, depo)
trid = q1("SELECT id FROM depo_transfer WHERE aciklama='TST-SIL-TR'")["id"]
admin.post(BASE + f"/stok/transferler/{trid}/sil", allow_redirects=False)
check("TR1 taslak transfer silindi", q1("SELECT id FROM depo_transfer WHERE id=?", trid) is None)

db_exec("INSERT INTO stok_sayim(depo_id, tarih, durum, aciklama) VALUES(?, '2026-09-08','Taslak','TST-SIL-SY')", depo)
syid = q1("SELECT id FROM stok_sayim WHERE aciklama='TST-SIL-SY'")["id"]
admin.post(BASE + f"/stok/sayim/{syid}/sil", allow_redirects=False)
check("SY1 taslak sayım silindi", q1("SELECT id FROM stok_sayim WHERE id=?", syid) is None)

# ============ 9) Demirbaş engeli ============
print("\n" + "=" * 70)
print("TEST 9 — Demirbaş: amortisman varken silme engellenir")
print("=" * 70)
db_exec("INSERT INTO demirbas(kod, ad, alis_tarihi, maliyet, durum) VALUES('TST-SIL-DMB','TST Demirbaş','2026-01-01',1000,'Aktif')")
did = q1("SELECT id FROM demirbas WHERE kod='TST-SIL-DMB'")["id"]
db_exec("INSERT INTO demirbas_amortisman(demirbas_id, donem, tutar, birikmis, net_deger) VALUES(?, '2026-02', 50, 50, 950)", did)
admin.post(BASE + f"/demirbas/{did}/sil", allow_redirects=False)
check("DMB1 amortismanlı demirbaş silinemedi", q1("SELECT id FROM demirbas WHERE id=?", did) is not None)
db_exec("DELETE FROM demirbas_amortisman WHERE demirbas_id=?", did)
db_exec("DELETE FROM demirbas WHERE id=?", did)

# ============ 10) Servis parça engeli ============
print("\n" + "=" * 70)
print("TEST 10 — Servis parça: tamamlanmış serviste silme engellenir")
print("=" * 70)
db_exec("INSERT INTO servis_kayit(servis_no, cari_id, cihaz, durum) VALUES('TST-SIL-SRV', ?, 'TV', 'Alındı')", musteri)
srid = q1("SELECT id FROM servis_kayit WHERE servis_no='TST-SIL-SRV'")["id"]
db_exec("INSERT INTO servis_parca(servis_id, stok_id, miktar, birim_fiyat, tutar) VALUES(?,?,1,10,10)", srid, stok["id"])
pid = q1("SELECT id FROM servis_parca WHERE servis_id=?", srid)["id"]
admin.post(BASE + f"/servis/parca/{pid}/sil", allow_redirects=False)
check("SRV1 açık serviste parça silindi", q1("SELECT id FROM servis_parca WHERE id=?", pid) is None)
db_exec("INSERT INTO servis_parca(servis_id, stok_id, miktar, birim_fiyat, tutar) VALUES(?,?,1,10,10)", srid, stok["id"])
pid2 = q1("SELECT id FROM servis_parca WHERE servis_id=? ORDER BY id DESC", srid)["id"]
db_exec("UPDATE servis_kayit SET durum='Tamamlandı' WHERE id=?", srid)
admin.post(BASE + f"/servis/parca/{pid2}/sil", allow_redirects=False)
check("SRV2 tamamlanmış serviste parça silinemedi", q1("SELECT id FROM servis_parca WHERE id=?", pid2) is not None)
db_exec("DELETE FROM servis_parca WHERE servis_id=?", srid)
db_exec("DELETE FROM audit_log WHERE tablo='servis_parca' AND kayit_id IN (?,?)", pid, pid2)
db_exec("DELETE FROM servis_kayit WHERE id=?", srid)

print("\n" + "=" * 70)
print(f"SONUÇ: {len(ok)} başarılı / {len(fail)} başarısız")
if fail:
    print("BAŞARISIZ:", fail)
    raise SystemExit(1)
print("TÜM SİLME TESTLERİ GEÇTİ ✅")
