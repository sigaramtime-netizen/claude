# -*- coding: utf-8 -*-
"""F4 — e-Dönüşüm (Mock/Sandbox) v1.34.0 e2e testi.

GM'in 22 senaryosu, canlı sunucuya HTTP ile. Kural: e-Dönüşüm mali etki üretmez,
sadece belgeleştirir (F1 cari/yevmiye zaten oluştu). Otomatik tip: cari.e_fatura_mukellefi
1 → e-Fatura, 0 → e-Arşiv. Gelen dönüşümü TASLAK üretir, onay kullanıcıda.

Çalıştırma: sunucu 8080'de çalışırken  python3 test_f4_edonusum.py
"""
import datetime
import sqlite3

import requests

import edonusum  # _gelen_aktar / _xml_oku için (test hazırlık verisi)

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
MARK = "F4TEST"

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print((("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else "")))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris():
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": "admin", "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, "giriş başarısız"
    return s


def aktif_sirket():
    return db1("SELECT sirket_id FROM sessionler ORDER BY rowid DESC LIMIT 1")["sirket_id"]


def gec(s, sid):
    s.post(BASE + "/sirket/gec", data={"sirket_id": str(sid), "next": "/"},
           allow_redirects=False)


def satir(stok_id, manuel="", fiyat="100", miktar="1"):
    return [("k_stok_id", stok_id), ("k_varyant_id", "0"), ("k_manuel_ad", manuel),
            ("k_birim", "Adet"), ("k_goruntu_ad", ""), ("k_miktar", miktar),
            ("k_birim_fiyat", fiyat), ("k_iskonto", "0"), ("k_kdv", "20")]


def fatura_olustur(s, tip, cari_id, aciklama, fiyat="100", kdv_dahil="0"):
    r = s.post(BASE + "/fatura/yeni",
               data=[("tip", tip), ("cari_id", str(cari_id)),
                     ("tarih", datetime.date.today().isoformat()), ("para_birimi", "TRY"),
                     ("kdv_dahil", kdv_dahil), ("aciklama", MARK + " " + aciklama),
                     ("action", "kaydet")] + satir("1", fiyat=fiyat),
               allow_redirects=False)
    loc = (r.headers.get("Location") or "")
    return int(loc.rstrip("/").split("/")[-1])


def irsaliye_olustur(s, tip, cari_id, aciklama):
    r = s.post(BASE + "/irsaliye/yeni",
               data=[("tip", tip), ("cari_id", str(cari_id)), ("depo_id", "1"),
                     ("tarih", datetime.date.today().isoformat()),
                     ("aciklama", MARK + " " + aciklama), ("action", "kaydet")]
                    + satir("3"),
               allow_redirects=False)
    loc = (r.headers.get("Location") or "")
    return int(loc.rstrip("/").split("/")[-1])


def onayla(s, modul, kid):
    s.post(BASE + f"/{modul}/{kid}/durum", data={"durum": "Onaylandı"},
           allow_redirects=False)


def set_ayar(s, entegrator="Mock", test_modu="1", anahtar=""):
    return s.post(BASE + "/ayarlar/edonusum/kaydet",
                  data={"entegrator": entegrator, "api_anahtar": anahtar,
                        "test_modu": test_modu}, allow_redirects=False)


# ---- temizlik yardımcıları (idempotent) ------------------------------------
def temizle_ebelge_ile(ekler_where, ebelge_where):
    """ek_dosya (EDonusum) + e_belge satırlarını sil."""
    ids = [r["id"] for r in db("SELECT id FROM e_belge WHERE " + ebelge_where)]
    if ids:
        dbx("DELETE FROM ek_dosya WHERE ilgili_modul='EDonusum' AND ilgili_kayit_id IN (%s)"
            % ",".join("?" * len(ids)), *ids)
        dbx("DELETE FROM e_belge WHERE id IN (%s)" % ",".join("?" * len(ids)), *ids)


def temizle_fatura(fid):
    temizle_ebelge_ile("", "kaynak_fatura_id=%d" % fid)
    dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN (SELECT id FROM yevmiye "
        "WHERE kaynak_modul='Fatura' AND kaynak_id=?)", fid)
    dbx("DELETE FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?", fid)
    dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
    dbx("DELETE FROM stok_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
    dbx("DELETE FROM audit_log WHERE tablo='fatura' AND kayit_id=?", fid)
    dbx("DELETE FROM fatura_kalem WHERE fatura_id=?", fid)
    dbx("DELETE FROM fatura WHERE id=?", fid)


def temizle_irsaliye(iid):
    temizle_ebelge_ile("", "kaynak_irsaliye_id=%d" % iid)
    dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN (SELECT id FROM yevmiye "
        "WHERE kaynak_modul='Irsaliye' AND kaynak_id=?)", iid)
    dbx("DELETE FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id=?", iid)
    dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", iid)
    dbx("DELETE FROM stok_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", iid)
    dbx("DELETE FROM audit_log WHERE tablo='irsaliye' AND kayit_id=?", iid)
    dbx("DELETE FROM irsaliye_kalem WHERE irsaliye_id=?", iid)
    dbx("DELETE FROM irsaliye WHERE id=?", iid)


def temizle_gelen(gid):
    dbx("DELETE FROM ek_dosya WHERE ilgili_modul='GelenBelge' AND ilgili_kayit_id=?", gid)
    dbx("DELETE FROM gelen_belge WHERE id=?", gid)


def gelen_bul(belge_no):
    r = db1("SELECT id, durum, donusum_fatura_id, donusum_irsaliye_id FROM gelen_belge "
            "WHERE belge_no=? AND sirket_id=1", belge_no)
    return r


# ---------------------------------------------------------------------------
print("== F4 / e-Dönüşüm (Mock/Sandbox) — e2e testi ==")
s = giris()
sid = aktif_sirket()
print("aktif sirket_id:", sid)

# --- idempotent başlangıç temizliği -----------------------------------------
for k in ("F4B",):
    dbx("DELETE FROM kullanici_sirket WHERE sirket_id IN (SELECT id FROM sirket WHERE kod=?)", k)
    dbx("DELETE FROM sirket WHERE kod=?", k)
# F4TEST kalıntıları (önceki koşulardan)
for r in db("SELECT id FROM fatura WHERE aciklama LIKE ?", MARK + "%"):
    temizle_fatura(r["id"])
for r in db("SELECT id FROM irsaliye WHERE aciklama LIKE ?", MARK + "%"):
    temizle_irsaliye(r["id"])
for r in db("SELECT id FROM e_belge WHERE belge_no LIKE ?", MARK + "%"):
    dbx("DELETE FROM ek_dosya WHERE ilgili_modul='EDonusum' AND ilgili_kayit_id=?", r["id"])
    dbx("DELETE FROM e_belge WHERE id=?", r["id"])
for r in db("SELECT id FROM gelen_belge WHERE belge_no LIKE ?", MARK + "%"):
    temizle_gelen(r["id"])
# gelen kutusunu sıfırla (seed GLN belgeleri test sonunda geri yüklenecek)
dbx("DELETE FROM ek_dosya WHERE ilgili_modul='GelenBelge'")
dbx("DELETE FROM gelen_belge")
dbx("DELETE FROM entegrator_ayar")  # varsayılan: Mock + test modu 1 (meta fallback)

mukellef = db1("SELECT id FROM cari_kart WHERE vergi_no='4810009988' AND sirket_id=1")  # Batman
degil = db1("SELECT id FROM cari_kart WHERE vergi_no='4710005566' AND sirket_id=1")      # Mardin
tedarikci = db1("SELECT id FROM cari_kart WHERE vergi_no='7310001122' AND sirket_id=1")  # Vestel

# ===========================================================================
print("=" * 70); print("BÖLÜM 1 — Otomatik e-belge üretimi (tip + taslak)")
print("=" * 70)
fa = fatura_olustur(s, "Satis", mukellef["id"], "mükellef satış")
fb = fatura_olustur(s, "Satis", degil["id"], "mükellef olmayan satış")
onayla(s, "fatura", fa)
onayla(s, "fatura", fb)
ea = db1("SELECT * FROM e_belge WHERE kaynak_fatura_id=?", fa)
eb = db1("SELECT * FROM e_belge WHERE kaynak_fatura_id=?", fb)
check("1. test_cari_mukellef_ayari: mükellef→eFatura, değil→eArsiv (otomatik)",
      ea is not None and eb is not None
      and ea["tur"] == "EFatura" and eb["tur"] == "EArsiv",
      f"ea={ea['tur'] if ea else None}, eb={eb['tur'] if eb else None}")
check("2. test_fatura_onay_otomatik_ebeveyn: Satış onayı → e_belge Taslak + tip doğru",
      ea is not None and ea["durum"] == "Taslak" and ea["tur"] == "EFatura"
      and ea["belge_no"].startswith("EF"),
      f"{ea['belge_no'] if ea else None} / {ea['durum'] if ea else None}")

# ===========================================================================
print("=" * 70); print("BÖLÜM 2 — e-İrsaliye otomatik üretim")
print("=" * 70)
iid = irsaliye_olustur(s, "Satis", mukellef["id"], "satış irsaliyesi")
onayla(s, "irsaliye", iid)
ei = db1("SELECT * FROM e_belge WHERE kaynak_irsaliye_id=?", iid)
check("3. test_irsaliye_onay_otomatik_eirsaliye: Satış irsaliyesi onayı → EIrsaliye Taslak",
      ei is not None and ei["tur"] == "EIrsaliye" and ei["durum"] == "Taslak",
      f"{ei['belge_no'] if ei else None} / {ei['tur'] if ei else None}")

# ===========================================================================
print("=" * 70); print("BÖLÜM 3 — Gönderim + durum makinesi")
print("=" * 70)
# 4: test modu 1 (varsayılan) → gönder → anında Onaylandı
r = s.post(BASE + f"/e-fatura/{ea['id']}/gonder", data={}, allow_redirects=False)
ea2 = db1("SELECT durum, ettn, gonderim_tarihi FROM e_belge WHERE id=?", ea["id"])
check("4. test_gonder_mock_onay: test modu 1 → Gönderildi→Onaylandı + ETN",
      r.status_code == 302 and ea2["durum"] == "Onaylandı" and ea2["ettn"],
      f"durum={ea2['durum']}, ettn={ea2['ettn']}")

# 5: test modu 0 → Gönderildi; mock red → Reddedildi; tekrar gönderilebilir
set_ayar(s, "Mock", "0")
fc = fatura_olustur(s, "Satis", mukellef["id"], "red yolu")
onayla(s, "fatura", fc)
ec = db1("SELECT * FROM e_belge WHERE kaynak_fatura_id=?", fc)
s.post(BASE + f"/e-fatura/{ec['id']}/gonder", data={}, allow_redirects=False)
ec1 = db1("SELECT durum FROM e_belge WHERE id=?", ec["id"])
s.post(BASE + f"/edonusum/{ec['id']}/mock-yanit", data={"yanit": "Reddedildi"},
       allow_redirects=False)
ec2 = db1("SELECT durum FROM e_belge WHERE id=?", ec["id"])
set_ayar(s, "Mock", "1")
s.post(BASE + f"/e-fatura/{ec['id']}/gonder", data={}, allow_redirects=False)
ec3 = db1("SELECT durum FROM e_belge WHERE id=?", ec["id"])
check("5. test_gonder_red_yolu: test_modu 0 → Gönderildi; red → Reddedildi; tekrar gönder → Onaylandı",
      ec1["durum"] == "Gönderildi" and ec2["durum"] == "Reddedildi"
      and ec3["durum"] == "Onaylandı",
      f"{ec1['durum']} → {ec2['durum']} → {ec3['durum']}")

# 6: çifte e-belge engeli
r = s.post(BASE + "/edonusum/olustur", data={"kaynak_tablo": "fatura", "kaynak_id": str(fa)},
           allow_redirects=False)
n = db1("SELECT COUNT(*) c FROM e_belge WHERE kaynak_fatura_id=? AND durum!='İptal'", fa)
check("6. test_cifte_ebeveyn_engeli: aynı fatura 2. kez e_belge üretemez",
      r.status_code == 302 and n["c"] == 1, f"e_belge sayısı={n['c']}")

# ===========================================================================
print("=" * 70); print("BÖLÜM 4 — Gelen kutusu")
print("=" * 70)
r = s.post(BASE + "/e-fatura/gelen/cek", data={}, allow_redirects=False)
n_ef = db1("SELECT COUNT(*) c FROM gelen_belge WHERE tur='EFatura' AND sirket_id=1")
check("7. test_gelen_cek_mock: /e-fatura/gelen/cek → en az 1 e-Fatura geldi",
      r.status_code == 302 and n_ef["c"] >= 1, f"{n_ef['c']} belge")

# K1: Şirket B
dbx("INSERT INTO sirket(kod, unvan, aktif) VALUES('F4B','F4 İzolasyon Şirketi B',1)")
s_b = db1("SELECT id FROM sirket WHERE kod='F4B'")["id"]
dbx("INSERT OR IGNORE INTO kullanici_sirket(kullanici_id, sirket_id) VALUES(1,?)", s_b)
rA = s.get(BASE + "/e-fatura/gelen").text
gec(s, s_b)
rB = s.get(BASE + "/e-fatura/gelen").text
gec(s, 1)
check("8. test_gelen_liste_k1: Şirket B'de A'nın geleni görünmez",
      "GLN-FAT-2026-0001" in rA and "GLN-FAT-2026-0001" not in rB)

# 9: Kabul
g_ef = gelen_bul("GLN-FAT-2026-0001")
s.post(BASE + f"/e-fatura/gelen/{g_ef['id']}/kabul", data={}, allow_redirects=False)
check("9. test_gelen_kabul: gelen e-Fatura Kabul",
      gelen_bul("GLN-FAT-2026-0001")["durum"] == "Kabul")

# 10: Red (özel belge)
belge_red = {"belge_no": MARK + "-GLN-RED-0001", "tur": "EFatura",
             "gonderen_vkn": "7310002233", "gonderen_unvan": "Arçelik Pazarlama A.Ş.",
             "alici_vkn": "4810009988", "belge_tarih": "2026-09-06",
             "tutar": 100.0, "kdv": 20.0, "para_birimi": "TRY",
             "aciklama": "red testi",
             "xml": ('<Invoice><InvoiceLine><SellersItemIdentification><ID>CM-9KG-ARC-004</ID>'
                     '</SellersItemIdentification><Item><Name>Arçelik 9kg</Name></Item>'
                     '<InvoicedQuantity>1</InvoicedQuantity><Price><PriceAmount>100</PriceAmount>'
                     '</Price><ClassifiedTaxCategory><Percent>20</Percent></ClassifiedTaxCategory>'
                     '</InvoiceLine></Invoice>')}
gred_id, _ = edonusum._gelen_aktar(belge_red, 1)
s.post(BASE + f"/e-fatura/gelen/{gred_id}/red", data={}, allow_redirects=False)
check("10. test_gelen_red: gelen belge Red",
      db1("SELECT durum FROM gelen_belge WHERE id=?", gred_id)["durum"] == "Red")

# ===========================================================================
print("=" * 70); print("BÖLÜM 5 — Gelen dönüşümü (Alış Faturası / İrsaliyesi)")
print("=" * 70)
# 11: e-Fatura → Alış Faturası taslağı
g_ef = gelen_bul("GLN-FAT-2026-0001")
r = s.post(BASE + f"/e-fatura/gelen/{g_ef['id']}/donustur", data={}, allow_redirects=False)
af = db1("SELECT id, tip, durum, cari_id, fatura_no FROM fatura WHERE aciklama LIKE ?",
         "%GLN-FAT-2026-0001%")
kalemler = db("SELECT stok_id FROM fatura_kalem WHERE fatura_id=?", af["id"]) if af else []
check("11. test_gelen_donustur_fatura: e-Fatura → Alış Faturası TASLAK + kalemler eşleşti",
      af is not None and af["tip"] == "Alis" and af["durum"] == "Taslak"
      and af["cari_id"] == db1("SELECT id FROM cari_kart WHERE vergi_no='7310002233' AND sirket_id=1")["id"]
      and len(kalemler) == 2 and all(k["stok_id"] for k in kalemler),
      f"{af['fatura_no'] if af else None} kalem={[k['stok_id'] for k in kalemler]}")

# 12: e-İrsaliye → Alış İrsaliyesi (önce /gelen/yenile ile irsaliyeyi çek)
s.post(BASE + "/gelen/yenile", data={}, allow_redirects=False)
g_ir = gelen_bul("GLN-IRS-2026-0001")
r = s.post(BASE + f"/e-irsaliye/gelen/{g_ir['id']}/donustur", data={}, allow_redirects=False)
ai = db1("SELECT id, tip, durum, cari_id, irsaliye_no FROM irsaliye WHERE aciklama LIKE ?",
         "%GLN-IRS-2026-0001%")
ik = db("SELECT stok_id FROM irsaliye_kalem WHERE irsaliye_id=?", ai["id"]) if ai else []
check("12. test_gelen_donustur_irsaliye: e-İrsaliye → Alış İrsaliyesi TASLAK",
      ai is not None and ai["tip"] == "Alis" and ai["durum"] == "Taslak"
      and ai["cari_id"] == db1("SELECT id FROM cari_kart WHERE vergi_no='7310001122' AND sirket_id=1")["id"]
      and len(ik) == 2 and all(k["stok_id"] for k in ik),
      f"{ai['irsaliye_no'] if ai else None} kalem={[k['stok_id'] for k in ik]}")

# 13: çifte dönüşüm engeli
once = db1("SELECT COUNT(*) c FROM fatura WHERE aciklama LIKE ?", "%GLN-FAT-2026-0001%")["c"]
s.post(BASE + f"/e-fatura/gelen/{g_ef['id']}/donustur", data={}, allow_redirects=False)
sonra = db1("SELECT COUNT(*) c FROM fatura WHERE aciklama LIKE ?", "%GLN-FAT-2026-0001%")["c"]
check("13. test_gelen_cifte_donusum_engeli: aynı gelen 2. kez dönüştürülemez",
      sonra == once == 1, f"fatura sayısı {once}→{sonra}")

# 14: eşleşmeyen kalem → manuel satır
belge_man = {"belge_no": MARK + "-GLN-MAN-0001", "tur": "EFatura",
             "gonderen_vkn": "7310002233", "gonderen_unvan": "Arçelik Pazarlama A.Ş.",
             "alici_vkn": "4810009988", "belge_tarih": "2026-09-06",
             "tutar": 250.0, "kdv": 50.0, "para_birimi": "TRY",
             "aciklama": "manuel kalem testi",
             "xml": ('<Invoice>'
                     '<InvoiceLine><SellersItemIdentification><ID>CM-9KG-ARC-004</ID>'
                     '</SellersItemIdentification><Item><Name>Arçelik 9kg</Name></Item>'
                     '<InvoicedQuantity>1</InvoicedQuantity><Price><PriceAmount>100</PriceAmount>'
                     '</Price><ClassifiedTaxCategory><Percent>20</Percent></ClassifiedTaxCategory>'
                     '</InvoiceLine>'
                     '<InvoiceLine><SellersItemIdentification><ID>XXX-BILINMEYEN-999</ID>'
                     '</SellersItemIdentification><Item><Name>Bilinmeyen Parça</Name></Item>'
                     '<InvoicedQuantity>1</InvoicedQuantity><Price><PriceAmount>150</PriceAmount>'
                     '</Price><ClassifiedTaxCategory><Percent>20</Percent></ClassifiedTaxCategory>'
                     '</InvoiceLine></Invoice>')}
gman_id, _ = edonusum._gelen_aktar(belge_man, 1)
s.post(BASE + f"/e-fatura/gelen/{gman_id}/donustur", data={}, allow_redirects=False)
afm = db1("SELECT id FROM fatura WHERE aciklama LIKE ?", "%" + MARK + "-GLN-MAN-0001%")
km = db("SELECT stok_id, aciklama FROM fatura_kalem WHERE fatura_id=? ORDER BY id",
        afm["id"]) if afm else []
man_satir = [k for k in km if k["stok_id"] is None]
check("14. test_gelen_manuel_kalem: eşleşmeyen kalem manuel satır (stok_id NULL + aciklama)",
      afm is not None and len(km) == 2 and len(man_satir) == 1
      and "XXX-BILINMEYEN-999" in (man_satir[0]["aciklama"] or ""),
      f"kalem={[(k['stok_id'], (k['aciklama'] or '')[:20]) for k in km]}")

# ===========================================================================
print("=" * 70); print("BÖLÜM 6 — Kapsam/altın kural kontrolleri")
print("=" * 70)
# 15: Alış faturası e-belge üretmez
falis = fatura_olustur(s, "Alis", tedarikci["id"], "alış fatura")
onayla(s, "fatura", falis)
ealis = db1("SELECT id FROM e_belge WHERE kaynak_fatura_id=?", falis)
check("15. test_alis_faturasi_ebeveyn_yok: Alış faturası e-Fatura oluşturmaz",
      ealis is None)

# 16: entegratör ayar kaydı (K1)
r = set_ayar(s, "EDM", "1", "key-123456")
ayar = db1("SELECT * FROM entegrator_ayar WHERE sirket_id=1")
check("16. test_entegrator_ayar_kayit: Mock → EDM + api_anahtar, K1 (sirket_id PK)",
      r.status_code == 302 and ayar is not None and ayar["entegrator"] == "EDM"
      and ayar["api_anahtar"] == "key-123456" and ayar["sirket_id"] == 1,
      f"{dict(ayar) if ayar else None}")

# 17: Mock hint
set_ayar(s, "Mock", "1")
html = s.get(BASE + "/ayarlar/edonusum").text
check("17. test_entegrator_mock_uyari: Mock seçiliyken simülasyon hint'i görünüyor",
      "Mock" in html and ("sandbox" in html.lower() or "simülasyon" in html.lower()
                          or "bağlanmaz" in html.lower()))

# 18: mali etki korunumu
c0 = db1("SELECT COUNT(*) c FROM cari_hareket")["c"]
y0 = db1("SELECT COUNT(*) c FROM yevmiye")["c"]
fd = fatura_olustur(s, "Satis", mukellef["id"], "mali etki")
onayla(s, "fatura", fd)
c1 = db1("SELECT COUNT(*) c FROM cari_hareket")["c"]
y1 = db1("SELECT COUNT(*) c FROM yevmiye")["c"]
ed = db1("SELECT id FROM e_belge WHERE kaynak_fatura_id=?", fd)
s.post(BASE + f"/e-fatura/{ed['id']}/gonder", data={}, allow_redirects=False)
c2 = db1("SELECT COUNT(*) c FROM cari_hareket")["c"]
y2 = db1("SELECT COUNT(*) c FROM yevmiye")["c"]
check("18. test_f1_mali_etki_korundu: e-Fatura Gönder → cari/yevmiye artmadı",
      c1 > c0 and y1 > y0 and c2 == c1 and y2 == y1,
      f"cari {c0}→{c1}→{c2}, yevmiye {y0}→{y1}→{y2}")

# 19: F2 KDV (net kayıt) XML'e doğru yansır
fk = fatura_olustur(s, "Satis", mukellef["id"], "kdv dahil", fiyat="120", kdv_dahil="1")
onayla(s, "fatura", fk)
fk_row = db1("SELECT * FROM fatura WHERE id=?", fk)
ek = db1("SELECT id FROM e_belge WHERE kaynak_fatura_id=?", fk)
_conn = sqlite3.connect(DB); _conn.row_factory = sqlite3.Row
xml = edonusum._xml_oku(_conn, "EDonusum", ek["id"]) if ek else None
_conn.close()
kdv_ok = abs(fk_row["kdv_toplam"] - round((fk_row["ara_toplam"] or 0) * 0.2, 2)) < 0.001
check("19. test_f2_kdv_korundu: KDV dahil → net kayıt + XML'de net doğru",
      fk_row is not None and round(fk_row["ara_toplam"], 2) == 100.0
      and kdv_ok and xml is not None
      and f"<LineExtensionAmount>{fk_row['ara_toplam']}" in xml,
      f"ara={fk_row['ara_toplam']}, kdv={fk_row['kdv_toplam']}, genel={fk_row['genel_toplam']}")

# 20: F3 typeahead regresyonu
r_ara = s.get(BASE + "/api/ara", params={"tip": "stok", "q": "BUZ-510-VST-003"})
data = r_ara.json() if r_ara.status_code == 200 else []
check("20. test_f3_typeahead_korundu: /api/ara hâlâ çalışıyor",
      r_ara.status_code == 200 and data and data[0]["kod"] == "BUZ-510-VST-003",
      str(data[:1]))

# ===========================================================================
print("=" * 70); print("TEMİZLİK + BÜTÜNLÜK")
print("=" * 70)
# F4TEST belgeleri ve türevlerini temizle
for r in db("SELECT id FROM fatura WHERE aciklama LIKE ? OR aciklama LIKE ? OR aciklama LIKE ?",
            MARK + "%", "%GLN-FAT-2026-0001%", "%" + MARK + "-GLN-MAN-0001%"):
    temizle_fatura(r["id"])
for r in db("SELECT id FROM irsaliye WHERE aciklama LIKE ? OR aciklama LIKE ?",
            MARK + "%", "%GLN-IRS-2026-0001%"):
    temizle_irsaliye(r["id"])
for r in db("SELECT id FROM gelen_belge WHERE belge_no LIKE ? OR belge_no LIKE 'GLN-%'",
            MARK + "%"):
    temizle_gelen(r["id"])
dbx("DELETE FROM ek_dosya WHERE ilgili_modul='GelenBelge'")
dbx("DELETE FROM gelen_belge WHERE belge_no LIKE 'GLN-%'")
# entegrator_ayar'ı varsayılana döndür (Mock, test modu 1)
dbx("DELETE FROM entegrator_ayar")
set_ayar(s, "Mock", "1")
# seed gelen kutusunu geri yükle (mock entegratörden)
import entegrator as ent_mod
for b in ent_mod.MockEntegrator(test_modu=True).gelen_kutusu():
    edonusum._gelen_aktar(b, 1)
# Şirket B'yi kaldır
dbx("DELETE FROM kullanici_sirket WHERE sirket_id IN (SELECT id FROM sirket WHERE kod='F4B')")
dbx("DELETE FROM sirket WHERE kod='F4B'")

fk_rows = db("PRAGMA foreign_key_check")
check("21. test_fk_butunluk: FK check boş", len(fk_rows) == 0,
      str([tuple(r) for r in fk_rows][:5]))

kalinti = db1("SELECT COUNT(*) c FROM ("
              "SELECT id FROM fatura WHERE aciklama LIKE ? "
              "UNION ALL SELECT id FROM irsaliye WHERE aciklama LIKE ? "
              "UNION ALL SELECT belge_no AS id FROM e_belge WHERE belge_no LIKE ? "
              "UNION ALL SELECT belge_no AS id FROM gelen_belge WHERE belge_no LIKE ?)",
              MARK + "%", MARK + "%", MARK + "%", MARK + "%")
sirket_b = db1("SELECT COUNT(*) c FROM sirket WHERE kod='F4B'")
check("22. test_kalinti_yok: F4TEST kalıntısı yok",
      kalinti["c"] == 0 and sirket_b["c"] == 0,
      f"kalıntı={kalinti['c']}, F4B={sirket_b['c']}")

print(f"\n=== SONUÇ: {len(ok)} başarılı / {len(fail)} başarısız ===")
if fail:
    print("BAŞARISIZ:", fail)
    raise SystemExit(1)
print("TÜM F4 E-DÖNÜŞÜM TESTLERİ GEÇTİ ✅")
