# -*- coding: utf-8 -*-
"""F3 — Ortak Arama / Type-ahead (v1.33.0) e2e testi.

Kural: TÜM stok/cari seçim noktaları TEK /api/ara endpoint'i + TEK typeahead.js
bileşeni kullanır. K1: her yanıt sirket_id ile süzülür. DB şeması değişmez.

GM'in 18 senaryosu, gerçek seed verisine uyarlanmıştır (seed'de ST00001/CR0001/
"Yılmaz" YOK; karşılıkları: BUZ-510-VST-003 / BAT-001 / "Batman Çarşı Elektronik").

Çalıştırma: sunucu 8080'de çalışırken  python3 test_f3_arama.py
"""
import datetime
import os
import sqlite3

import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
MARK = "F3TEST"

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print((("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else "")))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris():
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": "admin", "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, "giriş başarısız"
    return s


def aktif_sirket():
    return db1("SELECT sirket_id FROM sessionler ORDER BY rowid DESC LIMIT 1")["sirket_id"]


def gec(s, sid):
    s.post(BASE + "/sirket/gec", data={"sirket_id": str(sid), "next": "/"},
           allow_redirects=False)


def ara(s, **params):
    r = s.get(BASE + "/api/ara", params=params)
    return r.status_code, r.json()


def satir(stok_id, manuel="", fiyat="100"):
    return [("k_stok_id", stok_id), ("k_varyant_id", "0"), ("k_manuel_ad", manuel),
            ("k_birim", "Adet"), ("k_goruntu_ad", ""), ("k_miktar", "1"),
            ("k_birim_fiyat", fiyat), ("k_iskonto", "0"), ("k_kdv", "20")]


def temizle_fatura(fid):
    dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN "
        "(SELECT id FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?)", fid)
    dbx("DELETE FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?", fid)
    dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
    dbx("DELETE FROM audit_log WHERE tablo='fatura' AND kayit_id=?", fid)
    dbx("DELETE FROM fatura_kalem WHERE fatura_id=?", fid)
    dbx("DELETE FROM fatura WHERE id=?", fid)


def temizle_irsaliye(iid):
    dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN "
        "(SELECT id FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id=?)", iid)
    dbx("DELETE FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id=?", iid)
    dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", iid)
    dbx("DELETE FROM stok_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", iid)
    dbx("DELETE FROM audit_log WHERE tablo='irsaliye' AND kayit_id=?", iid)
    dbx("DELETE FROM irsaliye_kalem WHERE irsaliye_id=?", iid)
    dbx("DELETE FROM irsaliye WHERE id=?", iid)


def temizle_teklif(tid):
    dbx("DELETE FROM audit_log WHERE tablo='teklif' AND kayit_id=?", tid)
    dbx("DELETE FROM teklif_kalem WHERE teklif_id=?", tid)
    dbx("DELETE FROM teklif WHERE id=?", tid)


def temizle_siparis(sid):
    dbx("DELETE FROM audit_log WHERE tablo='siparis' AND kayit_id=?", sid)
    dbx("DELETE FROM siparis_kalem WHERE siparis_id=?", sid)
    dbx("DELETE FROM siparis WHERE id=?", sid)


def temizle_pos(fid):
    dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN (SELECT id FROM yevmiye WHERE "
        "(kaynak_modul='Fatura' AND kaynak_id=?) OR "
        "(kaynak_modul='Kasa' AND kaynak_id IN (SELECT id FROM kasa_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?)) OR "
        "(kaynak_modul='Banka' AND kaynak_id IN (SELECT id FROM banka_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?)))",
        fid, fid, fid)
    dbx("DELETE FROM yevmiye WHERE (kaynak_modul='Fatura' AND kaynak_id=?) OR "
        "(kaynak_modul='Kasa' AND kaynak_id IN (SELECT id FROM kasa_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?)) OR "
        "(kaynak_modul='Banka' AND kaynak_id IN (SELECT id FROM banka_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?))",
        fid, fid, fid)
    dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
    dbx("DELETE FROM kasa_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
    dbx("DELETE FROM banka_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
    dbx("DELETE FROM stok_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
    dbx("DELETE FROM audit_log WHERE tablo='pos_satis' AND kayit_id IN (SELECT id FROM pos_satis WHERE fatura_id=?)", fid)
    dbx("DELETE FROM audit_log WHERE tablo='fatura' AND kayit_id=?", fid)
    dbx("DELETE FROM pos_satis_odeme WHERE pos_satis_id IN (SELECT id FROM pos_satis WHERE fatura_id=?)", fid)
    dbx("DELETE FROM pos_satis WHERE fatura_id=?", fid)
    dbx("DELETE FROM fatura_kalem WHERE fatura_id=?", fid)
    dbx("DELETE FROM fatura WHERE id=?", fid)


# ---------------------------------------------------------------------------
print("== F3 / Ortak Arama (type-ahead) — e2e testi ==")
s = giris()

# --- idempotent başlangıç temizliği (önceki koşulardan kalıntı) ---
for k in ("F3-IZO-STOK", "F3POS-STOK"):
    dbx("DELETE FROM stok_seviye WHERE stok_id IN (SELECT id FROM stok_kart WHERE kod=?)", k)
    dbx("DELETE FROM stok_hareket WHERE stok_id IN (SELECT id FROM stok_kart WHERE kod=?)", k)
    dbx("DELETE FROM stok_kart WHERE kod=?", k)
dbx("DELETE FROM cari_kart WHERE kod='F3-IZO-CARI'")
dbx("DELETE FROM stok_kart WHERE kod LIKE 'F3LIMIT%'")
dbx("DELETE FROM kullanici_sirket WHERE sirket_id IN (SELECT id FROM sirket WHERE kod='F3B')")
dbx("DELETE FROM sirket WHERE kod='F3B'")

# Seed karşılıkları
buz = db1("SELECT id, kod, barkod FROM stok_kart WHERE kod='BUZ-510-VST-003' AND sirket_id=1")
bat = db1("SELECT id, kod, unvan FROM cari_kart WHERE kod='BAT-001' AND sirket_id=1")

# ===========================================================================
print("=" * 70); print("BÖLÜM 1 — /api/ara: stok (kod/ad/barkod/boş/yok/limit)")
print("=" * 70)
st, data = ara(s, tip="stok", q="BUZ-510-VST-003")
check("1. test_api_stok_kod_ile: tam kod → ST döner",
      st == 200 and data and data[0]["kod"] == "BUZ-510-VST-003", str(data[:1]))

st, data = ara(s, tip="stok", q="Vestel")
check("2. test_api_stok_ad_ile: q=Vestel → ad içeren stok(lar)",
      st == 200 and len(data) >= 1 and all("Vestel" in d["ad"] for d in data),
      f"{len(data)} kayıt")

st, data = ara(s, tip="stok", q="8691234500035")
check("3. test_api_stok_barkod_ile: barkod → BUZ-510-VST-003",
      st == 200 and data and data[0]["kod"] == "BUZ-510-VST-003", str(data[:1]))

st, data = ara(s, tip="stok", q="BUZ")
check("4. test_api_stok_kismi: kısmi kod → 1..20 kayıt",
      st == 200 and 1 <= len(data) <= 20, f"{len(data)} kayıt")

st, data = ara(s, tip="stok", q="")
check("7a. test_api_bos_sorgu (stok): ilk 20 kayıt",
      st == 200 and 5 <= len(data) <= 20, f"{len(data)} kayıt")

st, data = ara(s, tip="stok", q="ZZZXXX")
check("8a. test_api_yok (stok): []", st == 200 and data == [], str(data))

# ===========================================================================
print("=" * 70); print("BÖLÜM 2 — /api/ara: cari (kod/unvan/boş/filtre/yok)")
print("=" * 70)
st, data = ara(s, tip="cari", q="BAT-001")
check("5. test_api_cari_kod_ile: tam kod → BAT-001",
      st == 200 and data and data[0]["kod"] == "BAT-001", str(data[:1]))

st, data = ara(s, tip="cari", q="Batman")
check("6. test_api_cari_unvan_ile: q=Batman → Batman Çarşı Elektronik",
      st == 200 and data and data[0]["kod"] == "BAT-001"
      and "Batman" in data[0]["unvan"], str(data[:1]))

st, data = ara(s, tip="cari", q="")
check("7b. test_api_bos_sorgu (cari): ilk 20 kayıt",
      st == 200 and 1 <= len(data) <= 20, f"{len(data)} kayıt")

st, data = ara(s, tip="cari", q="", cari_tip="Alis")
kodlar = [d["kod"] for d in data]
tipler = db("SELECT tip FROM cari_kart WHERE kod IN (%s) AND sirket_id=1"
            % ",".join("?" * len(kodlar)), *kodlar) if kodlar else []
check("7c. cari_tip=Alis filtresi: yalnız tedarikçi/herikisi",
      st == 200 and data and len(data) >= 2
      and all(r["tip"] in ("Tedarikci", "HerIkisi") for r in tipler),
      f"{len(data)} kayıt — {kodlar}")

st, data = ara(s, tip="cari", q="ZZZXXX")
check("8b. test_api_yok (cari): []", st == 200 and data == [], str(data))

# ===========================================================================
print("=" * 70); print("BÖLÜM 3 — K1 izolasyon + limit 20")
print("=" * 70)
# ikinci şirket
dbx("INSERT INTO sirket(kod, unvan, aktif) VALUES('F3B','F3 İzolasyon Şirketi B',1)")
s_b = db1("SELECT id FROM sirket WHERE kod='F3B'")["id"]
dbx("INSERT OR IGNORE INTO kullanici_sirket(kullanici_id, sirket_id) "
    "SELECT id, ? FROM kullanici WHERE kullanici_adi='admin'", s_b)

# A şirketine F3 izolasyon stok + cari
r = s.post(BASE + "/stok/yeni", data={"kod": "F3-IZO-STOK", "ad": "F3 İzolasyon Ürünü",
                                      "birim": "Adet", "kdv_orani": "20", "satis_fiyat": "100"},
           allow_redirects=False)
s.post(BASE + "/cari/yeni", data={"kod": "F3-IZO-CARI", "unvan": "F3 İzolasyon Müşterisi",
                                  "tip": "Musteri"}, allow_redirects=False)
# B şirketine 30 adet sentetik stok (limit testi için)
for i in range(30):
    dbx("INSERT INTO stok_kart(kod, ad, barkod, aktif, sirket_id) VALUES(?,?,?,1,?)",
        f"F3LIMIT{i:03d}", f"F3 Limit Ürün {i:03d}", f"F3L{i:05d}", s_b)

gec(s, s_b)
check("9a. K1: B'de A stoku /api/ara'da görünmüyor",
      ara(s, tip="stok", q="F3-IZO-STOK")[1] == [])
check("9b. K1: B'de A carisi /api/ara'da görünmüyor",
      ara(s, tip="cari", q="F3-IZO-CARI")[1] == [])
check("9c. K1: B'de A'nın BUZ stoğu görünmüyor",
      ara(s, tip="stok", q="BUZ-510-VST-003")[1] == [])

st, data = ara(s, tip="stok", q="F3LIMIT")
check("10. test_api_limit: 30 stokta en fazla 20 döner",
      st == 200 and len(data) == 20, f"{len(data)} kayıt")

# B'ye ait stoklar B'de görünüyor (izolasyonun ters yönü)
st, data = ara(s, tip="stok", q="F3LIMIT000")
check("9d. B kendi stoğunu görüyor", st == 200 and data and data[0]["kod"] == "F3LIMIT000")

# temizlik + A'ya dön
dbx("DELETE FROM stok_kart WHERE kod LIKE 'F3LIMIT%'")
dbx("DELETE FROM kullanici_sirket WHERE sirket_id=?", s_b)
dbx("DELETE FROM sirket WHERE id=?", s_b)
gec(s, 1)

# ===========================================================================
print("=" * 70); print("BÖLÜM 4 — Form POST: typeahead hidden input ile belge üretimi")
print("=" * 70)
# 11+12: Fatura (cari + stok hidden input)
r = s.post(BASE + "/fatura/yeni",
           data=[("tip", "Satis"), ("cari_id", str(bat["id"])),
                 ("tarih", datetime.date.today().isoformat()), ("para_birimi", "TRY"),
                 ("aciklama", MARK + " fatura"), ("action", "kaydet")] + satir(str(buz["id"])),
           allow_redirects=False)
fid = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
f = db1("SELECT cari_id, durum FROM fatura WHERE id=?", fid)
fk = db1("SELECT stok_id FROM fatura_kalem WHERE fatura_id=?", fid)
check("11. test_form_post_typeahead_cari: cari_id hidden → fatura doğru cariyle oluştu",
      r.status_code == 302 and f is not None and f["cari_id"] == bat["id"])
check("12. test_form_post_typeahead_stok: k_stok_id hidden → kalem doğru stok",
      fk is not None and fk["stok_id"] == buz["id"])

# 13: İrsaliye
r = s.post(BASE + "/irsaliye/yeni",
           data=[("tip", "Satis"), ("cari_id", str(bat["id"])), ("depo_id", "1"),
                 ("tarih", datetime.date.today().isoformat()),
                 ("aciklama", MARK + " irsaliye"), ("action", "kaydet")] + satir(str(buz["id"])),
           allow_redirects=False)
iid = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
ik = db1("SELECT stok_id FROM irsaliye_kalem WHERE irsaliye_id=?", iid)
i = db1("SELECT cari_id FROM irsaliye WHERE id=?", iid)
check("13. test_irsaliye_typeahead: irsaliye cari+stok hidden ile oluştu",
      r.status_code == 302 and i is not None and i["cari_id"] == bat["id"]
      and ik is not None and ik["stok_id"] == buz["id"])

# 14: Sipariş
r = s.post(BASE + "/siparis/yeni",
           data=[("tip", "Musteri"), ("cari_id", str(bat["id"])), ("depo_id", "1"),
                 ("tarih", datetime.date.today().isoformat()), ("teslim_tarihi", ""),
                 ("aciklama", MARK + " siparis"), ("action", "kaydet")] + satir(str(buz["id"])),
           allow_redirects=False)
sid = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
sk = db1("SELECT stok_id FROM siparis_kalem WHERE siparis_id=?", sid)
check("14. test_siparis_typeahead: sipariş cari+stok hidden ile oluştu",
      r.status_code == 302 and sk is not None and sk["stok_id"] == buz["id"])

# 15: Teklif
r = s.post(BASE + "/teklif/yeni",
           data=[("cari_id", str(bat["id"])), ("tarih", datetime.date.today().isoformat()),
                 ("gecerlilik_tarihi", ""), ("aciklama", MARK + " teklif"),
                 ("action", "kaydet")] + satir(str(buz["id"])),
           allow_redirects=False)
tid = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
tk = db1("SELECT stok_id FROM teklif_kalem WHERE teklif_id=?", tid)
check("15. test_teklif_typeahead: teklif cari+stok hidden ile oluştu",
      r.status_code == 302 and tk is not None and tk["stok_id"] == buz["id"])

# 16: POS — adla arama + satış
st, data = ara(s, tip="stok", q="Vestel")
check("16a. POS adla arama: q=Vestel → en az 1 ürün", st == 200 and len(data) >= 1)
ter = db1("SELECT depo_id FROM pos_terminal WHERE id=1")
depo = ter["depo_id"] if ter else 1
dbx("INSERT INTO stok_kart(kod, ad, barkod, birim, kdv_orani, satis_fiyat, aktif, sirket_id) "
    "VALUES('F3POS-STOK','F3 POS Ürünü','F3POS1','Adet',20,100,1,1)")
pos_stok = db1("SELECT id FROM stok_kart WHERE kod='F3POS-STOK'")["id"]
dbx("INSERT INTO stok_seviye(stok_id, varyant_id, depo_id, miktar, sirket_id) VALUES(?,0,?,100,1)",
    pos_stok, depo)
r = s.post(BASE + "/pos/satis",
           data=[("terminal_id", "1"), ("cari_id", ""), ("taksit", "1"), ("vade", ""),
                 ("k_stok_id", str(pos_stok)), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
                 ("k_miktar", "1"), ("k_birim_fiyat", "100"), ("k_iskonto", "0"), ("k_kdv", "20"),
                 ("p_tip", "Nakit"), ("p_tutar", "120"), ("p_vade", "")],
           allow_redirects=False)
pfid = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
pf = db1("SELECT durum FROM fatura WHERE id=?", pfid)
check("16b. POS satışı (hidden stok input) → Onaylı fatura",
      r.status_code == 302 and pf is not None and pf["durum"] == "Onaylandı")

# ===========================================================================
print("=" * 70); print("BÖLÜM 5 — Statik dosya + template widget kontrolü")
print("=" * 70)
r = s.get(BASE + "/static/js/typeahead.js")
check("17. test_js_dosya_var: /static/js/typeahead.js 200 + initTypeahead",
      r.status_code == 200 and "initTypeahead" in r.text)

r = s.get(BASE + "/fatura/yeni")
check("18. test_template_toggle_var: fatura/form.html typeahead div + data-tip=cari",
      r.status_code == 200 and 'class="typeahead"' in r.text and 'data-tip="cari"' in r.text)

# Tüm hedef şablonlarda widget var mı? (GM tablosu: 14 nokta)
T = "templates/"
hedefler = {
    "fatura/form.html": "cari", "irsaliye/form.html": "cari",
    "teklif/form.html": "cari", "siparis/form.html": "cari",
    "pos/satis.html": "cari", "satin_alma/form.html": "cari",
    "satin_alma/teklif_form.html": "cari", "servis/form.html": "cari",
    "servis/detay.html": "stok", "bakim/form.html": "cari", "crm/form.html": "cari",
}
eksik = []
for f, tip in hedefler.items():
    icerik = open(T + f, encoding="utf-8").read()
    if 'class="typeahead"' not in icerik or f'data-tip="{tip}"' not in icerik:
        eksik.append(f)
check("19. 11 şablonun hepsinde typeahead widget var (tek bileşen)",
      len(eksik) == 0, str(eksik))

# Tek kaynak: template/js'lerde eski /api/stok/ara ve /api/cari/ara çağrısı kalmamalı
eskiler = []
for root, _, files in os.walk("templates"):
    for fn in files:
        if fn.endswith(".html"):
            t = open(os.path.join(root, fn), encoding="utf-8").read()
            if "/api/stok/ara" in t or "/api/cari/ara" in t:
                eskiler.append(os.path.join(root, fn))
for root, _, files in os.walk("static"):
    for fn in files:
        if fn.endswith(".js"):
            t = open(os.path.join(root, fn), encoding="utf-8").read()
            if "/api/stok/ara" in t or "/api/cari/ara" in t:
                eskiler.append(os.path.join(root, fn))
check("20. Tek endpoint: template/js'lerde eski arama ucu çağrısı yok", len(eskiler) == 0, str(eskiler))

# api.py'de TEK /api/ara kayıtlı (eski uçlar sarmalayıcı olarak durur)
api_icerik = open("api.py", encoding="utf-8").read()
check("21. api.py'de tek /api/ara route'u + sarmalayıcılar",
      'route(r"/api/ara"' in api_icerik and api_icerik.count('route(r"/api') >= 3)

# ===========================================================================
print("=" * 70); print("TEMİZLİK + BÜTÜNLÜK")
print("=" * 70)
temizle_fatura(fid)
temizle_irsaliye(iid)
temizle_siparis(sid)
temizle_teklif(tid)
temizle_pos(pfid)
dbx("DELETE FROM stok_seviye WHERE stok_id=?", pos_stok)
dbx("DELETE FROM stok_hareket WHERE stok_id=?", pos_stok)
dbx("DELETE FROM stok_kart WHERE id=?", pos_stok)
for k in ("F3-IZO-STOK", "F3POS-STOK"):
    dbx("DELETE FROM stok_seviye WHERE stok_id IN (SELECT id FROM stok_kart WHERE kod=?)", k)
    dbx("DELETE FROM stok_hareket WHERE stok_id IN (SELECT id FROM stok_kart WHERE kod=?)", k)
    dbx("DELETE FROM stok_kart WHERE kod=?", k)
dbx("DELETE FROM cari_kart WHERE kod='F3-IZO-CARI'")

fk = db("PRAGMA foreign_key_check")
check("22.1 FK bütünlüğü", len(fk) == 0, str([tuple(r) for r in fk][:5]))
kalinti = db1("SELECT COUNT(*) c FROM (SELECT id FROM fatura WHERE aciklama LIKE ? "
              "UNION ALL SELECT id FROM irsaliye WHERE aciklama LIKE ? "
              "UNION ALL SELECT id FROM teklif WHERE aciklama LIKE ? "
              "UNION ALL SELECT id FROM siparis WHERE aciklama LIKE ?)",
              MARK + "%", MARK + "%", MARK + "%", MARK + "%")
check("22.2 F3TEST kalıntısı yok", kalinti["c"] == 0, str(kalinti["c"]))

print(f"\n=== SONUÇ: {len(ok)} başarılı / {len(fail)} başarısız ===")
if fail:
    print("BAŞARISIZ:", fail)
    raise SystemExit(1)
print("TÜM F3 ARAMA TESTLERİ GEÇTİ ✅")
