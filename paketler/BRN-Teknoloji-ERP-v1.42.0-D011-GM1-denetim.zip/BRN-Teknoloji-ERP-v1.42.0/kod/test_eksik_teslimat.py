# -*- coding: utf-8 -*-
"""B3 — Eksik Teslimatlar + Satın Alma Raporu e2e testi.

Kapsam (faz protokolü örnek senaryosu):
  1. Alış siparişi (SAP) oluşturulur + onaylanır.
  2. Kısmi Alış irsaliyesi onaylanır → teslim_edilen artar, sipariş 'Kısmi'.
  3. Eksik listesi: doğru kalan (3) ve eksik tutar (TRY).
  4. Gecikme hesabı (teslim tarihi geçmiş).
  5. Kalan kapat → sipariş 'Tamamlandı', eksikten düşer.
  6. Kapatma geri al → 'Kısmi', eksik geri gelir.
  7. Kısmi kapat (miktar=1) → kalan 2.
  8. Aşırı kapat engeli (miktar > kalan).
  9. Tedarikçi filtresi.
  10. Rapor: dönem özeti + eksik dökümü render.
  11. Şirket izolasyonu.
  12. USD teklif detayı |kur filtresiyle render (B2 regresyonu).

Çalıştırma: sunucu 8080'de çalışırken  python3 test_eksik_teslimat.py
"""
import datetime
import sqlite3
import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
KOD = "EKSB"
YIL = datetime.date.today().year
BUGUN = datetime.date.today()
DUN = (BUGUN - datetime.timedelta(days=1)).isoformat()

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else ""))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris(kullanici="admin"):
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": kullanici, "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, f"giriş başarısız ({kullanici})"
    return s


def alis_siparis(s, aciklama, miktar, teslim=DUN):
    s.post(BASE + "/siparis/yeni", data=[
        ("tip", "Alis"), ("cari_id", "5"), ("depo_id", "1"),
        ("tarih", BUGUN.isoformat()), ("teslim_tarihi", teslim),
        ("aciklama", aciklama), ("action", "kaydet"),
        ("k_stok_id", "3"), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
        ("k_birim", "Adet"), ("k_miktar", str(miktar)), ("k_birim_fiyat", "100"),
        ("k_iskonto", "0"), ("k_kdv", "20"),
    ], allow_redirects=False)
    return db1("SELECT * FROM siparis WHERE aciklama=? ORDER BY id DESC", aciklama)


def alis_irsaliye(s, siparis_id, miktar):
    s.post(BASE + "/irsaliye/yeni", data=[
        ("tip", "Alis"), ("cari_id", "5"), ("depo_id", "1"),
        ("tarih", BUGUN.isoformat()), ("kaynak_siparis", str(siparis_id)),
        ("aciklama", "EKSIK-TEST-IRS"), ("action", "kaydet"),
        ("k_stok_id", "3"), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
        ("k_birim", "Adet"), ("k_goruntu_ad", ""), ("k_miktar", str(miktar)),
        ("k_birim_fiyat", "100"), ("k_iskonto", "0"), ("k_kdv", "20"),
    ], allow_redirects=False)
    return db1("SELECT * FROM irsaliye WHERE aciklama='EKSIK-TEST-IRS' AND kaynak_siparis_id=? "
               "ORDER BY id DESC", siparis_id)


def main():
    admin = giris("admin")

    # --- 0. Kalıntı temizliği ---
    eski = db1("SELECT id FROM sirket WHERE kod=?", KOD)
    if eski:
        sid = eski["id"]
        for t in ("irsaliye_kalem", "irsaliye", "siparis_kalem", "siparis",
                  "satin_alma_talebi_kalem", "satin_alma_talebi", "alinan_teklif_kalem",
                  "alinan_teklif", "cari_kart", "hesap", "demirbas_kategori", "depo",
                  "kullanici_sirket"):
            dbx(f"DELETE FROM {t} WHERE sirket_id=?", sid)
        dbx("DELETE FROM sirket WHERE id=?", sid)
    dbx("DELETE FROM stok_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id IN "
        "(SELECT id FROM irsaliye WHERE aciklama='EKSIK-TEST-IRS')")
    # F1 — irsaliye onayı fiş + cari üretiyor; kalıntıları da temizle (yetim bırakma)
    dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN "
        "(SELECT id FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id IN "
        "(SELECT id FROM irsaliye WHERE aciklama='EKSIK-TEST-IRS'))")
    dbx("DELETE FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id IN "
        "(SELECT id FROM irsaliye WHERE aciklama='EKSIK-TEST-IRS')")
    dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id IN "
        "(SELECT id FROM irsaliye WHERE aciklama='EKSIK-TEST-IRS')")
    dbx("DELETE FROM irsaliye_kalem WHERE irsaliye_id IN "
        "(SELECT id FROM irsaliye WHERE aciklama='EKSIK-TEST-IRS')")
    dbx("DELETE FROM irsaliye WHERE aciklama='EKSIK-TEST-IRS'")
    dbx("DELETE FROM siparis_kalem WHERE siparis_id IN "
        "(SELECT id FROM siparis WHERE aciklama LIKE 'EKSIK-TEST-%')")
    dbx("DELETE FROM siparis WHERE aciklama LIKE 'EKSIK-TEST-%'")
    dbx("DELETE FROM alinan_teklif_kalem WHERE teklif_id IN "
        "(SELECT id FROM alinan_teklif WHERE aciklama LIKE 'KUR-TEST-%')")
    dbx("DELETE FROM alinan_teklif WHERE aciklama LIKE 'KUR-TEST-%'")

    # --- 1. Alış siparişi + onay ---
    s1 = alis_siparis(admin, "EKSIK-TEST-S1", 5)
    check("Alış siparişi oluştu (Bekliyor)", s1 is not None and s1["durum"] == "Bekliyor",
          f"no={s1['siparis_no'] if s1 else '-'}")
    admin.post(BASE + f"/siparis/{s1['id']}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
    check("Sipariş onaylandı", db1("SELECT durum FROM siparis WHERE id=?", s1["id"])["durum"] == "Onaylandı")
    sev_bas = db1("SELECT miktar FROM stok_seviye WHERE stok_id=3 AND varyant_id=0 AND depo_id=1")

    # --- 2. Kısmi irsaliye (2/5) ---
    i1 = alis_irsaliye(admin, s1["id"], 2)
    check("Alış irsaliyesi oluştu (Taslak)", i1 is not None and i1["durum"] == "Taslak",
          f"no={i1['irsaliye_no'] if i1 else '-'}")
    admin.post(BASE + f"/irsaliye/{i1['id']}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
    k = db1("SELECT miktar, teslim_edilen, kalan_iptal FROM siparis_kalem WHERE siparis_id=?", s1["id"])
    check("teslim_edilen 2 oldu", abs(k["teslim_edilen"] - 2.0) < 0.001, f"teslim={k['teslim_edilen']}")
    check("Sipariş durumu Kısmi", db1("SELECT durum FROM siparis WHERE id=?", s1["id"])["durum"] == "Kısmi")

    # --- 3. Eksik listesi doğrulama ---
    h = admin.get(BASE + "/satin-alma/eksik-teslimatlar").text
    check("Eksik listede sipariş görünüyor", s1["siparis_no"] in h)
    kalem_id = db1("SELECT id FROM siparis_kalem WHERE siparis_id=?", s1["id"])["id"]
    # eksik tutar: kalan 3 × 100 = 300 TRY
    check("Eksik tutar TRY (3×100=300)", "300,00 ₺" in h, "listede 300,00 ₺")

    # --- 4. Gecikme (teslim tarihi dün) ---
    check("Gecikme rozeti (1 gün)", "1 gün" in h)

    # --- 5. Kalan kapat → Tamamlandı ---
    admin.post(BASE + f"/satin-alma/eksik-teslimatlar/{kalem_id}/kapat",
               data={"hedef": "kapat"}, allow_redirects=False)
    k = db1("SELECT kalan_iptal FROM siparis_kalem WHERE id=?", kalem_id)
    check("kalan_iptal 3 oldu", abs(k["kalan_iptal"] - 3.0) < 0.001, f"iptal={k['kalan_iptal']}")
    check("Sipariş Tamamlandı", db1("SELECT durum FROM siparis WHERE id=?", s1["id"])["durum"] == "Tamamlandı")
    h = admin.get(BASE + "/satin-alma/eksik-teslimatlar").text
    check("Eksikten düştü", s1["siparis_no"] not in h)

    # --- 6. Geri al ---
    admin.post(BASE + f"/satin-alma/eksik-teslimatlar/{kalem_id}/kapat",
               data={"hedef": "geri_al"}, allow_redirects=False)
    check("Geri al: kalan_iptal 0", abs(db1("SELECT kalan_iptal FROM siparis_kalem WHERE id=?", kalem_id)["kalan_iptal"]) < 0.001)
    check("Geri al: sipariş Kısmi", db1("SELECT durum FROM siparis WHERE id=?", s1["id"])["durum"] == "Kısmi")
    check("Geri al: eksikte tekrar", s1["siparis_no"] in admin.get(BASE + "/satin-alma/eksik-teslimatlar").text)

    # --- 7. Kısmi kapat (1/3) ---
    admin.post(BASE + f"/satin-alma/eksik-teslimatlar/{kalem_id}/kapat",
               data={"hedef": "kapat", "miktar": "1"}, allow_redirects=False)
    k = db1("SELECT kalan_iptal, miktar, teslim_edilen FROM siparis_kalem WHERE id=?", kalem_id)
    kalan = k["miktar"] - k["teslim_edilen"] - k["kalan_iptal"]
    check("Kısmi kapat (kalan 2)", abs(k["kalan_iptal"] - 1.0) < 0.001 and abs(kalan - 2.0) < 0.001,
          f"iptal={k['kalan_iptal']} kalan={kalan}")

    # --- 8. Aşırı kapat engeli ---
    admin.post(BASE + f"/satin-alma/eksik-teslimatlar/{kalem_id}/kapat",
               data={"hedef": "kapat", "miktar": "99"}, allow_redirects=False)
    k = db1("SELECT kalan_iptal FROM siparis_kalem WHERE id=?", kalem_id)
    check("Aşırı kapat engellendi", abs(k["kalan_iptal"] - 1.0) < 0.001, f"iptal={k['kalan_iptal']}")

    # --- 9. Tedarikçi filtresi ---
    h = admin.get(BASE + "/satin-alma/eksik-teslimatlar?tedarikci_id=6").text
    check("Tedarikçi filtresi (cari 6 → sipariş yok)", s1["siparis_no"] not in h)

    # --- 10. Rapor ---
    r = admin.get(BASE + f"/satin-alma/rapor?baslangic={BUGUN.isoformat()}&bitis={BUGUN.isoformat()}")
    check("Rapor render (200)", r.status_code == 200 and "Satın Alma Raporu" in r.text)
    check("Raporda sipariş dökümü", s1["siparis_no"] in r.text)

    # --- 11. Şirket izolasyonu ---
    admin.post(BASE + "/ayarlar/sirketler", data={"kod": KOD, "unvan": "Eksik İzolasyon A.Ş."},
               allow_redirects=False)
    b_id = db1("SELECT id FROM sirket WHERE kod=?", KOD)["id"]
    admin.post(BASE + "/sirket/gec", data={"sirket_id": str(b_id), "next": "/"}, allow_redirects=False)
    hb = admin.get(BASE + "/satin-alma/eksik-teslimatlar").text
    check("B şirketinde A eksikleri görünmüyor", s1["siparis_no"] not in hb)
    admin.post(BASE + "/sirket/gec", data={"sirket_id": "1", "next": "/"}, allow_redirects=False)

    # --- 12. USD teklif detayı |kur filtresi (B2 regresyonu) ---
    admin.post(BASE + "/satin-alma/teklifler/yeni", data=[
        ("tedarikci_id", "5"), ("talep_id", ""), ("depo_id", ""),
        ("tarih", BUGUN.isoformat()), ("gecerlilik_tarihi", ""), ("para_birimi", "USD"),
        ("doviz_kur", "30"), ("teslim_suresi_gun", "7"), ("odeme_vadesi_gun", "30"),
        ("aciklama", "KUR-TEST-1"),
        ("k_stok_id", "3"), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
        ("k_birim", "Adet"), ("k_miktar", "1"), ("k_birim_fiyat", "100"),
        ("k_iskonto", "0"), ("k_kdv", "20"),
    ], allow_redirects=False)
    tk = db1("SELECT id FROM alinan_teklif WHERE aciklama='KUR-TEST-1' ORDER BY id DESC")
    rd = admin.get(BASE + f"/satin-alma/teklifler/{tk['id']}")
    check("USD teklif detayı |kur ile render (500 yok)",
          rd.status_code == 200 and "30,0000" in rd.text, f"status={rd.status_code}")

    # --- 13. Temizlik ---
    for t in ("irsaliye_kalem", "irsaliye", "siparis_kalem", "siparis",
              "satin_alma_talebi_kalem", "satin_alma_talebi", "alinan_teklif_kalem",
              "alinan_teklif", "cari_kart", "hesap", "demirbas_kategori", "depo",
              "kullanici_sirket"):
        dbx(f"DELETE FROM {t} WHERE sirket_id=?", b_id)
    dbx("DELETE FROM sirket WHERE id=?", b_id)
    dbx("UPDATE sessionler SET sirket_id=1 WHERE sirket_id=?", b_id)
    dbx("DELETE FROM stok_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id IN "
        "(SELECT id FROM irsaliye WHERE aciklama='EKSIK-TEST-IRS')")
    # F1 — irsaliye onayı fiş + cari üretiyor; kalıntıları da temizle (yetim bırakma)
    dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN "
        "(SELECT id FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id IN "
        "(SELECT id FROM irsaliye WHERE aciklama='EKSIK-TEST-IRS'))")
    dbx("DELETE FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id IN "
        "(SELECT id FROM irsaliye WHERE aciklama='EKSIK-TEST-IRS')")
    dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id IN "
        "(SELECT id FROM irsaliye WHERE aciklama='EKSIK-TEST-IRS')")
    dbx("DELETE FROM irsaliye_kalem WHERE irsaliye_id IN "
        "(SELECT id FROM irsaliye WHERE aciklama='EKSIK-TEST-IRS')")
    dbx("DELETE FROM irsaliye WHERE aciklama='EKSIK-TEST-IRS'")
    if sev_bas:
        dbx("UPDATE stok_seviye SET miktar=? WHERE stok_id=3 AND varyant_id=0 AND depo_id=1",
            sev_bas["miktar"])
    dbx("DELETE FROM siparis_kalem WHERE siparis_id IN "
        "(SELECT id FROM siparis WHERE aciklama LIKE 'EKSIK-TEST-%')")
    dbx("DELETE FROM siparis WHERE aciklama LIKE 'EKSIK-TEST-%'")
    dbx("DELETE FROM alinan_teklif_kalem WHERE teklif_id IN "
        "(SELECT id FROM alinan_teklif WHERE aciklama LIKE 'KUR-TEST-%')")
    dbx("DELETE FROM alinan_teklif WHERE aciklama LIKE 'KUR-TEST-%'")

    print(f"\nSONUÇ: {len(ok)} başarılı / {len(fail)} başarısız")
    if fail:
        print("BAŞARISIZ:", fail)
        raise SystemExit(1)
    print("EKSİK TESLİMATLAR + RAPOR (B3) E2E TESTİ GEÇTİ ✅")


if __name__ == "__main__":
    main()
