/* Brn Teknoloji ERP — F3 (v1.33.0) ORTAK ARAMA / TYPE-AHEAD BİLEŞENİ.
 *
 * TEK KAYNAK: GET /api/ara?tip=stok|cari&q=...&cari_tip=Alis|Satis
 *   tip=stok → kod / ad / barkod (ve varyant)
 *   tip=cari → kod / unvan  (cari_tip: Alis=tedarikçi, Satis=müşteri)
 *   q boşsa  → ilk 20 kayıt
 *
 * Kullanım (hidden input form ile POST edilir — JS'siz de veri kaybolmaz):
 *   <input type="hidden" name="cari_id" id="cari-id" value="{{ secili_id }}">
 *   <div class="typeahead" data-tip="cari" data-cari-tip="Satis"
 *        data-target="cari-id" data-placeholder="Müşteri ara…"
 *        data-initial="{{ secili_etiket }}" data-allow-empty="1"></div>
 *
 * Seçim olunca document'e "ta:select" olayı fırlatılır:
 *   detail = { targetId: 'cari-id', item: { id, kod, unvan, ... } | null }
 * (form-satir.js cari iskonto senkronu için bunu dinler.)
 */
(function () {
  "use strict";

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function initTypeahead(container) {
    if (!container || container.getAttribute('data-ta-init') === '1') return;
    container.setAttribute('data-ta-init', '1');

    var tip = container.getAttribute('data-tip') || 'stok';
    var cariTip = container.getAttribute('data-cari-tip') || '';
    var targetId = container.getAttribute('data-target') || '';
    var placeholder = container.getAttribute('data-placeholder') || 'Ara…';
    var initial = container.getAttribute('data-initial') || '';
    var allowEmpty = container.getAttribute('data-allow-empty') === '1';

    var hidden = document.getElementById(targetId);
    if (!hidden) return;

    /* --- DOM: input + (temizle) + liste --- */
    var wrap = document.createElement('div');
    wrap.className = 'ac-wrap ta-wrap';

    var input = document.createElement('input');
    input.type = 'text';
    input.className = 'search ta-input';
    input.autocomplete = 'off';
    input.placeholder = placeholder;
    input.value = initial;

    var clearBtn = null;
    if (allowEmpty) {
      clearBtn = document.createElement('button');
      clearBtn.type = 'button';
      clearBtn.className = 'ta-clear';
      clearBtn.textContent = '✕';
      clearBtn.title = 'Temizle';
      clearBtn.style.display = hidden.value ? '' : 'none';
      input.className += ' has-clear';
    }

    var list = document.createElement('div');
    list.className = 'ac-list';

    wrap.appendChild(input);
    if (clearBtn) wrap.appendChild(clearBtn);
    wrap.appendChild(list);
    container.appendChild(wrap);

    var items = [], sel = -1, timer = null;

    function label(it) {
      if (tip === 'cari') return it.unvan + ' (' + it.kod + ')';
      return it.kod + ' — ' + it.ad + (it.varyant_ad ? ' (' + it.varyant_ad + ')' : '');
    }

    function render() {
      list.innerHTML = '';
      if (!items.length) {
        if (input.value.trim()) {
          list.innerHTML = '<div class="ac-no">Eşleşme yok.</div>';
          list.classList.add('acik');
        } else {
          list.classList.remove('acik');
        }
        return;
      }
      items.forEach(function (it, i) {
        var d = document.createElement('div');
        d.className = 'ac-item' + (i === sel ? ' aktif' : '');
        if (tip === 'cari') {
          d.innerHTML = '<span class="ac-kod">' + esc(it.kod) + '</span>' +
            '<span class="ac-ad">' + esc(it.unvan) + '</span>' +
            (it.il ? ' <span class="ac-muted">' + esc(it.il) + '</span>' : '');
        } else {
          var vAd = it.varyant_ad ? ' <span class="ac-muted">— ' + esc(it.varyant_ad) + '</span>' : '';
          var birim = it.birim ? ' <span class="ac-muted">' + esc(it.birim) + '</span>' : '';
          d.innerHTML = '<span class="ac-kod">' + esc(it.kod) + '</span>' +
            '<span class="ac-ad">' + esc(it.ad) + vAd + birim + '</span>';
        }
        d.addEventListener('mousedown', function (e) { e.preventDefault(); pick(it); });
        list.appendChild(d);
      });
      list.classList.add('acik');
    }

    function close() {
      list.classList.remove('acik');
      list.innerHTML = '';
      items = [];
      sel = -1;
    }

    function pick(it) {
      hidden.value = it.id;
      input.value = label(it);
      if (clearBtn) clearBtn.style.display = '';
      close();
      document.dispatchEvent(new CustomEvent('ta:select',
        { detail: { targetId: targetId, item: it } }));
    }

    function clear() {
      hidden.value = '';
      input.value = '';
      if (clearBtn) clearBtn.style.display = 'none';
      close();
      document.dispatchEvent(new CustomEvent('ta:select',
        { detail: { targetId: targetId, item: null } }));
      input.focus();
    }

    function fetchList(qtext) {
      var url = '/api/ara?tip=' + encodeURIComponent(tip) + '&q=' + encodeURIComponent(qtext);
      if (cariTip) url += '&cari_tip=' + encodeURIComponent(cariTip);
      fetch(url)
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (document.activeElement !== input) return;
          items = data || [];
          sel = -1;
          render();
        })
        .catch(function () { close(); });
    }

    /* Enter'da eşleşme yoksa: elle yazılan KOD ile tam eşleşme çöz (fallback). */
    function resolveExact(text) {
      var t = text.trim().toLowerCase();
      if (!t) return false;
      for (var i = 0; i < items.length; i++) {
        var it = items[i];
        if ((it.kod && String(it.kod).toLowerCase() === t) ||
            (tip === 'stok' && it.barkod && String(it.barkod) === text.trim())) {
          pick(it);
          return true;
        }
      }
      return false;
    }

    input.addEventListener('focus', function () {
      if (!input.value.trim()) fetchList('');
    });
    input.addEventListener('input', function () {
      hidden.value = '';
      if (clearBtn) clearBtn.style.display = 'none';
      var qtext = input.value.trim();
      if (!qtext) { close(); return; }
      clearTimeout(timer);
      timer = setTimeout(function () { fetchList(qtext); }, 200);
    });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        if (!list.classList.contains('acik') || !items.length) return;
        e.preventDefault();
        sel = (sel + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
        render();
      } else if (e.key === 'Enter') {
        if (list.classList.contains('acik') && sel >= 0) {
          e.preventDefault();
          pick(items[sel]);
        } else {
          e.preventDefault();
          if (resolveExact(input.value)) return;
          close();
        }
      } else if (e.key === 'Escape') {
        close();
      }
    });
    input.addEventListener('blur', function () { setTimeout(close, 150); });
    if (clearBtn) {
      clearBtn.addEventListener('mousedown', function (e) { e.preventDefault(); clear(); });
    }
  }

  function initAll() {
    document.querySelectorAll('.typeahead').forEach(initTypeahead);
  }

  window.initTypeahead = initTypeahead;
  window.initTypeaheadAll = initAll;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }
})();
