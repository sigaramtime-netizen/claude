/* Brn Teknoloji ERP — satır içinde yazarak belge satırı ekleme (Fatura / İrsaliye).
 *
 * Akış:
 *   - "+ Satır Ekle" boş bir satır açar.
 *   - Ürün hücresine ad / kod / barkod yazdıkça canlı arama yapılır (dropdown).
 *   - Listeden seçilirse satır stoklu olur (fiyat/KDV/iskonto otomatik dolar, K9).
 *   - Hiçbir stok kartı eşleşmezse satır otomatik "manuel" olur (serbest metin).
 *   - Cari alanı da yazdıkça aranabilir.
 * Formun üzerinde şunlar beklenir:
 *   <form data-tip="Satis" data-manuel-yasak="0">  (Transfer'de manuel-yasak=1)
 *   Cari: <div class="typeahead" data-target="cari-id" data-iskonto="0"> (typeahead.js)
 *   <tbody id="kalemler-body"> + <script type="application/json" id="satirlar-data">
 *   toplam alanları: #t-ara #t-isk #t-kdv #t-genel
 */
(function () {
  "use strict";

  var form = document.querySelector('form[data-belge]');
  if (!form) return;

  var tip = form.getAttribute('data-tip') || 'Satis';
  var manuelYasak = form.getAttribute('data-manuel-yasak') === '1';
  var tbody = document.getElementById('kalemler-body');
  if (!tbody) return;

  var bosMsg = document.getElementById('satir-bos');
  var cariIskonto = 0;

  // Birim listesi (stok.py BIRIMLER ile aynı); #birimler-data varsa onu kullanır.
  var BIRIMLER = ["Adet", "Kutu", "Paket", "Çift", "Takım", "Metre", "m²", "Kg", "Lt", "Top", "Rulo"];
  try {
    var bd = document.getElementById('birimler-data');
    if (bd && bd.textContent.trim()) BIRIMLER = JSON.parse(bd.textContent);
  } catch (e) { /* fallback listede kal */ }

  /* ---------- yardımcılar ---------- */
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function nf(v) { // 1234.5 -> "1.234,50"
    var n = Math.round((parseFloat(v) || 0) * 100) / 100;
    return n.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  // D007 — döviz: para birimi select'i varsa sembolü ona göre göster.
  var SEMBOLLER = { TRY: '₺', USD: '$', EUR: '€', GBP: '£' };
  function paraSembol() {
    var pb = document.getElementById('para-birimi');
    var kod = pb && pb.value ? pb.value : 'TRY';
    return SEMBOLLER[kod] || kod;
  }
  function para(v) { return nf(v) + ' ' + paraSembol(); }

  /* ---------- F2 — KDV dahil/hariç modu ---------- */
  var kdvToggle = document.getElementById('kdv-dahil');
  // D007 — KDV modu artık <select> olabilir (değer "1" = dahil); checkbox geriye dönük uyumlu.
  function kdvModu() { return !!(kdvToggle && (kdvToggle.value === '1' || kdvToggle.checked)); }
  // Gösterilen fiyat → NET (KDV dahil modda brütten ayıklar)
  function fiyatNet(displayed, kdv) {
    var d = parseFloat(displayed) || 0;
    if (!kdvModu()) return d;
    return Math.round(d / (1 + (parseFloat(kdv) || 0) / 100) * 100) / 100;
  }
  // NET fiyat → gösterim (KDV dahil modda brüte çevirir)
  function fiyatGoster(net, kdv) {
    if (!kdvModu()) return net;
    return Math.round((parseFloat(net) || 0) * (1 + (parseFloat(kdv) || 0) / 100) * 100) / 100;
  }

  function positionList(list, input) {
    var r = input.getBoundingClientRect();
    var w = Math.max(r.width, 300);
    var top = r.bottom + 4;
    if (top + 240 > window.innerHeight) top = Math.max(8, r.top - 244);
    list.style.position = 'fixed';
    list.style.top = top + 'px';
    list.style.left = Math.min(r.left, window.innerWidth - w - 8) + 'px';
    list.style.width = w + 'px';
  }

  /* ---------- toplamlar ---------- */
  function hesapla() {
    var ara = 0, isk = 0, kdv = 0;
    tbody.querySelectorAll('tr.satir').forEach(function (tr) {
      var m = parseFloat(tr.querySelector('input[name=k_miktar]').value) || 0;
      var k = parseFloat(tr.querySelector('input[name=k_kdv]').value) || 0;
      var f = fiyatNet(tr.querySelector('input[name=k_birim_fiyat]').value, k);
      var i = parseFloat(tr.querySelector('input[name=k_iskonto]').value) || 0;
      var brut = m * f;
      var iskT = brut * i / 100;
      var net = brut - iskT;
      var kdvT = net * k / 100;
      tr.querySelector('.tutar-cell').textContent = para(net);
      ara += net; isk += iskT; kdv += kdvT;
    });
    var genel = ara + kdv;
    function set(id, v) { var el = document.getElementById(id); if (el) el.textContent = para(v); }
    set('t-ara', ara); set('t-isk', isk); set('t-kdv', kdv); set('t-genel', genel);
  }

  function updateBos() {
    if (bosMsg) bosMsg.style.display = tbody.querySelectorAll('tr.satir').length ? 'none' : '';
  }

  /* ---------- satır ---------- */
  function makeRow(d) {
    d = d || {};
    var tr = document.createElement('tr');
    tr.className = 'satir';
    var birimOpts = BIRIMLER.map(function (b) {
      return '<option value="' + esc(b) + '">' + esc(b) + '</option>';
    }).join('');
    tr.innerHTML =
      '<td class="urun-cell"><div class="ac-wrap">' +
        '<input type="text" class="stok-ara" autocomplete="off" placeholder="Ürün adı, kodu veya barkodu yazın…">' +
        '<span class="badge b-warn satir-durum" style="display:none;">manuel</span>' +
        '<div class="ac-list"></div>' +
      '</div>' +
      '<div class="goruntu-ad-satir">' +
        '<input type="text" class="goruntu-ad" name="k_goruntu_ad" autocomplete="off" placeholder="Görünen ad (boşsa stok adı)">' +
      '</div>' +
      '<input type="hidden" name="k_stok_id" value="">' +
      '<input type="hidden" name="k_varyant_id" value="0">' +
      '<input type="hidden" name="k_manuel_ad" value="">' +
      '</td>' +
      '<td class="num"><input type="number" step="0.01" min="0" name="k_miktar" class="sayi-giris"></td>' +
      '<td><select class="birim-sel" name="k_birim">' + birimOpts + '</select></td>' +
      '<td class="num"><input type="number" step="0.01" min="0" name="k_birim_fiyat" class="sayi-giris"></td>' +
      '<td class="num"><input type="number" step="0.01" min="0" name="k_iskonto" class="sayi-giris"></td>' +
      '<td class="num"><input type="number" step="0.01" min="0" name="k_kdv" class="sayi-giris"></td>' +
      '<td class="num tutar-cell">0,00 ₺</td>' +
      '<td class="right"><button type="button" class="btn sm danger satir-sil" title="Satırı sil">✕</button></td>';

    var ara = tr.querySelector('.stok-ara');
    var list = tr.querySelector('.ac-list');
    var durum = tr.querySelector('.satir-durum');

    function q(name) { return tr.querySelector('input[name=' + name + ']'); }

    function setDurum(kind, text) {
      if (!text) { durum.style.display = 'none'; return; }
      durum.style.display = '';
      durum.textContent = text;
      durum.className = 'badge ' + (kind === 'manuel' ? 'b-warn' : 'b-muted') + ' satir-durum';
    }

    function applyStok(it) {
      q('k_stok_id').value = it.id;
      q('k_varyant_id').value = it.varyant_id || 0;
      q('k_manuel_ad').value = '';
      var fiyat = tip === 'Alis' ? (it.alis_fiyat || 0) : (it.satis_fiyat || 0);
      q('k_kdv').value = (it.kdv_orani != null ? it.kdv_orani : 20);
      // F2 — KDV dahil modda stok kartının NET fiyatı brüt olarak gösterilir.
      q('k_birim_fiyat').value = fiyatGoster(fiyat, q('k_kdv').value);
      // K9 iskonto önceliği: stok özel > cari > 0
      var isk = (it.iskonto_orani || 0) > 0 ? it.iskonto_orani : (cariIskonto || 0);
      q('k_iskonto').value = isk;
      setBirim(it.birim || 'Adet');
      // Görünen ad (K34.7): boşsa belgede stok adı gösterilir.
      var gaRow = tr.querySelector('.goruntu-ad-satir');
      var ga = tr.querySelector('.goruntu-ad');
      if (ga) { ga.value = ''; ga.placeholder = 'Görünen ad (boşsa: ' + it.ad + ')'; }
      if (gaRow) gaRow.style.display = '';
      ara.value = it.kod + ' — ' + it.ad + (it.varyant_ad ? ' (' + it.varyant_ad + ')' : '');
      setDurum('stok', it.kod + (it.varyant_id ? '·' + it.varyant_ad : ''));
      hesapla();
    }

    function setBirim(value) {
      var sel = tr.querySelector('select[name=k_birim]');
      if (!sel) return;
      var v = value || 'Adet';
      var found = false;
      for (var i = 0; i < sel.options.length; i++) { if (sel.options[i].value === v) found = true; }
      if (!found) {
        var o = document.createElement('option');
        o.value = v; o.textContent = v;
        sel.appendChild(o);
      }
      sel.value = v;
    }

    function markManual(text) {
      q('k_stok_id').value = '';
      q('k_varyant_id').value = 0;
      q('k_manuel_ad').value = text;
      var gaRow = tr.querySelector('.goruntu-ad-satir');
      if (gaRow) gaRow.style.display = 'none';
      var ga = tr.querySelector('.goruntu-ad');
      if (ga) ga.value = '';
      setDurum('manuel', text ? 'manuel' : '');
      hesapla();
    }

    function clearRow() {
      q('k_stok_id').value = '';
      q('k_varyant_id').value = 0;
      q('k_manuel_ad').value = '';
      var gaRow = tr.querySelector('.goruntu-ad-satir');
      if (gaRow) gaRow.style.display = 'none';
      var ga = tr.querySelector('.goruntu-ad');
      if (ga) ga.value = '';
      setBirim('Adet');
      setDurum('manuel', '');
      hesapla();
    }

    /* ---- canlı arama durumu ---- */
    var picked = false, settled = false, items = [], sel = -1, timer = null, seq = 0;

    function renderList() {
      list.innerHTML = '';
      if (!items.length) {
        if (ara.value.trim() && !manuelYasak) {
          list.innerHTML = '<div class="ac-no">Eşleşme yok — bırakınca bu satır <b>manuel</b> olur.</div>';
          positionList(list, ara);
          list.classList.add('acik');
        } else if (ara.value.trim() && manuelYasak) {
          list.innerHTML = '<div class="ac-no">Eşleşme yok (transferde yalnız stoklu satır).</div>';
          positionList(list, ara);
          list.classList.add('acik');
        } else {
          list.classList.remove('acik');
        }
        return;
      }
      items.forEach(function (it, i) {
        var d = document.createElement('div');
        d.className = 'ac-item' + (i === sel ? ' aktif' : '');
        var vAd = it.varyant_ad ? ' <span class="ac-muted">— ' + esc(it.varyant_ad) + '</span>' : '';
        var birim = it.birim ? ' <span class="ac-muted">' + esc(it.birim) + '</span>' : '';
        d.innerHTML = '<span class="ac-kod">' + esc(it.kod) + '</span>' +
          '<span class="ac-ad">' + esc(it.ad) + vAd + birim + '</span>';
        d.addEventListener('mousedown', function (e) { e.preventDefault(); pick(it); });
        list.appendChild(d);
      });
      positionList(list, ara);
      list.classList.add('acik');
    }

    function closeList() { list.classList.remove('acik'); list.innerHTML = ''; }

    function pick(it) {
      picked = true;
      settled = true;
      applyStok(it);
      closeList();
    }

    function fetchList(qtext) {
      var my = ++seq;                     // yarış durumu koruması: yalnız en son istek uygulanır
      fetch('/api/ara?tip=stok&q=' + encodeURIComponent(qtext))
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (my !== seq) return;         // araya daha yeni bir istek girdiyse bu eski yanıtı yok say
          if (document.activeElement !== ara) return;
          items = data || []; sel = -1;
          renderList();
        })
        .catch(function () { closeList(); });
    }

    /* ---- karar: seçilmediyse manuel / tam eşleşme ---- */
    function resolve() {
      if (settled) return;
      var text = ara.value.trim();
      if (!text) { clearRow(); settled = true; return; }
      // Senkron: kaydet'e hemen basılsa bile veri kaybolmasın → önce manuel kabul et.
      if (!manuelYasak) markManual(text);
      settled = true;
      // Asenkron: tam eşleşme (kod / barkod / ad) varsa stoğa yükselt.
      var my = ++seq;
      fetch('/api/ara?tip=stok&q=' + encodeURIComponent(text))
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (my !== seq) return;               // daha yeni bir istek varsa eski yanıtı yok say
          if (ara.value.trim() !== text) return;  // kullanıcı bu arada değiştirdiyse vazgeç
          var list2 = data || [];
          var ex = null;
          for (var i = 0; i < list2.length; i++) {
            var s = list2[i];
            if (s.kod && s.kod.toLowerCase() === text.toLowerCase()) { ex = s; break; }
          }
          if (!ex) for (var j = 0; j < list2.length; j++) {
            if (list2[j].barkod && list2[j].barkod === text) { ex = list2[j]; break; }
          }
          if (!ex) for (var k2 = 0; k2 < list2.length; k2++) {
            if (!list2[k2].varyant_id && list2[k2].ad && list2[k2].ad.toLowerCase() === text.toLowerCase()) { ex = list2[k2]; break; }
          }
          if (ex) {
            applyStok(ex);
            settled = true;
          } else if (manuelYasak) {
            clearRow();
            settled = true;
            ara.value = '';
            var hint = tr.querySelector('.ac-hint');
            if (!hint) {
              hint = document.createElement('div');
              hint.className = 'ac-hint-danger';
              tr.querySelector('.urun-cell').appendChild(hint);
            }
            hint.textContent = "Transfer'de yalnız stoklu satır eklenebilir.";
            setTimeout(function () { if (hint.parentNode) hint.remove(); }, 2500);
          }
        })
        .catch(function () {});
    }

    ara.addEventListener('input', function () {
      picked = false;
      settled = false;
      q('k_stok_id').value = '';
      q('k_varyant_id').value = '0';
      q('k_manuel_ad').value = '';
      setDurum('manuel', '');
      var gaRow = tr.querySelector('.goruntu-ad-satir');
      if (gaRow) gaRow.style.display = 'none';
      var ga = tr.querySelector('.goruntu-ad');
      if (ga) ga.value = '';
      var qtext = ara.value.trim();
      if (!qtext) { closeList(); hesapla(); return; }
      clearTimeout(timer);
      timer = setTimeout(function () { fetchList(qtext); }, 170);
    });

    ara.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        if (!list.classList.contains('acik') || !items.length) return;
        e.preventDefault();
        sel = (sel + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
        renderList();
      } else if (e.key === 'Enter') {
        if (list.classList.contains('acik') && sel >= 0) {
          e.preventDefault();
          pick(items[sel]);
        } else {
          e.preventDefault();
          closeList();
          resolve();
        }
      } else if (e.key === 'Escape') {
        closeList();
      }
    });

    ara.addEventListener('blur', function () {
      closeList();
      setTimeout(function () { if (!settled) resolve(); }, 120);
    });

    tr.querySelector('.satir-sil').addEventListener('click', function () {
      tr.remove();
      updateBos();
      hesapla();
    });

    /* ---- başlangıç değerleri ---- */
    q('k_miktar').value = (d.miktar != null ? d.miktar : 1);
    q('k_iskonto').value = (d.iskonto_orani != null ? d.iskonto_orani : 0);
    q('k_kdv').value = (d.kdv_orani != null ? d.kdv_orani : 20);
    // F2 — KDV dahil modda net fiyat brüt olarak gösterilir (satır verisi daima NET gelir).
    q('k_birim_fiyat').value = fiyatGoster((d.birim_fiyat != null ? d.birim_fiyat : 0),
                                           q('k_kdv').value);
    setBirim(d.birim || 'Adet');
    if (d.stok_id) {
      q('k_stok_id').value = d.stok_id;
      q('k_varyant_id').value = d.varyant_id || 0;
      q('k_manuel_ad').value = '';
      ara.value = (d.stok_kod || '') + (d.stok_kod && d.stok_ad ? ' — ' : '') + (d.stok_ad || '');
      var gaRow0 = tr.querySelector('.goruntu-ad-satir');
      var ga0 = tr.querySelector('.goruntu-ad');
      if (ga0) { ga0.value = d.goruntu_adi || ''; ga0.placeholder = 'Görünen ad (boşsa: ' + (d.stok_ad || '') + ')'; }
      if (gaRow0) gaRow0.style.display = '';
      setDurum('stok', d.stok_kod || '');
    } else if (d.manuel_ad) {
      q('k_manuel_ad').value = d.manuel_ad;
      ara.value = d.manuel_ad;
      setDurum('manuel', 'manuel');
    }

    return tr;
  }

  /* ---------- başlangıç satırları ---------- */
  var initial = [];
  try { initial = JSON.parse(document.getElementById('satirlar-data').textContent || '[]'); } catch (e) { initial = []; }
  initial.forEach(function (d) { tbody.appendChild(makeRow(d)); });
  updateBos();
  hesapla();

  /* ---------- "+ Satır Ekle" ---------- */
  var ekleBtn = document.getElementById('satir-ekle');
  if (ekleBtn) ekleBtn.addEventListener('click', function () {
    var tr = makeRow(null);
    tbody.appendChild(tr);
    updateBos();
    hesapla();
    tr.querySelector('.stok-ara').focus();
  });

  /* ---------- sayı girişleri → canlı toplam ---------- */
  tbody.addEventListener('input', function (e) { if (e.target.classList.contains('sayi-giris')) hesapla(); });
  tbody.addEventListener('change', function (e) { if (e.target.classList.contains('sayi-giris')) hesapla(); });

  /* ---------- F2 — KDV dahil/hariç modu değişimi: fiyatları anında çevir ---------- */
  if (kdvToggle) {
    kdvToggle.addEventListener('change', function () {
      tbody.querySelectorAll('tr.satir').forEach(function (tr) {
        var fEl = tr.querySelector('input[name=k_birim_fiyat]');
        var kdv = parseFloat(tr.querySelector('input[name=k_kdv]').value) || 0;
        var cur = parseFloat(fEl.value) || 0;
        if (kdvModu()) fEl.value = Math.round(cur * (1 + kdv / 100) * 100) / 100;
        else fEl.value = Math.round(cur / (1 + kdv / 100) * 100) / 100;
      });
      hesapla();
    });
  }

  /* ---------- cari — F3: typeahead.js widget'ı; burada yalnız iskonto senkronu ---------- */
  var cariTa = document.querySelector('.typeahead[data-target="cari-id"]');
  if (cariTa) cariIskonto = parseFloat(cariTa.getAttribute('data-iskonto') || 0) || 0;
  document.addEventListener('ta:select', function (e) {
    var d = e.detail || {};
    if (d.targetId === 'cari-id') {
      cariIskonto = parseFloat((d.item && d.item.iskonto_orani) || 0) || 0;
    }
  });
})();
