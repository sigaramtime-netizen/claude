# -*- coding: utf-8 -*-
"""İstek 3 — Çoklu Şirket: oturum bazlı aktif şirket geçişi.

- `POST /sirket/gec` → sessionler.sirket_id günceller (N-N üyelik doğrulamalı).
- Şirket CRUD (Ayarlar > Şirketler) Adım 5'te gelir.
"""
import db
from core import route, redirect, flash


@route(r"/sirket/gec", methods=("POST",), roles=())
def sirket_gec(req):
    ham = (req.form.get("sirket_id") or "").strip()
    if not ham.isdigit():
        flash(req, "Geçersiz şirket seçimi.", "danger")
        return redirect("/")
    hedef = int(ham)
    conn = db.get_conn()
    # N-N üyelik: Admin tüm aktif şirketlere; diğer kullanıcılar kullanici_sirket'tekilerine.
    if req.user["rol"] == "Admin":
        izinli = {r["id"] for r in conn.execute(
            "SELECT id FROM sirket WHERE aktif=1").fetchall()}
    else:
        izinli = {r["id"] for r in conn.execute(
            "SELECT sirket_id AS id FROM kullanici_sirket WHERE kullanici_id=?",
            (req.user["id"],)).fetchall()}
    if hedef not in izinli:
        conn.close()
        flash(req, "Bu şirkete erişim yetkiniz yok.", "danger")
        return redirect("/")
    conn.execute("UPDATE sessionler SET sirket_id=? WHERE token=?",
                 (hedef, req.session_token))
    conn.commit()
    conn.close()
    flash(req, "Aktif şirket değiştirildi.", "ok")
    nxt = (req.form.get("next") or "").strip()
    if not nxt.startswith("/"):
        nxt = "/"
    return redirect(nxt)
