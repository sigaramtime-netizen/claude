# -*- coding: utf-8 -*-
"""Notlar modülü (Faz 3 — 1.1): serbest metin not defteri.

- `notlar` tablosu Faz 1'den beri cari/stok kartlarında ilişkisel not olarak kullanılıyor;
  bu modül ona bağımsız bir "hızlı not" ekranı getirir (liste + yeni + sil).
- Etiketleme: boşlukla ayrılmış #etiket metinleri (örn. "#öncelikli #tahsilat").
- Hatırlatma: `hatirlatma` tarihi girilirse app.py'deki tarama bunu otomatik bildirime çevirir.
"""
import datetime

import db
from core import route, render_template, redirect, flash, audit

# ilgili_tablo -> (etiket, tablo, görünen kolon, url öneki)
ILGILI = {
    "cari_kart": ("Cari", "cari_kart", "unvan", "/cari/"),
    "servis_kayit": ("Servis", "servis_kayit", "servis_no", "/servis/"),
    "fatura": ("Fatura", "fatura", "fatura_no", "/fatura/"),
}


def _etiket_listesi(v):
    return [t for t in (v or "").split() if t.startswith("#")]


@route(r"/notlar", roles=())
def notlar_liste(req):
    conn = db.get_conn()
    where, params = ["1=1"], []
    q = (req.q("q") or "").strip()
    if q:
        where.append("(n.metin LIKE ? OR n.etiketler LIKE ?)")
        params += [f"%{q}%", f"%{q}%"]
    etiket = (req.q("etiket") or "").strip()
    if etiket:
        where.append("n.etiketler LIKE ?")
        params.append(f"%{etiket}%")
    hatirli = req.q("hatirli")
    if hatirli == "1":
        where.append("n.hatirlatma IS NOT NULL")
    where.insert(0, "n.sirket_id = ?")
    params.insert(0, db.sirket_id(req))
    rows = [dict(r) for r in conn.execute(
        "SELECT n.*, u.kullanici_adi AS kullanici FROM notlar n "
        "LEFT JOIN kullanici u ON u.id=n.kullanici_id WHERE " + " AND ".join(where) +
        " ORDER BY COALESCE(n.hatirlatma,'9999') ASC, n.id DESC LIMIT 200",
        params,
    ).fetchall()]
    bugun = datetime.date.today().isoformat()
    for r in rows:
        r["etiketler_l"] = _etiket_listesi(r["etiketler"])
        r["gecmis"] = bool(r["hatirlatma"] and r["hatirlatma"] < bugun)
        if r["ilgili_tablo"] in ILGILI:
            label, tablo, kolon, url = ILGILI[r["ilgili_tablo"]]
            hedef = conn.execute(
                f"SELECT {kolon} AS g FROM {tablo} WHERE id=?", (r["ilgili_id"],)).fetchone()
            r["ilgili_label"] = label
            r["ilgili_ad"] = hedef["g"] if hedef else "—"
            r["ilgili_url"] = url + str(r["ilgili_id"]) if hedef else None
    conn.close()
    return render_template("notlar/liste.html", rows=rows, q=q, etiket=etiket, hatirli=hatirli,
                           bugun=bugun)


@route(r"/notlar/yeni", methods=("GET", "POST"), roles=())
def notlar_yeni(req):
    conn = db.get_conn()
    if req.method == "POST":
        metin = (req.form.get("metin") or "").strip()
        if not metin:
            flash(req, "Not metni boş olamaz.", "danger")
            conn.close()
            return redirect("/notlar/yeni")
        etiketler = " ".join(t for t in (req.form.get("etiketler") or "").split() if t.startswith("#"))
        hatirlatma = (req.form.get("hatirlatma") or "").strip() or None
        ilgili_tablo, ilgili_id = None, None
        ilgili_ref = (req.form.get("ilgili_ref") or "").strip()
        if "|" in ilgili_ref:
            t, i = ilgili_ref.split("|", 1)
            if t in ILGILI and i.strip().isdigit():
                ilgili_tablo, ilgili_id = t, int(i)
        cur = conn.execute(
            "INSERT INTO notlar(ilgili_tablo, ilgili_id, metin, etiketler, hatirlatma, kullanici_id, sirket_id) "
            "VALUES(?,?,?,?,?,?,?)",
            (ilgili_tablo or "", int(ilgili_id) if ilgili_id else 0, metin,
             etiketler or None, hatirlatma, req.user["id"], db.sirket_id(req)),
        )
        conn.commit()
        audit(req, "notlar", cur.lastrowid, "olustur", {"metin": metin[:80]})
        conn.close()
        flash(req, "Not kaydedildi.", "ok")
        return redirect("/notlar")

    sid = db.sirket_id(req)
    cariler = conn.execute("SELECT id, unvan FROM cari_kart WHERE aktif=1 AND sirket_id=? ORDER BY unvan",
                           (sid,)).fetchall()
    servisler = conn.execute("SELECT id, servis_no, cihaz FROM servis_kayit WHERE sirket_id=? ORDER BY id DESC LIMIT 100",
                             (sid,)).fetchall()
    faturalar = conn.execute("SELECT id, fatura_no FROM fatura WHERE sirket_id=? ORDER BY id DESC LIMIT 100",
                             (sid,)).fetchall()
    conn.close()
    return render_template("notlar/form.html", cariler=cariler, servisler=servisler,
                           faturalar=faturalar, bugun=datetime.date.today().isoformat())


@route(r"/notlar/(?P<nid>\d+)/sil", methods=("POST",), roles=())
def notlar_sil(req, nid):
    conn = db.get_conn()
    r = conn.execute("SELECT * FROM notlar WHERE id=? AND sirket_id=?",
                     (int(nid), db.sirket_id(req))).fetchone()
    if r:
        conn.execute("DELETE FROM notlar WHERE id=?", (int(nid),))
        conn.commit()
        audit(req, "notlar", int(nid), "sil", {"metin": (r["metin"] or "")[:80]})
        flash(req, "Not silindi.", "ok")
    conn.close()
    return redirect("/notlar")
