# -*- coding: utf-8 -*-
"""Faz 6 — Bildirim sağlayıcı soyutlaması (SMS / e-posta entegrasyon noktası).

e-belge entegratörüyle (Faz 4) aynı desen: soyut `Saglayici` + `MockSaglayici` (sandbox).
Gerçek bir SMS/e-posta sağlayıcısına geçişte yalnızca yeni bir `Saglayici` sınıfı yazılır ve
`aktif_saglayici` ona döner; uygulama kodu değişmez. Ayar `meta` tablosunda tutulur
(anahtar: `bildirim.kanal` — kapali/sms/eposta).

Gönderimler `bildirim_gonderim` tablosuna günlüklenir (mock'ta durum doğrudan 'Gonderildi').
"""
import db

KANALLAR = ("sms", "eposta")


class Saglayici:
    """Soyut dış bildirim sağlayıcısı (SMS/e-posta)."""

    def gonder(self, conn, hedef, kanal, baslik, mesaj, ilgili_tablo, ilgili_id, bildirim_id):
        raise NotImplementedError


class MockSaglayici(Saglayici):
    """Sandbox sağlayıcı: gönderimi `bildirim_gonderim` günlüğüne 'Gonderildi' (mock) yazar."""

    def gonder(self, conn, hedef, kanal, baslik, mesaj, ilgili_tablo, ilgili_id, bildirim_id):
        cur = conn.execute(
            "INSERT INTO bildirim_gonderim(bildirim_id, kanal, hedef, baslik, mesaj, "
            "ilgili_tablo, ilgili_id, durum) VALUES(?,?,?,?,?,?,?,'Gonderildi')",
            (bildirim_id, kanal, hedef, baslik, mesaj, ilgili_tablo, ilgili_id),
        )
        return cur.lastrowid


def _kanal_ayari(conn):
    row = conn.execute("SELECT deger FROM meta WHERE anahtar='bildirim.kanal'").fetchone()
    return (row["deger"] if row else "kapali").lower()


def aktif_saglayici(conn):
    """Etkin sağlayıcıyı döndürür; kanal kapalıysa None."""
    return MockSaglayici() if _kanal_ayari(conn) in KANALLAR else None


def gonder(hedef=None, kanal=None, baslik="", mesaj="", ilgili_tablo=None, ilgili_id=None,
           bildirim_id=None):
    """Sağlayıcı üzerinden bildirim gönder; kanal kapalı/geçersizse sessizce atlar.

    Dönüş: gönderim günlüğü id'si veya None.
    """
    if not hedef or kanal not in KANALLAR:
        return None
    conn = db.get_conn()
    sg = aktif_saglayici(conn)
    if sg is None:
        conn.close()
        return None
    rid = sg.gonder(conn, hedef, kanal, baslik, mesaj, ilgili_tablo, ilgili_id, bildirim_id)
    conn.commit()
    conn.close()
    return rid


def ayar_guncelle(kanal):
    """Kanal ayarını güncelle ('kapali', 'sms', 'eposta')."""
    if kanal not in ("kapali",) + KANALLAR:
        return False
    conn = db.get_conn()
    conn.execute(
        "INSERT INTO meta(anahtar, deger) VALUES('bildirim.kanal', ?) "
        "ON CONFLICT(anahtar) DO UPDATE SET deger=excluded.deger",
        (kanal,),
    )
    conn.commit()
    conn.close()
    return True
