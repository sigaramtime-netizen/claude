# -*- coding: utf-8 -*-
"""B2 — Alınan Teklif + Teklif Değerlendirme e2e testi.

Kapsam (faz protokolü örnek senaryosu):
  1. Kalemsiz teklif oluşturulamaz.
  2. Tedarikçisiz teklif oluşturulamaz.
  3. Teklif oluşturulur (Taslak, ALT-{YYYY}-NNN).
  4. Taslak düzenlenir (miktar değişir).
  5. Alındı geçişi.
  6. Kazanan seçme yetkisi olmayan (Satis) seçemez.
  7. Tek kazanan kuralı (yeni kazanan eskiyi geri alır).
  8. Kazanan tekliften SAP üretilir; kalem + para_birimi + doviz_kur taşınır.
  9. Talep bağlıysa talep de Siparişe Dönüştü olur.
  10. İkinci dönüşüm engellenir.
  11. Ele işaretleme.
  12. Silme kuralları (Taslak silinir; Alındı silinemez).
  13. Döviz teklifi: TRY karşılığı = genel_toplam × kur; SAP'ye kur sabitlenir.
  14. Şirket izolasyonu + bağımsız sayaç (B şirketi ALT-2026-001).

Çalıştırma: sunucu 8080'de çalışırken  python3 test_alinan_teklif.py
"""
import datetime
import sqlite3
import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
KOD = "ALTB"
YIL = datetime.date.today().year

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else ""))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris(kullanici="admin"):
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": kullanici, "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, f"giriş başarısız ({kullanici})"
    return s


def talep_olustur(s, stok_id, miktar, gerekce):
    s.post(BASE + "/satin-alma/talepler/yeni", data=[
        ("kaynak", "Yurt İçi"), ("gerekce", gerekce),
        ("k_stok_id", str(stok_id)), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
        ("k_birim", "Adet"), ("k_miktar", str(miktar)),
        ("k_birim_fiyat", "10000"), ("k_oncelik", "Normal"),
    ], allow_redirects=False)
    return db1("SELECT id FROM satin_alma_talebi WHERE gerekce=? ORDER BY id DESC", gerekce)


def teklif_olustur(s, tedarikci_id, miktar, fiyat, aciklama, talep_id=None,
                   pb="TRY", kur="", stok_id=3, manuel_ad=""):
    data = [
        ("tedarikci_id", str(tedarikci_id)),
        ("talep_id", str(talep_id) if talep_id else ""),
        ("depo_id", ""), ("tarih", datetime.date.today().isoformat()),
        ("gecerlilik_tarihi", "2026-12-31"), ("para_birimi", pb),
        ("doviz_kur", str(kur)), ("teslim_suresi_gun", "7"), ("odeme_vadesi_gun", "30"),
        ("aciklama", aciklama),
        ("k_stok_id", str(stok_id)), ("k_varyant_id", "0"), ("k_manuel_ad", manuel_ad),
        ("k_birim", "Adet"), ("k_miktar", str(miktar)), ("k_birim_fiyat", str(fiyat)),
        ("k_iskonto", "0"), ("k_kdv", "20"),
    ]
    s.post(BASE + "/satin-alma/teklifler/yeni", data=data, allow_redirects=False)
    return db1("SELECT * FROM alinan_teklif WHERE aciklama=? ORDER BY id DESC", aciklama)


def durum(s, tid, hedef):
    s.post(BASE + f"/satin-alma/teklifler/{tid}/durum",
           data={"hedef": hedef}, allow_redirects=False)


def main():
    admin = giris("admin")
    satis = giris("satis")

    # --- 0. Kalıntı temizliği ---
    eski = db1("SELECT id FROM sirket WHERE kod=?", KOD)
    if eski:
        sid = eski["id"]
        for t in ("alinan_teklif_kalem", "alinan_teklif", "satin_alma_talebi_kalem",
                  "satin_alma_talebi", "siparis_kalem", "siparis",
                  "cari_kart", "hesap", "demirbas_kategori", "depo", "kullanici_sirket"):
            dbx(f"DELETE FROM {t} WHERE sirket_id=?", sid)
        dbx("DELETE FROM sirket WHERE id=?", sid)
    dbx("DELETE FROM alinan_teklif_kalem WHERE teklif_id IN "
        "(SELECT id FROM alinan_teklif WHERE aciklama LIKE 'ALT-TEST-%')")
    dbx("DELETE FROM alinan_teklif WHERE aciklama LIKE 'ALT-TEST-%'")
    dbx("DELETE FROM satin_alma_talebi_kalem WHERE talep_id IN "
        "(SELECT id FROM satin_alma_talebi WHERE gerekce LIKE 'SAT-TEST-ALT-%')")
    dbx("DELETE FROM satin_alma_talebi WHERE gerekce LIKE 'SAT-TEST-ALT-%'")
    dbx("DELETE FROM siparis_kalem WHERE siparis_id IN "
        "(SELECT id FROM siparis WHERE aciklama LIKE '%ALT-TEST%')")
    dbx("DELETE FROM siparis WHERE aciklama LIKE '%ALT-TEST%'")

    # --- 1. Kalemsiz teklif engeli ---
    once = db1("SELECT COUNT(*) c FROM alinan_teklif WHERE sirket_id=1")["c"]
    r = admin.post(BASE + "/satin-alma/teklifler/yeni", data=[
        ("tedarikci_id", "5"), ("aciklama", "ALT-TEST-BOS"),
        ("k_stok_id", ""), ("k_manuel_ad", ""), ("k_miktar", ""),
    ], allow_redirects=False)
    sonra = db1("SELECT COUNT(*) c FROM alinan_teklif WHERE sirket_id=1")["c"]
    check("Kalemsiz teklif oluşturulamadı", once == sonra and r.status_code == 200,
          f"once={once} sonra={sonra}")

    # --- 2. Tedarikçisiz teklif engeli ---
    once = db1("SELECT COUNT(*) c FROM alinan_teklif WHERE sirket_id=1")["c"]
    admin.post(BASE + "/satin-alma/teklifler/yeni", data=[
        ("tedarikci_id", ""), ("aciklama", "ALT-TEST-TEDYOK"),
        ("k_stok_id", "3"), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
        ("k_birim", "Adet"), ("k_miktar", "1"), ("k_birim_fiyat", "100"),
        ("k_iskonto", "0"), ("k_kdv", "20"),
    ], allow_redirects=False)
    sonra = db1("SELECT COUNT(*) c FROM alinan_teklif WHERE sirket_id=1")["c"]
    check("Tedarikçisiz teklif oluşturulamadı", once == sonra)

    # --- 3. Teklif oluştur (Taslak) ---
    t1 = teklif_olustur(admin, 5, 2, 10000, "ALT-TEST-A1")
    check("Teklif oluştu (Taslak)", t1 is not None and t1["durum"] == "Taslak",
          f"no={t1['teklif_no'] if t1 else '-'}")
    check("Belge no formatı ALT-yıl-NNN", t1 and t1["teklif_no"].startswith(f"ALT-{YIL}-"),
          t1["teklif_no"] if t1 else "-")
    check("Kalem + toplam (2×10000, %20 KDV → 24000)",
          t1 and abs(t1["genel_toplam"] - 24000.0) < 0.01, f"toplam={t1['genel_toplam'] if t1 else '-'}")

    # --- 4. Taslak düzenle (miktar 2→3 → toplam 36000) ---
    admin.post(BASE + f"/satin-alma/teklifler/{t1['id']}/duzenle", data=[
        ("tedarikci_id", "5"), ("talep_id", ""), ("depo_id", ""),
        ("tarih", datetime.date.today().isoformat()), ("gecerlilik_tarihi", "2026-12-31"),
        ("para_birimi", "TRY"), ("doviz_kur", "1"), ("teslim_suresi_gun", "7"),
        ("odeme_vadesi_gun", "30"), ("aciklama", "ALT-TEST-A1"),
        ("k_stok_id", "3"), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
        ("k_birim", "Adet"), ("k_miktar", "3"), ("k_birim_fiyat", "10000"),
        ("k_iskonto", "0"), ("k_kdv", "20"),
    ], allow_redirects=False)
    t1 = db1("SELECT * FROM alinan_teklif WHERE id=?", t1["id"])
    check("Taslak düzenlendi (genel toplam 36000)", abs(t1["genel_toplam"] - 36000.0) < 0.01,
          f"toplam={t1['genel_toplam']}")

    # --- 5. Alındı geçişi ---
    durum(admin, t1["id"], "alindi")
    check("Alındı yapıldı", db1("SELECT durum FROM alinan_teklif WHERE id=?", t1["id"])["durum"] == "Alındı")

    # --- 6. Yetkisiz kazanan (Satis) engeli ---
    satis.post(BASE + f"/satin-alma/teklifler/{t1['id']}/durum",
               data={"hedef": "kazanan"}, allow_redirects=False)
    check("Satis kazanan seçemedi (yetki)",
          db1("SELECT durum FROM alinan_teklif WHERE id=?", t1["id"])["durum"] == "Alındı")

    # --- 7. Kazanan + SAP + talep dönüşümü ---
    talep1 = talep_olustur(admin, 3, 2, "SAT-TEST-ALT-T1")
    tA = teklif_olustur(admin, 5, 2, 10000, "ALT-TEST-K1", talep_id=talep1["id"])
    tB = teklif_olustur(admin, 6, 2, 9800, "ALT-TEST-K2", talep_id=talep1["id"])
    durum(admin, tA["id"], "alindi")
    durum(admin, tB["id"], "alindi")
    durum(admin, tA["id"], "kazanan")
    check("İlk teklif Kazanan", db1("SELECT durum FROM alinan_teklif WHERE id=?", tA["id"])["durum"] == "Kazanan")
    durum(admin, tB["id"], "kazanan")
    check("Tek kazanan kuralı (eski kazanan geri alındı)",
          db1("SELECT durum FROM alinan_teklif WHERE id=?", tA["id"])["durum"] == "Alındı" and
          db1("SELECT durum FROM alinan_teklif WHERE id=?", tB["id"])["durum"] == "Kazanan")

    admin.post(BASE + f"/satin-alma/teklifler/{tB['id']}/siparise-donustur",
               allow_redirects=False)
    tB = db1("SELECT * FROM alinan_teklif WHERE id=?", tB["id"])
    check("Teklif Siparişe Dönüştü", tB["durum"] == "Siparişe Dönüştü" and tB["donusen_siparis_id"] is not None)
    sap = db1("SELECT * FROM siparis WHERE id=?", tB["donusen_siparis_id"]) if tB["donusen_siparis_id"] else None
    check("SAP üretildi (Bekliyor, Alis)", sap and sap["tip"] == "Alis" and sap["durum"] == "Bekliyor",
          f"no={sap['siparis_no'] if sap else '-'}")
    check("SAP kalemi kopyalandı (2×9800, %20 → 23520)",
          sap and abs(sap["genel_toplam"] - 23520.0) < 0.01, f"toplam={sap['genel_toplam'] if sap else '-'}")
    talep1 = db1("SELECT * FROM satin_alma_talebi WHERE id=?", talep1["id"])
    check("Bağlı talep de Siparişe Dönüştü",
          talep1["durum"] == "Siparişe Dönüştü" and talep1["donusen_siparis_id"] == tB["donusen_siparis_id"])

    # --- 8. İkinci dönüşüm engeli ---
    admin.post(BASE + f"/satin-alma/teklifler/{tB['id']}/siparise-donustur",
               allow_redirects=False)
    adet = db1("SELECT COUNT(*) c FROM siparis WHERE aciklama LIKE ?",
               f"%{tB['teklif_no']} teklifinden%")["c"]
    check("İkinci dönüşüm engellendi (tek SAP)", adet == 1, f"sap_adet={adet}")

    # --- 9. Ele işaretleme ---
    t2 = teklif_olustur(admin, 5, 1, 5000, "ALT-TEST-A2")
    durum(admin, t2["id"], "alindi")
    durum(admin, t2["id"], "ele")
    check("Ele işaretlendi", db1("SELECT durum FROM alinan_teklif WHERE id=?", t2["id"])["durum"] == "Elendi")

    # --- 10. Silme kuralları ---
    t3 = teklif_olustur(admin, 5, 1, 1000, "ALT-TEST-A3")  # Taslak
    admin.post(BASE + f"/satin-alma/teklifler/{t3['id']}/sil", allow_redirects=False)
    check("Taslak teklif silindi", db1("SELECT id FROM alinan_teklif WHERE id=?", t3["id"]) is None)
    t4 = teklif_olustur(admin, 5, 1, 1000, "ALT-TEST-A4")
    durum(admin, t4["id"], "alindi")
    admin.post(BASE + f"/satin-alma/teklifler/{t4['id']}/sil", allow_redirects=False)
    check("Alındı teklif silinemedi", db1("SELECT id FROM alinan_teklif WHERE id=?", t4["id"]) is not None)

    # --- 11. Döviz teklifi ---
    t5 = teklif_olustur(admin, 5, 1, 100, "ALT-TEST-USD", pb="USD", kur="30")
    check("USD teklif genel toplam 120 (100 + %20)", abs(t5["genel_toplam"] - 120.0) < 0.01,
          f"toplam={t5['genel_toplam']} kur={t5['doviz_kur']}")
    durum(admin, t5["id"], "alindi")
    durum(admin, t5["id"], "kazanan")
    admin.post(BASE + f"/satin-alma/teklifler/{t5['id']}/siparise-donustur",
               allow_redirects=False)
    t5 = db1("SELECT * FROM alinan_teklif WHERE id=?", t5["id"])
    sap5 = db1("SELECT * FROM siparis WHERE id=?", t5["donusen_siparis_id"])
    check("SAP'ye para birimi + kur sabitlendi",
          sap5 and sap5["para_birimi"] == "USD" and abs(sap5["doviz_kur"] - 30.0) < 0.001,
          f"pb={sap5['para_birimi'] if sap5 else '-'} kur={sap5['doviz_kur'] if sap5 else '-'}")

    # --- 12. Şirket izolasyonu + bağımsız sayaç ---
    admin.post(BASE + "/ayarlar/sirketler", data={"kod": KOD, "unvan": "Teklif İzolasyon A.Ş."},
               allow_redirects=False)
    b_id = db1("SELECT id FROM sirket WHERE kod=?", KOD)["id"]
    admin.post(BASE + "/sirket/gec", data={"sirket_id": str(b_id), "next": "/"}, allow_redirects=False)
    rb = admin.get(BASE + "/satin-alma/teklifler").text
    check("B şirketinde A teklifleri görünmüyor",
          "ALT-2026-001" not in rb and "ALT-TEST-A1" not in rb)
    admin.post(BASE + "/cari/yeni", data={"unvan": "ALTB Tedarikçi", "tip": "Tedarikci"},
               allow_redirects=False)
    b_ted = db1("SELECT id FROM cari_kart WHERE unvan='ALTB Tedarikçi'")["id"]
    tb = teklif_olustur(admin, b_ted, 1, 200, "ALT-TEST-B1", stok_id="", manuel_ad="ISO parça")
    check("B'de teklif sayacı bağımsız (ALT-2026-001)", tb and tb["teklif_no"] == f"ALT-{YIL}-001",
          tb["teklif_no"] if tb else "-")
    check("B teklifi B şirketine damgalı", tb and tb["sirket_id"] == b_id)

    # --- 13. Temizlik ---
    admin.post(BASE + "/sirket/gec", data={"sirket_id": "1", "next": "/"}, allow_redirects=False)
    for t in ("alinan_teklif_kalem", "alinan_teklif", "satin_alma_talebi_kalem",
              "satin_alma_talebi", "siparis_kalem", "siparis",
              "cari_kart", "hesap", "demirbas_kategori", "depo", "kullanici_sirket"):
        dbx(f"DELETE FROM {t} WHERE sirket_id=?", b_id)
    dbx("DELETE FROM sirket WHERE id=?", b_id)
    dbx("UPDATE sessionler SET sirket_id=1 WHERE sirket_id=?", b_id)
    dbx("DELETE FROM alinan_teklif_kalem WHERE teklif_id IN "
        "(SELECT id FROM alinan_teklif WHERE aciklama LIKE 'ALT-TEST-%')")
    dbx("DELETE FROM alinan_teklif WHERE aciklama LIKE 'ALT-TEST-%'")
    dbx("DELETE FROM satin_alma_talebi_kalem WHERE talep_id IN "
        "(SELECT id FROM satin_alma_talebi WHERE gerekce LIKE 'SAT-TEST-ALT-%')")
    dbx("DELETE FROM satin_alma_talebi WHERE gerekce LIKE 'SAT-TEST-ALT-%'")
    dbx("DELETE FROM siparis_kalem WHERE siparis_id IN "
        "(SELECT id FROM siparis WHERE aciklama LIKE '%ALT-TEST%')")
    dbx("DELETE FROM siparis WHERE aciklama LIKE '%ALT-TEST%'")

    print(f"\nSONUÇ: {len(ok)} başarılı / {len(fail)} başarısız")
    if fail:
        print("BAŞARISIZ:", fail)
        raise SystemExit(1)
    print("ALINAN TEKLİF (B2) E2E TESTİ GEÇTİ ✅")


if __name__ == "__main__":
    main()
