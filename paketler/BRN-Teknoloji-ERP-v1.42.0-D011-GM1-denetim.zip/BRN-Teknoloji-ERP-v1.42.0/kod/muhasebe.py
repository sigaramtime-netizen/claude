"""Faz 5 — Genel Muhasebe (1.20).

Çift taraflı (çift kayıt) defter: yevmiye, büyük defter, mizan + otomatik fiş üretimi
(Fatura/Kasa/Banka/Çek-Senet → yevmiye, K26). Tekdüzen Hesap Planı (db.HESAP_PLANI).
Manüel çift veri girişi gerekmez: mali etki doğuran her hareket kaynağından (kaynak_modul/kaynak_id)
tek yevmiye üretilir; iptal edilen hareketin fişi de geri alınır (net sıfır).
"""
import datetime

from core import route, render_template, redirect, flash, audit, notify, izole_sube
import db

MUH_WRITE = ("Admin", "Muhasebe")

TIP_LABEL = {"Aktif": "Aktif", "Pasif": "Pasif", "Ozkaynak": "Özkaynak", "Gelir": "Gelir", "Gider": "Gider"}
TIP_BADGE = {"Aktif": "b-info", "Pasif": "b-warn", "Ozkaynak": "b-muted", "Gelir": "b-ok", "Gider": "b-danger"}


def _f(v, default=0.0):
    try:
        return float(v if v not in (None, "") else default)
    except (TypeError, ValueError):
        return default


def _i(v):
    try:
        return int(v) if v not in (None, "") else None
    except (TypeError, ValueError):
        return None


# --------------------------------------------------------------------------
# Otomatik fiş üretimi (K26)
# --------------------------------------------------------------------------

def _hesap_id(conn, kod, sid=None):
    if sid is not None:
        r = conn.execute("SELECT id FROM hesap WHERE kod=? AND sirket_id=?", (kod, sid)).fetchone()
    else:
        r = conn.execute("SELECT id FROM hesap WHERE kod=?", (kod,)).fetchone()
    return r["id"] if r else None


def _kalem_yaz(conn, yevmiye_id, satirlar, sid=None):
    for kod, borc, alacak in satirlar:
        if abs(borc) < 0.005 and abs(alacak) < 0.005:
            continue
        hid = _hesap_id(conn, kod, sid)
        if hid is None:
            # Eksik hesap kodunda sessizce atlama → dengesiz fiş oluşur; bunun yerine hata
            # fırlat (çağıranın transaction'ı geri alınır → cari hareket de kalıcı olmaz).
            raise RuntimeError(f"Hesap planında '{kod}' kodu bulunamadı; fiş üretilemedi.")
        conn.execute(
            "INSERT INTO yevmiye_kalem(yevmiye_id, hesap_id, borc, alacak, aciklama, sirket_id) "
            "VALUES(?,?,?,?,?,?)",
            (yevmiye_id, hid, round(borc, 2), round(alacak, 2), kod,
             sid if sid is not None else 1))


def _fatura_satirlar(conn, f):
    """Satış: 120 borç / 600 alacak (matrah) + 391 alacak (KDV).
    Alış: stoklu satırlar → 153 (Ticari Mallar), manuel satırlar → 770 (Genel Yönetim Giderleri)
    + 191 borç (KDV) / 320 alacak. TL karşılık (K18).
    Faz 6.1: manuel (stoğa bağlı olmayan) satırlar — stok_id NULL.
    """
    kur = f["doviz_kur"] or 1.0
    ara = round((f["ara_toplam"] or 0.0) * kur, 2)
    kdv = round((f["kdv_toplam"] or 0.0) * kur, 2)
    genel = round((f["genel_toplam"] or 0.0) * kur, 2)
    if f["tip"] == "Satis":
        # Manuel satırlar da hasılat (600) — yevmiye yapısı değişmez.
        return [("120", genel, 0.0), ("600", 0.0, ara), ("391", 0.0, kdv)]
    # Alış: matrahı stoklu / manuel olarak böl (manuel → 770).
    kalemler = conn.execute(
        "SELECT stok_id, tutar FROM fatura_kalem WHERE fatura_id=?", (f["id"],)
    ).fetchall()
    manuel_var = any(not k["stok_id"] for k in kalemler)
    stok_var = any(k["stok_id"] for k in kalemler)
    if manuel_var and stok_var:
        stok_ara = round(sum((k["tutar"] or 0.0) for k in kalemler if k["stok_id"]) * kur, 2)
        manuel_ara = round(ara - stok_ara, 2)  # kalan → fiş dengeli kalır
    elif manuel_var:
        stok_ara, manuel_ara = 0.0, ara
    else:
        stok_ara, manuel_ara = ara, 0.0
    satirlar = []
    if stok_ara > 0:
        satirlar.append(("153", stok_ara, 0.0))
    if manuel_ara > 0:
        satirlar.append(("770", manuel_ara, 0.0))
    satirlar += [("191", kdv, 0.0), ("320", 0.0, genel)]
    return satirlar


def _irsaliye_satirlar(conn, i):
    """F1 — irsaliyenin mali etkisi (faturayla aynı desen; D007 → döviz kur çevrimi).
    Satış: 120 borç / 600 alacak (matrah) + 391 alacak (KDV).
    Alış: stoklu → 153, manuel → 770 + 191 borç (KDV) / 320 alacak.
    Transfer: cari yok → mali etki üretilmez (None). TL karşılık (K18)."""
    if i["tip"] == "Transfer":
        return None
    kur = i["doviz_kur"] or 1.0
    ara = round((i["ara_toplam"] or 0.0) * kur, 2)
    kdv = round((i["kdv_toplam"] or 0.0) * kur, 2)
    genel = round((i["genel_toplam"] or 0.0) * kur, 2)
    if i["tip"] == "Satis":
        return [("120", genel, 0.0), ("600", 0.0, ara), ("391", 0.0, kdv)]
    kalemler = conn.execute(
        "SELECT stok_id, tutar FROM irsaliye_kalem WHERE irsaliye_id=?", (i["id"],)
    ).fetchall()
    manuel_var = any(not k["stok_id"] for k in kalemler)
    stok_var = any(k["stok_id"] for k in kalemler)
    if manuel_var and stok_var:
        stok_ara = round(sum((k["tutar"] or 0.0) for k in kalemler if k["stok_id"]) * kur, 2)
        manuel_ara = round(ara - stok_ara, 2)
    elif manuel_var:
        stok_ara, manuel_ara = 0.0, ara
    else:
        stok_ara, manuel_ara = ara, 0.0
    satirlar = []
    if stok_ara > 0:
        satirlar.append(("153", stok_ara, 0.0))
    if manuel_ara > 0:
        satirlar.append(("770", manuel_ara, 0.0))
    satirlar += [("191", kdv, 0.0), ("320", 0.0, genel)]
    return satirlar


def _cari_hesap(conn, cari_id, yon):
    """Cari tipine göre karşı hesap: Müşteri→120 ALICILAR, Tedarikçi→320 SATICILAR.
    HerIkisi → yön bazlı (giriş/tahsilat→120, çıkış/ödeme→320). Cari yoksa None."""
    if not cari_id:
        return None
    r = conn.execute("SELECT tip FROM cari_kart WHERE id=?", (cari_id,)).fetchone()
    tip = r["tip"] if r else "Musteri"
    if tip == "Tedarikci":
        return "320"
    if tip == "HerIkisi":
        return "120" if yon == "giris" else "320"
    return "120"


def _kasa_satirlar(conn, h):
    tip = h["islem_tipi"]
    t = round((h["tutar"] or 0.0) * (h["doviz_kur"] or 1.0), 2)
    if tip == "Nakit Girişi":
        return [("100", t, 0.0), (_cari_hesap(conn, h["cari_id"], "giris") or "679", 0.0, t)]
    if tip == "Nakit Çıkışı":
        return [(_cari_hesap(conn, h["cari_id"], "cikis") or "632", t, 0.0), ("100", 0.0, t)]
    if tip == "Açılış Bakiyesi":
        return [("100", t, 0.0), ("500", 0.0, t)]
    if tip == "Kasa → Banka":
        return [("102", t, 0.0), ("100", 0.0, t)]
    if tip == "Banka → Kasa":
        return [("100", t, 0.0), ("102", 0.0, t)]
    return None


def _banka_satirlar(conn, h):
    tip = h["islem_tipi"]
    t = round((h["tutar"] or 0.0) * (h["doviz_kur"] or 1.0), 2)
    if tip == "Havale/EFT Girişi":
        return [("102", t, 0.0), (_cari_hesap(conn, h["cari_id"], "giris") or "679", 0.0, t)]
    if tip == "Havale/EFT Çıkışı":
        return [(_cari_hesap(conn, h["cari_id"], "cikis") or "632", t, 0.0), ("102", 0.0, t)]
    if tip == "Banka Ekstresi (Giriş)":
        return [("102", t, 0.0), ("679", 0.0, t)]
    if tip == "Banka Ekstresi (Çıkış)":
        return [("632", t, 0.0), ("102", 0.0, t)]
    if tip == "Açılış Bakiyesi":
        return [("102", t, 0.0), ("500", 0.0, t)]
    if tip == "Kasa → Banka":
        return [("102", t, 0.0), ("100", 0.0, t)]
    if tip == "Banka → Kasa":
        return [("100", t, 0.0), ("102", 0.0, t)]
    return None


def _cek_ara_kod(cek):
    """Çek/senet için Tekdüzen ara hesap kodu: 101 Alınan Çekler / 121 Alacak Senetleri /
    103 Verilen Çekler ve Ödeme Emirleri / 321 Borç Senetleri."""
    if cek["tip"] == "Alinan":
        return "101" if cek["tur"] == "Cek" else "121"
    return "103" if cek["tur"] == "Cek" else "321"


def _cek_satirlar(cek, sahne):
    """K26 revize — çek/senet durum geçişlerine göre doğru ARA HESAP eşlemesi.

    giris  (Alındı/Verildi → portföye giriş):  ara borç / 120 alacak (Alinan);
                                               320 borç / ara alacak (Verilen).
    tahsil (Tahsil Edildi, Alinan):             100 borç / ara alacak.
    odeme  (Ödendi, Verilen):                   ara borç / 100 alacak.
    Çek elde tutulurken Kasa/Banka'ya YAZILMAZ — nakit ancak tahsilde/ödemede girer.
    """
    t = round((cek["tutar"] or 0.0) * (cek["doviz_kur"] or 1.0), 2)
    ara = _cek_ara_kod(cek)
    if sahne == "giris":
        if cek["durum"] not in ("Bekliyor", "Tahsile Verildi", "Tahsil Edildi", "Ödendi", "Ciro"):
            return None
        if cek["tip"] == "Alinan":
            return [(ara, t, 0.0), ("120", 0.0, t)]
        return [("320", t, 0.0), (ara, 0.0, t)]
    if sahne == "tahsil" and cek["tip"] == "Alinan" and cek["durum"] == "Tahsil Edildi":
        return [("100", t, 0.0), (ara, 0.0, t)]
    if sahne == "odeme" and cek["tip"] == "Verilen" and cek["durum"] == "Ödendi":
        return [(ara, t, 0.0), ("100", 0.0, t)]
    return None


def fis_uret(conn, kaynak_modul, kaynak_id, sahne=None):
    """K26 — kaynak hareketten otomatik yevmiye üret (idempotent).

    Dedup anahtarı: (kaynak_modul, kaynak_id, kaynak_sahne). Fatura/Kasa/Banka tek fiş
    (sahne=None); Çek/Senet sahne bazlı çok fiş üretir (giris/tahsil/odeme). Dönüş: id veya None.
    """
    if kaynak_id is None:
        return None
    var = conn.execute(
        "SELECT id FROM yevmiye WHERE kaynak_modul=? AND kaynak_id=? "
        "AND COALESCE(kaynak_sahne,'')=COALESCE(?,'')",
        (kaynak_modul, int(kaynak_id), sahne or "")).fetchone()
    if var:
        return var["id"]
    satirlar = None
    aciklama = ""
    tarih = datetime.date.today().isoformat()
    sube_id = None
    sid = None
    if kaynak_modul == "Fatura":
        f = conn.execute("SELECT * FROM fatura WHERE id=?", (int(kaynak_id),)).fetchone()
        if not f or f["durum"] != "Onaylandı":
            return None
        satirlar = _fatura_satirlar(conn, f)
        aciklama = f"{f['fatura_no']} — {f['aciklama'] or ''}".strip(" —")
        tarih = f["tarih"] or tarih
        sube_id = f["sube_id"]
        sid = f["sirket_id"]
    elif kaynak_modul == "Kasa":
        h = conn.execute("SELECT * FROM kasa_hareket WHERE id=?", (int(kaynak_id),)).fetchone()
        # transfer karşı hareketi (ilgili_kayit_id dolu) primary tarafta üretilir
        if not h or (h["ilgili_modul"] == "Transfer" and h["ilgili_kayit_id"] is not None):
            return None
        satirlar = _kasa_satirlar(conn, h)
        aciklama = f"Kasa {h['islem_tipi']} — {h['aciklama'] or ''}".strip(" —")
        tarih = h["tarih"] or tarih
        k = conn.execute("SELECT sube_id FROM kasa WHERE id=?", (h["kasa_id"],)).fetchone()
        sube_id = k["sube_id"] if k else None
        sid = h["sirket_id"]
    elif kaynak_modul == "Banka":
        h = conn.execute("SELECT * FROM banka_hareket WHERE id=?", (int(kaynak_id),)).fetchone()
        if not h or (h["ilgili_modul"] == "Transfer" and h["ilgili_kayit_id"] is not None):
            return None
        satirlar = _banka_satirlar(conn, h)
        aciklama = f"Banka {h['islem_tipi']} — {h['aciklama'] or ''}".strip(" —")
        tarih = h["tarih"] or tarih
        k = conn.execute("SELECT sube_id FROM banka_hesap WHERE id=?", (h["banka_hesap_id"],)).fetchone()
        sube_id = k["sube_id"] if k else None
        sid = h["sirket_id"]
    elif kaynak_modul == "CekSenet":
        c = conn.execute("SELECT * FROM cek_senet WHERE id=?", (int(kaynak_id),)).fetchone()
        if not c:
            return None
        satirlar = _cek_satirlar(c, sahne)
        if not satirlar:
            return None
        aciklama = f"{c['no']} — {c['aciklama'] or ''}".strip(" —")
        if sahne == "giris":
            tarih = c["keside_tarihi"] or tarih
        sube_id = c["sube_id"]
        sid = c["sirket_id"]
    elif kaynak_modul == "Demirbas":
        d = conn.execute("SELECT * FROM demirbas WHERE id=?", (int(kaynak_id),)).fetchone()
        da = conn.execute(
            "SELECT * FROM demirbas_amortisman WHERE demirbas_id=? AND donem=?",
            (int(kaynak_id), sahne)).fetchone()
        if not d or not da:
            return None
        tutar = round(da["tutar"] or 0.0, 2)
        satirlar = [("770", tutar, 0.0), ("257", 0.0, tutar)]
        aciklama = f"{d['kod']} {d['ad']} — amortisman {sahne}".strip()
        tarih = f"{(sahne or '')[:7]}-01"
        sube_id = d["sube_id"]
        sid = d["sirket_id"]
    elif kaynak_modul == "Irsaliye":
        i = conn.execute("SELECT * FROM irsaliye WHERE id=?", (int(kaynak_id),)).fetchone()
        if not i or i["durum"] != "Onaylandı" or i["tip"] == "Transfer":
            return None
        satirlar = _irsaliye_satirlar(conn, i)
        aciklama = f"{i['irsaliye_no']} — {i['aciklama'] or ''}".strip(" —")
        tarih = i["tarih"] or tarih
        sube_id = i["sube_id"]
        sid = i["sirket_id"]
    if not satirlar:
        return None
    fis_no = db.sonraki_belge_no(conn, "yevmiye", "fis_no", "FIS", datetime.date.today().year, sid)
    cur = conn.execute(
        "INSERT INTO yevmiye(fis_no, tarih, aciklama, kaynak_modul, kaynak_id, kaynak_sahne, "
        "sube_id, durum, sirket_id) "
        "VALUES(?,?,?,?,?,?,?,'Onaylandı',?)",
        (fis_no, tarih, aciklama, kaynak_modul, int(kaynak_id), sahne, sube_id,
         sid if sid is not None else 1))
    _kalem_yaz(conn, cur.lastrowid, satirlar, sid)
    return cur.lastrowid


def fis_sil(conn, kaynak_modul, kaynak_id, sahne=None):
    """Kaynak hareket iptal edilince üretilen fişi geri al (net sıfır). Sahne verilirse yalnız o fiş."""
    if kaynak_id is None:
        return
    y = conn.execute(
        "SELECT id FROM yevmiye WHERE kaynak_modul=? AND kaynak_id=? "
        "AND COALESCE(kaynak_sahne,'')=COALESCE(?,'')",
        (kaynak_modul, int(kaynak_id), sahne or "")).fetchone()
    if y:
        conn.execute("DELETE FROM yevmiye_kalem WHERE yevmiye_id=?", (y["id"],))
        conn.execute("DELETE FROM yevmiye WHERE id=?", (y["id"],))


def fis_sil_tumu(conn, kaynak_modul, kaynak_id):
    """Bir kaynağın TÜM fişlerini (her sahne) geri al — çek/senet iptal/karşılıksız için."""
    if kaynak_id is None:
        return
    for y in conn.execute(
            "SELECT id FROM yevmiye WHERE kaynak_modul=? AND kaynak_id=?",
            (kaynak_modul, int(kaynak_id))).fetchall():
        conn.execute("DELETE FROM yevmiye_kalem WHERE yevmiye_id=?", (y["id"],))
        conn.execute("DELETE FROM yevmiye WHERE id=?", (y["id"],))


def cek_senkron(conn, cid, created_by=None, zorla=False):
    """Çek/senet için cari hareket + yevmiye setini GÜNCEL durumla senkronize et (idempotent).

    - Portföyde (Bekliyor/Tahsile Verildi/Tahsil Edildi/Ödendi/Ciro):
        cari: Alinan→ALACAK, Verilen→BORÇ (çek alındığında cari kapanır; K17 revize).
        fiş:  giris (+tahsil → Tahsil Edildi'de, +odeme → Ödendi'de).
    - Karşılıksız / İptal: cari + TÜM fişler geri alınır (net sıfır).
    zorla=True: önce mevcut cari+fişi siler (düzenlemede tutar/cari değiştiyse).
    """
    c = conn.execute("SELECT * FROM cek_senet WHERE id=?", (int(cid),)).fetchone()
    if not c:
        return None
    cek = dict(c)
    durum = cek["durum"]
    tutar_tl = round((cek.get("tutar") or 0.0) * (cek.get("doviz_kur") or 1.0), 2)
    tarih = cek.get("keside_tarihi") or datetime.date.today().isoformat()
    pb = cek.get("para_birimi") or "TRY"
    kur = cek.get("doviz_kur") or 1.0
    portfoyde = durum in ("Bekliyor", "Tahsile Verildi", "Tahsil Edildi", "Ödendi", "Ciro")

    if zorla or not portfoyde:
        conn.execute("DELETE FROM cari_hareket WHERE ilgili_modul='CekSenet' AND ilgili_kayit_id=?",
                     (int(cid),))
        fis_sil_tumu(conn, "CekSenet", int(cid))

    # Cari senkron
    if portfoyde:
        mevcut = conn.execute(
            "SELECT id, cari_id, borc, alacak FROM cari_hareket "
            "WHERE ilgili_modul='CekSenet' AND ilgili_kayit_id=?", (int(cid),)).fetchall()
        istenen_borc = 0.0 if cek["tip"] == "Alinan" else tutar_tl
        istenen_alacak = tutar_tl if cek["tip"] == "Alinan" else 0.0
        if mevcut and (len(mevcut) > 1 or mevcut[0]["cari_id"] != cek["cari_id"]
                       or abs((mevcut[0]["borc"] or 0) - istenen_borc) > 0.005
                       or abs((mevcut[0]["alacak"] or 0) - istenen_alacak) > 0.005):
            conn.execute("DELETE FROM cari_hareket WHERE ilgili_modul='CekSenet' AND ilgili_kayit_id=?",
                         (int(cid),))
            mevcut = []
        if not mevcut:
            import cari
            if cek["tip"] == "Alinan":
                cari.hareket_ekle(conn, cek["cari_id"], tarih, "Tahsilat", cek["no"],
                                  cek.get("aciklama"), borc=0.0, alacak=tutar_tl,
                                  ilgili_modul="CekSenet", ilgili_kayit_id=int(cid),
                                  vade=cek.get("vade"), created_by=created_by,
                                  para_birimi=pb, doviz_kur=kur)
            else:
                cari.hareket_ekle(conn, cek["cari_id"], tarih, "Ödeme", cek["no"],
                                  cek.get("aciklama"), borc=tutar_tl, alacak=0.0,
                                  ilgili_modul="CekSenet", ilgili_kayit_id=int(cid),
                                  vade=cek.get("vade"), created_by=created_by,
                                  para_birimi=pb, doviz_kur=kur)

    # Fiş senkron (eksikleri üret)
    if durum in ("Bekliyor", "Tahsile Verildi", "Ciro"):
        fis_uret(conn, "CekSenet", int(cid), sahne="giris")
    elif durum == "Tahsil Edildi":
        fis_uret(conn, "CekSenet", int(cid), sahne="giris")
        fis_uret(conn, "CekSenet", int(cid), sahne="tahsil")
    elif durum == "Ödendi":
        fis_uret(conn, "CekSenet", int(cid), sahne="giris")
        fis_uret(conn, "CekSenet", int(cid), sahne="odeme")
    return cek


def sube_backfill(conn):
    """K1 — mevcut fişlerin sube_id'sini kaynağından geri doldur (NULL kalanlara).

    Fatura/Çek-Senet doğrudan kendi sube_id'sini; Kasa/Banka, kasa/banka hesabının
    sube_id'sini taşır. Yeni fişlerde fis_uret zaten sube_id yazar; bu fonksiyon yalnız
    migrasyon öncesi üretilmiş fişleri tamamlar (idempotent).
    """
    conn.execute(
        "UPDATE yevmiye SET sube_id=(SELECT f.sube_id FROM fatura f WHERE f.id=yevmiye.kaynak_id) "
        "WHERE kaynak_modul='Fatura' AND sube_id IS NULL AND EXISTS("
        "SELECT 1 FROM fatura f WHERE f.id=yevmiye.kaynak_id AND f.sube_id IS NOT NULL)")
    conn.execute(
        "UPDATE yevmiye SET sube_id=(SELECT k.sube_id FROM kasa k JOIN kasa_hareket h ON h.kasa_id=k.id "
        "WHERE h.id=yevmiye.kaynak_id) WHERE kaynak_modul='Kasa' AND sube_id IS NULL")
    conn.execute(
        "UPDATE yevmiye SET sube_id=(SELECT b.sube_id FROM banka_hesap b JOIN banka_hareket h ON h.banka_hesap_id=b.id "
        "WHERE h.id=yevmiye.kaynak_id) WHERE kaynak_modul='Banka' AND sube_id IS NULL")
    conn.execute(
        "UPDATE yevmiye SET sube_id=(SELECT c.sube_id FROM cek_senet c WHERE c.id=yevmiye.kaynak_id) "
        "WHERE kaynak_modul='CekSenet' AND sube_id IS NULL AND EXISTS("
        "SELECT 1 FROM cek_senet c WHERE c.id=yevmiye.kaynak_id AND c.sube_id IS NOT NULL)")


def toplu_uret(conn, sid=None):
    """Mevcut hareketlerden eksik fişleri üret (retroaktif, idempotent). Dönüş: üretilen adet."""
    adet = 0
    # F1 — mali etki "zincirdeki ilk belgede bir kere": kaynak irsaliyesi olan faturalar
    # yalnızca belgeleştirir; mali etki irsaliye onayında oluşmuştur. Burada yalnız
    # irsaliyesiz faturalara fiş üretilir.
    f_where = "WHERE durum='Onaylandı' AND kaynak_irsaliye_id IS NULL" + (" AND sirket_id=?" if sid is not None else "")
    f_args = (sid,) if sid is not None else ()
    for r in conn.execute(f"SELECT id FROM fatura {f_where}", f_args).fetchall():
        adet += 1 if fis_uret(conn, "Fatura", r["id"]) else 0
    # F1 — onaylı irsaliyeler kendi fişlerini üretir (Transfer hariç).
    i_where = "WHERE durum='Onaylandı' AND tip != 'Transfer'" + (" AND sirket_id=?" if sid is not None else "")
    for r in conn.execute(f"SELECT id FROM irsaliye {i_where}", f_args).fetchall():
        adet += 1 if fis_uret(conn, "Irsaliye", r["id"]) else 0
    for r in conn.execute("SELECT id FROM kasa_hareket" + (" WHERE sirket_id=?" if sid is not None else ""),
                          (sid,) if sid is not None else ()).fetchall():
        adet += 1 if fis_uret(conn, "Kasa", r["id"]) else 0
    for r in conn.execute("SELECT id FROM banka_hareket" + (" WHERE sirket_id=?" if sid is not None else ""),
                          (sid,) if sid is not None else ()).fetchall():
        adet += 1 if fis_uret(conn, "Banka", r["id"]) else 0
    for r in conn.execute("SELECT id FROM cek_senet" + (" WHERE sirket_id=?" if sid is not None else ""),
                          (sid,) if sid is not None else ()).fetchall():
        once = conn.execute(
            "SELECT COUNT(*) c FROM yevmiye WHERE kaynak_modul='CekSenet' AND kaynak_id=?",
            (r["id"],)).fetchone()["c"]
        cek_senkron(conn, r["id"])
        sonra = conn.execute(
            "SELECT COUNT(*) c FROM yevmiye WHERE kaynak_modul='CekSenet' AND kaynak_id=?",
            (r["id"],)).fetchone()["c"]
        adet += sonra - once
    sube_backfill(conn)
    return adet


# --------------------------------------------------------------------------
# Açılış / Kapanış fişleri
# --------------------------------------------------------------------------

def _hesap_bakiyesi(conn, kod, sid=None):
    extra = " AND y.sirket_id=?" if sid is not None else ""
    args = [kod] + ([sid] if sid is not None else [])
    r = conn.execute(
        "SELECT COALESCE(SUM(k.borc),0) b, COALESCE(SUM(k.alacak),0) a FROM yevmiye_kalem k "
        "JOIN yevmiye y ON y.id=k.yevmiye_id JOIN hesap h ON h.id=k.hesap_id "
        "WHERE y.durum='Onaylandı' AND h.kod=?" + extra, args).fetchone()
    return round((r["b"] - r["a"]), 2)


def acilis_fisi(conn, created_by, sid=None):
    """Kasa/Banka + cari açılış bakiyelerinden açılış fişi (fark → 500 Sermaye). Idempotent: yıl bazlı tek."""
    yil = datetime.date.today().year
    var = conn.execute("SELECT id FROM yevmiye WHERE aciklama LIKE ? AND sirket_id=?",
                       (f"Dönem Açılış Fişi {yil}%", sid if sid is not None else 1)).fetchone()
    if var:
        return var["id"], False
    satirlar = []
    for kod in ("100", "102"):
        b = _hesap_bakiyesi(conn, kod, sid)
        if abs(b) > 0.005:
            satirlar.append((kod, max(b, 0.0), max(-b, 0.0)))
    for kod in ("120", "320", "153", "191"):
        b = _hesap_bakiyesi(conn, kod, sid)
        if abs(b) > 0.005:
            satirlar.append((kod, max(b, 0.0), max(-b, 0.0)))
    borc_top = sum(s[1] for s in satirlar)
    alacak_top = sum(s[2] for s in satirlar)
    fark = round(borc_top - alacak_top, 2)
    if abs(fark) > 0.005:
        satirlar.append(("500", 0.0, fark) if fark > 0 else ("500", -fark, 0.0))
    if not satirlar:
        return None, False
    fis_no = db.sonraki_belge_no(conn, "yevmiye", "fis_no", "FIS", yil, sid)
    cur = conn.execute(
        "INSERT INTO yevmiye(fis_no, tarih, aciklama, kaynak_modul, durum, created_by, sirket_id) "
        "VALUES(?,?,?,'Muhasebe','Onaylandı',?,?)",
        (fis_no, datetime.date.today().isoformat(), f"Dönem Açılış Fişi {yil}", created_by,
         sid if sid is not None else 1))
    _kalem_yaz(conn, cur.lastrowid, satirlar, sid)
    return cur.lastrowid, True


def kapanis_fisi(conn, created_by, sid=None):
    """Gelir/Gider hesaplarını kapatıp 590 (kâr) / 591 (zarar) devri. Idempotent: yıl bazlı tek."""
    yil = datetime.date.today().year
    var = conn.execute("SELECT id FROM yevmiye WHERE aciklama LIKE ? AND sirket_id=?",
                       (f"Dönem Kapanış Fişi {yil}%", sid if sid is not None else 1)).fetchone()
    if var:
        return var["id"], False
    satirlar = []
    h_where = "WHERE tip IN ('Gelir','Gider')" + (" AND sirket_id=?" if sid is not None else "")
    h_args = (sid,) if sid is not None else ()
    for r in conn.execute(f"SELECT kod, tip FROM hesap {h_where} ORDER BY kod", h_args).fetchall():
        b = _hesap_bakiyesi(conn, r["kod"], sid)
        if abs(b) > 0.005:
            # gelir: alacak bakiyeli → borç yazarak kapat; gider: borç bakiyeli → alacak yazarak kapat
            if r["tip"] == "Gelir":
                satirlar.append((r["kod"], b, 0.0))
            else:
                satirlar.append((r["kod"], 0.0, b))
    borc_top = sum(s[1] for s in satirlar)
    alacak_top = sum(s[2] for s in satirlar)
    fark = round(borc_top - alacak_top, 2)
    if abs(fark) > 0.005:
        satirlar.append(("590", fark, 0.0) if fark > 0 else ("591", 0.0, -fark))
    if not satirlar:
        return None, False
    fis_no = db.sonraki_belge_no(conn, "yevmiye", "fis_no", "FIS", yil, sid)
    cur = conn.execute(
        "INSERT INTO yevmiye(fis_no, tarih, aciklama, kaynak_modul, durum, created_by, sirket_id) "
        "VALUES(?,?,?,'Muhasebe','Onaylandı',?,?)",
        (fis_no, datetime.date.today().isoformat(), f"Dönem Kapanış Fişi {yil}", created_by,
         sid if sid is not None else 1))
    _kalem_yaz(conn, cur.lastrowid, satirlar, sid)
    return cur.lastrowid, True


# --------------------------------------------------------------------------
# Rotalar
# --------------------------------------------------------------------------

@route(r"/muhasebe", roles=())
def muhasebe_liste(req):
    conn = db.get_conn()
    where, args = ["y.sirket_id=?"], [db.sirket_id(req)]
    if req.q("q"):
        q = f"%{req.q('q')}%"
        where.append("(y.fis_no LIKE ? OR y.aciklama LIKE ?)")
        args += [q, q]
    km = req.q("kaynak")
    if km:
        where.append("y.kaynak_modul=?")
        args.append(km)
    if izole_sube(req):
        where.append("y.sube_id=?")
        args.append(izole_sube(req))
    rows = conn.execute(
        "SELECT y.*, "
        "(SELECT COUNT(*) FROM yevmiye_kalem k WHERE k.yevmiye_id=y.id) AS kalem_adet, "
        "(SELECT COALESCE(SUM(k.borc),0) FROM yevmiye_kalem k WHERE k.yevmiye_id=y.id) AS borc_top, "
        "(SELECT COALESCE(SUM(k.alacak),0) FROM yevmiye_kalem k WHERE k.yevmiye_id=y.id) AS alacak_top "
        f"FROM yevmiye y WHERE {' AND '.join(where)} ORDER BY y.tarih DESC, y.id DESC LIMIT 200",
        args).fetchall()
    sayac = {d: conn.execute("SELECT COUNT(*) c FROM yevmiye WHERE durum=? AND sirket_id=?",
                             (d, db.sirket_id(req))).fetchone()["c"]
             for d in ("Taslak", "Onaylandı", "İptal")}
    conn.close()
    return render_template("muhasebe/liste.html", rows=rows, sayac=sayac, q=req.q("q"),
                           km=km, KAYNAK_LABEL={"Fatura": "Fatura", "Kasa": "Kasa", "Banka": "Banka",
                                                "CekSenet": "Çek/Senet", "Muhasebe": "Manüel",
                                                "Irsaliye": "İrsaliye"})


@route(r"/muhasebe/yeni", methods=("GET", "POST"), roles=MUH_WRITE)
def muhasebe_yeni(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    hesaplar = conn.execute("SELECT * FROM hesap WHERE aktif=1 AND sirket_id=? ORDER BY kod",
                            (sid,)).fetchall()
    if req.method == "POST":
        tarih = req.form.get("tarih") or datetime.date.today().isoformat()
        aciklama = (req.form.get("aciklama") or "").strip()
        hesap_ids = req.form_list.get("hesap_id", [])
        borclar = req.form_list.get("borc", [])
        alacaklar = req.form_list.get("alacak", [])
        izinli = {h["id"] for h in hesaplar}
        satirlar = []
        for i, hid in enumerate(hesap_ids):
            b = _f(borclar[i] if i < len(borclar) else "")
            a = _f(alacaklar[i] if i < len(alacaklar) else "")
            if not hid or (b <= 0 and a <= 0):
                continue
            if _i(hid) not in izinli:  # çapraz şirket hesap_id enjeksiyonuna karşı koruma
                conn.close()
                flash(req, "Geçersiz hesap seçimi.", "danger")
                return render_template("muhasebe/yeni.html", hesaplar=hesaplar,
                                       tarih=tarih, aciklama=aciklama)
            satirlar.append((hid, b, a))
        if not satirlar or round(sum(s[1] for s in satirlar), 2) != round(sum(s[2] for s in satirlar), 2):
            conn.close()
            flash(req, "Fiş dengeli değil: satır girin ve borç toplamı = alacak toplamı olmalı.", "danger")
            return render_template("muhasebe/yeni.html", hesaplar=hesaplar,
                                   tarih=tarih, aciklama=aciklama)
        fis_no = db.sonraki_belge_no(conn, "yevmiye", "fis_no", "FIS", datetime.date.today().year, sid)
        cur = conn.execute(
            "INSERT INTO yevmiye(fis_no, tarih, aciklama, kaynak_modul, durum, created_by, sirket_id) "
            "VALUES(?,?,?,'Muhasebe','Onaylandı',?,?)",
            (fis_no, tarih, aciklama, req.user["id"], sid))
        for hid, b, a in satirlar:
            conn.execute("INSERT INTO yevmiye_kalem(yevmiye_id, hesap_id, borc, alacak, sirket_id) "
                         "VALUES(?,?,?,?,?)",
                         (cur.lastrowid, int(hid), b, a, sid))
        conn.commit()
        audit(req, "yevmiye", cur.lastrowid, "olustur", {"fis_no": fis_no, "manuel": True})
        conn.close()
        flash(req, f"Yevmiye fişi oluşturuldu: {fis_no}", "ok")
        return redirect(f"/muhasebe/{cur.lastrowid}")
    conn.close()
    return render_template("muhasebe/yeni.html", hesaplar=hesaplar,
                           tarih=datetime.date.today().isoformat(), aciklama="")


@route(r"/muhasebe/toplu-uret", methods=("POST",), roles=MUH_WRITE)
def muhasebe_toplu_uret(req):
    conn = db.get_conn()
    adet = toplu_uret(conn, db.sirket_id(req))
    conn.commit()
    audit(req, "yevmiye", 0, "toplu_uret", {"adet": adet})
    conn.close()
    flash(req, f"Toplu fiş üretimi tamamlandı: {adet} yeni yevmiye oluşturuldu.", "ok")
    return redirect("/muhasebe")


@route(r"/muhasebe/acilis", methods=("POST",), roles=MUH_WRITE)
def muhasebe_acilis(req):
    conn = db.get_conn()
    fid, yeni = acilis_fisi(conn, req.user["id"], db.sirket_id(req))
    conn.commit()
    conn.close()
    if fid:
        flash(req, ("Açılış fişi oluşturuldu." if yeni else "Bu yılın açılış fişi zaten var."), "ok" if yeni else "info")
        return redirect(f"/muhasebe/{fid}")
    flash(req, "Açılış fişi için veri yok.", "info")
    return redirect("/muhasebe")


@route(r"/muhasebe/kapanis", methods=("POST",), roles=MUH_WRITE)
def muhasebe_kapanis(req):
    conn = db.get_conn()
    fid, yeni = kapanis_fisi(conn, req.user["id"], db.sirket_id(req))
    conn.commit()
    conn.close()
    if fid:
        flash(req, ("Kapanış fişi oluşturuldu." if yeni else "Bu yılın kapanış fişi zaten var."), "ok" if yeni else "info")
        return redirect(f"/muhasebe/{fid}")
    flash(req, "Kapanış fişi için gelir/gider verisi yok.", "info")
    return redirect("/muhasebe")


@route(r"/muhasebe/hesaplar", roles=())
def muhasebe_hesaplar(req):
    conn = db.get_conn()
    hesaplar = conn.execute("SELECT * FROM hesap WHERE aktif=1 AND sirket_id=? ORDER BY kod",
                            (db.sirket_id(req),)).fetchall()
    gruplar = {}
    for h in hesaplar:
        gruplar.setdefault(h["tip"], []).append(h)
    conn.close()
    return render_template("muhasebe/hesaplar.html", gruplar=gruplar, TIP_LABEL=TIP_LABEL, TIP_BADGE=TIP_BADGE)


@route(r"/muhasebe/mizan", roles=())
def muhasebe_mizan(req):
    conn = db.get_conn()
    sube_id = _i(req.q("sube_id"))
    # K1/Faz 6 — şubeli kullanıcının mizanı varsayılan olarak kendi şubesine kilitlenir.
    if req.q("sube_id") in (None, "") and izole_sube(req):
        sube_id = izole_sube(req)
    subeler = conn.execute("SELECT id, ad FROM sube WHERE aktif=1 AND sirket_id=? ORDER BY ad",
                            (db.sirket_id(req),)).fetchall()
    rows = [dict(r) for r in conn.execute(
        "SELECT h.kod, h.ad, h.tip, COALESCE(t.b,0) b, COALESCE(t.a,0) a FROM hesap h "
        "LEFT JOIN (SELECT k.hesap_id, SUM(k.borc) b, SUM(k.alacak) a FROM yevmiye_kalem k "
        "JOIN yevmiye y ON y.id=k.yevmiye_id "
        "WHERE y.durum='Onaylandı' AND y.sirket_id=? AND (? IS NULL OR y.sube_id=?) "
        "GROUP BY k.hesap_id) t "
        "ON t.hesap_id=h.id WHERE h.aktif=1 AND h.sirket_id=? ORDER BY h.kod",
        (db.sirket_id(req), sube_id, sube_id, db.sirket_id(req))).fetchall()]
    tb = ta = 0.0
    for r in rows:
        r["bakiye"] = round(r["b"] - r["a"], 2)
        tb += r["b"]
        ta += r["a"]
    conn.close()
    return render_template("muhasebe/mizan.html", rows=rows, tb=round(tb, 2), ta=round(ta, 2),
                           subeler=subeler, sube_id=sube_id)


@route(r"/muhasebe/defter", roles=())
def muhasebe_defter(req):
    conn = db.get_conn()
    hesaplar = conn.execute("SELECT * FROM hesap WHERE aktif=1 AND sirket_id=? ORDER BY kod",
                            (db.sirket_id(req),)).fetchall()
    hesap_id = _i(req.q("hesap_id")) or (hesaplar[0]["id"] if hesaplar else None)
    hesap = conn.execute("SELECT * FROM hesap WHERE id=? AND sirket_id=?",
                         (hesap_id, db.sirket_id(req))).fetchone() if hesap_id else None
    kalemler = []
    bakiye = 0.0
    if hesap:
        iz = izole_sube(req)
        kalemler = [dict(k) for k in conn.execute(
            "SELECT k.id, k.yevmiye_id, k.hesap_id, k.borc, k.alacak, y.fis_no, y.tarih, "
            "y.aciklama AS fis_aciklama, y.durum FROM yevmiye_kalem k "
            "JOIN yevmiye y ON y.id=k.yevmiye_id WHERE k.hesap_id=? AND y.durum='Onaylandı' "
            "AND y.sirket_id=? "
            + (" AND y.sube_id=?" if iz else "") +
            " ORDER BY y.tarih, y.id", (hesap_id, db.sirket_id(req)) + ((iz,) if iz else ())).fetchall()]
        bakiye = 0.0
        for k in kalemler:
            bakiye += round((k["borc"] or 0) - (k["alacak"] or 0), 2)
            k["bakiye"] = round(bakiye, 2)
    conn.close()
    return render_template("muhasebe/defter.html", hesaplar=hesaplar, hesap=hesap,
                           kalemler=kalemler, hesap_id=hesap_id)


@route(r"/muhasebe/(?P<fid>\d+)", roles=())
def muhasebe_detay(req, fid):
    conn = db.get_conn()
    y = conn.execute("SELECT * FROM yevmiye WHERE id=? AND sirket_id=?",
                     (int(fid), db.sirket_id(req))).fetchone()
    if not y:
        conn.close()
        flash(req, "Fiş bulunamadı.", "danger")
        return redirect("/muhasebe")
    kalemler = conn.execute(
        "SELECT k.*, h.kod, h.ad, h.tip FROM yevmiye_kalem k "
        "LEFT JOIN hesap h ON h.id=k.hesap_id WHERE k.yevmiye_id=? ORDER BY k.id", (int(fid),)).fetchall()
    loglar = conn.execute("SELECT * FROM audit_log WHERE tablo='yevmiye' AND kayit_id=? ORDER BY id DESC",
                          (int(fid),)).fetchall()
    bt = round(sum(k["borc"] or 0 for k in kalemler), 2)
    at = round(sum(k["alacak"] or 0 for k in kalemler), 2)
    conn.close()
    return render_template("muhasebe/detay.html", yevmiye=y, kalemler=kalemler, loglar=loglar,
                           bt=bt, at=at, TIP_LABEL=TIP_LABEL, TIP_BADGE=TIP_BADGE)


@route(r"/muhasebe/(?P<fid>\d+)/durum", methods=("POST",), roles=MUH_WRITE)
def muhasebe_durum(req, fid):
    hedef = req.form.get("durum")
    if hedef not in ("Onaylandı", "İptal"):
        flash(req, "Geçersiz durum geçişi.", "danger")
        return redirect(f"/muhasebe/{fid}")
    conn = db.get_conn()
    y = conn.execute("SELECT * FROM yevmiye WHERE id=? AND sirket_id=?",
                     (int(fid), db.sirket_id(req))).fetchone()
    if not y:
        conn.close()
        return redirect("/muhasebe")
    # Kaynaktan üretilmiş fişler elle durum değiştirilemez (kaynak akış yönetir)
    if y["kaynak_modul"] not in (None, "Muhasebe"):
        conn.close()
        flash(req, "Bu fiş bir belgeden otomatik üretildi; durumu kaynak belgeden yönetilir.", "danger")
        return redirect(f"/muhasebe/{fid}")
    if hedef == "Onaylandı" and y["durum"] != "Taslak":
        conn.close()
        flash(req, "Yalnızca Taslak fiş onaylanabilir.", "danger")
        return redirect(f"/muhasebe/{fid}")
    if hedef == "İptal" and y["durum"] not in ("Taslak", "Onaylandı"):
        conn.close()
        flash(req, "Bu durumdaki fiş iptal edilemez.", "danger")
        return redirect(f"/muhasebe/{fid}")
    conn.execute("UPDATE yevmiye SET durum=?, updated_at=datetime('now','localtime') WHERE id=?",
                 (hedef, int(fid)))
    conn.commit()
    audit(req, "yevmiye", int(fid), "durum", {"eski": y["durum"], "yeni": hedef})
    conn.close()
    flash(req, f"Fiş '{hedef}' olarak güncellendi.", "ok")
    return redirect(f"/muhasebe/{fid}")
