# -*- coding: utf-8 -*-
"""C — POS (Satış Noktası) e2e testi.

Kapsam (faz protokolü örnek senaryosu):
  1. Terminal kartı: oluştur + listele + düzenle + pasifleştir/aktifleştir.
  2. Bölünmüş ödeme (Nakit + Kart + Havale) → Onaylı Satış Faturası + cari + stok + kasa/banka + yevmiye.
  3. Kart komisyonu otomatik: bankaya net tutar, komisyon gideri pos_satis'ta izlenir.
  4. Veresiye: vade yazımı, cari borç kapanmaz.
  5. Çek/Senet: cek_senet + cari ALACAK + cek_senkron yevmiyesi.
  6. Perakende cari (boş müşteri) → varsayılan "Peşin (Perakende) Müşteri".
  7. Korumalar: stok yetersiz / ödeme fazlası / çek vadesiz / pasif terminal.
  8. Günlük rapor render.
  9. Yetki: Depo kullanıcısı /pos'a giremez (403).
  10. Şirket izolasyonu: 2. şirket terminal göremez, çapraz terminalle satış engellenir.

Çalıştırma: sunucu 8080'de çalışırken  python3 test_pos.py
"""
import datetime
import sqlite3
import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
KOD = "POSTEST"
YIL = datetime.date.today().year
BUGUN = datetime.date.today()
YARIN = (BUGUN + datetime.timedelta(days=1)).isoformat()

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else ""))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris(kullanici="admin"):
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": kullanici, "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, f"giriş başarısız ({kullanici})"
    return s


def satis(s, terminal="1", urun=None, satirlar=None, odemeler=None, cari_id="", taksit="1", vade=""):
    """POS satışı POST eder. urun/satirlar/odemeler listeler halinde verilir."""
    data = [("terminal_id", terminal), ("cari_id", cari_id), ("taksit", taksit), ("vade", vade)]
    for r in (satirlar or ([urun] if urun else [])):
        data += [("k_stok_id", r["stok_id"]), ("k_varyant_id", r.get("varyant_id", "0")),
                 ("k_manuel_ad", r.get("manuel_ad", "")), ("k_miktar", str(r["miktar"])),
                 ("k_birim_fiyat", str(r["birim_fiyat"])), ("k_iskonto", str(r.get("iskonto", "0"))),
                 ("k_kdv", str(r.get("kdv", "20")))]
    for o in (odemeler or []):
        data += [("p_tip", o["tip"]), ("p_tutar", str(o["tutar"])), ("p_vade", o.get("vade", ""))]
    return s.post(BASE + "/pos/satis", data=data, allow_redirects=False)


def yetim_fisler():
    """yevmiye.kaynak_id polimorfik referanstır (SQLite FK'sı değil) — elle taranır."""
    src = {"Fatura": "fatura", "Kasa": "kasa_hareket", "Banka": "banka_hareket",
           "CekSenet": "cek_senet", "Demirbas": "demirbas"}
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    bad = []
    for r in c.execute("SELECT id, fis_no, kaynak_modul, kaynak_id FROM yevmiye"):
        t = src.get(r["kaynak_modul"])
        if t and not c.execute(f"SELECT 1 FROM {t} WHERE id=?", (r["kaynak_id"],)).fetchone():
            bad.append((r["id"], r["fis_no"], r["kaynak_modul"], r["kaynak_id"]))
    c.close()
    return bad


# ---------------------------------------------------------------------------
print("== C / POS — e2e testi ==")
s = giris("admin")

# --- Kurulum: önceki koşulardan kalıntıları temizle (idempotent başlangıç) ---
dbx("DELETE FROM pos_terminal WHERE ad='Test Terminal 2'")
dbx("DELETE FROM stok_seviye WHERE stok_id IN (SELECT id FROM stok_kart WHERE kod='POSTEST')")
dbx("DELETE FROM stok_hareket WHERE stok_id IN (SELECT id FROM stok_kart WHERE kod='POSTEST')")
dbx("DELETE FROM stok_kart WHERE kod='POSTEST'")
dbx("DELETE FROM cari_kart WHERE kod='POSMUS'")
dbx("DELETE FROM kullanici_sirket WHERE sirket_id IN (SELECT id FROM sirket WHERE kod='POSIKI')")
dbx("DELETE FROM sirket WHERE kod='POSIKI'")

# --- Kurulum: test ürünü + test müşterisi ---
dbx("INSERT INTO stok_kart(kod, ad, barkod, birim, kdv_orani, satis_fiyat, aktif, sirket_id) "
    "VALUES(?,?,?,?,?,?,1,1)", KOD, "POS Test Ürünü", "POS001", "Adet", 20, 100)
stok_id = db1("SELECT id FROM stok_kart WHERE kod=?", KOD)["id"]
dbx("INSERT OR IGNORE INTO stok_seviye(stok_id, varyant_id, depo_id, miktar, sirket_id) "
    "VALUES(?,0,2,100,1)", stok_id)
dbx("INSERT INTO cari_kart(kod, unvan, tip, aktif, sirket_id) VALUES('POSMUS','POS Test Müşteri','Musteri',1,1)")
cari_id = db1("SELECT id FROM cari_kart WHERE kod='POSMUS'")["id"]

# 1. Terminal kartı
r = s.get(BASE + "/pos/terminaller")
check("1.1 terminal listesi render", r.status_code == 200 and "POS" in r.text)
r = s.post(BASE + "/pos/terminal/yeni", data=[
    ("ad", "Test Terminal 2"), ("kasa_id", "2"), ("banka_id", "2"), ("depo_id", "2"),
    ("komisyon_orani", "2.50"), ("max_taksit", "6")], allow_redirects=False)
t2 = db1("SELECT * FROM pos_terminal WHERE ad='Test Terminal 2'")
check("1.2 yeni terminal oluşturuldu", t2 is not None and abs(t2["komisyon_orani"] - 2.5) < 1e-9
      and t2["max_taksit"] == 6 and t2["kasa_id"] == 2 and t2["banka_id"] == 2)
s.post(BASE + f"/pos/terminal/{t2['id']}/duzenle", data=[
    ("ad", "Test Terminal 2"), ("kasa_id", "2"), ("banka_id", "2"), ("depo_id", "2"),
    ("komisyon_orani", "3.00"), ("max_taksit", "3")], allow_redirects=False)
t2 = db1("SELECT * FROM pos_terminal WHERE id=?", t2["id"])
check("1.3 terminal düzenleme", abs(t2["komisyon_orani"] - 3.0) < 1e-9 and t2["max_taksit"] == 3)
s.post(BASE + f"/pos/terminal/{t2['id']}/durum", allow_redirects=False)
check("1.4 terminal pasifleştirildi", db1("SELECT aktif FROM pos_terminal WHERE id=?", t2["id"])["aktif"] == 0)
r = satis(s, terminal=str(t2["id"]), urun={"stok_id": str(stok_id), "miktar": 1,
                                          "birim_fiyat": 100}, odemeler=[{"tip": "Nakit", "tutar": 120}])
check("1.5 pasif terminalle satış engellendi", r.status_code == 302 and r.headers.get("Location") == "/pos")
s.post(BASE + f"/pos/terminal/{t2['id']}/durum", allow_redirects=False)

# 2. Bölünmüş ödeme: Nakit 72 + Kart 48 (komisyon %1.79) → 1 adet × 100 TL, KDV 20 → genel 120
r = satis(s, urun={"stok_id": str(stok_id), "miktar": 1, "birim_fiyat": 100},
          odemeler=[{"tip": "Nakit", "tutar": 72}, {"tip": "Kart", "tutar": 48}])
check("2.1 satış tamamlandı (fatura redirect)", r.status_code == 302 and "/fatura/" in (r.headers.get("Location") or ""))
fid = int(r.headers["Location"].rstrip("/").split("/")[-1])
f = db1("SELECT * FROM fatura WHERE id=?", fid)
check("2.2 Onaylı Satış Faturası üretildi", f is not None and f["durum"] == "Onaylandı"
      and f["tip"] == "Satis" and abs(f["genel_toplam"] - 120.0) < 1e-9)
check("2.3 fatura kalemi", db1("SELECT COUNT(*) c FROM fatura_kalem WHERE fatura_id=?", fid)["c"] == 1)
ps = db1("SELECT * FROM pos_satis WHERE fatura_id=?", fid)
kom_beklenen = round(48 * 0.0179, 2)
check("2.4 pos_satis kaydı + komisyon", ps is not None and abs(ps["komisyon_toplam"] - kom_beklenen) < 1e-9,
      f"kom={ps['komisyon_toplam']}")
odm = db("SELECT * FROM pos_satis_odeme WHERE pos_satis_id=? ORDER BY id", ps["id"])
check("2.5 ödeme satırları (2 adet)", len(odm) == 2 and odm[0]["tip"] == "Nakit" and odm[1]["tip"] == "Kart")
check("2.6 kart komisyonu satırda", abs(odm[1]["komisyon"] - kom_beklenen) < 1e-9)
net = round(48 - kom_beklenen, 2)
bh = db1("SELECT * FROM banka_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
check("2.7 bankaya net tutar yattı", bh is not None and abs(bh["tutar"] - net) < 1e-9,
      f"net={bh['tutar'] if bh else None}")
kh = db1("SELECT * FROM kasa_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
check("2.8 kasaya nakit girdi", kh is not None and abs(kh["tutar"] - 72.0) < 1e-9)
ch = db("SELECT * FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
borc = sum(r["borc"] or 0 for r in ch); alacak = sum(r["alacak"] or 0 for r in ch)
check("2.9 cari net sıfır (tam tahsilat)", abs(borc - 120.0) < 1e-9 and abs(alacak - 120.0) < 1e-9)
sh = db1("SELECT * FROM stok_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
check("2.10 stok düşümü (POS Çıkışı)", sh is not None and sh["islem_tipi"] == "POS Çıkışı"
      and sh["miktar"] == -1 and sh["depo_id"] == 2)
yf = db("SELECT kaynak_modul FROM yevmiye WHERE kaynak_id=? OR kaynak_id IN "
        "(SELECT id FROM kasa_hareket WHERE ilgili_kayit_id=?) OR kaynak_id IN "
        "(SELECT id FROM banka_hareket WHERE ilgili_kayit_id=?)", fid, fid, fid)
mods = {r["kaynak_modul"] for r in yf}
check("2.11 yevmiye: Fatura+Kasa+Banka fişleri", {"Fatura", "Kasa", "Banka"} <= mods, str(mods))
check("2.12 taksit bilgisi", ps["taksit"] == 1)

# 3. Havale ödemesi (komisyonsuz brüt banka girişi)
r = satis(s, urun={"stok_id": str(stok_id), "miktar": 1, "birim_fiyat": 100},
          odemeler=[{"tip": "Havale", "tutar": 120}])
fid3 = int(r.headers["Location"].rstrip("/").split("/")[-1])
bh3 = db1("SELECT * FROM banka_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid3)
ps3 = db1("SELECT * FROM pos_satis WHERE fatura_id=?", fid3)
check("3.1 havale komisyonsuz net yattı", bh3 is not None and abs(bh3["tutar"] - 120.0) < 1e-9
      and abs(ps3["komisyon_toplam"]) < 1e-9)

# 4. Veresiye: 40 nakit → 80 veresiye (genel 120), vade yazımı
r = satis(s, urun={"stok_id": str(stok_id), "miktar": 1, "birim_fiyat": 100}, vade=YARIN,
          odemeler=[{"tip": "Nakit", "tutar": 40}])
fid4 = int(r.headers["Location"].rstrip("/").split("/")[-1])
ps4 = db1("SELECT * FROM pos_satis WHERE fatura_id=?", fid4)
f4 = db1("SELECT * FROM fatura WHERE id=?", fid4)
check("4.1 veresiye tutarı", abs(ps4["veresiye_tutar"] - 80.0) < 1e-9)
check("4.2 fatura vadesi yazıldı", f4["vade"] == YARIN)
ch4 = db("SELECT borc, alacak FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid4)
net4 = sum(r["borc"] or 0 for r in ch4) - sum(r["alacak"] or 0 for r in ch4)
check("4.3 cari veresiye borcu kaldı", abs(net4 - 80.0) < 1e-9, f"net={net4}")
check("4.4 veresiye ödeme satırı", db1("SELECT COUNT(*) c FROM pos_satis_odeme WHERE pos_satis_id=? "
      "AND tip='Veresiye'", ps4["id"])["c"] == 1)

# 5. Çek ile ödeme: genel 120 çek, vade zorunlu
r = satis(s, urun={"stok_id": str(stok_id), "miktar": 1, "birim_fiyat": 100},
          odemeler=[{"tip": "Cek", "tutar": 120, "vade": YARIN}])
fid5 = int(r.headers["Location"].rstrip("/").split("/")[-1])
cek = db1("SELECT * FROM cek_senet WHERE aciklama LIKE 'POS satışı %' ORDER BY id DESC LIMIT 1")
check("5.1 çek kaydı oluştu", cek is not None and cek["tip"] == "Alinan" and cek["tur"] == "Cek"
      and abs(cek["tutar"] - 120.0) < 1e-9 and cek["vade"] == YARIN)
chk = db1("SELECT * FROM cari_hareket WHERE ilgili_modul='CekSenet' AND ilgili_kayit_id=?", cek["id"])
check("5.2 alınan çek cariye ALACAK", chk is not None and abs(chk["alacak"] - 120.0) < 1e-9)
ycek = db1("SELECT COUNT(*) c FROM yevmiye WHERE kaynak_modul='CekSenet' AND kaynak_id=?", cek["id"])
check("5.3 çek yevmiyesi üretildi", ycek["c"] >= 1)
poscek = db1("SELECT * FROM pos_satis_odeme WHERE pos_satis_id=(SELECT id FROM pos_satis WHERE fatura_id=?) "
             "AND tip='Cek'", fid5)
check("5.4 ödeme satırı çek referanslı", poscek is not None and poscek["cek_senet_id"] == cek["id"])

# 6. Perakende cari (boş müşteri)
r = satis(s, urun={"stok_id": str(stok_id), "miktar": 1, "birim_fiyat": 100},
          odemeler=[{"tip": "Nakit", "tutar": 120}])
fid6 = int(r.headers["Location"].rstrip("/").split("/")[-1])
f6 = db1("SELECT f.cari_id, c.kod FROM fatura f JOIN cari_kart c ON c.id=f.cari_id WHERE f.id=?", fid6)
check("6.1 perakende müşteri kullanıldı", f6["kod"] == "PER-001")

# 7. Korumalar
once = db1("SELECT COUNT(*) c FROM fatura")["c"]
r = satis(s, urun={"stok_id": str(stok_id), "miktar": 9999, "birim_fiyat": 100},
          odemeler=[{"tip": "Nakit", "tutar": 999999}])
check("7.1 stok yetersiz engellendi", r.status_code == 302 and r.headers.get("Location") == "/pos"
      and db1("SELECT COUNT(*) c FROM fatura")["c"] == once)
r = satis(s, urun={"stok_id": str(stok_id), "miktar": 1, "birim_fiyat": 100},
          odemeler=[{"tip": "Nakit", "tutar": 999}])
check("7.2 ödeme fazlası engellendi", r.status_code == 302 and r.headers.get("Location") == "/pos"
      and db1("SELECT COUNT(*) c FROM fatura")["c"] == once)
r = satis(s, urun={"stok_id": str(stok_id), "miktar": 1, "birim_fiyat": 100},
          odemeler=[{"tip": "Senet", "tutar": 120, "vade": ""}])
check("7.3 vadesiz çek/senet engellendi", r.status_code == 302 and r.headers.get("Location") == "/pos"
      and db1("SELECT COUNT(*) c FROM fatura")["c"] == once)
r = satis(s, urun={"stok_id": "999999", "miktar": 1, "birim_fiyat": 100},
          odemeler=[{"tip": "Nakit", "tutar": 120}])
check("7.4 yabancı şirket ürünü engellendi", r.status_code == 302 and r.headers.get("Location") == "/pos"
      and db1("SELECT COUNT(*) c FROM fatura")["c"] == once)

# 8. Rapor + satış listesi + detay
r = s.get(BASE + "/pos/satislar")
check("8.1 satış listesi render", r.status_code == 200 and "SF-" in r.text)
r = s.get(BASE + f"/pos/satis/{ps['id']}")
check("8.2 satış detayı render", r.status_code == 200)
r = s.get(BASE + f"/pos/rapor?tarih={BUGUN.isoformat()}")
check("8.3 günlük rapor render", r.status_code == 200)

# 9. Yetki: Depo kullanıcısı /pos'a giremez
sd = giris("depo")
r = sd.get(BASE + "/pos")
check("9.1 depo → /pos 403", r.status_code == 403)
r = sd.post(BASE + "/pos/satis", data=[("terminal_id", "1")], allow_redirects=False)
check("9.2 depo → satış POST 403", r.status_code == 403)

# 10. Şirket izolasyonu
dbx("INSERT INTO sirket(kod, unvan, aktif) VALUES('POSIKI','POS İkinci Şirket',1)")
s2 = db1("SELECT id FROM sirket WHERE kod='POSIKI'")["id"]
s.post(BASE + "/sirket/gec", data={"sirket_id": str(s2), "next": "/"}, allow_redirects=False)
r = s.get(BASE + "/pos/terminaller")
check("10.1 2. şirkette terminal listesi boş", r.status_code == 200 and "Terminal tanımlı değil" in r.text)
r = satis(s, terminal="1", urun={"stok_id": str(stok_id), "miktar": 1, "birim_fiyat": 100},
          odemeler=[{"tip": "Nakit", "tutar": 120}])
check("10.2 çapraz şirket terminaliyle satış engellendi",
      r.status_code == 302 and r.headers.get("Location") == "/pos")
s.post(BASE + "/sirket/gec", data={"sirket_id": "1", "next": "/"}, allow_redirects=False)

# --- Temizlik ---
fidler = [fid, fid3, fid4, fid5, fid6]
for fidx in fidler:
    p = db1("SELECT id FROM pos_satis WHERE fatura_id=?", fidx)
    if p:
        for o in db("SELECT cek_senet_id FROM pos_satis_odeme WHERE pos_satis_id=?", p["id"]):
            if o["cek_senet_id"]:
                dbx("DELETE FROM cari_hareket WHERE ilgili_modul='CekSenet' AND ilgili_kayit_id=?", o["cek_senet_id"])
                dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN (SELECT id FROM yevmiye WHERE kaynak_modul='CekSenet' AND kaynak_id=?)", o["cek_senet_id"])
                dbx("DELETE FROM yevmiye WHERE kaynak_modul='CekSenet' AND kaynak_id=?", o["cek_senet_id"])
                dbx("DELETE FROM cek_senet WHERE id=?", o["cek_senet_id"])
        dbx("DELETE FROM pos_satis_odeme WHERE pos_satis_id=?", p["id"])
        dbx("DELETE FROM pos_satis WHERE id=?", p["id"])
    # stok seviye geri al (her satış -1 depo 2)
    dbx("UPDATE stok_seviye SET miktar=miktar+1 WHERE stok_id=? AND depo_id=2", stok_id)
    dbx("DELETE FROM stok_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fidx)
    dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fidx)
    for hid in [r["id"] for r in db("SELECT id FROM kasa_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fidx)]:
        dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN (SELECT id FROM yevmiye WHERE kaynak_modul='Kasa' AND kaynak_id=?)", hid)
        dbx("DELETE FROM yevmiye WHERE kaynak_modul='Kasa' AND kaynak_id=?", hid)
    for hid in [r["id"] for r in db("SELECT id FROM banka_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fidx)]:
        dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN (SELECT id FROM yevmiye WHERE kaynak_modul='Banka' AND kaynak_id=?)", hid)
        dbx("DELETE FROM yevmiye WHERE kaynak_modul='Banka' AND kaynak_id=?", hid)
    dbx("DELETE FROM kasa_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fidx)
    dbx("DELETE FROM banka_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fidx)
    dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN (SELECT id FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?)", fidx)
    dbx("DELETE FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?", fidx)
    dbx("DELETE FROM fatura_kalem WHERE fatura_id=?", fidx)
    dbx("DELETE FROM fatura WHERE id=?", fidx)
# terminal 2 + test kayıtları
dbx("DELETE FROM pos_terminal WHERE ad='Test Terminal 2'")
dbx("DELETE FROM stok_seviye WHERE stok_id=?", stok_id)
dbx("DELETE FROM stok_kart WHERE id=?", stok_id)
dbx("DELETE FROM cari_kart WHERE kod='POSMUS'")
dbx("DELETE FROM kullanici_sirket WHERE sirket_id IN (SELECT id FROM sirket WHERE kod='POSIKI')")
dbx("DELETE FROM sirket WHERE kod='POSIKI'")

# --- Yetim kontrolü ---
yetim = db1("SELECT COUNT(*) c FROM pos_satis p LEFT JOIN fatura f ON f.id=p.fatura_id WHERE f.id IS NULL")["c"]
check("11.1 yetim pos_satis yok", yetim == 0, f"yetim={yetim}")
fk = db("PRAGMA foreign_key_check")
check("11.2 yabancı anahtar bütünlüğü", len(fk) == 0, str([tuple(r) for r in fk][:5]))
yf = yetim_fisler()
check("11.3 yetim yevmiye fişi yok (kaynak silinmiş)", len(yf) == 0, str(yf[:5]))

print(f"\n=== SONUÇ: {len(ok)} başarılı / {len(fail)} başarısız ===")
if fail:
    print("BAŞARISIZ:", fail)
    raise SystemExit(1)
print("TÜM POS TESTLERİ GEÇTİ ✅")
