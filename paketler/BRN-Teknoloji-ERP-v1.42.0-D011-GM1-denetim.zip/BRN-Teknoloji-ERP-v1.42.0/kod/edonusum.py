# -*- coding: utf-8 -*-
"""e-Dönüşüm modülü (Faz 4 — 1.13 giden + 1.14 gelen kutusu).

GİDEN (1.13):
- Onaylı satış faturası/irsaliyesinden e-belge üretimi (Taslak).
- Fatura tipini otomatik belirleme: alıcı e-Fatura mükellefiyse e-Fatura, değilse e-Arşiv
  (`cari_kart.e_fatura_mukellefi`).
- Soyut entegratör katmanı (İzibiz/EDM uyumlu) üzerinden GİB'e iletim — şu an MockEntegrator.
- GİB durum takibi: Taslak → Gönderildi → Onaylandı / Reddedildi (CHECK ile sabit).
- Ham e-belge (UBL-TR benzeri XML) K16 `ek_dosya` tablosunda saklanır (yeni tablo yok).

GELEN (1.14):
- Tedarikçilerden gelen e-Fatura/e-İrsaliye listesi (entegratörden çekilir — mock).
- XML/UBL otomatik okunur; kalemler stok kartlarıyla eşleştirilir (kod → ad).
- Tek tıkla dönüştürme: e-Fatura → Alış Faturası, e-İrsaliye → Alış İrsaliyesi (Taslak);
  bağlantı K8 deseniyle (`gelen_belge.donusum_fatura_id` / `donusum_irsaliye_id` FK).
- Kabul / Red / İtiraz işlemleri.
"""
import datetime
import os
import secrets
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

import db
import entegrator as ent
import fatura
import ekler
from config import UPLOAD_DIR, FIRMA_ADI
from core import route, render_template, redirect, flash, audit, _local

EDONUSUM_WRITE = ("Admin", "Muhasebe")
EDONUSUM_ADMIN = ("Admin",)

TUR_LABEL = ent.TUR_LABEL
TUR_ON_EK = ent.TUR_ON_EK
DURUMLAR = ent.DURUMLAR
DURUM_BADGE = ent.DURUM_BADGE
GELEN_DURUMLAR = ent.GELEN_DURUMLAR
GELEN_BADGE = ent.GELEN_BADGE

GELEN_FALLBACK_KOD = "HZM-GLN-ESLESME"


def _aktif_sirket():
    try:
        req = getattr(_local, "req", None)
        if req is not None:
            return db.sirket_id(req)
    except Exception:
        pass
    return 1


def _entegrator():
    """Aktif entegratör ayarını okur (F4: entegrator_ayar tablosu — K1 şirket izolasyonlu).
    Eski meta tabanlı ayar (entegrator_*) geriye dönük olarak yedek kalır."""
    conn = db.get_conn()
    sid = _aktif_sirket()
    row = conn.execute(
        "SELECT entegrator, api_anahtar, test_modu FROM entegrator_ayar WHERE sirket_id=?",
        (sid,)).fetchone()
    if row:
        ayar = {"saglayici": row["entegrator"] or "Mock",
                "api_anahtari": row["api_anahtar"] or "",
                "test_modu": "1" if row["test_modu"] else "0"}
    else:
        rows = conn.execute("SELECT anahtar, deger FROM meta WHERE anahtar LIKE 'entegrator_%'").fetchall()
        ayar = {r["anahtar"].replace("entegrator_", ""): r["deger"] for r in rows}
    conn.close()
    return ent._entegrator_uret(ayar)


def _tur_belirle(conn, cari_id):
    """Alıcı mükellefiyse e-Fatura, değilse e-Arşiv (1.13)."""
    c = conn.execute("SELECT e_fatura_mukellefi FROM cari_kart WHERE id=?", (cari_id,)).fetchone()
    if c and c["e_fatura_mukellefi"]:
        return "EFatura", "Temel"
    return "EArsiv", "Temel"


def _firma(conn, sirket_id=None):
    # İstek 3: firma → sirket (e-belge kendi şirketinin kimliğini kullanır).
    r = conn.execute("SELECT unvan, vergi_no FROM sirket WHERE id=? LIMIT 1",
                     (sirket_id or 1,)).fetchone()
    return {"unvan": (r["unvan"] if r else None) or FIRMA_ADI,
            "vergi_no": (r["vergi_no"] if r else None) or ""}


# --------------------------------------------------------------------------
# XML üretimi / okuma (ham e-belge — K16 ek_dosya'da saklanır)
# --------------------------------------------------------------------------
def _ubl_fatura_xml(f, kalemler, cari_row, firma):
    L = ['<?xml version="1.0" encoding="UTF-8"?>',
         '<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2">',
         f'  <ID>{escape(f["fatura_no"])}</ID>',
         f'  <IssueDate>{f["tarih"]}</IssueDate>',
         '  <InvoiceTypeCode>SATIS</InvoiceTypeCode>',
         f'  <DocumentCurrencyCode>{f["para_birimi"] or "TRY"}</DocumentCurrencyCode>',
         '  <AccountingSupplierParty>',
         f'    <PartyName>{escape(firma["unvan"])}</PartyName>',
         f'    <PartyTaxScheme><CompanyID>{escape(firma["vergi_no"])}</CompanyID></PartyTaxScheme>',
         '  </AccountingSupplierParty>',
         '  <AccountingCustomerParty>',
         f'    <PartyName>{escape((cari_row or {}).get("unvan") or "")}</PartyName>',
         f'    <PartyTaxScheme><CompanyID>{escape((cari_row or {}).get("vergi_no") or "")}</CompanyID></PartyTaxScheme>',
         '  </AccountingCustomerParty>',
         '  <LegalMonetaryTotal>',
         f'    <LineExtensionAmount>{f["ara_toplam"]}</LineExtensionAmount>',
         f'    <TaxInclusiveAmount>{f["genel_toplam"]}</TaxInclusiveAmount>',
         '  </LegalMonetaryTotal>']
    for k in kalemler:
        L += ['  <InvoiceLine>',
              f'    <SellersItemIdentification><ID>{escape(k["stok_kod"] or "")}</ID></SellersItemIdentification>',
              f'    <Item><Name>{escape(k["stok_ad"] or "")}</Name></Item>',
              f'    <InvoicedQuantity>{k["miktar"]}</InvoicedQuantity>',
              f'    <Price><PriceAmount>{k["birim_fiyat"]}</PriceAmount></Price>',
              f'    <ClassifiedTaxCategory><Percent>{k["kdv_orani"] or 20}</Percent></ClassifiedTaxCategory>',
              '  </InvoiceLine>']
    L.append('</Invoice>')
    return "\n".join(L) + "\n"


def _ubl_irsaliye_xml(ir, kalemler, cari_row, firma):
    L = ['<?xml version="1.0" encoding="UTF-8"?>',
         '<DespatchAdvice xmlns="urn:oasis:names:specification:ubl:schema:xsd:DespatchAdvice-2">',
         f'  <ID>{escape(ir["irsaliye_no"])}</ID>',
         f'  <IssueDate>{ir["tarih"]}</IssueDate>',
         '  <DespatchSupplierParty>',
         f'    <PartyName>{escape(firma["unvan"])}</PartyName>',
         f'    <PartyTaxScheme><CompanyID>{escape(firma["vergi_no"])}</CompanyID></PartyTaxScheme>',
         '  </DespatchSupplierParty>',
         '  <DeliveryCustomerParty>',
         f'    <PartyName>{escape((cari_row or {}).get("unvan") or "")}</PartyName>',
         f'    <PartyTaxScheme><CompanyID>{escape((cari_row or {}).get("vergi_no") or "")}</CompanyID></PartyTaxScheme>',
         '  </DeliveryCustomerParty>']
    for k in kalemler:
        L += ['  <DespatchLine>',
              f'    <SellersItemIdentification><ID>{escape(k["stok_kod"] or "")}</ID></SellersItemIdentification>',
              f'    <Item><Name>{escape(k["stok_ad"] or "")}</Name></Item>',
              f'    <DeliveredQuantity>{k["miktar"]}</DeliveredQuantity>',
              f'    <Price><PriceAmount>{k["birim_fiyat"]}</PriceAmount></Price>',
              '  </DespatchLine>']
    L.append('</DespatchAdvice>')
    return "\n".join(L) + "\n"


def _xml_yaz(conn, modul, kayit_id, ad, xml_str):
    """Ham e-belgeyi diske + ek_dosya'ya yazar (K16)."""
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    yeni = f"{modul}_{kayit_id}_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}_{secrets.token_hex(4)}.xml"
    yol = os.path.join(UPLOAD_DIR, yeni)
    with open(yol, "w", encoding="utf-8") as fh:
        fh.write(xml_str)
    cur = conn.execute(
        "INSERT INTO ek_dosya(ilgili_modul, ilgili_kayit_id, dosya_adi, dosya_yolu, dosya_tipi, boyut, aciklama) "
        "VALUES(?,?,?,?,?,?,?)",
        (modul, kayit_id, ad, yeni, "xml", len(xml_str.encode("utf-8")), "ham e-belge (UBL-TR benzeri XML)"))
    return cur.lastrowid


def _xml_oku(conn, modul, kayit_id):
    """ek_dosya'dan ham XML'i okur (yoksa None)."""
    r = conn.execute(
        "SELECT dosya_yolu FROM ek_dosya WHERE ilgili_modul=? AND ilgili_kayit_id=? "
        "AND dosya_tipi='xml' ORDER BY id DESC LIMIT 1", (modul, kayit_id)).fetchone()
    if not r:
        return None
    yol = os.path.join(UPLOAD_DIR, r["dosya_yolu"])
    if not os.path.isfile(yol):
        return None
    with open(yol, encoding="utf-8") as fh:
        return fh.read()


def _e_belge_xml_uret_yaz(conn, eid):
    """e_belge için kaynağından XML üretir (varsa atlar)."""
    if _xml_oku(conn, "EDonusum", eid):
        return
    e = conn.execute("SELECT * FROM e_belge WHERE id=?", (eid,)).fetchone()
    if not e:
        return
    firma = _firma(conn, e["sirket_id"])
    cari_row = conn.execute("SELECT unvan, vergi_no FROM cari_kart WHERE id=?", (e["cari_id"],)).fetchone() \
        if e["cari_id"] else None
    cari_row = dict(cari_row) if cari_row else None
    if e["kaynak_fatura_id"]:
        f = conn.execute("SELECT * FROM fatura WHERE id=?", (e["kaynak_fatura_id"],)).fetchone()
        kalemler = conn.execute(
            "SELECT k.*, st.kod AS stok_kod, st.ad AS stok_ad FROM fatura_kalem k "
            "JOIN stok_kart st ON st.id=k.stok_id WHERE k.fatura_id=?", (e["kaynak_fatura_id"],)).fetchall()
        if f:
            _xml_yaz(conn, "EDonusum", eid, f"{e['belge_no']}.xml", _ubl_fatura_xml(f, kalemler, cari_row, firma))
    elif e["kaynak_irsaliye_id"]:
        ir = conn.execute("SELECT * FROM irsaliye WHERE id=?", (e["kaynak_irsaliye_id"],)).fetchone()
        kalemler = conn.execute(
            "SELECT k.*, st.kod AS stok_kod, st.ad AS stok_ad FROM irsaliye_kalem k "
            "JOIN stok_kart st ON st.id=k.stok_id WHERE k.irsaliye_id=?", (e["kaynak_irsaliye_id"],)).fetchall()
        if ir:
            _xml_yaz(conn, "EDonusum", eid, f"{e['belge_no']}.xml", _ubl_irsaliye_xml(ir, kalemler, cari_row, firma))


# --------------------------------------------------------------------------
# Gelen belge aktarımı (mock entegratörden çekilen belgeler)
# --------------------------------------------------------------------------
def _gelen_aktar(belge, sid=None):
    """Entegratörden gelen belgeyi gelen_belge + ek_dosya'ya yazar (dedup: belge_no).

    Dönüş: (gid, yeni_mi)
    """
    conn = db.get_conn()
    var = conn.execute("SELECT id FROM gelen_belge WHERE belge_no=? AND sirket_id=?",
                       (belge["belge_no"], sid if sid is not None else 1)).fetchone()
    if var:
        conn.close()
        return var["id"], False
    cur = conn.execute(
        "INSERT INTO gelen_belge(belge_no, tur, gonderen_vkn, gonderen_unvan, alici_vkn, "
        "belge_tarih, tutar, kdv, para_birimi, aciklama, sirket_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        (belge["belge_no"], belge["tur"], belge["gonderen_vkn"], belge["gonderen_unvan"],
         belge["alici_vkn"], belge["belge_tarih"], belge["tutar"], belge["kdv"],
         belge.get("para_birimi") or "TRY", belge.get("aciklama"), sid if sid is not None else 1))
    gid = cur.lastrowid
    if belge.get("xml"):
        _xml_yaz(conn, "GelenBelge", gid, f"{belge['belge_no']}.xml", belge["xml"])
    conn.commit()
    conn.close()
    return gid, True


def _ln(tag):
    return tag.split("}")[-1]


def _xml_kalemler(xml_str):
    """UBL XML'den kalem listesi çıkarır (Invoice/DespatchAdvice ortak)."""
    kalemler = []
    try:
        root = ET.fromstring(xml_str)
    except ET.ParseError:
        return kalemler
    for el in root.iter():
        if _ln(el.tag) not in ("InvoiceLine", "DespatchLine"):
            continue
        kod = ad = None
        miktar = 1.0
        bf = 0.0
        kdv = 20.0
        for c in el.iter():
            ln = _ln(c.tag)
            if ln == "ID" and c.text and c.text.strip():
                kod = c.text.strip()
            elif ln == "Name" and c.text and c.text.strip():
                ad = c.text.strip()
            elif ln in ("InvoicedQuantity", "DeliveredQuantity"):
                try:
                    miktar = float(c.text)
                except (TypeError, ValueError):
                    pass
            elif ln == "PriceAmount":
                try:
                    bf = float(c.text)
                except (TypeError, ValueError):
                    pass
            elif ln == "Percent":
                try:
                    kdv = float(c.text)
                except (TypeError, ValueError):
                    pass
        kalemler.append({"kod": kod, "ad": ad, "miktar": miktar, "birim_fiyat": bf, "kdv_orani": kdv})
    return kalemler


def _stok_eslestir(conn, kod, ad, sid=None):
    """Gelen kalemi stok kartıyla eşleştir: önce kod, sonra ad benzerliği."""
    extra = " AND sirket_id=?" if sid is not None else ""
    s = (sid,) if sid is not None else ()
    if kod:
        k = conn.execute(f"SELECT * FROM stok_kart WHERE kod=? AND aktif=1{extra}",
                         (kod,) + s).fetchone()
        if k:
            return k
    if ad:
        k = conn.execute(f"SELECT * FROM stok_kart WHERE aktif=1 AND ad LIKE ?{extra} ORDER BY id LIMIT 1",
                         (f"%{ad[:30]}%",) + s).fetchone()
        if k:
            return k
    return None


def _fallback_stok(conn, sid=None):
    k = conn.execute("SELECT * FROM stok_kart WHERE kod=? AND aktif=1 AND sirket_id=?",
                     (GELEN_FALLBACK_KOD, sid if sid is not None else 1)).fetchone()
    if k:
        return k
    kat = conn.execute("SELECT id FROM kategori WHERE ad='Hizmet' AND sirket_id=?",
                       (sid if sid is not None else 1,)).fetchone()
    cur = conn.execute(
        "INSERT INTO stok_kart(kod, ad, kategori_id, birim, kdv_orani, otv_orani, alis_fiyat, satis_fiyat, "
        "para_birimi, iskonto_orani, kritik_stok, seri_lot_takibi, varyant_takibi, aktif, tip, sirket_id) "
        "VALUES(?,?,?, 'Adet', 20.0, 0.0, 0.0, 0.0, 'TRY', 0.0, 0.0, 0, 0, 1, 'Hizmet', ?)",
        (GELEN_FALLBACK_KOD, "Eşleşmeyen Gelen Belge Kalemi", kat["id"] if kat else None,
         sid if sid is not None else 1))
    return conn.execute("SELECT * FROM stok_kart WHERE id=?", (cur.lastrowid,)).fetchone()


def _tedarikci_bul(conn, vkn, sid=None):
    extra = " AND sirket_id=?" if sid is not None else ""
    s = (sid,) if sid is not None else ()
    return conn.execute(f"SELECT * FROM cari_kart WHERE vergi_no=?{extra}", (vkn,) + s).fetchone()


# --------------------------------------------------------------------------
# Rotalar — GİDEN (1.13)
# --------------------------------------------------------------------------
@route(r"/edonusum", roles=())
def edonusum_liste(req):
    conn = db.get_conn()
    where, params = ["e.sirket_id=?"], [db.sirket_id(req)]
    q = (req.q("q") or "").strip()
    if q:
        where.append("(e.belge_no LIKE ? OR e.alici_unvan LIKE ? OR f.fatura_no LIKE ? OR i.irsaliye_no LIKE ?)")
        params += [f"%{q}%"] * 4
    tur = req.q("tur")
    if tur in TUR_LABEL:
        where.append("e.tur=?")
        params.append(tur)
    durum = req.q("durum")
    if durum in DURUMLAR:
        where.append("e.durum=?")
        params.append(durum)
    rows = conn.execute(
        "SELECT e.*, c.unvan AS cari_unvan, f.fatura_no AS kaynak_fatura_no, i.irsaliye_no AS kaynak_irsaliye_no "
        "FROM e_belge e LEFT JOIN cari_kart c ON c.id=e.cari_id "
        "LEFT JOIN fatura f ON f.id=e.kaynak_fatura_id LEFT JOIN irsaliye i ON i.id=e.kaynak_irsaliye_id "
        "WHERE " + " AND ".join(where) + " ORDER BY e.id DESC", params).fetchall()
    sayac = dict.fromkeys(DURUMLAR, 0)
    for r in rows:
        sayac[r["durum"]] = sayac.get(r["durum"], 0) + 1
    enteg = _entegrator()
    conn.close()
    return render_template("edonusum/liste.html", rows=rows, q=q, tur=tur, durum=durum,
                           sayac=sayac, TUR_LABEL=TUR_LABEL, DURUM_BADGE=DURUM_BADGE, enteg=enteg)


@route(r"/edonusum/yeni", roles=EDONUSUM_WRITE)
def edonusum_yeni(req):
    conn = db.get_conn()
    faturalar = conn.execute(
        "SELECT f.*, c.unvan, c.e_fatura_mukellefi FROM fatura f JOIN cari_kart c ON c.id=f.cari_id "
        "WHERE f.tip='Satis' AND f.durum='Onaylandı' AND f.sirket_id=? AND NOT EXISTS "
        "(SELECT 1 FROM e_belge e WHERE e.kaynak_fatura_id=f.id AND e.durum != 'İptal') "
        "ORDER BY f.id DESC", (db.sirket_id(req),)
    ).fetchall()
    irsaliyeler = conn.execute(
        "SELECT i.*, c.unvan, c.e_fatura_mukellefi FROM irsaliye i JOIN cari_kart c ON c.id=i.cari_id "
        "WHERE i.tip='Satis' AND i.durum='Onaylandı' AND i.sirket_id=? AND NOT EXISTS "
        "(SELECT 1 FROM e_belge e WHERE e.kaynak_irsaliye_id=i.id AND e.durum != 'İptal') "
        "ORDER BY i.id DESC", (db.sirket_id(req),)
    ).fetchall()
    for r in faturalar:
        r = dict(r)
        r["oneri_tur"], _ = _tur_belirle(conn, r["cari_id"])
    conn.close()
    return render_template("edonusum/yeni.html", faturalar=faturalar, irsaliyeler=irsaliyeler,
                           TUR_LABEL=TUR_LABEL)


@route(r"/edonusum/olustur", methods=("POST",), roles=EDONUSUM_WRITE)
def edonusum_olustur(req):
    kaynak_tablo = req.form.get("kaynak_tablo")
    kaynak_id = req.form.get("kaynak_id")
    if kaynak_tablo not in ("fatura", "irsaliye") or not (kaynak_id or "").isdigit():
        flash(req, "Geçersiz kaynak.", "danger")
        return redirect("/edonusum/yeni")
    conn = db.get_conn()
    eid, hata = _olustur(conn, req, kaynak_tablo, int(kaynak_id))
    if hata:
        conn.close()
        flash(req, hata, "danger")
        return redirect("/edonusum/yeni")
    conn.commit()
    conn.close()
    audit(req, "e_belge", eid, "olustur", {"kaynak": f"{kaynak_tablo}:{kaynak_id}"})
    flash(req, "e-Belge taslağı oluşturuldu.", "ok")
    return redirect(f"/edonusum/{eid}")


def _olustur(conn, req, kaynak_tablo, kaynak_id):
    yil = datetime.date.today().year
    sid = db.sirket_id(req)
    if kaynak_tablo == "fatura":
        f = conn.execute("SELECT * FROM fatura WHERE id=? AND sirket_id=?", (kaynak_id, sid)).fetchone()
        if not f:
            return None, "Fatura bulunamadı."
        if f["tip"] != "Satis":
            return None, "Yalnızca satış faturası e-belgeye dönüşür."
        if f["durum"] != "Onaylandı":
            return None, "Yalnızca 'Onaylandı' faturadan e-belge üretilebilir."
        var = conn.execute("SELECT 1 FROM e_belge WHERE kaynak_fatura_id=? AND durum != 'İptal'",
                           (kaynak_id,)).fetchone()
        if var:
            return None, "Bu fatura için zaten e-belge var."
        tur, senaryo = _tur_belirle(conn, f["cari_id"])
        cari_row = conn.execute("SELECT unvan, vergi_no FROM cari_kart WHERE id=?",
                                (f["cari_id"],)).fetchone()
        no = db.sonraki_belge_no(conn, "e_belge", "belge_no", TUR_ON_EK[tur], yil, sid)
        cur = conn.execute(
            "INSERT INTO e_belge(belge_no, tur, kaynak_fatura_id, cari_id, alici_vkn, alici_unvan, "
            "senaryo, created_by, sirket_id) VALUES(?,?,?,?,?,?,?,?,?)",
            (no, tur, kaynak_id, f["cari_id"],
             cari_row["vergi_no"] if cari_row else None,
             cari_row["unvan"] if cari_row else None, senaryo, req.user["id"], sid))
        eid = cur.lastrowid
        _e_belge_xml_uret_yaz(conn, eid)
        return eid, None
    # irsaliye
    ir = conn.execute("SELECT * FROM irsaliye WHERE id=? AND sirket_id=?", (kaynak_id, sid)).fetchone()
    if not ir:
        return None, "İrsaliye bulunamadı."
    if ir["tip"] not in ("Satis", "Alis"):
        # F4 — Transfer irsaliyesinde cari/KDV yoktur; e-İrsaliye üretilmez.
        return None, "Yalnızca satış/alış irsaliyesi e-İrsaliyeye dönüşür."
    if ir["durum"] != "Onaylandı":
        return None, "Yalnızca 'Onaylandı' irsaliyeden e-İrsaliye üretilebilir."
    var = conn.execute("SELECT 1 FROM e_belge WHERE kaynak_irsaliye_id=? AND durum != 'İptal'",
                       (kaynak_id,)).fetchone()
    if var:
        return None, "Bu irsaliye için zaten e-belge var."
    cari_row = conn.execute("SELECT unvan, vergi_no FROM cari_kart WHERE id=?",
                            (ir["cari_id"],)).fetchone()
    no = db.sonraki_belge_no(conn, "e_belge", "belge_no", "EI", yil, sid)
    cur = conn.execute(
        "INSERT INTO e_belge(belge_no, tur, kaynak_irsaliye_id, cari_id, alici_vkn, alici_unvan, "
        "senaryo, created_by, sirket_id) VALUES(?,?,?,?,?,?,?,?,?)",
        (no, "EIrsaliye", kaynak_id, ir["cari_id"],
         cari_row["vergi_no"] if cari_row else None,
         cari_row["unvan"] if cari_row else None, "Temel", req.user["id"], sid))
    eid = cur.lastrowid
    _e_belge_xml_uret_yaz(conn, eid)
    return eid, None


@route(r"/edonusum/(?P<eid>\d+)", roles=())
def edonusum_detay(req, eid):
    conn = db.get_conn()
    e = conn.execute(
        "SELECT e.*, c.unvan AS cari_unvan, f.fatura_no AS kaynak_fatura_no, i.irsaliye_no AS kaynak_irsaliye_no "
        "FROM e_belge e LEFT JOIN cari_kart c ON c.id=e.cari_id "
        "LEFT JOIN fatura f ON f.id=e.kaynak_fatura_id LEFT JOIN irsaliye i ON i.id=e.kaynak_irsaliye_id "
        "WHERE e.id=? AND e.sirket_id=?", (int(eid), db.sirket_id(req))).fetchone()
    if not e:
        conn.close()
        return redirect("/edonusum")
    kalemler = []
    if e["kaynak_fatura_id"]:
        kalemler = conn.execute(
            "SELECT k.*, st.kod AS stok_kod, st.ad AS stok_ad FROM fatura_kalem k "
            "JOIN stok_kart st ON st.id=k.stok_id WHERE k.fatura_id=? ORDER BY k.id",
            (e["kaynak_fatura_id"],)).fetchall()
    elif e["kaynak_irsaliye_id"]:
        kalemler = conn.execute(
            "SELECT k.*, st.kod AS stok_kod, st.ad AS stok_ad FROM irsaliye_kalem k "
            "JOIN stok_kart st ON st.id=k.stok_id WHERE k.irsaliye_id=? ORDER BY k.id",
            (e["kaynak_irsaliye_id"],)).fetchall()
    _e_belge_xml_uret_yaz(conn, int(eid))
    conn.commit()
    ekler_list = ekler.ekler_for(conn, "EDonusum", int(eid))
    xml_text = _xml_oku(conn, "EDonusum", int(eid))
    conn.close()
    return render_template("edonusum/detay.html", e=e, kalemler=kalemler, ekler=ekler_list,
                           xml_text=xml_text, TUR_LABEL=TUR_LABEL, DURUM_BADGE=DURUM_BADGE)


def _gonder(conn, req, eid):
    """Giden e-belgeyi entegratöre iletir. Döner: (e_belge_row, hata) — hata None ise başarılı.

    F4 — test modu AÇIKKEN mock GİB anında yanıtlar: Gönderildi → Onaylandı (deterministik).
    Test modu KAPALIYSA belge 'Gönderildi'de kalır; yanıt 'durum-sorgula' ile gelir
    (mock %10 Reddedildi üretebilir; reddedilen belge tekrar gönderilebilir).
    """
    e = conn.execute("SELECT * FROM e_belge WHERE id=? AND sirket_id=?",
                     (int(eid), db.sirket_id(req))).fetchone()
    if not e:
        return None, "e-Belge bulunamadı."
    if e["durum"] not in ("Taslak", "Reddedildi"):
        return e, "Yalnızca 'Taslak' veya 'Reddedildi' durumundaki belge gönderilebilir."
    _e_belge_xml_uret_yaz(conn, int(eid))
    conn.commit()
    xml = _xml_oku(conn, "EDonusum", int(eid))
    if not xml:
        return e, "Gönderilecek ham e-belge üretilemedi."
    enteg = _entegrator()
    sonuc = enteg.gonder(xml, e["tur"], e["senaryo"])
    conn.execute(
        "UPDATE e_belge SET durum='Gönderildi', ettn=?, gonderim_tarihi=datetime('now','localtime'), "
        "hata_mesaji=NULL, updated_at=datetime('now','localtime') WHERE id=?",
        (sonuc["ettn"], int(eid)))
    if enteg.test_modu:
        conn.execute("UPDATE e_belge SET durum='Onaylandı', "
                     "updated_at=datetime('now','localtime') WHERE id=?", (int(eid),))
    conn.commit()
    audit(req, "e_belge", int(eid), "gonder", {"ettn": sonuc["ettn"], "entegrator": enteg.ad,
                                               "test_modu": 1 if enteg.test_modu else 0})
    return conn.execute("SELECT * FROM e_belge WHERE id=?", (int(eid),)).fetchone(), None


@route(r"/edonusum/(?P<eid>\d+)/gonder", methods=("POST",), roles=EDONUSUM_WRITE)
def edonusum_gonder(req, eid):
    conn = db.get_conn()
    e, hata = _gonder(conn, req, eid)
    if hata:
        conn.close()
        flash(req, hata, "danger")
        return redirect(f"/edonusum/{int(eid)}")
    conn.close()
    flash(req, f"Belge GİB'e iletildi. ETN: {e['ettn']} — durum: {e['durum']}.", "ok")
    return redirect(f"/edonusum/{int(eid)}")


@route(r"/edonusum/(?P<eid>\d+)/durum-sorgula", methods=("POST",), roles=EDONUSUM_WRITE)
def edonusum_durum_sorgula(req, eid):
    conn = db.get_conn()
    e = conn.execute("SELECT * FROM e_belge WHERE id=? AND sirket_id=?",
                     (int(eid), db.sirket_id(req))).fetchone()
    if not e:
        conn.close()
        return redirect("/edonusum")
    if e["durum"] != "Gönderildi" or not e["ettn"]:
        conn.close()
        flash(req, "Durum sorgusu yalnızca 'Gönderildi' durumundaki belgeler için yapılır.", "danger")
        return redirect(f"/edonusum/{eid}")
    enteg = _entegrator()
    yanit = enteg.durum_sorgula(e["ettn"])
    if yanit == "Reddedildi":
        conn.execute("UPDATE e_belge SET durum='Reddedildi', hata_mesaji='GİB reddi (mock)', "
                     "updated_at=datetime('now','localtime') WHERE id=?", (int(eid),))
    elif yanit == "Onaylandı":
        conn.execute("UPDATE e_belge SET durum='Onaylandı', updated_at=datetime('now','localtime') WHERE id=?",
                     (int(eid),))
    conn.commit()
    conn.close()
    audit(req, "e_belge", int(eid), "durum_sorgula", {"yanit": yanit, "entegrator": enteg.ad})
    flash(req, f"GİB yanıtı (mock): {yanit}.", "ok")
    return redirect(f"/edonusum/{eid}")


@route(r"/edonusum/(?P<eid>\d+)/mock-yanit", methods=("POST",), roles=EDONUSUM_ADMIN)
def edonusum_mock_yanit(req, eid):
    """Sandbox: GİB yanıtını elle simüle et (Onaylandı / Reddedildi). Gerçek entegratörde bu
    yanıt callback/sorgu ile kendiliğinden gelir."""
    conn = db.get_conn()
    e = conn.execute("SELECT * FROM e_belge WHERE id=? AND sirket_id=?",
                     (int(eid), db.sirket_id(req))).fetchone()
    if not e:
        conn.close()
        return redirect("/edonusum")
    if e["durum"] != "Gönderildi":
        conn.close()
        flash(req, "Mock yanıt yalnızca 'Gönderildi' durumunda uygulanır.", "danger")
        return redirect(f"/edonusum/{eid}")
    yanit = req.form.get("yanit")
    if yanit == "Reddedildi":
        conn.execute("UPDATE e_belge SET durum='Reddedildi', hata_mesaji=?, "
                     "updated_at=datetime('now','localtime') WHERE id=?",
                     ((req.form.get("hata") or "GİB reddi (mock senaryo)").strip(), int(eid)))
    elif yanit == "Onaylandı":
        conn.execute("UPDATE e_belge SET durum='Onaylandı', updated_at=datetime('now','localtime') WHERE id=?",
                     (int(eid),))
    else:
        conn.close()
        flash(req, "Geçersiz mock yanıt.", "danger")
        return redirect(f"/edonusum/{eid}")
    conn.commit()
    conn.close()
    audit(req, "e_belge", int(eid), "mock_yanit", {"yanit": yanit})
    flash(req, f"Mock GİB yanıtı uygulandı: {yanit}.", "ok")
    return redirect(f"/edonusum/{eid}")


@route(r"/edonusum/ayarlar", methods=("GET", "POST"), roles=EDONUSUM_ADMIN)
def edonusum_ayarlar(req):
    # Faz 6.1: entegratör ayarları Ayarlar'a taşındı — eski yol oraya yönlendirilir.
    return redirect("/ayarlar/entegrator")


# --------------------------------------------------------------------------
# Rotalar — GELEN KUTUSU (1.14)
# --------------------------------------------------------------------------
@route(r"/gelen", roles=())
def gelen_liste(req):
    conn = db.get_conn()
    where, params = ["g.sirket_id=?"], [db.sirket_id(req)]
    q = (req.q("q") or "").strip()
    if q:
        where.append("(g.belge_no LIKE ? OR g.gonderen_unvan LIKE ?)")
        params += [f"%{q}%"] * 2
    tur = req.q("tur")
    if tur in ("EFatura", "EIrsaliye"):
        where.append("g.tur=?")
        params.append(tur)
    durum = req.q("durum")
    if durum in GELEN_DURUMLAR:
        where.append("g.durum=?")
        params.append(durum)
    rows = conn.execute(
        "SELECT g.*, f.fatura_no AS don_fatura_no, i.irsaliye_no AS don_irsaliye_no "
        "FROM gelen_belge g LEFT JOIN fatura f ON f.id=g.donusum_fatura_id "
        "LEFT JOIN irsaliye i ON i.id=g.donusum_irsaliye_id "
        "WHERE " + " AND ".join(where) + " ORDER BY g.id DESC", params).fetchall()
    sayac = dict.fromkeys(GELEN_DURUMLAR, 0)
    for r in rows:
        sayac[r["durum"]] = sayac.get(r["durum"], 0) + 1
    conn.close()
    return render_template("gelen/liste.html", rows=rows, q=q, tur=tur, durum=durum,
                           sayac=sayac, GELEN_DURUMLAR=GELEN_DURUMLAR, GELEN_BADGE=GELEN_BADGE)


@route(r"/gelen/yenile", methods=("POST",), roles=EDONUSUM_WRITE)
def gelen_yenile(req):
    enteg = _entegrator()
    gelenler = enteg.gelen_kutusu()
    yeni = 0
    for b in gelenler:
        _, created = _gelen_aktar(b, db.sirket_id(req))
        if created:
            yeni += 1
    flash(req, f"Gelen kutusu yenilendi ({enteg.ad}). {yeni} yeni belge eklendi.", "ok")
    return redirect("/gelen")


@route(r"/gelen/(?P<gid>\d+)", roles=())
def gelen_detay(req, gid):
    conn = db.get_conn()
    g = conn.execute(
        "SELECT g.*, f.fatura_no AS don_fatura_no, i.irsaliye_no AS don_irsaliye_no "
        "FROM gelen_belge g LEFT JOIN fatura f ON f.id=g.donusum_fatura_id "
        "LEFT JOIN irsaliye i ON i.id=g.donusum_irsaliye_id WHERE g.id=? AND g.sirket_id=?",
        (int(gid), db.sirket_id(req))).fetchone()
    if not g:
        conn.close()
        return redirect("/gelen")
    xml_text = _xml_oku(conn, "GelenBelge", int(gid))
    kalemler = _xml_kalemler(xml_text) if xml_text else []
    # her kaleme eşleşen stok kartını göster
    for k in kalemler:
        k["kart"] = _stok_eslestir(conn, k["kod"], k["ad"], db.sirket_id(req))
        k["kart_ad"] = (k["kart"]["ad"] + " (" + k["kart"]["kod"] + ")") if k["kart"] else None
    ekler_list = ekler.ekler_for(conn, "GelenBelge", int(gid))
    tedarikci = _tedarikci_bul(conn, g["gonderen_vkn"], db.sirket_id(req)) if g["gonderen_vkn"] else None
    conn.close()
    return render_template("gelen/detay.html", g=g, kalemler=kalemler, ekler=ekler_list,
                           xml_text=xml_text, tedarikci=tedarikci,
                           GELEN_DURUMLAR=GELEN_DURUMLAR, GELEN_BADGE=GELEN_BADGE)


@route(r"/gelen/(?P<gid>\d+)/durum", methods=("POST",), roles=EDONUSUM_WRITE)
def gelen_durum(req, gid):
    yeni = req.form.get("durum")
    if yeni not in GELEN_DURUMLAR:
        flash(req, "Geçersiz durum.", "danger")
        return redirect(f"/gelen/{gid}")
    conn = db.get_conn()
    g = conn.execute("SELECT * FROM gelen_belge WHERE id=? AND sirket_id=?",
                     (int(gid), db.sirket_id(req))).fetchone()
    if not g:
        conn.close()
        return redirect("/gelen")
    conn.execute("UPDATE gelen_belge SET durum=?, updated_at=datetime('now','localtime') WHERE id=?",
                 (yeni, int(gid)))
    conn.commit()
    conn.close()
    audit(req, "gelen_belge", int(gid), "durum", {"yeni": yeni})
    flash(req, f"Gelen belge durumu: {yeni}.", "ok")
    return redirect(f"/gelen/{gid}")


@route(r"/gelen/(?P<gid>\d+)/donustur", methods=("POST",), roles=EDONUSUM_WRITE)
def gelen_donustur(req, gid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    g = conn.execute("SELECT * FROM gelen_belge WHERE id=? AND sirket_id=?",
                     (int(gid), sid)).fetchone()
    if not g:
        conn.close()
        return redirect("/gelen")
    if g["durum"] in ("Red", "Itiraz"):
        conn.close()
        flash(req, "Red/İtiraz durumundaki belge dönüştürülemez.", "danger")
        return redirect(f"/gelen/{gid}")
    if g["donusum_fatura_id"] or g["donusum_irsaliye_id"]:
        conn.close()
        flash(req, "Bu belge zaten dönüştürülmüş.", "info")
        return redirect(f"/gelen/{gid}")
    tedarikci = _tedarikci_bul(conn, g["gonderen_vkn"], sid) if g["gonderen_vkn"] else None
    if not tedarikci:
        conn.close()
        flash(req, f"Tedarikçi cari kartı bulunamadı (VKN {g['gonderen_vkn']}). "
                   "Önce cari kartı açın.", "danger")
        return redirect(f"/gelen/{gid}")
    xml_text = _xml_oku(conn, "GelenBelge", int(gid))
    kalemler = _xml_kalemler(xml_text) if xml_text else []
    if not kalemler:
        kalemler = [{"kod": None, "ad": g["gonderen_unvan"], "miktar": 1,
                     "birim_fiyat": g["tutar"] or 0, "kdv_orani": 20.0}]

    satirlar = []
    eslesmeyen = []
    for k in kalemler:
        kart = _stok_eslestir(conn, k["kod"], k["ad"], sid)
        if kart:
            satirlar.append({"stok_id": kart["id"], "manuel_ad": "", "miktar": k["miktar"],
                             "birim_fiyat": k["birim_fiyat"],
                             "iskonto_orani": 0.0, "kdv_orani": k["kdv_orani"] or kart["kdv_orani"] or 20})
        else:
            # F4 — eşleşmeyen kalem manuel (serbest metin) satır olur (stok_id NULL).
            ad = f"{k['kod'] or ''} {k['ad'] or ''}".strip() or "Eşleşmeyen gelen belge kalemi"
            eslesmeyen.append(ad)
            satirlar.append({"stok_id": None, "manuel_ad": ad, "miktar": k["miktar"],
                             "birim_fiyat": k["birim_fiyat"],
                             "iskonto_orani": 0.0, "kdv_orani": k["kdv_orani"] or 20})

    yil = datetime.date.today().year
    if g["tur"] == "EFatura":
        top = fatura._toplamlar([dict(s) for s in satirlar])
        no = db.sonraki_belge_no(conn, "fatura", "fatura_no", "AF", yil, sid)
        cur = conn.execute(
            "INSERT INTO fatura(fatura_no, tip, cari_id, tarih, durum, para_birimi, doviz_kur, "
            "ara_toplam, iskonto_toplam, kdv_toplam, genel_toplam, aciklama, created_by, sirket_id) "
            "VALUES(?,?,?,?,'Taslak',?,1,?,0,?,?,?,?,?)",
            (no, "Alis", tedarikci["id"], g["belge_tarih"] or datetime.date.today().isoformat(),
             g["para_birimi"] or "TRY", top["ara_toplam"], top["kdv_toplam"], top["genel_toplam"],
             f"Gelen e-Fatura {g['belge_no']} — {g['gonderen_unvan']}", req.user["id"], sid))
        fid = cur.lastrowid
        for s in satirlar:
            conn.execute(
                "INSERT INTO fatura_kalem(fatura_id, stok_id, varyant_id, miktar, birim_fiyat, "
                "iskonto_orani, kdv_orani, tutar, aciklama, sirket_id) VALUES(?,?,0,?,?,?,?,?,?,?)",
                (fid, s["stok_id"], s["miktar"], s["birim_fiyat"], s["iskonto_orani"],
                 s["kdv_orani"], round(s["miktar"] * s["birim_fiyat"], 2),
                 s.get("manuel_ad") or None, sid))
        conn.execute("UPDATE gelen_belge SET donusum_fatura_id=?, durum='Kabul', "
                     "updated_at=datetime('now','localtime') WHERE id=?", (fid, int(gid)))
        conn.commit()
        conn.close()
        audit(req, "gelen_belge", int(gid), "donustur", {"fatura_id": fid, "eslesmeyen": eslesmeyen})
        flash(req, f"Alış Faturası taslağı oluşturuldu: {no}. "
                   + (f"Eşleşmeyen kalemler: {', '.join(eslesmeyen)}." if eslesmeyen else ""), "ok")
        return redirect(f"/fatura/{fid}")
    # EIrsaliye → Alış İrsaliyesi (Taslak)
    top = fatura._toplamlar([dict(s) for s in satirlar])
    no = db.sonraki_belge_no(conn, "irsaliye", "irsaliye_no", "IRA", yil, sid)
    depo = conn.execute("SELECT id FROM depo WHERE aktif=1 AND sirket_id=? ORDER BY id LIMIT 1",
                        (sid,)).fetchone()
    cur = conn.execute(
        "INSERT INTO irsaliye(irsaliye_no, tip, cari_id, depo_id, tarih, durum, para_birimi, "
        "ara_toplam, iskonto_toplam, kdv_toplam, genel_toplam, aciklama, created_by, sirket_id) "
        "VALUES(?,?,?,?,?,'Taslak','TRY',?,0,?,?,?,?,?)",
        (no, "Alis", tedarikci["id"], depo["id"] if depo else 1,
         g["belge_tarih"] or datetime.date.today().isoformat(), top["ara_toplam"], top["kdv_toplam"],
         top["genel_toplam"], f"Gelen e-İrsaliye {g['belge_no']} — {g['gonderen_unvan']}",
         req.user["id"], sid))
    iid = cur.lastrowid
    for s in satirlar:
        conn.execute(
            "INSERT INTO irsaliye_kalem(irsaliye_id, stok_id, varyant_id, miktar, birim_fiyat, "
            "iskonto_orani, kdv_orani, tutar, aciklama, sirket_id) VALUES(?,?,0,?,?,?,?,?,?,?)",
            (iid, s["stok_id"], s["miktar"], s["birim_fiyat"], s["iskonto_orani"],
             s["kdv_orani"], round(s["miktar"] * s["birim_fiyat"], 2),
             s.get("manuel_ad") or None, sid))
    conn.execute("UPDATE gelen_belge SET donusum_irsaliye_id=?, durum='Kabul', "
                 "updated_at=datetime('now','localtime') WHERE id=?", (iid, int(gid)))
    conn.commit()
    conn.close()
    audit(req, "gelen_belge", int(gid), "donustur", {"irsaliye_id": iid, "eslesmeyen": eslesmeyen})
    flash(req, f"Alış İrsaliyesi taslağı oluşturuldu: {no}. "
               + (f"Eşleşmeyen kalemler: {', '.join(eslesmeyen)}." if eslesmeyen else ""), "ok")
    return redirect(f"/irsaliye/{iid}")


# ---------------------------------------------------------------------------
# F4 (v1.34.0) — GM rotaları: /e-fatura, /e-irsaliye, gelen kutuları, ayarlar
# (Mevcut /edonusum ve /gelen rotaları geriye dönük olarak korunur; bu rotalar
#  aynı TEK entegratör katmanını (_entegrator/_gonder/_olustur) kullanır.)
# ---------------------------------------------------------------------------
@route(r"/e-fatura", roles=())
def e_fatura_liste(req):
    conn = db.get_conn()
    where, params = ["e.sirket_id=? AND e.tur IN ('EFatura','EArsiv')"], [db.sirket_id(req)]
    q = (req.q("q") or "").strip()
    if q:
        where.append("(e.belge_no LIKE ? OR e.alici_unvan LIKE ? OR f.fatura_no LIKE ?)")
        params += [f"%{q}%"] * 3
    durum = req.q("durum")
    if durum in DURUMLAR:
        where.append("e.durum=?")
        params.append(durum)
    rows = conn.execute(
        "SELECT e.*, c.unvan AS cari_unvan, f.fatura_no AS kaynak_fatura_no "
        "FROM e_belge e LEFT JOIN cari_kart c ON c.id=e.cari_id "
        "LEFT JOIN fatura f ON f.id=e.kaynak_fatura_id "
        "WHERE " + " AND ".join(where) + " ORDER BY e.id DESC", params).fetchall()
    sayac = dict.fromkeys(DURUMLAR, 0)
    for r in rows:
        sayac[r["durum"]] = sayac.get(r["durum"], 0) + 1
    enteg = _entegrator()
    conn.close()
    return render_template("e_fatura/liste.html", rows=rows, q=q, durum=durum,
                           sayac=sayac, TUR_LABEL=TUR_LABEL, DURUM_BADGE=DURUM_BADGE, enteg=enteg)


@route(r"/e-fatura/(?P<eid>\d+)/gonder", methods=("POST",), roles=EDONUSUM_WRITE)
def e_fatura_gonder(req, eid):
    conn = db.get_conn()
    e, hata = _gonder(conn, req, eid)
    if hata:
        conn.close()
        flash(req, hata, "danger")
        return redirect(f"/edonusum/{int(eid)}")
    conn.close()
    flash(req, f"e-Belge iletildi. ETN: {e['ettn']} — durum: {e['durum']}.", "ok")
    return redirect("/e-fatura")


@route(r"/e-fatura/(?P<eid>\d+)/iptal", methods=("POST",), roles=EDONUSUM_WRITE)
def e_fatura_iptal(req, eid):
    conn = db.get_conn()
    e = conn.execute("SELECT * FROM e_belge WHERE id=? AND sirket_id=?",
                     (int(eid), db.sirket_id(req))).fetchone()
    if not e:
        conn.close()
        return redirect("/e-fatura")
    if e["durum"] in ("Onaylandı", "Gönderildi"):
        conn.close()
        flash(req, "GİB'e bildirilmiş belge buradan iptal edilemez.", "danger")
        return redirect("/e-fatura")
    conn.execute("UPDATE e_belge SET durum='İptal', updated_at=datetime('now','localtime') WHERE id=?",
                 (int(eid),))
    conn.commit()
    conn.close()
    audit(req, "e_belge", int(eid), "iptal", {})
    flash(req, "e-Belge iptal edildi.", "ok")
    return redirect("/e-fatura")


@route(r"/e-irsaliye", roles=())
def e_irsaliye_liste(req):
    conn = db.get_conn()
    where, params = ["e.sirket_id=? AND e.tur='EIrsaliye'"], [db.sirket_id(req)]
    q = (req.q("q") or "").strip()
    if q:
        where.append("(e.belge_no LIKE ? OR e.alici_unvan LIKE ? OR i.irsaliye_no LIKE ?)")
        params += [f"%{q}%"] * 3
    durum = req.q("durum")
    if durum in DURUMLAR:
        where.append("e.durum=?")
        params.append(durum)
    rows = conn.execute(
        "SELECT e.*, c.unvan AS cari_unvan, i.irsaliye_no AS kaynak_irsaliye_no "
        "FROM e_belge e LEFT JOIN cari_kart c ON c.id=e.cari_id "
        "LEFT JOIN irsaliye i ON i.id=e.kaynak_irsaliye_id "
        "WHERE " + " AND ".join(where) + " ORDER BY e.id DESC", params).fetchall()
    sayac = dict.fromkeys(DURUMLAR, 0)
    for r in rows:
        sayac[r["durum"]] = sayac.get(r["durum"], 0) + 1
    enteg = _entegrator()
    conn.close()
    return render_template("e_irsaliye/liste.html", rows=rows, q=q, durum=durum,
                           sayac=sayac, TUR_LABEL=TUR_LABEL, DURUM_BADGE=DURUM_BADGE, enteg=enteg)


@route(r"/e-irsaliye/(?P<eid>\d+)/gonder", methods=("POST",), roles=EDONUSUM_WRITE)
def e_irsaliye_gonder(req, eid):
    conn = db.get_conn()
    e, hata = _gonder(conn, req, eid)
    if hata:
        conn.close()
        flash(req, hata, "danger")
        return redirect(f"/edonusum/{int(eid)}")
    conn.close()
    flash(req, f"e-İrsaliye iletildi. ETN: {e['ettn']} — durum: {e['durum']}.", "ok")
    return redirect("/e-irsaliye")


def _gelen_liste(req, tur, template):
    conn = db.get_conn()
    where, params = ["g.sirket_id=? AND g.tur=?"], [db.sirket_id(req), tur]
    q = (req.q("q") or "").strip()
    if q:
        where.append("(g.belge_no LIKE ? OR g.gonderen_unvan LIKE ?)")
        params += [f"%{q}%"] * 2
    durum = req.q("durum")
    if durum in GELEN_DURUMLAR:
        where.append("g.durum=?")
        params.append(durum)
    rows = conn.execute(
        "SELECT g.*, f.fatura_no AS don_fatura_no, i.irsaliye_no AS don_irsaliye_no "
        "FROM gelen_belge g LEFT JOIN fatura f ON f.id=g.donusum_fatura_id "
        "LEFT JOIN irsaliye i ON i.id=g.donusum_irsaliye_id "
        "WHERE " + " AND ".join(where) + " ORDER BY g.id DESC", params).fetchall()
    sayac = dict.fromkeys(GELEN_DURUMLAR, 0)
    for r in rows:
        sayac[r["durum"]] = sayac.get(r["durum"], 0) + 1
    enteg = _entegrator()
    conn.close()
    return render_template(template, rows=rows, q=q, durum=durum, sayac=sayac,
                           GELEN_DURUMLAR=GELEN_DURUMLAR, GELEN_BADGE=GELEN_BADGE, enteg=enteg)


@route(r"/e-fatura/gelen", roles=())
def e_fatura_gelen(req):
    return _gelen_liste(req, "EFatura", "e_fatura/gelen.html")


@route(r"/e-irsaliye/gelen", roles=())
def e_irsaliye_gelen(req):
    return _gelen_liste(req, "EIrsaliye", "e_irsaliye/gelen.html")


@route(r"/e-fatura/gelen/cek", methods=("POST",), roles=EDONUSUM_WRITE)
def e_fatura_gelen_cek(req):
    enteg = _entegrator()
    gelenler = [b for b in enteg.gelen_kutusu() if b["tur"] == "EFatura"]
    yeni = 0
    for b in gelenler:
        _, created = _gelen_aktar(b, db.sirket_id(req))
        if created:
            yeni += 1
    flash(req, f"Gelen e-Fatura kutusu yenilendi ({enteg.ad}). {yeni} yeni belge.", "ok")
    return redirect("/e-fatura/gelen")


def _gelen_durum_ayarla(req, gid, yeni, geri):
    if yeni not in GELEN_DURUMLAR:
        flash(req, "Geçersiz durum.", "danger")
        return redirect(geri)
    conn = db.get_conn()
    g = conn.execute("SELECT * FROM gelen_belge WHERE id=? AND sirket_id=?",
                     (int(gid), db.sirket_id(req))).fetchone()
    if not g:
        conn.close()
        return redirect(geri)
    conn.execute("UPDATE gelen_belge SET durum=?, updated_at=datetime('now','localtime') WHERE id=?",
                 (yeni, int(gid)))
    conn.commit()
    conn.close()
    audit(req, "gelen_belge", int(gid), "durum", {"yeni": yeni})
    flash(req, f"Gelen belge durumu: {yeni}.", "ok")
    return redirect(geri)


@route(r"/e-fatura/gelen/(?P<gid>\d+)/kabul", methods=("POST",), roles=EDONUSUM_WRITE)
def e_fatura_gelen_kabul(req, gid):
    return _gelen_durum_ayarla(req, gid, "Kabul", "/e-fatura/gelen")


@route(r"/e-fatura/gelen/(?P<gid>\d+)/red", methods=("POST",), roles=EDONUSUM_WRITE)
def e_fatura_gelen_red(req, gid):
    return _gelen_durum_ayarla(req, gid, "Red", "/e-fatura/gelen")


@route(r"/e-fatura/gelen/(?P<gid>\d+)/donustur", methods=("POST",), roles=EDONUSUM_WRITE)
def e_fatura_gelen_donustur(req, gid):
    return gelen_donustur(req, gid)


@route(r"/e-irsaliye/gelen/(?P<gid>\d+)/donustur", methods=("POST",), roles=EDONUSUM_WRITE)
def e_irsaliye_gelen_donustur(req, gid):
    return gelen_donustur(req, gid)


# --- F4 — Ayarlar: entegratör seçimi (entegrator_ayar, K1) ---
@route(r"/ayarlar/edonusum", methods=("GET",), roles=EDONUSUM_ADMIN)
def ayarlar_edonusum(req):
    conn = db.get_conn()
    row = conn.execute("SELECT * FROM entegrator_ayar WHERE sirket_id=?",
                       (db.sirket_id(req),)).fetchone()
    conn.close()
    enteg = _entegrator()
    saglik = enteg.saglik()
    return render_template("ayarlar/edonusum.html", ayar=row, enteg=enteg, saglik=saglik)


@route(r"/ayarlar/edonusum/kaydet", methods=("POST",), roles=EDONUSUM_ADMIN)
def ayarlar_edonusum_kaydet(req):
    saglayici = (req.form.get("entegrator") or req.form.get("saglayici") or "Mock").strip()
    anahtar = (req.form.get("api_anahtar") or req.form.get("api_anahtari") or "").strip()
    test_modu = 1 if req.form.get("test_modu") == "1" else 0
    conn = db.get_conn()
    conn.execute(
        "INSERT INTO entegrator_ayar(sirket_id, entegrator, api_anahtar, test_modu, updated_at) "
        "VALUES(?,?,?,?,datetime('now','localtime')) "
        "ON CONFLICT(sirket_id) DO UPDATE SET entegrator=excluded.entegrator, "
        "api_anahtar=excluded.api_anahtar, test_modu=excluded.test_modu, "
        "updated_at=excluded.updated_at",
        (db.sirket_id(req), saglayici, anahtar or None, test_modu))
    conn.commit()
    conn.close()
    audit(req, "entegrator_ayar", db.sirket_id(req), "kaydet",
          {"entegrator": saglayici, "test_modu": test_modu})
    flash(req, "e-Dönüşüm ayarları kaydedildi.", "ok")
    return redirect("/ayarlar/edonusum")
