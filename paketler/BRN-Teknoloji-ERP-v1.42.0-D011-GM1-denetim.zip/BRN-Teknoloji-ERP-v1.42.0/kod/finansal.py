# -*- coding: utf-8 -*-
"""Finansal Analiz (1.19) — Faz 5.

Satış / kâr-zarar / nakit akışı grafikleri, dönemsel karşılaştırma (bu ay vs geçen ay vs
geçen yıl), ürün/kategori bazlı en çok satan/en kârlı ürün, cari tahsilat performansı,
servis gelir analizi ve bütçe hedefi tanımlama + gerçekleşen karşılaştırma (Odoo mantığı).

TASARIM (K4/K6): Analitikler **türetilmiş** (salt-okunur) — tek doğruluk kaynakları:
- Satış → `fatura` (tip='Satis', durum='Onaylandı'; TL karşılık `ara_toplam × doviz_kur`).
- Kâr/Zarar → Genel Muhasebe `hesap` Gelir/Gider bakiyeleri (600…679 / 620…770).
- Nakit akışı → `kasa_hareket` + `banka_hareket` (transfer/açılış hariç — mükerrer sayım yok).
- Ürün/kategori → `fatura_kalem` × `stok_kart` × `kategori`.
- Tahsilat → `cari_hareket` (bakiye = Σborç − Σalacak kuralı).
- Servis geliri → `servis_kayit` + `servis_parca`.
YENİ veri modeli yalnızca **bütçe hedefi** (`butce`) içindir; o da analitiklerden bağımsız
bir hedef tablosudur (Odoo bütçe yönetimi mantığı: dönem + tip + hedef tutar).
"""
import datetime
import json

import db
from core import route, render_template, redirect, flash, audit, Response

# F5-A (v1.35.0) — Finansal Analiz yalnızca Yönetici + Muhasebe görebilir.
FINANSAL_GOR = ("Admin", "Muhasebe")
BUTCE_WRITE = ("Admin", "Muhasebe")
AY_KISA = ["Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara"]
AY_AD = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran",
         "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]

# Kâr/zarar hesap grupları (Tekdüzen) — GM'den türetilir.
GELIR_KODLARI = ("600", "602", "642", "646", "679")
GIDER_KODLARI = ("620", "632", "656", "760", "770")


def _f(v, default=0.0):
    try:
        return float(v if v not in (None, "") else default)
    except (TypeError, ValueError):
        return default


def _say(v):
    """Türkçe binlik/ondalık: 1234567.8 -> 1.234.567,80 (işaretsiz)."""
    s = f"{abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return ("-" if v < 0 else "") + s


def _say_k(v):
    """Grafik etiketi için kompakt: 136878 -> 136,9k."""
    a = abs(v)
    if a >= 1_000_000:
        return f"{v/1_000_000:.1f}M".replace(".", ",")
    if a >= 1000:
        return f"{v/1000:.0f}k"
    return f"{v:.0f}"


def _ym_ekle(ym, k):
    y, m = int(ym[:4]), int(ym[5:7]) + k
    while m <= 0:
        m += 12
        y -= 1
    while m > 12:
        m -= 12
        y += 1
    return f"{y:04d}-{m:02d}"


def _son_aylar(n, bit_ym):
    out = []
    for i in range(n - 1, -1, -1):
        ym = _ym_ekle(bit_ym, -i)
        m = int(ym[5:7])
        out.append((ym, f"{AY_KISA[m - 1]} '{str(int(ym[:4]))[2:]}"))
    return out


# --------------------------------------------------------------------------
# Türetilmiş aylık seriler (tek doğruluk kaynakları)
# --------------------------------------------------------------------------
def _satis_aylik(conn, sid=None):
    extra = " AND sirket_id=?" if sid is not None else ""
    args = [sid] if sid is not None else []
    rows = conn.execute(
        "SELECT substr(tarih,1,7) ym, "
        "SUM(ara_toplam * COALESCE(doviz_kur,1)) matrah, "
        "SUM(kdv_toplam * COALESCE(doviz_kur,1)) kdv, "
        "COUNT(*) adet FROM fatura WHERE tip='Satis' AND durum='Onaylandı'" + extra + " GROUP BY ym",
        args
    ).fetchall()
    return {r["ym"]: (r["matrah"] or 0.0, r["kdv"] or 0.0, r["adet"]) for r in rows}


def _kz_aylik(conn, sid=None):
    """Kâr/zarar (GM esaslı): Gelir = Gelir hesapları net alacak, Gider = Gider hesapları net borç."""
    extra = " AND y.sirket_id=?" if sid is not None else ""
    args = [sid] if sid is not None else []
    rows = conn.execute(
        "SELECT substr(y.tarih,1,7) ym, "
        "SUM(CASE WHEN h.tip='Gelir' THEN k.alacak - k.borc ELSE 0 END) gelir, "
        "SUM(CASE WHEN h.tip='Gider' THEN k.borc - k.alacak ELSE 0 END) gider "
        "FROM yevmiye_kalem k JOIN hesap h ON h.id=k.hesap_id "
        "JOIN yevmiye y ON y.id=k.yevmiye_id "
        "WHERE y.durum='Onaylandı' AND h.tip IN ('Gelir','Gider')" + extra + " GROUP BY ym",
        args
    ).fetchall()
    return {r["ym"]: (r["gelir"] or 0.0, r["gider"] or 0.0) for r in rows}


def _nakit_aylik(conn, sid=None):
    """İşletme nakit akışı: transfer ve açılış bakiyesi HARİÇ (mükerrer/gerçek-dışı sayım önlenir)."""
    extra = " AND sirket_id=?" if sid is not None else ""
    args = [sid] if sid is not None else []
    out = {}
    for r in conn.execute(
        "SELECT substr(tarih,1,7) ym, "
        "SUM(CASE WHEN islem_tipi='Nakit Girişi' THEN tutar*COALESCE(doviz_kur,1) ELSE 0 END) g, "
        "SUM(CASE WHEN islem_tipi='Nakit Çıkışı' THEN tutar*COALESCE(doviz_kur,1) ELSE 0 END) c "
        "FROM kasa_hareket WHERE 1=1" + extra + " GROUP BY ym", args
    ).fetchall():
        d = out.setdefault(r["ym"], [0.0, 0.0])
        d[0] += r["g"] or 0.0
        d[1] += r["c"] or 0.0
    for r in conn.execute(
        "SELECT substr(tarih,1,7) ym, "
        "SUM(CASE WHEN islem_tipi IN ('Havale/EFT Girişi','Banka Ekstresi (Giriş)') "
        "THEN tutar*COALESCE(doviz_kur,1) ELSE 0 END) g, "
        "SUM(CASE WHEN islem_tipi IN ('Havale/EFT Çıkışı','Banka Ekstresi (Çıkış)') "
        "THEN tutar*COALESCE(doviz_kur,1) ELSE 0 END) c "
        "FROM banka_hareket WHERE 1=1" + extra + " GROUP BY ym", args
    ).fetchall():
        d = out.setdefault(r["ym"], [0.0, 0.0])
        d[0] += r["g"] or 0.0
        d[1] += r["c"] or 0.0
    return out


def _cogs_aylik(conn, sid=None):
    """Tahmini brüt kâr (COGS dahil) — 'En Kârlı Ürün' yönteminin aylık toplamı:
    fatura kalemi cirosu (TL karşılık) − (miktar × güncel alış fiyatı). Tahminidir
    (tarihsel maliyet yerine güncel `stok_kart.alis_fiyat` kullanılır)."""
    extra = " AND f.sirket_id=?" if sid is not None else ""
    args = [sid] if sid is not None else []
    rows = conn.execute(
        "SELECT substr(f.tarih,1,7) ym, "
        "SUM(fk.tutar * COALESCE(f.doviz_kur,1)) ciro, "
        "SUM(fk.miktar * s.alis_fiyat) maliyet "
        "FROM fatura_kalem fk JOIN fatura f ON f.id=fk.fatura_id "
        "JOIN stok_kart s ON s.id=fk.stok_id "
        "WHERE f.tip='Satis' AND f.durum='Onaylandı'" + extra + " GROUP BY ym", args
    ).fetchall()
    return {r["ym"]: (r["ciro"] or 0.0, r["maliyet"] or 0.0) for r in rows}


# --------------------------------------------------------------------------
# F5-A (v1.35.0) — dashboard / bütçe / API yardımcıları
# --------------------------------------------------------------------------
def _satis_genel_aylik(conn, sid=None):
    """Onaylı satış faturalarının GENEL TOPLAM (KDV dahil, TL) aylık — dashboard
    'Bu Ay Satış' kartı ve bütçe gerçekleşeniyle AYNI metrik (cari_hareket borcu)."""
    extra = " AND sirket_id=?" if sid is not None else ""
    args = [sid] if sid is not None else []
    rows = conn.execute(
        "SELECT substr(tarih,1,7) ym, "
        "SUM(genel_toplam * COALESCE(doviz_kur,1)) t "
        "FROM fatura WHERE tip='Satis' AND durum='Onaylandı'" + extra + " GROUP BY ym",
        args).fetchall()
    return {r["ym"]: (r["t"] or 0.0) for r in rows}


def _alis_genel_aylik(conn, sid=None):
    """Onaylı alış faturalarının GENEL TOPLAM (KDV dahil, TL) aylık."""
    extra = " AND sirket_id=?" if sid is not None else ""
    args = [sid] if sid is not None else []
    rows = conn.execute(
        "SELECT substr(tarih,1,7) ym, "
        "SUM(genel_toplam * COALESCE(doviz_kur,1)) t "
        "FROM fatura WHERE tip='Alis' AND durum='Onaylandı'" + extra + " GROUP BY ym",
        args).fetchall()
    return {r["ym"]: (r["t"] or 0.0) for r in rows}


def _nakit_gunluk(conn, sid=None, gun=30):
    """Son `gun` günün günlük net nakit akışı (kasa + banka; transfer/açılış hariç).

    Dönüş: [{"tarih": "YYYY-MM-DD", "giris": x, "cikis": y, "net": x-y}, ...] kronolojik.
    """
    extra = " AND sirket_id=?" if sid is not None else ""
    args = [sid] if sid is not None else []
    gunler = {}
    bugun = datetime.date.today()
    for i in range(gun):
        d = (bugun - datetime.timedelta(days=gun - 1 - i)).isoformat()
        gunler[d] = [0.0, 0.0]

    for r in conn.execute(
        "SELECT tarih, islem_tipi, tutar, doviz_kur FROM kasa_hareket WHERE 1=1" + extra,
        args).fetchall():
        d = (r["tarih"] or "")[:10]
        if d not in gunler:
            continue
        t = (r["tutar"] or 0.0) * (r["doviz_kur"] or 1.0)
        if r["islem_tipi"] == "Nakit Girişi":
            gunler[d][0] += t
        elif r["islem_tipi"] == "Nakit Çıkışı":
            gunler[d][1] += t
    for r in conn.execute(
        "SELECT tarih, islem_tipi, tutar, doviz_kur FROM banka_hareket WHERE 1=1" + extra,
        args).fetchall():
        d = (r["tarih"] or "")[:10]
        if d not in gunler:
            continue
        t = (r["tutar"] or 0.0) * (r["doviz_kur"] or 1.0)
        if r["islem_tipi"] in ("Havale/EFT Girişi", "Banka Ekstresi (Giriş)"):
            gunler[d][0] += t
        elif r["islem_tipi"] in ("Havale/EFT Çıkışı", "Banka Ekstresi (Çıkış)"):
            gunler[d][1] += t
    out = []
    for d, (g, c) in sorted(gunler.items()):
        out.append({"tarih": d, "giris": round(g, 2), "cikis": round(c, 2),
                    "net": round(g - c, 2)})
    return out


def _bu_ay_kar(conn, sid, bugun=None):
    """Bu ay brüt kâr (ciro − maliyet; maliyet = miktar × güncel alış fiyatı)."""
    bugun = bugun or datetime.date.today()
    ym = f"{bugun.year:04d}-{bugun.month:02d}"
    ci, ma = _cogs_aylik(conn, sid).get(ym, (0.0, 0.0))
    return round(ci - ma, 2)


def _banka_bakiye(conn, sid=None):
    """Aktif banka hesaplarının TL karşılık toplam bakiyesi (K1 süzgeci)."""
    where, params = ["1=1"], []
    if sid is not None:
        where.append("h.sirket_id=?")
        params.append(sid)
    rows = conn.execute(
        "SELECT h.id FROM banka_hesap h WHERE h.aktif=1 AND " + " AND ".join(where),
        params).fetchall()
    toplam = 0.0
    for h in rows:
        toplam += _banka_bakiye_hesap(conn, h["id"])
    return round(toplam, 2)


def _banka_bakiye_hesap(conn, hesap_id):
    rows = conn.execute(
        "SELECT islem_tipi, tutar, doviz_kur FROM banka_hareket WHERE banka_hesap_id=?",
        (hesap_id,)).fetchall()
    def yon(tip):
        return 1 if tip in ("Havale/EFT Girişi", "Banka Ekstresi (Giriş)", "Açılış Bakiyesi (Giriş)") else -1
    return round(sum(yon(r["islem_tipi"]) * (r["tutar"] or 0.0) * (r["doviz_kur"] or 1.0)
                     for r in rows), 2)


def _urun_top(conn, sid=None, limit=10):
    """En çok satan / en kârlı ürünler (API + ekran ortak). Kâr = net ciro − (miktar×alış)."""
    extra = " AND f.sirket_id=?" if sid is not None else ""
    args = [sid] if sid is not None else []
    rows = conn.execute(
        "SELECT s.id, s.kod, s.ad, s.alis_fiyat, "
        "SUM(fk.miktar) adet, "
        "SUM(fk.tutar * COALESCE(f.doviz_kur,1)) ciro, "
        "SUM((fk.birim_fiyat * COALESCE(f.doviz_kur,1) - s.alis_fiyat) * fk.miktar) kar "
        "FROM fatura_kalem fk JOIN fatura f ON f.id=fk.fatura_id "
        "JOIN stok_kart s ON s.id=fk.stok_id "
        "WHERE f.tip='Satis' AND f.durum='Onaylandı'" + extra + " GROUP BY s.id",
        args).fetchall()
    urunler = []
    for r in rows:
        urunler.append({"kod": r["kod"], "ad": r["ad"],
                        "adet": round(r["adet"] or 0.0, 2),
                        "ciro": round(r["ciro"] or 0.0, 2),
                        "kar": round(r["kar"] or 0.0, 2)})
    return urunler


def _cari_ciro_top(conn, sid=None, limit=10):
    """En çok ciro yapan cariler (onaylı satış faturaları, genel toplam TL)."""
    extra = " AND f.sirket_id=?" if sid is not None else ""
    args = [sid] if sid is not None else []
    rows = conn.execute(
        "SELECT c.id, c.kod, c.unvan, "
        "SUM(f.genel_toplam * COALESCE(f.doviz_kur,1)) ciro "
        "FROM fatura f JOIN cari_kart c ON c.id=f.cari_id "
        "WHERE f.tip='Satis' AND f.durum='Onaylandı'" + extra + " "
        "GROUP BY c.id ORDER BY ciro DESC LIMIT ?",
        args + [limit]).fetchall()
    return [{"kod": r["kod"], "unvan": r["unvan"],
             "ciro": round(r["ciro"] or 0.0, 2)} for r in rows]


def _tahsilat_tediye_ay(conn, sid, bugun=None):
    """Bu ay tahsilat (kasa/banka giriş) ve tediye (çıkış) TL toplamı."""
    bugun = bugun or datetime.date.today()
    bas = f"{bugun.year:04d}-{bugun.month:02d}-01"
    tahsilat = conn.execute(
        "SELECT COALESCE(SUM(tutar*COALESCE(doviz_kur,1)),0) t FROM kasa_hareket "
        "WHERE islem_tipi='Nakit Girişi' AND tarih>=? AND sirket_id=?",
        (bas, sid)).fetchone()["t"]
    tahsilat += conn.execute(
        "SELECT COALESCE(SUM(tutar*COALESCE(doviz_kur,1)),0) t FROM banka_hareket "
        "WHERE islem_tipi IN ('Havale/EFT Girişi','Banka Ekstresi (Giriş)') AND tarih>=? AND sirket_id=?",
        (bas, sid)).fetchone()["t"]
    tediye = conn.execute(
        "SELECT COALESCE(SUM(tutar*COALESCE(doviz_kur,1)),0) t FROM kasa_hareket "
        "WHERE islem_tipi='Nakit Çıkışı' AND tarih>=? AND sirket_id=?",
        (bas, sid)).fetchone()["t"]
    tediye += conn.execute(
        "SELECT COALESCE(SUM(tutar*COALESCE(doviz_kur,1)),0) t FROM banka_hareket "
        "WHERE islem_tipi IN ('Havale/EFT Çıkışı','Banka Ekstresi (Çıkış)') AND tarih>=? AND sirket_id=?",
        (bas, sid)).fetchone()["t"]
    return round(tahsilat, 2), round(tediye, 2)


# --------------------------------------------------------------------------
# SVG grafik yardımcıları (harici kütüphane yok — çevrimdışı önizlemede de çalışır)
# --------------------------------------------------------------------------
def _bar_svg(points, width=640, height=230, color="#4f8cff", neg="#e5534b"):
    """Dikey çubuk grafik. points: [(etiket, değer), ...] (değer negatif olabilir)."""
    if not points:
        return '<div class="empty">Bu aralıkta veri yok.</div>'
    vals = [p[1] for p in points]
    vmax = max(abs(v) for v in vals) or 1.0
    left, right, top, bottom = 10, width - 10, 16, height - 26
    plot_h = bottom - top
    n = len(points)
    bw = (right - left) / n
    bar_w = max(4.0, bw * 0.56)
    has_neg = any(v < 0 for v in vals)
    if has_neg:
        zero_y = top + plot_h / 2
        scale = (plot_h / 2) / vmax
    else:
        zero_y = bottom
        scale = plot_h / vmax
    p = [f'<svg viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg" '
         f'role="img" style="width:100%;height:auto;display:block;">']
    for i in range(4):
        y = top + plot_h * i / 3
        p.append(f'<line x1="{left}" y1="{y:.1f}" x2="{right}" y2="{y:.1f}" '
                 f'stroke="#273042" stroke-width="1"/>')
    p.append(f'<line x1="{left}" y1="{zero_y:.1f}" x2="{right}" y2="{zero_y:.1f}" '
             f'stroke="#5a6478" stroke-width="1.2"/>')
    for i, (lab, v) in enumerate(points):
        x = left + bw * i + (bw - bar_w) / 2
        h = abs(v) * scale
        y = zero_y - h if v >= 0 else zero_y
        c = color if v >= 0 else neg
        p.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{bar_w:.1f}" '
                 f'height="{max(h, 0.001):.1f}" rx="2" fill="{c}"/>')
        ty = (zero_y - h - 4) if v >= 0 else (zero_y + 12)
        p.append(f'<text x="{x + bar_w / 2:.1f}" y="{ty:.1f}" fill="#cbd5e1" '
                 f'font-size="9" text-anchor="middle">{_say_k(v)}</text>')
        p.append(f'<text x="{x + bar_w / 2:.1f}" y="{height - 8}" fill="#8b95a7" '
                 f'font-size="9" text-anchor="middle">{lab}</text>')
    p.append('</svg>')
    return "".join(p)


def _bar2_svg(a_pts, b_pts, width=640, height=240, color_a="#3fbf7f", color_b="#f0a34a"):
    """Gruplu (ikili) dikey çubuk: iki seriyi yan yana çizer (aynı etiketler)."""
    if not a_pts:
        return '<div class="empty">Bu aralıkta veri yok.</div>'
    vals = [v for _, v in a_pts] + [v for _, v in b_pts]
    vmin = min(0.0, min(vals))
    vmax = max(0.0, max(vals))
    span = (vmax - vmin) or 1.0
    left, right, top, bottom = 10, width - 10, 16, height - 26
    plot_h = bottom - top
    n = len(a_pts)
    gw = (right - left) / n
    bar_w = max(3.0, gw * 0.30)

    def y_of(v):
        return top + (vmax - v) / span * plot_h

    zero_y = y_of(0.0)
    p = [f'<svg viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg" '
         f'role="img" style="width:100%;height:auto;display:block;">']
    for frac in (0.0, 0.5, 1.0):
        y = top + plot_h * frac
        p.append(f'<line x1="{left}" y1="{y:.1f}" x2="{right}" y2="{y:.1f}" '
                 f'stroke="#273042" stroke-width="1"/>')
    p.append(f'<line x1="{left}" y1="{zero_y:.1f}" x2="{right}" y2="{zero_y:.1f}" '
             f'stroke="#5a6478" stroke-width="1.2"/>')
    for i in range(n):
        lab = a_pts[i][0]
        cx = left + gw * i + gw / 2
        x0 = cx - bar_w - 1.5
        for pts, color in ((a_pts, color_a), (b_pts, color_b)):
            v = pts[i][1]
            y0 = min(y_of(v), zero_y)
            h = abs(y_of(v) - zero_y)
            p.append(f'<rect x="{x0:.1f}" y="{y0:.1f}" width="{bar_w:.1f}" '
                     f'height="{max(h, 0.001):.1f}" rx="1.5" fill="{color}"/>')
            x0 += bar_w + 3
        p.append(f'<text x="{cx:.1f}" y="{height - 8}" fill="#8b95a7" '
                 f'font-size="9" text-anchor="middle">{lab}</text>')
    p.append('</svg>')
    return "".join(p)


def _hbar_svg(rows, value_key, width=640, bar_h=26, color="#4f8cff", neg="#e5534b"):
    """Yatay sıralama çubuğu. rows: [{'ad':.., value_key:..}, ...]."""
    if not rows:
        return '<div class="empty">Bu aralıkta veri yok.</div>'
    vmax = max(abs(r[value_key]) for r in rows) or 1.0
    left = 170
    right_num = 64
    height = len(rows) * bar_h + 10
    p = [f'<svg viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg" '
         f'role="img" style="width:100%;height:auto;display:block;">']
    for i, r in enumerate(rows):
        y = 4 + i * bar_h
        v = r[value_key]
        w = abs(v) / vmax * (width - left - right_num - 8)
        c = color if v >= 0 else neg
        p.append(f'<text x="4" y="{y + bar_h / 2 + 3}" fill="#cbd5e1" font-size="11" '
                 f'text-anchor="start">{str(r["ad"])[:26]}</text>')
        p.append(f'<rect x="{left}" y="{y}" width="{max(w, 1.0):.1f}" height="{bar_h - 8}" '
                 f'rx="3" fill="{c}"/>')
        p.append(f'<text x="{left + w + 6:.1f}" y="{y + bar_h / 2 + 3}" fill="#8b95a7" '
                 f'font-size="10">{_say_k(v)}</text>')
    p.append('</svg>')
    return "".join(p)


def _delta_pct(yeni, eski):
    if eski == 0:
        return None
    return (yeni - eski) / abs(eski) * 100


def _ok(yeni, eski):
    d = _delta_pct(yeni, eski)
    if d is None:
        return "", "—"
    return ("▲" if d >= 0 else "▼"), f"{abs(d):.1f}%"


# --------------------------------------------------------------------------
# Rotalar
# --------------------------------------------------------------------------
@route(r"/finansal", roles=FINANSAL_GOR)
def finansal_dashboard(req):
    conn = db.get_conn()
    bugun = datetime.date.today()
    ref = req.q("ay") or f"{bugun.year:04d}-{bugun.month:02d}"
    if len(ref) != 7 or ref[4] != "-":
        ref = f"{bugun.year:04d}-{bugun.month:02d}"

    sid = db.sirket_id(req)
    satis = _satis_aylik(conn, sid)
    kz = _kz_aylik(conn, sid)
    nak = _nakit_aylik(conn, sid)
    cogs = _cogs_aylik(conn, sid)

    # 12 aylık seriler
    aylar = _son_aylar(12, ref)
    satis_seri = [(lab, satis.get(ym, (0, 0, 0))[0]) for ym, lab in aylar]
    kz_seri = []
    cogs_seri = []
    for ym, lab in aylar:
        g, gr = kz.get(ym, (0, 0))
        kz_seri.append((lab, g - gr))
        ci, ma = cogs.get(ym, (0.0, 0.0))
        cogs_seri.append((lab, ci - ma))
    nakit_seri = []
    for ym, lab in aylar:
        ng, nc = nak.get(ym, (0.0, 0.0))
        nakit_seri.append((lab, ng - nc))

    # Dönemsel karşılaştırma
    def _per(ym):
        s = satis.get(ym, (0, 0, 0))
        g, gr = kz.get(ym, (0, 0))
        ng, nc = nak.get(ym, (0.0, 0.0))
        ci, ma = cogs.get(ym, (0.0, 0.0))
        return {"satis": s[0], "kdv": s[1], "adet": s[2], "net_kar": g - gr,
                "brut_kar": ci - ma, "nakit_giris": ng, "nakit_cikis": nc,
                "nakit_net": ng - nc}

    bu, ge, gy = _per(ref), _per(_ym_ekle(ref, -1)), _per(_ym_ekle(ref, -12))
    karsilastirma = {
        "bu": bu, "gecen": ge, "gecen_yil": gy,
        "bu_ok": _ok(bu["satis"], ge["satis"]),
        "bu_ok_yil": _ok(bu["satis"], gy["satis"]),
    }

    # KPI: kümülatif (tüm onaylı dönem)
    toplam_satis = sum(v[0] for v in satis.values())
    toplam_kdv = sum(v[1] for v in satis.values())
    toplam_gelir = sum(g for g, _ in kz.values())
    toplam_gider = sum(gr for _, gr in kz.values())
    toplam_brut = sum(ci - ma for ci, ma in cogs.values())

    # F5-A (v1.35.0) — seçili dönem için bütçe hedefi vs gerçekleşen (analiz sayfası).
    ref_yil, ref_ay = int(ref[:4]), int(ref[5:7])
    hedef = conn.execute(
        "SELECT * FROM butce_hedef WHERE sirket_id=? AND yil=? AND ay=?",
        (sid, ref_yil, ref_ay)).fetchone()
    gercek_satis = round(_satis_genel_aylik(conn, sid).get(ref, 0.0), 2)
    gercek_kar = round(bu["brut_kar"], 2)
    butce_karsilastirma = {"hedef": hedef, "gercek_satis": gercek_satis,
                           "gercek_kar": gercek_kar}

    conn.close()
    return render_template(
        "finansal/index.html",
        ref=ref,
        ay_ad=f"{AY_AD[int(ref[5:7]) - 1]} {ref[:4]}",
        satis_svg=_bar_svg(satis_seri, color="#4f8cff"),
        kz_svg=_bar2_svg(kz_seri, cogs_seri, color_a="#3fbf7f", color_b="#f0a34a"),
        nakit_svg=_bar_svg(nakit_seri, color="#f0a34a"),
        karsilastirma=karsilastirma,
        toplam_satis=toplam_satis,
        toplam_kdv=toplam_kdv,
        toplam_gelir=toplam_gelir,
        toplam_gider=toplam_gider,
        toplam_brut=toplam_brut,
        net_kar=toplam_gelir - toplam_gider,
        butce_karsilastirma=butce_karsilastirma,
    )


@route(r"/finansal/urunler", roles=FINANSAL_GOR)
def finansal_urunler(req):
    conn = db.get_conn()
    urunler = [dict(r) for r in conn.execute(
        "SELECT s.id, s.kod, s.ad, s.alis_fiyat, COALESCE(k.ad,'(Kategorisiz)') kat, "
        "SUM(fk.miktar) adet, "
        "SUM(fk.tutar * COALESCE(f.doviz_kur,1)) ciro, "
        "SUM((fk.birim_fiyat * COALESCE(f.doviz_kur,1) - s.alis_fiyat) * fk.miktar) kar "
        "FROM fatura_kalem fk JOIN fatura f ON f.id=fk.fatura_id "
        "JOIN stok_kart s ON s.id=fk.stok_id LEFT JOIN kategori k ON k.id=s.kategori_id "
        "WHERE f.tip='Satis' AND f.durum='Onaylandı' AND f.sirket_id=? GROUP BY s.id",
        (db.sirket_id(req),)
    ).fetchall()]
    for u in urunler:
        u["adet"] = u["adet"] or 0
        u["ciro"] = u["ciro"] or 0.0
        u["kar"] = u["kar"] or 0.0
    cok_satan = sorted(urunler, key=lambda u: -u["adet"])[:10]
    karlilar = sorted(urunler, key=lambda u: -u["kar"])[:10]

    kategoriler = [dict(r) for r in conn.execute(
        "SELECT COALESCE(k.ad,'(Kategorisiz)') kat, "
        "SUM(fk.tutar * COALESCE(f.doviz_kur,1)) ciro, SUM(fk.miktar) adet "
        "FROM fatura_kalem fk JOIN fatura f ON f.id=fk.fatura_id "
        "JOIN stok_kart s ON s.id=fk.stok_id LEFT JOIN kategori k ON k.id=s.kategori_id "
        "WHERE f.tip='Satis' AND f.durum='Onaylandı' AND f.sirket_id=? "
        "GROUP BY COALESCE(k.ad,'(Kategorisiz)') ORDER BY ciro DESC",
        (db.sirket_id(req),)
    ).fetchall()]
    for k in kategoriler:
        k["ciro"] = k["ciro"] or 0.0
        k["adet"] = k["adet"] or 0

    n_urun = len(urunler)
    toplam_ciro = sum(u["ciro"] for u in urunler)
    toplam_kar = sum(u["kar"] for u in urunler)
    conn.close()
    return render_template(
        "finansal/urunler.html",
        cok_satan=cok_satan,
        karlilar=karlilar,
        kategoriler=kategoriler,
        n_urun=n_urun,
        toplam_ciro=toplam_ciro,
        toplam_kar=toplam_kar,
        cok_satan_svg=_hbar_svg([{"ad": u["ad"], "adet": u["adet"]} for u in cok_satan], "adet", color="#4f8cff"),
        karlilar_svg=_hbar_svg([{"ad": u["ad"], "kar": u["kar"]} for u in karlilar], "kar", color="#3fbf7f"),
    )


@route(r"/finansal/tahsilat", roles=FINANSAL_GOR)
def finansal_tahsilat(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    caris = conn.execute(
        "SELECT * FROM cari_kart WHERE aktif=1 AND tip IN ('Musteri','HerIkisi') AND sirket_id=? "
        "ORDER BY unvan", (sid,)
    ).fetchall()
    rows = []
    for c in caris:
        borc = conn.execute(
            "SELECT COALESCE(SUM(borc),0) s FROM cari_hareket "
            "WHERE cari_id=? AND belge_tipi='Satış Faturası' AND sirket_id=?", (c["id"], sid)).fetchone()["s"]
        tahsilat = conn.execute(
            "SELECT COALESCE(SUM(alacak),0) s FROM cari_hareket "
            "WHERE cari_id=? AND belge_tipi='Tahsilat' AND sirket_id=?", (c["id"], sid)).fetchone()["s"]
        bakiye = conn.execute(
            "SELECT COALESCE(SUM(borc),0)-COALESCE(SUM(alacak),0) s "
            "FROM cari_hareket WHERE cari_id=? AND sirket_id=?", (c["id"], sid)).fetchone()["s"]
        rows.append({"kod": c["kod"], "unvan": c["unvan"], "borc": borc,
                     "tahsilat": tahsilat, "bakiye": bakiye,
                     "oran": (tahsilat / borc * 100) if borc > 0 else None})
    rows.sort(key=lambda r: -(r["borc"] or 0))

    # Servis gelir analizi
    parca = {r["servis_id"]: r["t"] for r in conn.execute(
        "SELECT servis_id, SUM(tutar) t FROM servis_parca WHERE sirket_id=? GROUP BY servis_id",
        (sid,)).fetchall()}
    srows = conn.execute("SELECT * FROM servis_kayit WHERE sirket_id=? ORDER BY gelis_tarihi",
                         (sid,)).fetchall()
    aylik = {}
    toplam = 0.0
    toplam_iscilik = 0.0
    toplam_parca = 0.0
    durumlar = {}
    garanti_n = ucretli_n = 0
    garanti_t = ucretli_t = 0.0
    for s in srows:
        p = parca.get(s["id"], 0.0) or 0.0
        gelir = (s["iscilik_ucreti"] or 0.0) + p
        ym = (s["gelis_tarihi"] or "")[:7]
        aylik[ym] = aylik.get(ym, 0.0) + gelir
        toplam += gelir
        toplam_iscilik += s["iscilik_ucreti"] or 0.0
        toplam_parca += p
        durumlar[s["durum"]] = durumlar.get(s["durum"], 0) + 1
        if s["garanti_kapsami"]:
            garanti_n += 1
            garanti_t += gelir
        else:
            ucretli_n += 1
            ucretli_t += gelir
    svc_aylar = _son_aylar(6, f"{datetime.date.today().year:04d}-{datetime.date.today().month:02d}")
    svc_seri = [(lab, aylik.get(ym, 0.0)) for ym, lab in svc_aylar]
    conn.close()

    toplam_borc = sum(r["borc"] for r in rows)
    toplam_tahsilat = sum(r["tahsilat"] for r in rows)
    return render_template(
        "finansal/tahsilat.html",
        rows=rows,
        toplam_borc=toplam_borc,
        toplam_tahsilat=toplam_tahsilat,
        genel_oran=(toplam_tahsilat / toplam_borc * 100) if toplam_borc > 0 else None,
        servis_toplam=toplam,
        servis_iscilik=toplam_iscilik,
        servis_parca=toplam_parca,
        servis_adet=len(srows),
        durumlar=durumlar,
        garanti_n=garanti_n,
        garanti_t=garanti_t,
        ucretli_n=ucretli_n,
        ucretli_t=ucretli_t,
        servis_svg=_bar_svg(svc_seri, color="#8b5cf6"),
        tahsilat_svg=_hbar_svg([{"ad": r["unvan"], "oran": r["oran"] if r["oran"] is not None else 0}
                                for r in rows], "oran", color="#4f8cff"),
    )


@route(r"/finansal/butce", methods=("GET",), roles=FINANSAL_GOR)
def finansal_butce(req):
    conn = db.get_conn()
    bugun = datetime.date.today()
    sid = db.sirket_id(req)
    yil = _f(req.q("yil") or bugun.year, bugun.year)
    yil = int(yil) if yil > 0 else bugun.year
    hedefler = conn.execute(
        "SELECT * FROM butce_hedef WHERE yil=? AND sirket_id=? ORDER BY ay",
        (yil, sid)).fetchall()
    hmap = {r["ay"]: r for r in hedefler}
    satis_gen = _satis_genel_aylik(conn, sid)
    cogs = _cogs_aylik(conn, sid)
    satirlar = []
    for ay in range(1, 13):
        ym = f"{yil:04d}-{ay:02d}"
        h = hmap.get(ay)
        gsatis = satis_gen.get(ym, 0.0)
        ci, ma = cogs.get(ym, (0.0, 0.0))
        gkar = round(ci - ma, 2)
        hs, hk = (h["hedef_satis"], h["hedef_kar"]) if h else (0.0, 0.0)
        satirlar.append({
            "ay": ay,
            "hedef_satis": hs, "gercek_satis": round(gsatis, 2),
            "satis_sapma": round((gsatis - hs) / hs * 100, 1) if hs else None,
            "hedef_kar": hk, "gercek_kar": gkar,
            "kar_sapma": round((gkar - hk) / hk * 100, 1) if hk else None,
            "id": h["id"] if h else None,
        })
    conn.close()
    return render_template("finansal/butce.html", yil=yil, satirlar=satirlar, AY_AD=AY_AD)


@route(r"/finansal/butce/kaydet", methods=("POST",), roles=BUTCE_WRITE)
def finansal_butce_kaydet(req):
    conn = db.get_conn()
    yil = _f(req.form.get("yil"))
    ay = _f(req.form.get("ay"))
    hedef_satis = _f(req.form.get("hedef_satis"))
    hedef_kar = _f(req.form.get("hedef_kar"))
    if not (1 <= ay <= 12) or yil <= 0 or hedef_satis < 0 or hedef_kar < 0:
        flash(req, "Geçerli yıl, ay (1-12) ve negatif olmayan hedefler zorunludur.", "danger")
        conn.close()
        return redirect("/finansal/butce")
    conn.execute(
        "INSERT INTO butce_hedef(sirket_id, yil, ay, hedef_satis, hedef_kar, olusturan) "
        "VALUES(?,?,?,?,?,?) "
        "ON CONFLICT(sirket_id, yil, ay) DO UPDATE SET hedef_satis=excluded.hedef_satis, "
        "hedef_kar=excluded.hedef_kar, olusturan=excluded.olusturan, "
        "olusturma_tarihi=datetime('now','localtime')",
        (db.sirket_id(req), int(yil), int(ay), hedef_satis, hedef_kar,
         req.user["id"] if req.user else None))
    conn.commit()
    audit(req, "butce_hedef", db.sirket_id(req), "kaydet",
          {"yil": int(yil), "ay": int(ay), "hedef_satis": hedef_satis, "hedef_kar": hedef_kar})
    conn.close()
    flash(req, f"{int(yil)}-{int(ay):02d} bütçe hedefi kaydedildi.", "ok")
    return redirect(f"/finansal/butce?yil={int(yil)}")


@route(r"/finansal/butce/(?P<bid>\d+)/sil", methods=("POST",), roles=BUTCE_WRITE)
def finansal_butce_sil(req, bid):
    conn = db.get_conn()
    b = conn.execute("SELECT * FROM butce_hedef WHERE id=? AND sirket_id=?",
                     (int(bid), db.sirket_id(req))).fetchone()
    if not b:
        conn.close()
        flash(req, "Bütçe hedefi bulunamadı.", "danger")
        return redirect("/finansal/butce")
    conn.execute("DELETE FROM butce_hedef WHERE id=?", (int(bid),))
    conn.commit()
    audit(req, "butce_hedef", int(bid), "sil", {"yil": b["yil"], "ay": b["ay"]})
    conn.close()
    flash(req, "Bütçe hedefi silindi.", "ok")
    return redirect(f"/finansal/butce?yil={b['yil']}")


# --------------------------------------------------------------------------
# F5-A — JSON özet ucu (dashboard grafikleri + en çok analizleri + bütçe)
# --------------------------------------------------------------------------
def _json(data):
    return Response(json.dumps(data, ensure_ascii=False), "200 OK",
                    [("Content-Type", "application/json; charset=utf-8")])


@route(r"/api/finansal/ozet", roles=FINANSAL_GOR)
def api_finansal_ozet(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    bugun = datetime.date.today()
    donem = req.q("donem") or "aylik"
    ym = f"{bugun.year:04d}-{bugun.month:02d}"

    satis_gen = _satis_genel_aylik(conn, sid)
    alis_gen = _alis_genel_aylik(conn, sid)
    cogs = _cogs_aylik(conn, sid)

    if donem == "haftalik":
        bas = (bugun - datetime.timedelta(days=6)).isoformat()
        satis = conn.execute(
            "SELECT COALESCE(SUM(genel_toplam*COALESCE(doviz_kur,1)),0) t FROM fatura "
            "WHERE tip='Satis' AND durum='Onaylandı' AND tarih>=? AND sirket_id=?",
            (bas, sid)).fetchone()["t"]
        alis = conn.execute(
            "SELECT COALESCE(SUM(genel_toplam*COALESCE(doviz_kur,1)),0) t FROM fatura "
            "WHERE tip='Alis' AND durum='Onaylandı' AND tarih>=? AND sirket_id=?",
            (bas, sid)).fetchone()["t"]
        kar = conn.execute(
            "SELECT COALESCE(SUM((fk.birim_fiyat*COALESCE(f.doviz_kur,1)-s.alis_fiyat)*fk.miktar),0) t "
            "FROM fatura_kalem fk JOIN fatura f ON f.id=fk.fatura_id "
            "JOIN stok_kart s ON s.id=fk.stok_id "
            "WHERE f.tip='Satis' AND f.durum='Onaylandı' AND f.tarih>=? AND f.sirket_id=?",
            (bas, sid)).fetchone()["t"]
    else:
        satis = satis_gen.get(ym, 0.0)
        alis = alis_gen.get(ym, 0.0)
        ci, ma = cogs.get(ym, (0.0, 0.0))
        kar = round(ci - ma, 2)

    tahsilat, tediye = _tahsilat_tediye_ay(conn, sid, bugun)
    urunler = _urun_top(conn, sid, 10)
    cok_satan = sorted(urunler, key=lambda u: -u["adet"])[:10]
    karlilar = sorted(urunler, key=lambda u: -u["kar"])[:10]
    cari_top = _cari_ciro_top(conn, sid, 10)
    nakit_akis = _nakit_gunluk(conn, sid, 30)
    banka_toplam = _banka_bakiye(conn, sid)

    # Bu ay bütçe hedefi vs gerçekleşen
    hedef = conn.execute(
        "SELECT * FROM butce_hedef WHERE sirket_id=? AND yil=? AND ay=?",
        (sid, bugun.year, bugun.month)).fetchone()
    butce = {"hedef_satis": 0.0, "gercek_satis": round(satis, 2), "sapma_pct": None,
             "hedef_kar": 0.0, "gercek_kar": round(kar, 2)}
    if hedef:
        hs = hedef["hedef_satis"] or 0.0
        butce["hedef_satis"] = hs
        butce["sapma_pct"] = round((satis - hs) / hs * 100, 1) if hs else None
        butce["hedef_kar"] = hedef["hedef_kar"] or 0.0

    def _per(pym):
        s = satis_gen.get(pym, 0.0)
        ci, ma = cogs.get(pym, (0.0, 0.0))
        return {"satis": round(s, 2), "kar": round(ci - ma, 2)}

    kars = {"bu_ay": _per(ym), "gecen_ay": _per(_ym_ekle(ym, -1)),
            "gecen_yil": _per(_ym_ekle(ym, -12))}

    conn.close()
    return _json({
        "donem": donem,
        "satis": round(satis, 2),
        "alis": round(alis, 2),
        "kar": round(kar, 2),
        "tahsilat": tahsilat,
        "tediye": tediye,
        "banka_bakiye": banka_toplam,
        "nakit_akis": nakit_akis,
        "en_cok_satan": cok_satan,
        "en_karli": karlilar,
        "en_cok_ciro_cari": cari_top,
        "donem_karsilastirma": kars,
        "butce": butce,
    })


def register():
    return "finansal"
