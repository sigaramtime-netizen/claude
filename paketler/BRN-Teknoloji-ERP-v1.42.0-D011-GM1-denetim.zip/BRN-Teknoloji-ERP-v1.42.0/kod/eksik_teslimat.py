# -*- coding: utf-8 -*-
"""Eksik Teslimatlar + Satın Alma Raporu modülü (B3 — Satın Alma Yönetimi kapanışı).

Eksik Teslimat = Alış siparişi (SAP) kalemlerinde kalan > 0 olan satırlar:
    kalan = miktar - teslim_edilen - kalan_iptal
- `kalan_iptal` (siparis_kalem) kısmi teslimatın bilinçli kapatılmasını taşır;
  irsaliye onayındaki durum türetimi de bu kolonu teslim edilmiş gibi sayar.
- Rapor: dönem + tedarikçi filtreli Satın Alma özeti (talep/teklif/SAP/irsaliye/fatura
  sayı + TRY tutar) + eksik teslimat dökümü. Yeni tablo yok — tümü türetilmiş.
- K1: şube izolasyonu; çoklu şirket (sirket_id).
"""
import datetime

import db
from core import route, render_template, redirect, flash, audit, notify, \
    izole_sube, Response

KAPAT_ROLLERI = ("Admin", "Muhasebe", "Depo")


def _f(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _i(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _tedarikciler(conn, sid=None):
    where, args = ["aktif=1 AND tip IN ('Tedarikci','HerIkisi')"], []
    if sid is not None:
        where.append("sirket_id=?")
        args.append(sid)
    return conn.execute(
        f"SELECT id, kod, unvan FROM cari_kart WHERE {' AND '.join(where)} ORDER BY unvan",
        args).fetchall()


def _eksik_satirlar(conn, sid, sube=None, tedarikci_id=None, sadece_gecikmis=False):
    where = ["sp.tip='Alis'", "sp.sirket_id=?", "(k.miktar - k.teslim_edilen - k.kalan_iptal) > 1e-9"]
    args = [sid]
    if sube is not None:
        where.append("sp.sube_id=?")
        args.append(sube)
    if tedarikci_id:
        where.append("sp.cari_id=?")
        args.append(tedarikci_id)
    if sadece_gecikmis:
        where.append("sp.teslim_tarihi IS NOT NULL AND sp.teslim_tarihi < ?")
        args.append(datetime.date.today().isoformat())
    w = " AND ".join(where)
    rows = conn.execute(
        f"SELECT k.id AS kalem_id, k.siparis_id, k.stok_id, k.miktar, k.teslim_edilen, "
        f"k.kalan_iptal, (k.miktar - k.teslim_edilen - k.kalan_iptal) AS kalan, "
        f"k.birim_fiyat, k.birim, k.aciklama AS manuel_ad, "
        f"s.ad AS stok_ad, s.kod AS stok_kod, "
        f"sp.siparis_no, sp.teslim_tarihi, sp.durum AS siparis_durum, "
        f"sp.para_birimi, COALESCE(sp.doviz_kur,1) AS doviz_kur, "
        f"c.unvan AS tedarikci_unvan, c.kod AS tedarikci_kod "
        f"FROM siparis_kalem k "
        f"JOIN siparis sp ON sp.id=k.siparis_id "
        f"LEFT JOIN stok_kart s ON s.id=k.stok_id "
        f"LEFT JOIN cari_kart c ON c.id=sp.cari_id "
        f"WHERE {w} ORDER BY sp.teslim_tarihi IS NULL, sp.teslim_tarihi ASC, sp.id DESC",
        args).fetchall()
    bugun = datetime.date.today()
    for r in rows:
        r = dict(r)
        r["eksik_tutar"] = round((r["kalan"] or 0) * (r["birim_fiyat"] or 0), 2)
        r["eksik_tutar_try"] = round(r["eksik_tutar"] * (r["doviz_kur"] or 1.0), 2)
        if r["teslim_tarihi"]:
            try:
                tt = datetime.date.fromisoformat(r["teslim_tarihi"])
                r["gecikme_gun"] = max((bugun - tt).days, 0)
            except ValueError:
                r["gecikme_gun"] = 0
        else:
            r["gecikme_gun"] = 0
        yield r


@route(r"/satin-alma/eksik-teslimatlar", roles=())
def eksik_liste(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    tedarikci_id = _i(req.q("tedarikci_id"))
    sadece_gecikmis = req.q("gecikmis") == "1"
    sube = izole_sube(req)
    rows = list(_eksik_satirlar(conn, sid, sube=sube, tedarikci_id=tedarikci_id,
                                sadece_gecikmis=sadece_gecikmis))
    toplam_kalem = len(rows)
    toplam_try = round(sum(r["eksik_tutar_try"] for r in rows), 2)
    tedarikciler = _tedarikciler(conn, sid)
    conn.close()
    return render_template("satin_alma/eksik_liste.html", rows=rows,
                           toplam_kalem=toplam_kalem, toplam_try=toplam_try,
                           tedarikciler=tedarikciler,
                           filtro={"tedarikci_id": tedarikci_id or "",
                                   "gecikmis": sadece_gecikmis})


@route(r"/satin-alma/eksik-teslimatlar/(?P<kid>\d+)/kapat", methods=("POST",), roles=KAPAT_ROLLERI)
def eksik_kapat(req, kid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    k = conn.execute(
        "SELECT k.*, sp.sirket_id AS sp_sirket, sp.sube_id AS sp_sube, sp.siparis_no "
        "FROM siparis_kalem k JOIN siparis sp ON sp.id=k.siparis_id WHERE k.id=?",
        (int(kid),)).fetchone()
    if not k or k["sp_sirket"] != sid:
        conn.close()
        return redirect("/satin-alma/eksik-teslimatlar")

    hedef = (req.form.get("hedef") or "kapat").strip()
    if hedef == "geri_al":
        conn.execute("UPDATE siparis_kalem SET kalan_iptal=0 WHERE id=?", (k["id"],))
        conn.commit()
        irsaliye_durum_guncelle(conn, k["siparis_id"])
        audit(req, "siparis_kalem", k["id"], "kalan_geri_al",
              {"siparis_no": k["siparis_no"]})
        flash(req, "Kalan kapatma geri alındı.", "ok")
        conn.close()
        return redirect("/satin-alma/eksik-teslimatlar")

    kalan = (k["miktar"] or 0) - (k["teslim_edilen"] or 0) - (k["kalan_iptal"] or 0)
    if kalan <= 1e-9:
        conn.close()
        flash(req, "Bu kalemde kapatılacak kalan yok.", "danger")
        return redirect("/satin-alma/eksik-teslimatlar")

    m = req.form.get("miktar")
    if m in (None, ""):
        kapat = kalan
    else:
        kapat = _f(m)
    if kapat <= 0 or kapat > kalan + 1e-9:
        conn.close()
        flash(req, f"Kapatılacak miktar 0 ile {kalan:g} arasında olmalı.", "danger")
        return redirect("/satin-alma/eksik-teslimatlar")
    conn.execute("UPDATE siparis_kalem SET kalan_iptal = kalan_iptal + ? WHERE id=?",
                 (kapat, k["id"]))
    conn.commit()
    irsaliye_durum_guncelle(conn, k["siparis_id"])
    audit(req, "siparis_kalem", k["id"], "kalan_kapat",
          {"siparis_no": k["siparis_no"], "miktar": round(kapat, 3)})
    notify("bilgi", "Eksik teslimat kapatıldı",
           f"{k['siparis_no']} siparişinde {kapat:g} birimlik kalan kapatıldı.",
           "siparis_kalem", k["id"], sirket_id=sid)
    flash(req, f"{kapat:g} birimlik kalan kapatıldı.", "ok")
    conn.close()
    return redirect("/satin-alma/eksik-teslimatlar")


def irsaliye_durum_guncelle(conn, siparis_id):
    """Sipariş başlık durumunu kalan_iptal dahil yeniden türetir (irsaliye ile ortak mantık)."""
    import irsaliye
    yeni = irsaliye._siparis_durum_turet(conn, siparis_id)
    conn.execute("UPDATE siparis SET durum=?, updated_at=datetime('now','localtime') WHERE id=?",
                 (yeni, siparis_id))
    conn.commit()


@route(r"/satin-alma/rapor", roles=())
def satin_alma_rapor(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    sube = izole_sube(req)
    bugun = datetime.date.today()
    baslangic = req.q("baslangic") or bugun.replace(day=1).isoformat()
    bitis = req.q("bitis") or bugun.isoformat()
    tedarikci_id = _i(req.q("tedarikci_id"))

    def _ozet(tablo, tarih_kolon, tip=None, kur="COALESCE(doviz_kur,1)"):
        where = [f"{tarih_kolon} BETWEEN ? AND ?", f"{tablo}.sirket_id=?"]
        args = [baslangic, bitis, sid]
        if tip is not None:
            where.append(f"{tablo}.tip=?")
            args.append(tip)
        if sube is not None and tablo in ("siparis", "irsaliye", "fatura"):
            where.append(f"{tablo}.sube_id=?")
            args.append(sube)
        if tedarikci_id and tablo in ("siparis", "irsaliye", "fatura", "alinan_teklif"):
            kol = "cari_id" if tablo != "alinan_teklif" else "tedarikci_id"
            where.append(f"{tablo}.{kol}=?")
            args.append(tedarikci_id)
        w = " AND ".join(where)
        r = conn.execute(
            f"SELECT COUNT(*) AS c, COALESCE(SUM(genel_toplam*{kur}),0) AS t "
            f"FROM {tablo} WHERE {w}", args).fetchone()
        return r["c"], round(r["t"] or 0, 2)

    # talep: tarih kolonu created_at, döviz yok (TRY)
    talep_where = ["date(created_at) BETWEEN ? AND ?", "sirket_id=?"]
    talep_args = [baslangic, bitis, sid]
    if sube is not None:
        talep_where.append("sube_id=?")
        talep_args.append(sube)
    talep_r = conn.execute(
        f"SELECT COUNT(*) c FROM satin_alma_talebi WHERE {' AND '.join(talep_where)}",
        talep_args).fetchone()
    talep_c = talep_r["c"]

    teklif_c, teklif_t = _ozet("alinan_teklif", "tarih")
    sap_c, sap_t = _ozet("siparis", "tarih", tip="Alis")
    irs_c, irs_t = _ozet("irsaliye", "tarih", tip="Alis", kur="1.0")
    fat_c, fat_t = _ozet("fatura", "tarih", tip="Alis")

    # Eksik teslimat özeti (dönemden bağımsız — açık kalanlar)
    eksikler = list(_eksik_satirlar(conn, sid, sube=sube, tedarikci_id=tedarikci_id))
    eksik_c = len(eksikler)
    eksik_t = round(sum(r["eksik_tutar_try"] for r in eksikler), 2)

    # Döküm: dönemdeki Alış siparişleri
    d_where = ["s.tarih BETWEEN ? AND ?", "s.sirket_id=?", "s.tip='Alis'"]
    d_args = [baslangic, bitis, sid]
    if sube is not None:
        d_where.append("s.sube_id=?")
        d_args.append(sube)
    if tedarikci_id:
        d_where.append("s.cari_id=?")
        d_args.append(tedarikci_id)
    dokum = conn.execute(
        f"SELECT s.id, s.siparis_no, s.tarih, s.teslim_tarihi, s.durum, "
        f"COALESCE(s.para_birimi,'TRY') AS pb, COALESCE(s.doviz_kur,1) AS kur, s.genel_toplam, "
        f"ROUND(s.genel_toplam*COALESCE(s.doviz_kur,1),2) AS try_toplam, "
        f"c.unvan AS tedarikci_unvan, c.kod AS tedarikci_kod "
        f"FROM siparis s LEFT JOIN cari_kart c ON c.id=s.cari_id "
        f"WHERE {' AND '.join(d_where)} ORDER BY s.tarih DESC, s.id DESC LIMIT 100",
        d_args).fetchall()

    tedarikciler = _tedarikciler(conn, sid)
    conn.close()
    return render_template("satin_alma/rapor.html",
                           ozet={"talep": talep_c, "teklif": teklif_c, "teklif_t": teklif_t,
                                 "sap": sap_c, "sap_t": sap_t, "irsaliye": irs_c, "irsaliye_t": irs_t,
                                 "fatura": fat_c, "fatura_t": fat_t,
                                 "eksik_c": eksik_c, "eksik_t": eksik_t},
                           dokum=dokum, eksikler=eksikler,
                           tedarikciler=tedarikciler,
                           filtro={"baslangic": baslangic, "bitis": bitis,
                                   "tedarikci_id": tedarikci_id or ""})


def register():
    pass
