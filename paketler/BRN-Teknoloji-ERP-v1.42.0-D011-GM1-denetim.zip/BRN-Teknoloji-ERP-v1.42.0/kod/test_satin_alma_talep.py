# -*- coding: utf-8 -*-
"""B1 — Satın Alma Talebi e2e testi.

Kapsam (faz protokolü örnek senaryosu):
  1. Kalemsiz talep oluşturulamaz (validasyon).
  2. Talep oluşturulur (Taslak); belge no SAT-{YYYY}-NNN.
  3. Taslak düzenlenir (miktar değişir).
  4. Onaya gönderilir → Onay Bekliyor.
  5. Onay yetkisi olmayan (Satis) onaylayamaz.
  6. Admin onaylar → Onaylandı.
  7. Onaylı talep Satın Alma Siparişine (SAP) dönüştürülür; kalemler kopyalanır.
  8. İkinci dönüştürme engellenir.
  9. Onaylanmış talep silinemez; Taslak silinebilir.
  10. Reddet (nedensiz engel + nedenli başarı).
  11. Şirket izolasyonu + bağımsız sayaç (B şirketi SAT-2026-001).

Çalıştırma: sunucu 8080'de çalışırken  python3 test_satin_alma_talep.py
"""
import datetime
import sqlite3
import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
KOD = "SATB"
YIL = datetime.date.today().year

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else ""))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris(kullanici="admin"):
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": kullanici, "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, f"giriş başarısız ({kullanici})"
    return s


def talep_olustur(s, stok_id, miktar, birim, fiyat, oncelik, gerekce,
                  kaynak="Yurt İçi", tedarikci_id="", depo_id="", manuel_ad=""):
    data = [
        ("kaynak", kaynak), ("depo_id", depo_id), ("tedarikci_id", tedarikci_id),
        ("gerekce", gerekce),
        ("k_stok_id", str(stok_id)), ("k_varyant_id", "0"), ("k_manuel_ad", manuel_ad),
        ("k_birim", birim), ("k_miktar", str(miktar)),
        ("k_birim_fiyat", str(fiyat)), ("k_oncelik", oncelik),
    ]
    s.post(BASE + "/satin-alma/talepler/yeni", data=data, allow_redirects=False)
    return db1("SELECT * FROM satin_alma_talebi WHERE gerekce=? ORDER BY id DESC", gerekce)


def main():
    admin = giris("admin")
    satis = giris("satis")

    # --- 0. Kalıntı temizliği ---
    eski = db1("SELECT id FROM sirket WHERE kod=?", KOD)
    if eski:
        sid = eski["id"]
        for t in ("satin_alma_talebi_kalem", "satin_alma_talebi", "siparis_kalem", "siparis",
                  "hesap", "demirbas_kategori", "depo", "kullanici_sirket"):
            dbx(f"DELETE FROM {t} WHERE sirket_id=?", sid)
        dbx("DELETE FROM sirket WHERE id=?", sid)
    dbx("DELETE FROM satin_alma_talebi_kalem WHERE talep_id IN "
        "(SELECT id FROM satin_alma_talebi WHERE gerekce LIKE 'SAT-TEST-%')")
    dbx("DELETE FROM satin_alma_talebi WHERE gerekce LIKE 'SAT-TEST-%'")
    dbx("DELETE FROM siparis_kalem WHERE siparis_id IN "
        "(SELECT id FROM siparis WHERE aciklama LIKE 'SAT-TEST-%')")
    dbx("DELETE FROM siparis WHERE aciklama LIKE 'SAT-TEST-%'")

    # --- 1. Kalemsiz talep oluşturulamaz ---
    once = db1("SELECT COUNT(*) c FROM satin_alma_talebi WHERE sirket_id=1")["c"]
    r = admin.post(BASE + "/satin-alma/talepler/yeni", data=[
        ("kaynak", "Yurt İçi"), ("gerekce", "SAT-TEST-BOS"),
        ("k_stok_id", ""), ("k_manuel_ad", ""), ("k_miktar", ""),
    ], allow_redirects=False)
    sonra = db1("SELECT COUNT(*) c FROM satin_alma_talebi WHERE sirket_id=1")["c"]
    check("Kalemsiz talep oluşturulamadı", once == sonra and r.status_code == 200,
          f"once={once} sonra={sonra} status={r.status_code}")

    # --- 2. Talep oluştur (Taslak) ---
    t1 = talep_olustur(admin, 3, 5, "Adet", 16000, "Normal", "SAT-TEST-A1", tedarikci_id="5")
    check("Talep oluştu (Taslak)", t1 is not None and t1["durum"] == "Taslak",
          f"no={t1['talep_no'] if t1 else '-'}")
    check("Belge no formatı SAT-yıl-NNN", t1 and t1["talep_no"].startswith(f"SAT-{YIL}-"),
          t1["talep_no"] if t1 else "-")
    check("Kalem kopyalandı", db1("SELECT COUNT(*) c FROM satin_alma_talebi_kalem WHERE talep_id=?",
                                  t1["id"])["c"] == 1)
    check("Tedarikçi damgalandı", t1["tedarikci_id"] == 5)

    # --- 3. Taslak düzenle (miktar 5 → 6) ---
    admin.post(BASE + f"/satin-alma/talepler/{t1['id']}/duzenle", data=[
        ("kaynak", "Yurt İçi"), ("depo_id", ""), ("tedarikci_id", "5"),
        ("gerekce", "SAT-TEST-A1"),
        ("k_stok_id", "3"), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
        ("k_birim", "Adet"), ("k_miktar", "6"), ("k_birim_fiyat", "16000"), ("k_oncelik", "Normal"),
    ], allow_redirects=False)
    m = db1("SELECT miktar FROM satin_alma_talebi_kalem WHERE talep_id=?", t1["id"])["miktar"]
    check("Taslak düzenlendi (miktar 6)", abs(m - 6.0) < 0.001, f"miktar={m}")

    # --- 4. Onaya gönder ---
    admin.post(BASE + f"/satin-alma/talepler/{t1['id']}/durum",
               data={"hedef": "gonder"}, allow_redirects=False)
    check("Onaya gönderildi", db1("SELECT durum FROM satin_alma_talebi WHERE id=?", t1["id"])["durum"] == "Onay Bekliyor")

    # --- 5. Yetkisiz onay (Satis) engellenir ---
    satis.post(BASE + f"/satin-alma/talepler/{t1['id']}/durum",
               data={"hedef": "onayla"}, allow_redirects=False)
    check("Satis onaylayamadı (yetki)", db1("SELECT durum FROM satin_alma_talebi WHERE id=?", t1["id"])["durum"] == "Onay Bekliyor")

    # --- 6. Admin onaylar ---
    admin.post(BASE + f"/satin-alma/talepler/{t1['id']}/durum",
               data={"hedef": "onayla"}, allow_redirects=False)
    t1d = db1("SELECT * FROM satin_alma_talebi WHERE id=?", t1["id"])
    check("Admin onayladı", t1d["durum"] == "Onaylandı" and t1d["onaylayan_id"] is not None,
          f"durum={t1d['durum']} onaylayan={t1d['onaylayan_id']}")

    # --- 7. SAP'ye dönüştür ---
    admin.post(BASE + f"/satin-alma/talepler/{t1['id']}/siparise-donustur",
               data={"tedarikci_id": "5"}, allow_redirects=False)
    t1d = db1("SELECT * FROM satin_alma_talebi WHERE id=?", t1["id"])
    check("Talep Siparişe Dönüştü", t1d["durum"] == "Siparişe Dönüştü" and t1d["donusen_siparis_id"] is not None)
    sap = db1("SELECT * FROM siparis WHERE id=?", t1d["donusen_siparis_id"]) if t1d["donusen_siparis_id"] else None
    check("SAP üretildi (Bekliyor, Alis)", sap and sap["tip"] == "Alis" and sap["durum"] == "Bekliyor",
          f"no={sap['siparis_no'] if sap else '-'}")
    check("SAP belge no SAP-yıl-NNN", sap and sap["siparis_no"].startswith(f"SAP-{YIL}-"),
          sap["siparis_no"] if sap else "-")
    check("SAP kalemi kopyalandı (miktar 6)",
          sap and db1("SELECT miktar FROM siparis_kalem WHERE siparis_id=?", sap["id"])["miktar"] == 6.0)
    check("SAP kalemi stok bağlı", sap and db1("SELECT stok_id FROM siparis_kalem WHERE siparis_id=?", sap["id"])["stok_id"] == 3)

    # --- 8. İkinci dönüştürme engellenir ---
    admin.post(BASE + f"/satin-alma/talepler/{t1['id']}/siparise-donustur",
               data={"tedarikci_id": "5"}, allow_redirects=False)
    adet = db1("SELECT COUNT(*) c FROM siparis WHERE aciklama LIKE ?",
               f"%{t1['talep_no']} talebinden%")["c"]
    check("İkinci dönüştürme engellendi (tek SAP)", adet == 1 and
          db1("SELECT durum FROM satin_alma_talebi WHERE id=?", t1["id"])["durum"] == "Siparişe Dönüştü",
          f"sap_adet={adet}")

    # --- 9. Silme kuralları ---
    t2 = talep_olustur(admin, 8, 2, "Adet", 2500, "Acil", "SAT-TEST-A2")
    admin.post(BASE + f"/satin-alma/talepler/{t2['id']}/durum", data={"hedef": "gonder"}, allow_redirects=False)
    admin.post(BASE + f"/satin-alma/talepler/{t2['id']}/durum", data={"hedef": "onayla"}, allow_redirects=False)
    admin.post(BASE + f"/satin-alma/talepler/{t2['id']}/sil", allow_redirects=False)
    check("Onaylanmış talep silinemedi", db1("SELECT id FROM satin_alma_talebi WHERE id=?", t2["id"]) is not None)

    t3 = talep_olustur(admin, 8, 1, "Adet", 2500, "Normal", "SAT-TEST-A3")
    admin.post(BASE + f"/satin-alma/talepler/{t3['id']}/sil", allow_redirects=False)
    check("Taslak talep silindi", db1("SELECT id FROM satin_alma_talebi WHERE id=?", t3["id"]) is None)

    # --- 10. Reddet ---
    t4 = talep_olustur(admin, 3, 2, "Adet", 16000, "Normal", "SAT-TEST-A4")
    admin.post(BASE + f"/satin-alma/talepler/{t4['id']}/durum", data={"hedef": "gonder"}, allow_redirects=False)
    admin.post(BASE + f"/satin-alma/talepler/{t4['id']}/durum", data={"hedef": "reddet"}, allow_redirects=False)
    check("Nedensiz red engellendi", db1("SELECT durum FROM satin_alma_talebi WHERE id=?", t4["id"])["durum"] == "Onay Bekliyor")
    admin.post(BASE + f"/satin-alma/talepler/{t4['id']}/durum",
               data={"hedef": "reddet", "red_nedeni": "Bütçe yok"}, allow_redirects=False)
    t4d = db1("SELECT * FROM satin_alma_talebi WHERE id=?", t4["id"])
    check("Nedenli red işlendi", t4d["durum"] == "Reddedildi" and t4d["red_nedeni"] == "Bütçe yok")

    # --- 11. Şirket izolasyonu + bağımsız sayaç ---
    admin.post(BASE + "/ayarlar/sirketler", data={"kod": KOD, "unvan": "Satın Alma İzolasyon A.Ş."},
               allow_redirects=False)
    b_id = db1("SELECT id FROM sirket WHERE kod=?", KOD)["id"]
    admin.post(BASE + "/sirket/gec", data={"sirket_id": str(b_id), "next": "/"}, allow_redirects=False)
    rb = admin.get(BASE + "/satin-alma/talepler").text
    check("B şirketinde A talepleri görünmüyor",
          "SAT-2026-001" not in rb and "SAT-TEST-A1" not in rb)
    tb = talep_olustur(admin, "", 1, "Adet", 16000, "Normal", "SAT-TEST-B1",
                       manuel_ad="ISO test parçası")
    check("B'de talep sayacı bağımsız (SAT-2026-001)", tb and tb["talep_no"] == f"SAT-{YIL}-001",
          tb["talep_no"] if tb else "-")
    check("B talebi B şirketine damgalı", tb and tb["sirket_id"] == b_id)
    check("B talebi manuel satırlı", tb and db1(
        "SELECT stok_id FROM satin_alma_talebi_kalem WHERE talep_id=?", tb["id"])["stok_id"] is None)

    # --- 12. Temizlik ---
    admin.post(BASE + "/sirket/gec", data={"sirket_id": "1", "next": "/"}, allow_redirects=False)
    for t in ("satin_alma_talebi_kalem", "satin_alma_talebi", "siparis_kalem", "siparis",
              "hesap", "demirbas_kategori", "depo", "kullanici_sirket"):
        dbx(f"DELETE FROM {t} WHERE sirket_id=?", b_id)
    dbx("DELETE FROM sirket WHERE id=?", b_id)
    dbx("UPDATE sessionler SET sirket_id=1 WHERE sirket_id=?", b_id)
    dbx("DELETE FROM satin_alma_talebi_kalem WHERE talep_id IN "
        "(SELECT id FROM satin_alma_talebi WHERE gerekce LIKE 'SAT-TEST-%')")
    dbx("DELETE FROM satin_alma_talebi WHERE gerekce LIKE 'SAT-TEST-%'")
    dbx("DELETE FROM siparis_kalem WHERE siparis_id IN "
        "(SELECT id FROM siparis WHERE aciklama LIKE 'SAT-TEST-%' OR aciklama LIKE '%SAT-TEST-%')")
    dbx("DELETE FROM siparis WHERE aciklama LIKE '%SAT-TEST-%'")

    print(f"\nSONUÇ: {len(ok)} başarılı / {len(fail)} başarısız")
    if fail:
        print("BAŞARISIZ:", fail)
        raise SystemExit(1)
    print("SATIN ALMA TALEBİ (B1) E2E TESTİ GEÇTİ ✅")


if __name__ == "__main__":
    main()
