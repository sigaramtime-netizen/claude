# -*- coding: utf-8 -*-
"""Döviz Takip modülü (Faz 2 — Satış Döngüsü'nün 6. ve son halkası).

- Güncel döviz kurları: otomatik (TCMB entegrasyon noktası) / manuel güncelleme (K18).
- Döviz cinsinden fatura/cari/çek-senet takibi: cari hareketler DAİMA TL karşılığı
  (K2 konvansiyonu) tutar; para_birimi + doviz_kur yalnızca izleme için saklanır.
- Kur farkı izleme + otomatik kur farkı faturası (WolvoxCloud özelliği): döviz faturası
  farklı bir kurdan tahsil/ödeme ile kapatılırsa aradaki fark TL cinsinden hesaplanır
  ve tek tıkla TL kur farkı faturasına dönüştürülür.
- Çoklu para birimi ile raporlama.
"""
import datetime
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

import db
import cari
from core import route, render_template, redirect, flash, audit, notify
from config import PARA_BIRIMLERI

DOVIZ_WRITE = ("Admin", "Muhasebe")
TCMB_URL = "https://www.tcmb.gov.tr/kurlar/today.xml"
TCMB_KODLARI = ("USD", "EUR", "GBP")


def _f(v, default=0.0):
    try:
        return float(v if v not in (None, "") else default)
    except (TypeError, ValueError):
        return default


def _kurlar(conn, sid=None):
    """Para birimi → [ {id, kur, tarih, kaynak} … ] (yeniden eskiye)."""
    extra = " WHERE sirket_id=?" if sid is not None else ""
    args = [sid] if sid is not None else []
    rows = conn.execute(f"SELECT * FROM doviz_kur{extra} ORDER BY tarih DESC, id DESC", args).fetchall()
    out = {}
    for r in rows:
        out.setdefault(r["para_birimi"], []).append(dict(r))
    return out


def _rapor(conn, sid=None):
    """Çoklu para birimi raporu: para birimi → güncel kur + döviz belge özetleri."""
    kurlar = _kurlar(conn, sid)
    ozet = []
    for pb in [p for p in PARA_BIRIMLERI if p != "TRY"]:
        kur = db.guncel_kur(conn, pb, sid)
        fatura_adedi = conn.execute(
            "SELECT COUNT(*) k FROM fatura WHERE para_birimi=? AND sirket_id=?", (pb, sid)).fetchone()["k"]
        fatura_tl = conn.execute(
            "SELECT COALESCE(SUM(genel_toplam * COALESCE(doviz_kur,1)),0) s FROM fatura "
            "WHERE para_birimi=? AND sirket_id=?", (pb, sid)).fetchone()["s"]
        cek_adedi = conn.execute(
            "SELECT COUNT(*) k FROM cek_senet WHERE para_birimi=? AND sirket_id=?", (pb, sid)).fetchone()["k"]
        cek_tl = conn.execute(
            "SELECT COALESCE(SUM(tutar * COALESCE(doviz_kur,1)),0) s FROM cek_senet "
            "WHERE para_birimi=? AND sirket_id=?", (pb, sid)).fetchone()["s"]
        poz = conn.execute(
            "SELECT COALESCE(SUM(borc-alacak),0) s FROM cari_hareket WHERE para_birimi=? AND sirket_id=?",
            (pb, sid)).fetchone()["s"]
        ozet.append({"pb": pb, "kur": kur, "kaynak": (kurlar.get(pb) or [{}])[0].get("kaynak", "—"),
                     "fatura_adedi": fatura_adedi, "fatura_tl": fatura_tl,
                     "cek_adedi": cek_adedi, "cek_tl": cek_tl, "pozisyon": poz})
    return ozet, kurlar


@route(r"/doviz", roles=())
def doviz_liste(req):
    conn = db.get_conn()
    ozet, kurlar = _rapor(conn, db.sirket_id(req))
    conn.close()
    return render_template("doviz/kur.html", ozet=ozet, kurlar=kurlar,
                           para_birimleri=PARA_BIRIMLERI,
                           bugun=datetime.date.today().isoformat())


@route(r"/doviz/kur", methods=("POST",), roles=DOVIZ_WRITE)
def doviz_kur_ekle(req):
    pb = req.form.get("para_birimi")
    if pb not in PARA_BIRIMLERI or pb == "TRY":
        flash(req, "Geçersiz para birimi.", "danger")
        return redirect("/doviz")
    kur = _f(req.form.get("kur"))
    tarih = (req.form.get("tarih") or "").strip() or datetime.date.today().isoformat()
    if kur <= 0:
        flash(req, "Kur sıfırdan büyük olmalıdır.", "danger")
        return redirect("/doviz")
    conn = db.get_conn()
    sid = db.sirket_id(req)
    # aynı gün + para birimi için güncelle (mükerrer satır yerine)
    mevcut = conn.execute("SELECT id FROM doviz_kur WHERE para_birimi=? AND tarih=? AND sirket_id=?",
                          (pb, tarih, sid)).fetchone()
    if mevcut:
        conn.execute("UPDATE doviz_kur SET kur=?, kaynak='Manuel' WHERE id=?", (kur, mevcut["id"]))
        kid = mevcut["id"]
    else:
        cur = conn.execute(
            "INSERT INTO doviz_kur(para_birimi, kur, tarih, kaynak, created_by, sirket_id) "
            "VALUES(?,?,?,'Manuel',?,?)", (pb, kur, tarih, req.user["id"], sid))
        kid = cur.lastrowid
    conn.commit()
    audit(req, "doviz_kur", kid, "kur", {"para_birimi": pb, "kur": kur, "tarih": tarih})
    conn.close()
    flash(req, f"{pb} kuru kaydedildi: {kur} TL ({tarih}).", "ok")
    return redirect("/doviz")


@route(r"/doviz/kur/(?P<kid>\d+)/sil", methods=("POST",), roles=DOVIZ_WRITE)
def doviz_kur_sil(req, kid):
    conn = db.get_conn()
    r = conn.execute("SELECT * FROM doviz_kur WHERE id=? AND sirket_id=?",
                     (int(kid), db.sirket_id(req))).fetchone()
    if r:
        conn.execute("DELETE FROM doviz_kur WHERE id=?", (int(kid),))
        conn.commit()
        audit(req, "doviz_kur", int(kid), "sil", {"para_birimi": r["para_birimi"]})
        flash(req, f"{r['para_birimi']} kuru silindi ({r['tarih']}).", "ok")
    conn.close()
    return redirect("/doviz")


def _tcmb_kurlari():
    """TCMB günlük kurlarını çek (entegrasyon noktası). Başarısızsa None."""
    req = urllib.request.Request(TCMB_URL, headers={"User-Agent": "BrnTeknolojiERP/1.0"})
    with urllib.request.urlopen(req, timeout=6) as resp:
        xml = resp.read()
    root = ET.fromstring(xml)
    out = {}
    for cur in root.iter("Currency"):
        kod = (cur.get("Kod") or cur.get("CurrencyCode") or "").strip().upper()
        if kod not in TCMB_KODLARI:
            continue
        satis = None
        for tag in ("ForexSelling", "ForexBuying"):
            el = cur.find(tag)
            if el is not None and el.text:
                satis = el.text.strip()
                break
        if satis:
            try:
                out[kod] = round(float(satis.replace(",", ".")), 4)
            except ValueError:
                pass
    return out or None


@route(r"/doviz/tcmb", methods=("POST",), roles=DOVIZ_WRITE)
def doviz_tcmb(req):
    try:
        kurlar = _tcmb_kurlari()
    except Exception:  # noqa: BLE001  (ağ yok / TCMB'ye ulaşılamadı)
        kurlar = None
    if not kurlar:
        flash(req, "TCMB'ye ulaşılamadı (ağ erişimi yok). Manuel kur girişi kullanın.", "danger")
        return redirect("/doviz")
    conn = db.get_conn()
    sid = db.sirket_id(req)
    tarih = datetime.date.today().isoformat()
    for pb, kur in kurlar.items():
        mevcut = conn.execute("SELECT id FROM doviz_kur WHERE para_birimi=? AND tarih=? AND sirket_id=?",
                              (pb, tarih, sid)).fetchone()
        if mevcut:
            conn.execute("UPDATE doviz_kur SET kur=?, kaynak='TCMB' WHERE id=?",
                         (kur, mevcut["id"]))
        else:
            conn.execute("INSERT INTO doviz_kur(para_birimi, kur, tarih, kaynak, created_by, sirket_id) "
                         "VALUES(?,?,?,'TCMB',?,?)", (pb, kur, tarih, req.user["id"], sid))
    conn.commit()
    audit(req, "doviz_kur", 0, "tcmb_guncelle", kurlar)
    conn.close()
    notify("bilgi", "Döviz kurları güncellendi (TCMB)",
           ", ".join(f"{k}={v}" for k, v in sorted(kurlar.items())), "doviz", 0,
           sirket_id=db.sirket_id(req))
    flash(req, "TCMB kurları güncellendi: " + ", ".join(f"{k}={v}" for k, v in sorted(kurlar.items())), "ok")
    return redirect("/doviz")


def _kur_farki_satirlari(conn, sid=None):
    """Onaylı döviz faturaları + bağlı (K15) döviz tahsilat/ödemelerden realize kur farkı."""
    extra = " AND f.sirket_id=?" if sid is not None else ""
    fargs = [sid] if sid is not None else []
    faturalar = conn.execute(
        "SELECT f.*, k.unvan AS cari_unvan, k.kod AS cari_kod FROM fatura f "
        "LEFT JOIN cari_kart k ON k.id=f.cari_id "
        "WHERE f.para_birimi!='TRY'" + extra + " ORDER BY f.id DESC", fargs).fetchall()
    satirlar = []
    for f in faturalar:
        f = dict(f)
        sextra = " AND sirket_id=?" if sid is not None else ""
        sargs = [f["id"], f["para_birimi"]] + ([sid] if sid is not None else [])
        kasa = conn.execute(
            "SELECT tutar, doviz_kur FROM kasa_hareket WHERE ilgili_modul='Fatura' "
            "AND ilgili_kayit_id=? AND para_birimi=?" + sextra, sargs).fetchall()
        banka = conn.execute(
            "SELECT tutar, doviz_kur FROM banka_hareket WHERE ilgili_modul='Fatura' "
            "AND ilgili_kayit_id=? AND para_birimi=?" + sextra, sargs).fetchall()
        hareketler = list(kasa) + list(banka)
        toplanan_doviz = sum((r["tutar"] or 0) for r in hareketler)
        # realize kur farkı = Σ tutar × (tahsilat kuru − fatura kuru)
        fark = round(sum((r["tutar"] or 0) * ((r["doviz_kur"] or f["doviz_kur"] or 1.0) - (f["doviz_kur"] or 1.0))
                         for r in hareketler), 2)
        kalan_doviz = round((f["genel_toplam"] or 0) - toplanan_doviz, 2)
        f["toplanan_doviz"] = toplanan_doviz
        f["fark"] = fark
        f["kalan_doviz"] = kalan_doviz
        f["kapali"] = kalan_doviz <= 0.005
        # K18 — KDV oranı: kaynak fatura kalemlerindeki tek oran; farklı/boşsa %20 varsayılır.
        oranlar = [r["kdv_orani"] for r in conn.execute(
            "SELECT DISTINCT kdv_orani FROM fatura_kalem WHERE fatura_id=?",
            (f["id"],)).fetchall()]
        kdv_orani = float(oranlar[0] or 0) if len(oranlar) == 1 else 20.0
        f["kdv_orani"] = kdv_orani
        f["kdv_toplam"] = round(fark * kdv_orani / 100.0, 2)
        f["genel_fark"] = round(fark + f["kdv_toplam"], 2)
        # daha önce bu faturadan kur farkı faturası üretildi mi? (mükerrer engel — fatura bazında)
        fextra = " AND sirket_id=?" if sid is not None else ""
        fargs2 = [f"Kur farkı faturası (kaynak: {f['fatura_no']})%"] + ([sid] if sid is not None else [])
        f["fark_faturasi_var"] = conn.execute(
            "SELECT COUNT(*) k FROM fatura WHERE aciklama LIKE ?" + fextra, fargs2).fetchone()["k"]
        satirlar.append(f)
    return satirlar


@route(r"/doviz/kur-farki", roles=())
def doviz_kur_farki(req):
    conn = db.get_conn()
    satirlar = _kur_farki_satirlari(conn, db.sirket_id(req))
    conn.close()
    return render_template("doviz/kur_farki.html", satirlar=satirlar,
                           durum_badge={"Onaylandı": "b-ok"})


@route(r"/doviz/kur-farki/(?P<fid>\d+)/fatura", methods=("POST",), roles=DOVIZ_WRITE)
def doviz_kur_farki_fatura(req, fid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    f = conn.execute("SELECT * FROM fatura WHERE id=? AND para_birimi!='TRY' AND sirket_id=?",
                     (int(fid), sid)).fetchone()
    if not f:
        conn.close()
        flash(req, "Döviz faturası bulunamadı.", "danger")
        return redirect("/doviz/kur-farki")
    satir = [s for s in _kur_farki_satirlari(conn, sid) if s["id"] == int(fid)]
    fark = round(satir[0]["fark"], 2) if satir else 0.0
    if abs(fark) < 0.01:
        conn.close()
        flash(req, "Bu fatura için realize kur farkı yok (fatura kuruyla aynı kurdan kapanmış).", "danger")
        return redirect("/doviz/kur-farki")
    if satir and satir[0]["fark_faturasi_var"]:
        conn.close()
        flash(req, "Bu fatura için kur farkı faturası zaten oluşturulmuş (mükerrer engel).", "danger")
        return redirect("/doviz/kur-farki")
    # K18 — kur farkı faturası yalnız fatura TAMAMEN kapatıldığında kesilir (kalan döviz = 0).
    # Kümülatif fark (tüm bağlı tahsilat/ödemeler) tek faturada kapatılır; parçalı tahsilat
    # senaryosunda erken/tekrar fatura kesilmesi bu kapıyla engellenir.
    if satir and not satir[0]["kapali"]:
        conn.close()
        flash(req, "Fatura henüz tam kapatılmamış (kalan döviz var). Kur farkı, tüm tahsilat/ödemeler tamamlanınca tek faturada kesilir.", "danger")
        return redirect("/doviz/kur-farki")

    # K18 — KDV: kur farkı faturaları KDV'ye tabidir; kaynak faturanın KDV oranı uygulanır.
    kdv_orani = float(satir[0].get("kdv_orani") or 20.0)
    matrah = round(abs(fark), 2)
    kdv_toplam = round(matrah * kdv_orani / 100.0, 2)
    genel = round(matrah + kdv_toplam, 2)

    on_ek = "SF" if f["tip"] == "Satis" else "AF"
    no = db.sonraki_belge_no(conn, "fatura", "fatura_no", on_ek, f["tarih"][:4], sid)
    aciklama = f"Kur farkı faturası (kaynak: {f['fatura_no']})"
    # Satış: fark>0 → müşteri borç, fark<0 → müşteri alacak. Alış için tersi. (KDV dahil genel)
    if f["tip"] == "Satis":
        borc, alacak = (genel, 0.0) if fark > 0 else (0.0, genel)
        belge = "Satış Faturası"
    else:
        borc, alacak = (0.0, genel) if fark > 0 else (genel, 0.0)
        belge = "Alış Faturası"
    cur = conn.execute(
        "INSERT INTO fatura(fatura_no, tip, cari_id, tarih, durum, para_birimi, doviz_kur, "
        "ara_toplam, iskonto_toplam, kdv_toplam, genel_toplam, aciklama, created_by, sirket_id) "
        "VALUES(?,?,?,?,'Onaylandı','TRY',1,?,0,?,?,?,?,?)",
        (no, f["tip"], f["cari_id"], datetime.date.today().isoformat(), matrah,
         kdv_toplam, genel, aciklama, req.user["id"], sid))
    yeni_fid = cur.lastrowid
    cari.hareket_ekle(conn, f["cari_id"], datetime.date.today().isoformat(), belge, no,
                      aciklama, borc=borc, alacak=alacak, ilgili_modul="Fatura",
                      ilgili_kayit_id=yeni_fid, created_by=req.user["id"])
    conn.commit()
    audit(req, "fatura", yeni_fid, "kur_farki_faturasi",
          {"kaynak_fatura": f["fatura_no"], "fark": fark, "kdv_orani": kdv_orani,
           "matrah": matrah, "kdv": kdv_toplam, "genel": genel})
    notify("bilgi", "Kur farkı faturası oluşturuldu",
           f"{f['fatura_no']} için {matrah} TL matrah + {kdv_toplam} TL KDV = {genel} TL kur farkı faturası {no} kesildi.",
           "fatura", yeni_fid, sirket_id=db.sirket_id(req))
    conn.close()
    flash(req, f"Kur farkı faturası oluşturuldu: {no} (matrah {matrah} TL + KDV {kdv_toplam} TL = {genel} TL).", "ok")
    return redirect("/doviz/kur-farki")
