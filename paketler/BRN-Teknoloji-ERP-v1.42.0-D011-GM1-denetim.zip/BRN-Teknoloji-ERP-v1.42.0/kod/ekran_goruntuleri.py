# -*- coding: utf-8 -*-
"""İstek 3 — ekran görüntüleri (demo): çoklu şirket arayüzü.

Çıktı: docs/ekran-goruntuleri/ altında PNG'ler.
Çalıştırma: sunucu 8080'de çalışırken  python3 ekran_goruntuleri.py
"""
import os
import sqlite3
import requests
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
OUT = "docs/ekran-goruntuleri"
KOD = "DEMO"


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def main():
    os.makedirs(OUT, exist_ok=True)
    s = requests.Session()
    s.post(BASE + "/giris", data={"kullanici_adi": "admin", "sifre": "1234"},
           allow_redirects=False)
    cookies = {c.name: c.value for c in s.cookies}

    # demo şirketi kur (kalıntı varsa önce temizle)
    eski = db1("SELECT id FROM sirket WHERE kod=?", KOD)
    if eski:
        sid = eski["id"]
        for t in ("kullanici_sirket", "hesap", "demirbas_kategori", "depo"):
            dbx(f"DELETE FROM {t} WHERE sirket_id=?", sid)
        dbx("DELETE FROM sirket WHERE id=?", sid)
    s.post(BASE + "/ayarlar/sirketler", data={
        "kod": KOD, "unvan": "Demo İzmir Mağazacılık A.Ş.", "kisa_ad": "Demo İzmir",
        "vergi_dairesi": "Konak VD", "vergi_no": "9876543210"}, allow_redirects=False)
    demo_id = db1("SELECT id FROM sirket WHERE kod=?", KOD)["id"]

    # B şirketine bir cari + kasa örneği ekleyelim (demo zenginliği)
    s.post(BASE + "/sirket/gec", data={"sirket_id": str(demo_id), "next": "/"},
           allow_redirects=False)
    s.post(BASE + "/cari/yeni", data={"unvan": "Ege Ticaret Ltd. Şti.", "tip": "Musteri",
                                      "il": "İzmir", "ilce": "Konak"}, allow_redirects=False)
    s.post(BASE + "/kasa/yeni", data={"ad": "İzmir Kasa", "kod": "KAS-IZM"},
           allow_redirects=False)
    s.post(BASE + "/sirket/gec", data={"sirket_id": "1", "next": "/"}, allow_redirects=False)

    shots = [
        ("01-ayarlar-sirketler", "/ayarlar/sirketler"),
        ("02-ustbar-sirket-secici", "/"),
        ("03-cari-liste-A", "/cari"),
        ("04-kullanicilar-uyelik", "/ayarlar/kullanicilar"),
    ]

    with sync_playwright() as p:
        browser = p.chromium.launch()
        ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        ctx.add_cookies([{"name": k, "value": v, "url": BASE} for k, v in cookies.items()])
        page = ctx.new_page()

        for ad, yol in shots:
            page.goto(BASE + yol, wait_until="networkidle")
            page.wait_for_timeout(300)
            page.screenshot(path=f"{OUT}/{ad}.png", full_page=True)
            print("çekildi:", ad)

        # B şirketine geçip izolasyon görünümü (cari listesi — A verisi görünmez)
        page.goto(BASE + "/", wait_until="networkidle")
        page.select_option("select[name='sirket_id']", str(demo_id))
        page.wait_for_timeout(500)
        page.goto(BASE + "/cari", wait_until="networkidle")
        page.wait_for_timeout(300)
        page.screenshot(path=f"{OUT}/05-cari-liste-B-izolasyon.png", full_page=True)
        print("çekildi: 05-cari-liste-B-izolasyon")

        # B mizanı (27 hesap, sıfır bakiye — A fişleri yok)
        page.goto(BASE + "/muhasebe/mizan", wait_until="networkidle")
        page.wait_for_timeout(300)
        page.screenshot(path=f"{OUT}/06-mizan-B.png", full_page=True)
        print("çekildi: 06-mizan-B")

        browser.close()

    # temizlik: demo şirketi kaldır (DB'yi ilk haline döndür)
    for t in ("cari_hareket", "cari_kart", "kasa_hareket", "kasa", "yevmiye_kalem", "yevmiye",
              "kullanici_sirket", "hesap", "demirbas_kategori", "depo"):
        dbx(f"DELETE FROM {t} WHERE sirket_id=?", demo_id)
    dbx("DELETE FROM sirket WHERE id=?", demo_id)
    dbx("UPDATE sessionler SET sirket_id=1 WHERE sirket_id=?", demo_id)
    print("demo şirket temizlendi; ekran görüntüleri:", OUT)


if __name__ == "__main__":
    main()
