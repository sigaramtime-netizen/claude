# -*- coding: utf-8 -*-
"""F1 — mali etki ekran görüntüleri (irsaliyeli akış).

Çıktı: docs/ekran-goruntuleri/yeni-tema/f1-*.png
Çalıştırma: sunucu 8080'de çalışırken  python3 ekran_f1.py
"""
import os
import requests
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8080"
OUT = "docs/ekran-goruntuleri/yeni-tema"


def main():
    os.makedirs(OUT, exist_ok=True)
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": "admin", "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, "giriş başarısız"
    cookies = {c.name: c.value for c in s.cookies}

    # Seed: IRS-2026-001 → BAT-001 (cari 1) ; FIS-2026-003 irsaliye fişi
    shots = [
        ("f1-irsaliye-detay", "/irsaliye/1"),              # onaylı satış irsaliyesi
        ("f1-cari-ekstre", "/cari/1/ekstre"),              # BAT-001 → Satış İrsaliyesi borç
        ("f1-muhasebe-fisler", "/muhasebe"),               # Irsaliye kaynaklı fişler
        ("f1-fis-detay", "/muhasebe/3"),                   # IRS-2026-001 fişi (120/600/391)
        ("f1-dashboard", "/"),                             # satış özeti irsaliye dahil
    ]

    with sync_playwright() as p:
        browser = p.chromium.launch()
        ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        ctx.add_cookies([{"name": k, "value": v, "url": BASE} for k, v in cookies.items()])
        page = ctx.new_page()
        for ad, yol in shots:
            page.goto(BASE + yol, wait_until="networkidle")
            page.wait_for_timeout(600)
            try:
                page.screenshot(path=f"{OUT}/{ad}.png", full_page=True)
            except Exception:
                page.screenshot(path=f"{OUT}/{ad}.png")
            print("çekildi:", ad)
        browser.close()
    print("F1 ekran görüntüleri tamam.")


if __name__ == "__main__":
    main()
