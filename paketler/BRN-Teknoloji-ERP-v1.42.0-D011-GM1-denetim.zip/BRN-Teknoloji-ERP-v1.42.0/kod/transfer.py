# -*- coding: utf-8 -*-
"""Transfer (1.18) — Faz 5: tüm transfer türlerinin TEK modülde konsolide görünümü.

Tasarım kararı (K4/K6 deseni): YENİ veri modeli AÇILMAZ — çift kayıt (ikinci doğruluk
kaynağı) riski doğurur. Bunun yerine mevcut kayıtlar tek kronolojik görünümde toplanır:
  - Depolar arası transfer (depo_transfer — Taslak/Tamamlandı onay akışı, Stok2)
  - Kasa ↔ Banka transfer (kasa_hareket/banka_hareket — anında, bakiye kontrollü)
  - Kasa → Kasa transfer (kasa_hareket çifti — bu modülle eklenen "kasalar arası")
"Şubeler arası" transferler kaynak/hedef şube farkıyla işaretlenir.
Salt-okunur; kayıtlar kendi modüllerinden yönetilir (linklerle).
"""

import datetime

import db
from core import route, render_template

TIP_BADGE = {"Depo": "b-info", "Kasa → Kasa": "b-warn", "Kasa ↔ Banka": "b-ok"}
DURUM_BADGE = {"Taslak": "b-warn", "Tamamlandi": "b-ok"}


def _filtre_uygula(rows, tip, bas, bit, sube):
    if tip:
        rows = [r for r in rows if r["tip"] == tip]
    if bas:
        rows = [r for r in rows if (r["tarih"] or "") >= bas]
    if bit:
        rows = [r for r in rows if (r["tarih"] or "") <= bit]
    if sube:
        rows = [r for r in rows if r["kaynak_sube"] == sube or r["hedef_sube"] == sube]
    return rows


def _kayit(conn, tip, tarih, kaynak, hedef, kaynak_sube, hedef_sube, tutar, kalem,
           durum, link, etiket):
    return {
        "tip": tip, "tarih": tarih, "kaynak": kaynak, "hedef": hedef,
        "kaynak_sube": kaynak_sube, "hedef_sube": hedef_sube,
        "tutar": tutar, "kalem": kalem, "durum": durum, "link": link,
        "etiket": etiket,
        "subeler_arasi": bool(kaynak_sube and hedef_sube and kaynak_sube != hedef_sube),
    }


def _depo_transferler(conn, sid=None):
    rows = []
    extra = " AND t.sirket_id=?" if sid is not None else ""
    args = [sid] if sid is not None else []
    for t in conn.execute(
        "SELECT t.*, d1.ad AS kaynak_ad, d1.sube_id AS kaynak_sube, "
        "d2.ad AS hedef_ad, d2.sube_id AS hedef_sube, "
        "(SELECT COUNT(*) FROM depo_transfer_kalem k WHERE k.transfer_id=t.id) AS kalem "
        "FROM depo_transfer t JOIN depo d1 ON d1.id=t.kaynak_depo_id "
        "JOIN depo d2 ON d2.id=t.hedef_depo_id WHERE t.id>0" + extra +
        " ORDER BY t.tarih DESC, t.id DESC", args).fetchall():
        t = dict(t)
        rows.append(_kayit(conn, "Depo", t["tarih"], t["kaynak_ad"], t["hedef_ad"],
                           t["kaynak_sube"], t["hedef_sube"], None, t["kalem"],
                           t["durum"], f"/stok/transferler/{t['id']}", "Depolar Arası"))
    return rows


def _kasa_banka_transferler(conn, sid=None):
    rows = []
    extra = " AND h.sirket_id=?" if sid is not None else ""
    args = [sid] if sid is not None else []
    # Kasa başlatımlı primaries: Kasa → Banka ve Kasa → Kasa (Çıkış)
    for h in conn.execute(
        "SELECT h.*, k.ad AS kasa_ad, k.sube_id AS kasa_sube FROM kasa_hareket h "
        "JOIN kasa k ON k.id=h.kasa_id WHERE h.ilgili_modul='Transfer' AND h.ilgili_kayit_id IS NULL "
        "AND h.islem_tipi IN ('Kasa → Banka','Kasa Transferi (Çıkış)')" + extra +
        " ORDER BY h.tarih DESC, h.id DESC", args).fetchall():
        h = dict(h)
        if h["islem_tipi"] == "Kasa Transferi (Çıkış)":
            kar = conn.execute(
                "SELECT k.ad AS ad, k.sube_id AS sb FROM kasa_hareket kh JOIN kasa k ON k.id=kh.kasa_id "
                "WHERE kh.ilgili_modul='Transfer' AND kh.ilgili_kayit_id=? LIMIT 1", (h["id"],)).fetchone()
            rows.append(_kayit(conn, "Kasa → Kasa", h["tarih"], h["kasa_ad"],
                               kar["ad"] if kar else "?", h["kasa_sube"],
                               kar["sb"] if kar else None, h["tutar"], None, "Tamamlandi",
                               "/kasa", "Kasalar Arası"))
        else:  # Kasa → Banka
            kar = conn.execute(
                "SELECT b.ad AS ad, b.sube_id AS sb FROM banka_hareket bh "
                "JOIN banka_hesap b ON b.id=bh.banka_hesap_id "
                "WHERE bh.ilgili_modul='Transfer' AND bh.ilgili_kayit_id=? LIMIT 1", (h["id"],)).fetchone()
            rows.append(_kayit(conn, "Kasa ↔ Banka", h["tarih"], h["kasa_ad"],
                               kar["ad"] if kar else "?", h["kasa_sube"],
                               kar["sb"] if kar else None, h["tutar"], None, "Tamamlandi",
                               "/kasa", "Kasa → Banka"))
    extra_b = " AND b.sirket_id=?" if sid is not None else ""
    args_b = [sid] if sid is not None else []
    # Banka başlatımlı primary: Banka → Kasa
    for b in conn.execute(
        "SELECT b.*, hb.ad AS banka_ad, hb.sube_id AS banka_sube FROM banka_hareket b "
        "JOIN banka_hesap hb ON hb.id=b.banka_hesap_id "
        "WHERE b.ilgili_modul='Transfer' AND b.ilgili_kayit_id IS NULL AND b.islem_tipi='Banka → Kasa'"
        + extra_b +
        " ORDER BY b.tarih DESC, b.id DESC", args_b).fetchall():
        b = dict(b)
        kar = conn.execute(
            "SELECT k.ad AS ad, k.sube_id AS sb FROM kasa_hareket kh JOIN kasa k ON k.id=kh.kasa_id "
            "WHERE kh.ilgili_modul='Transfer' AND kh.ilgili_kayit_id=? LIMIT 1", (b["id"],)).fetchone()
        rows.append(_kayit(conn, "Kasa ↔ Banka", b["tarih"],
                           b["banka_ad"], kar["ad"] if kar else "?",
                           b["banka_sube"], kar["sb"] if kar else None,
                           b["tutar"], None, "Tamamlandi", "/banka", "Banka → Kasa"))
    return rows


@route(r"/transfer", roles=())
def transfer_liste(req):
    conn = db.get_conn()
    rows = _depo_transferler(conn, db.sirket_id(req)) + _kasa_banka_transferler(conn, db.sirket_id(req))
    conn.close()

    # KPI (filtre öncesi tüm kayıtlar)
    n_depo = sum(1 for r in rows if r["tip"] == "Depo")
    n_kasa = len(rows) - n_depo
    n_taslak = sum(1 for r in rows if r["durum"] == "Taslak")
    toplam_tutar = round(sum((r["tutar"] or 0) for r in rows if r["tip"] != "Depo"), 2)

    tip = req.q("tip")
    bas = req.q("bas")
    bit = req.q("bit")
    sube = None
    if req.q("sube").isdigit():
        sube = int(req.q("sube"))
    rows = _filtre_uygula(rows, tip, bas, bit, sube)

    conn = db.get_conn()
    subeler = conn.execute("SELECT id, ad FROM sube WHERE aktif=1 AND sirket_id=? ORDER BY ad",
                           (db.sirket_id(req),)).fetchall()
    conn.close()

    return render_template("transfer/liste.html", rows=rows, n_depo=n_depo, n_kasa=n_kasa,
                           n_taslak=n_taslak, toplam_tutar=toplam_tutar,
                           TIP_BADGE=TIP_BADGE, DURUM_BADGE=DURUM_BADGE,
                           subeler=subeler, filtro={"tip": tip, "bas": bas, "bit": bit, "sube": sube})


def register():
    return "transfer"
