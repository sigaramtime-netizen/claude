# -*- coding: utf-8 -*-
"""İstek 3 — ek kanıt (2/3): Belge no bağımsızlığı + zincir (kaynak) çapraz şirket engeli (e2e).

Kapsam:
  1. A şirketinde teklif üretilir (TKF-<yil>-NNN); B şirketi kendi sayacıyla BAĞIMSIZ
     TKF-<yil>-001 üretir (composite UNIQUE çakışmaya izin verir).
  2. A teklifi onaylanır; B şirketi A'nın teklifini kaynak göstererek sipariş ÜRETEMEZ
     (GET formu redirect + POST kaydetme engeli — zincir şirket dışına sızmaz).
  3. Temizlik.

Çalıştırma: sunucu 8080'de çalışırken  python3 test_belge_sayac_e2e.py
"""
import datetime
import sqlite3
import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
KOD = "ISOS"
YIL = datetime.date.today().year

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else ""))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris():
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": "admin", "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, "giriş başarısız"
    return s


def aktif_sirket():
    return db1("SELECT sirket_id FROM sessionler ORDER BY rowid DESC LIMIT 1")["sirket_id"]


def teklif_olustur(s, cari_id, aciklama):
    s.post(BASE + "/teklif/yeni", data=[
        ("cari_id", str(cari_id)), ("tarih", datetime.date.today().isoformat()),
        ("gecerlilik_tarihi", "2026-12-31"), ("aciklama", aciklama), ("action", "kaydet"),
        ("k_stok_id", ""), ("k_varyant_id", "0"), ("k_manuel_ad", "Danışmanlık hizmeti"),
        ("k_birim", "Adet"), ("k_goruntu_ad", ""), ("k_miktar", "1"),
        ("k_birim_fiyat", "100"), ("k_iskonto", "0"), ("k_kdv", "20"),
    ], allow_redirects=False)
    t = db1("SELECT id, teklif_no, sirket_id FROM teklif WHERE aciklama=? ORDER BY id DESC", aciklama)
    return t


def main():
    admin = giris()
    # --- 0. Kalıntı temizliği ---
    eski = db1("SELECT id FROM sirket WHERE kod=?", KOD)
    if eski:
        sid = eski["id"]
        for t in ("teklif_kalem", "teklif", "cari_kart", "siparis_kalem", "siparis",
                  "hesap", "demirbas_kategori", "depo", "kullanici_sirket"):
            dbx(f"DELETE FROM {t} WHERE sirket_id=?", sid)
        dbx("DELETE FROM sirket WHERE id=?", sid)
    dbx("DELETE FROM teklif_kalem WHERE teklif_id IN (SELECT id FROM teklif WHERE aciklama LIKE 'ISO-SAYAC-%')")
    dbx("DELETE FROM teklif WHERE aciklama LIKE 'ISO-SAYAC-%'")
    dbx("DELETE FROM cari_kart WHERE unvan LIKE 'ISO Sayac%'")

    # --- 1. Şirket B kur ---
    admin.post(BASE + "/ayarlar/sirketler", data={"kod": KOD, "unvan": "Sayaç İzolasyon A.Ş."},
               allow_redirects=False)
    b_id = db1("SELECT id FROM sirket WHERE kod=?", KOD)["id"]

    # --- 2. A (şirket 1) — cari + teklif ---
    admin.post(BASE + "/sirket/gec", data={"sirket_id": "1", "next": "/"}, allow_redirects=False)
    admin.post(BASE + "/cari/yeni", data={"unvan": "ISO Sayac Müşteri A", "tip": "Musteri"},
               allow_redirects=False)
    a_cari = db1("SELECT id FROM cari_kart WHERE unvan='ISO Sayac Müşteri A'")["id"]
    ta = teklif_olustur(admin, a_cari, "ISO-SAYAC-A")
    check("A teklifi oluştu", ta is not None, f"no={ta['teklif_no'] if ta else '-'}")

    # --- 3. B — cari + teklif (bağımsız sayaç) ---
    admin.post(BASE + "/sirket/gec", data={"sirket_id": str(b_id), "next": "/"},
               allow_redirects=False)
    admin.post(BASE + "/cari/yeni", data={"unvan": "ISO Sayac Müşteri B", "tip": "Musteri"},
               allow_redirects=False)
    b_cari = db1("SELECT id FROM cari_kart WHERE unvan='ISO Sayac Müşteri B'")["id"]
    tb = teklif_olustur(admin, b_cari, "ISO-SAYAC-B")
    check("B teklifi oluştu", tb is not None, f"no={tb['teklif_no'] if tb else '-'}")

    # --- 4. Bağımsız sayaç + composite UNIQUE doğrulaması ---
    check("B sayacı 1'den başladı (bağımsız)",
          tb and tb["teklif_no"] == f"TKF-{YIL}-001", f"B no={tb['teklif_no'] if tb else '-'}")
    check("A no ≠ B no (iki şirket aynı format, ayrı sayaç)",
          ta and tb and ta["teklif_no"] != tb["teklif_no"],
          f"A={ta['teklif_no']} B={tb['teklif_no']}")
    check("teklifler farklı şirkete damgalı",
          ta and tb and ta["sirket_id"] == 1 and tb["sirket_id"] == b_id,
          f"A.sid={ta['sirket_id']} B.sid={tb['sirket_id']}")
    # composite UNIQUE: aynı belge no iki şirkette BİR ARADA durabilir (kısıt şirket başına).
    es_nolar = db("SELECT sirket_id FROM teklif WHERE teklif_no=?", tb["teklif_no"])
    sidler = {r["sirket_id"] for r in es_nolar}
    check("aynı belge no iki şirkette bir arada (composite UNIQUE)",
          len(es_nolar) >= 2 and 1 in sidler and b_id in sidler,
          f"{tb['teklif_no']} → sirketler={sorted(sidler)}")

    # --- 5. Zincir engeli: A teklifi → B'de sipariş üretilemez ---
    admin.post(BASE + "/sirket/gec", data={"sirket_id": "1", "next": "/"}, allow_redirects=False)
    admin.post(BASE + f"/teklif/{ta['id']}/durum", data={"durum": "Onaylandı"},
               allow_redirects=False)
    durum = db1("SELECT durum FROM teklif WHERE id=?", ta["id"])["durum"]
    check("A teklifi Onaylandı", durum == "Onaylandı", durum)

    admin.post(BASE + "/sirket/gec", data={"sirket_id": str(b_id), "next": "/"},
               allow_redirects=False)
    r = admin.get(BASE + f"/siparis/yeni?kaynak_teklif={ta['id']}", allow_redirects=False)
    check("B'de A teklifinden sipariş formu ENGELLİ (302)", r.status_code == 302,
          f"status={r.status_code}")

    admin.post(BASE + "/siparis/yeni", data=[
        ("cari_id", str(b_cari)), ("tarih", datetime.date.today().isoformat()),
        ("kaynak_teklif", str(ta["id"])), ("action", "kaydet"),
        ("k_stok_id", ""), ("k_varyant_id", "0"), ("k_manuel_ad", "Deneme"),
        ("k_birim", "Adet"), ("k_miktar", "1"), ("k_birim_fiyat", "50"),
        ("k_iskonto", "0"), ("k_kdv", "20"),
    ], allow_redirects=False)
    sizan = db1("SELECT id FROM siparis WHERE kaynak_teklif_id=? AND sirket_id=?",
                ta["id"], b_id)
    check("B'de A kaynaklı sipariş ÜRETİLMEDİ", sizan is None)

    # --- 6. Temizlik ---
    for t in ("siparis_kalem", "siparis", "teklif_kalem", "teklif", "cari_kart",
              "hesap", "demirbas_kategori", "depo", "kullanici_sirket"):
        dbx(f"DELETE FROM {t} WHERE sirket_id=?", b_id)
    dbx("DELETE FROM sirket WHERE id=?", b_id)
    dbx("UPDATE sessionler SET sirket_id=1 WHERE sirket_id=?", b_id)
    dbx("DELETE FROM teklif_kalem WHERE teklif_id IN (SELECT id FROM teklif WHERE aciklama LIKE 'ISO-SAYAC-%')")
    dbx("DELETE FROM teklif WHERE aciklama LIKE 'ISO-SAYAC-%'")
    dbx("DELETE FROM cari_kart WHERE unvan LIKE 'ISO Sayac%'")

    print(f"\nSONUÇ: {len(ok)} başarılı / {len(fail)} başarısız")
    if fail:
        print("BAŞARISIZ:", fail)
        raise SystemExit(1)
    print("BELGE NO BAĞIMSIZLIĞI + ZİNCİR ENGELİ E2E TESTİ GEÇTİ ✅")


if __name__ == "__main__":
    main()
