# -*- coding: utf-8 -*-
"""F1 — Mali etki "zincirdeki ilk belgede bir kere" e2e testi.

Kapsam:
  1. İrsaliye onayı → cari hareket (Satış İrsaliyesi BORÇ) + yevmiye fişi (kaynak Irsaliye).
  2. Kaynaklı fatura onayı → mali etki ÜRETMEZ (belgeleştirme yalnız).
  3. İrsaliyesiz fatura onayı → mali etki üretir (regresyon kontrolü).
  4. Alış irsaliyesi → cari ALACAK + fiş (153/191/320).
  5. Transfer irsaliyesi → mali etki YOK.
  6. İrsaliye iptali fatura varken ENGELLENİR.
  7. Kaynaklı fatura iptali → mali etkiye dokunmaz (irsaliye cari hareketi durur).
  8. İrsaliye iptali (fatura iptal edildikten sonra) → cari hareket + fiş geri alınır.
  9. Bütünlük: FK, yetim yevmiye, çifte kayıt yok.

Not: İrsaliyeler MANUEL satırla kurulur → stok hareketi üretilmez (temizlik sadeleşir).

Çalıştırma: sunucu 8080'de çalışırken  python3 test_f1_mali.py
"""
import datetime
import sqlite3
import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
BUGUN = datetime.date.today().isoformat()
MARK = "F1TEST"

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else ""))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris():
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": "admin", "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302
    return s


def cari_yev(kaynak_modul, kid):
    ch = db("SELECT COUNT(*) c FROM cari_hareket WHERE ilgili_modul=? AND ilgili_kayit_id=?",
            kaynak_modul, kid)[0]["c"]
    yv = db("SELECT COUNT(*) c FROM yevmiye WHERE kaynak_modul=? AND kaynak_id=?",
            kaynak_modul, kid)[0]["c"]
    return ch, yv


def _satir_verisi(manuel_ad=None, stok_id=None, bf=0, kdv=20):
    return {"k_stok_id": [str(stok_id) if stok_id else ""],
            "k_varyant_id": ["0"],
            "k_manuel_ad": [manuel_ad or ""],
            "k_miktar": ["1"], "k_birim_fiyat": [str(bf)], "k_iskonto": ["0"],
            "k_kdv": [str(kdv)], "k_birim": ["Adet"], "k_goruntu_ad": [""]}


def irsaliye_olustur(s, tip, cari_id, depo_id, manuel_ad=None, bf=0, kdv=20,
                     stok_id=None, hedef_depo_id=None, aciklama=MARK):
    data = {"tip": tip, "cari_id": str(cari_id), "depo_id": str(depo_id), "tarih": BUGUN,
            "aciklama": aciklama, "action": "kaydet"}
    data.update(_satir_verisi(manuel_ad, stok_id, bf, kdv))
    if hedef_depo_id:
        data["hedef_depo_id"] = str(hedef_depo_id)
    r = s.post(BASE + "/irsaliye/yeni", data=data, allow_redirects=False)
    loc = r.headers.get("Location") or ""
    assert "/irsaliye/" in loc, f"irsaliye oluşmadı: {r.status_code} {loc}"
    return int(loc.rstrip("/").split("/")[-1])


def fatura_olustur(s, tip, cari_id, manuel_ad, bf, kdv=20, kaynak_irsaliye=None,
                   aciklama=MARK):
    data = {"tip": tip, "cari_id": str(cari_id), "tarih": BUGUN, "aciklama": aciklama,
            "action": "kaydet"}
    data.update(_satir_verisi(manuel_ad, None, bf, kdv))
    if kaynak_irsaliye:
        data["kaynak_irsaliye"] = str(kaynak_irsaliye)
    r = s.post(BASE + "/fatura/yeni", data=data, allow_redirects=False)
    loc = r.headers.get("Location") or ""
    assert "/fatura/" in loc, f"fatura oluşmadı: {r.status_code} {loc}"
    return int(loc.rstrip("/").split("/")[-1])


def temizle():
    # stok hareketleri (onaylanan belgelerin ürettiği) — kayıt silinmeden önce
    dbx("DELETE FROM stok_hareket WHERE ilgili_modul IN ('Irsaliye','Fatura') AND ilgili_kayit_id IN "
        "(SELECT id FROM irsaliye WHERE aciklama=?)", MARK)
    dbx("DELETE FROM stok_hareket WHERE ilgili_modul IN ('Irsaliye','Fatura') AND ilgili_kayit_id IN "
        "(SELECT id FROM fatura WHERE aciklama=?)", MARK)
    # önce faturalar (kaynaklı) sonra irsaliyeler
    for f in db("SELECT id FROM fatura WHERE aciklama=?", MARK):
        fid = f["id"]
        dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN (SELECT id FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?)", fid)
        dbx("DELETE FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?", fid)
        dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
        dbx("DELETE FROM fatura_kalem WHERE fatura_id=?", fid)
        dbx("DELETE FROM fatura WHERE id=?", fid)
    for i in db("SELECT id FROM irsaliye WHERE aciklama=?", MARK):
        iid = i["id"]
        dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN (SELECT id FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id=?)", iid)
        dbx("DELETE FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id=?", iid)
        dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", iid)
        dbx("DELETE FROM irsaliye_kalem WHERE irsaliye_id=?", iid)
        dbx("DELETE FROM irsaliye WHERE id=?", iid)


print("== F1 / Mali etki: ilk belgede bir kere — e2e testi ==")
s = giris()
temizle()

cid = db1("SELECT id FROM cari_kart WHERE kod='BAT-001'")["id"]
depo = db1("SELECT id FROM depo WHERE sirket_id=1 LIMIT 1")["id"]

# 1. Satış irsaliyesi onayı → mali etki
iid = irsaliye_olustur(s, "Satis", cid, depo, "F1TEST satış hizmeti", 1000)
r = s.post(BASE + f"/irsaliye/{iid}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
check("1.1 irsaliye onaylandı", db1("SELECT durum FROM irsaliye WHERE id=?", iid)["durum"] == "Onaylandı")
ch = db("SELECT borc, alacak, belge_tipi FROM cari_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", iid)
check("1.2 cariye BORÇ (Satış İrsaliyesi)", len(ch) == 1 and ch[0]["belge_tipi"] == "Satış İrsaliyesi"
      and abs(ch[0]["borc"] - 1200.0) < 1e-9, str([dict(x) for x in ch]))
yv = db("SELECT id FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id=?", iid)
check("1.3 yevmiye fişi (Irsaliye)", len(yv) == 1)
kalem = db("SELECT h.kod, k.borc, k.alacak FROM yevmiye_kalem k JOIN hesap h ON h.id=k.hesap_id "
           "WHERE k.yevmiye_id=? ORDER BY k.id", yv[0]["id"])
check("1.4 fiş satırları 120/600/391", [x["kod"] for x in kalem] == ["120", "600", "391"],
      str([x["kod"] for x in kalem]))

# 2. Kaynaklı fatura → mali etki ÜRETMEZ
fid = fatura_olustur(s, "Satis", cid, "F1TEST satış hizmeti", 1000, kaynak_irsaliye=iid)
r = s.post(BASE + f"/fatura/{fid}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
check("2.1 kaynaklı fatura onaylandı", db1("SELECT durum FROM fatura WHERE id=?", fid)["durum"] == "Onaylandı")
fch, fyv = cari_yev("Fatura", fid)
check("2.2 kaynaklı fatura cari hareket ÜRETMEZ", fch == 0, f"cari={fch}")
check("2.3 kaynaklı fatura yevmiye ÜRETMEZ", fyv == 0, f"fiş={fyv}")

# 3. İrsaliyesiz fatura → mali etki ÜRETİR (regresyon)
fid2 = fatura_olustur(s, "Satis", cid, "F1TEST direkt satış", 500)
r = s.post(BASE + f"/fatura/{fid2}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
fch2, fyv2 = cari_yev("Fatura", fid2)
check("3.1 irsaliyesiz fatura cari hareket üretir", fch2 == 1, f"cari={fch2}")
check("3.2 irsaliyesiz fatura yevmiye üretir", fyv2 == 1, f"fiş={fyv2}")

# 4. Alış irsaliyesi (STOKLU) → ALACAK + 153/191/320
tid = db1("SELECT id FROM cari_kart WHERE kod='TED-001'")["id"]
aid = irsaliye_olustur(s, "Alis", tid, depo, bf=2000, stok_id=3)
s.post(BASE + f"/irsaliye/{aid}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
ch = db("SELECT borc, alacak, belge_tipi FROM cari_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", aid)
check("4.1 alış irsaliyesi cariye ALACAK", len(ch) == 1 and ch[0]["belge_tipi"] == "Alış İrsaliyesi"
      and abs(ch[0]["alacak"] - 2400.0) < 1e-9, str([dict(x) for x in ch]))
yv = db1("SELECT id FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id=?", aid)
kalem = db("SELECT h.kod, k.borc FROM yevmiye_kalem k JOIN hesap h ON h.id=k.hesap_id WHERE k.yevmiye_id=? ORDER BY k.id", yv["id"])
check("4.2 alış fişi 153/191/320 (stoklu)", [x["kod"] for x in kalem] == ["153", "191", "320"],
      str([dict(x) for x in kalem]))
check("4.3 153 borç = matrah 2000", abs(kalem[0]["borc"] - 2000.0) < 1e-9, str(kalem[0]["borc"]))

# 4b. Alış irsaliyesi (MANUEL) → 770/191/320
aid2 = irsaliye_olustur(s, "Alis", tid, depo, manuel_ad="F1TEST alış hizmeti", bf=300)
s.post(BASE + f"/irsaliye/{aid2}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
yv2 = db1("SELECT id FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id=?", aid2)
kalem2 = db("SELECT h.kod FROM yevmiye_kalem k JOIN hesap h ON h.id=k.hesap_id WHERE k.yevmiye_id=? ORDER BY k.id", yv2["id"])
check("4b.1 alış fişi 770/191/320 (manuel)", [x["kod"] for x in kalem2] == ["770", "191", "320"],
      str([x["kod"] for x in kalem2]))

# 5. Transfer irsaliyesi (stoklu) → mali etki YOK
depo2 = db1("SELECT id FROM depo WHERE sirket_id=1 AND id != ? LIMIT 1", depo)["id"]
tran_id = irsaliye_olustur(s, "Transfer", cid, depo, bf=100, stok_id=3, hedef_depo_id=depo2)
s.post(BASE + f"/irsaliye/{tran_id}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
tch, tyv = cari_yev("Irsaliye", tran_id)
check("5.1 transfer irsaliye cari hareket ÜRETMEZ", tch == 0, f"cari={tch}")
check("5.2 transfer irsaliye yevmiye ÜRETMEZ", tyv == 0, f"fiş={tyv}")
check("5.3 transfer stok hareketi ÜRETİR (depo transferi)", db(
    "SELECT COUNT(*) c FROM stok_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", tran_id)[0]["c"] == 2)

# 6. Fatura varken irsaliye iptali engellenir
r = s.post(BASE + f"/irsaliye/{iid}/durum", data={"durum": "İptal"}, allow_redirects=False)
check("6.1 fatura varken iptal engellendi", db1("SELECT durum FROM irsaliye WHERE id=?", iid)["durum"] == "Onaylandı")

# 7. Kaynaklı fatura iptali → irsaliye cari hareketi durur
s.post(BASE + f"/fatura/{fid}/durum", data={"durum": "İptal"}, allow_redirects=False)
check("7.1 kaynaklı fatura iptal oldu", db1("SELECT durum FROM fatura WHERE id=?", fid)["durum"] == "İptal")
ch = db("SELECT COUNT(*) c FROM cari_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", iid)
check("7.2 irsaliye cari hareketi hâlâ duruyor", ch[0]["c"] == 1)

# 8. İrsaliye iptali (fatura iptal edildikten sonra) → geri alınır
s.post(BASE + f"/irsaliye/{iid}/durum", data={"durum": "İptal"}, allow_redirects=False)
check("8.1 irsaliye iptal oldu", db1("SELECT durum FROM irsaliye WHERE id=?", iid)["durum"] == "İptal")
ich, iyv = cari_yev("Irsaliye", iid)
check("8.2 cari hareket geri alındı", ich == 0, f"cari={ich}")
check("8.3 yevmiye fişi geri alındı", iyv == 0, f"fiş={iyv}")

# 9. Temizlik + bütünlük
temizle()
fk = db("PRAGMA foreign_key_check")
check("9.1 FK bütünlüğü", len(fk) == 0, str([tuple(r) for r in fk][:5]))
src = {"Fatura": "fatura", "Kasa": "kasa_hareket", "Banka": "banka_hareket",
       "CekSenet": "cek_senet", "Demirbas": "demirbas", "Irsaliye": "irsaliye"}
bad = [r["fis_no"] for r in db("SELECT fis_no, kaynak_modul, kaynak_id FROM yevmiye")
       if src.get(r["kaynak_modul"]) and not db("SELECT 1 FROM " + src[r["kaynak_modul"]] + " WHERE id=?", r["kaynak_id"])]
check("9.2 yetim yevmiye yok", len(bad) == 0, str(bad[:5]))
check("9.3 F1TEST kalıntısı yok", db("SELECT COUNT(*) c FROM irsaliye WHERE aciklama=?", MARK)[0]["c"] == 0
      and db("SELECT COUNT(*) c FROM fatura WHERE aciklama=?", MARK)[0]["c"] == 0)

print(f"\n=== SONUÇ: {len(ok)} başarılı / {len(fail)} başarısız ===")
if fail:
    print("BAŞARISIZ:", fail)
    raise SystemExit(1)
print("TÜM F1 MALİ ETKİ TESTLERİ GEÇTİ ✅")
