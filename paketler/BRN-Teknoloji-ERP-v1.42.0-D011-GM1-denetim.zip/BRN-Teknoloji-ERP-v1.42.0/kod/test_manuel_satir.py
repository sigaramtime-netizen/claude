# -*- coding: utf-8 -*-
"""Manuel (serbest metin) satır özelliği uçtan uca testleri.

Çalıştırma: sunucu 8080'de çalışırken  python3 test_manuel_satir.py
"""
import sqlite3
import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"


def q1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def qall(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def temizle_fatura(fid):
    c = sqlite3.connect(DB)
    c.execute("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN (SELECT id FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?)", (fid,))
    c.execute("DELETE FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?", (fid,))
    c.execute("DELETE FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", (fid,))
    c.execute("DELETE FROM audit_log WHERE tablo='fatura' AND kayit_id=?", (fid,))
    c.execute("DELETE FROM fatura_kalem WHERE fatura_id=?", (fid,))
    c.execute("DELETE FROM fatura WHERE id=?", (fid,))
    c.commit(); c.close()


def temizle_irsaliye(iid):
    c = sqlite3.connect(DB)
    # F1 — irsaliye onayı fiş + cari üretir; kalıntı bırakma
    c.execute("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN "
              "(SELECT id FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id=?)", (iid,))
    c.execute("DELETE FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id=?", (iid,))
    c.execute("DELETE FROM cari_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", (iid,))
    c.execute("DELETE FROM stok_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", (iid,))
    c.execute("DELETE FROM audit_log WHERE tablo='irsaliye' AND kayit_id=?", (iid,))
    c.execute("DELETE FROM irsaliye_kalem WHERE irsaliye_id=?", (iid,))
    c.execute("DELETE FROM irsaliye WHERE id=?", (iid,))
    c.commit(); c.close()


def yevmiye(modul, kid):
    return qall(
        "SELECT h.kod AS hesap_kod, ROUND(kl.borc,2) b, ROUND(kl.alacak,2) a "
        "FROM yevmiye y JOIN yevmiye_kalem kl ON kl.yevmiye_id=y.id "
        "LEFT JOIN hesap h ON h.id=kl.hesap_id "
        "WHERE y.kaynak_modul=? AND y.kaynak_id=?", modul, kid)


def giris():
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": "admin", "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302 and "erp_session" in s.cookies.get_dict(), "giriş başarısız"
    return s


ok = []
fail = []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else ""))


admin = giris()

# --- kullanılacak kayıtlar ---
musteri = q1("SELECT id, unvan FROM cari_kart WHERE aktif=1 AND tip IN ('Musteri','HerIkisi') ORDER BY id LIMIT 1")
tedarik = q1("SELECT id, unvan FROM cari_kart WHERE aktif=1 AND tip IN ('Tedarikci','HerIkisi') ORDER BY id LIMIT 1")
stok = q1("SELECT id, ad, satis_fiyat FROM stok_kart WHERE aktif=1 ORDER BY id LIMIT 1")
sev = q1("SELECT depo_id, miktar FROM stok_seviye WHERE stok_id=? AND varyant_id=0 ORDER BY depo_id LIMIT 1", stok["id"])
print(f"Kaynaklar: müşteri={musteri['id']} {musteri['unvan']} | tedarik={tedarik['id']} {tedarik['unvan']} | "
      f"stok={stok['id']} {stok['ad']} | seviye depo={sev['depo_id']} miktar={sev['miktar']}")

# ======================================================================
print("\n" + "=" * 70)
print("TEST A — Satış faturası: stok + manuel satır (600'a tek satır yazılır)")
print("=" * 70)
r = admin.post(BASE + "/fatura/yeni", data=[
    ("tip", "Satis"), ("cari_id", str(musteri["id"])), ("tarih", "2026-09-08"),
    ("para_birimi", "TRY"), ("doviz_kur", ""), ("vade", ""), ("aciklama", "TST-A manuel"),
    ("action", "kaydet"),
    ("k_stok_id", str(stok["id"])), ("k_stok_id", ""),
    ("k_varyant_id", "0"), ("k_varyant_id", "0"),
    ("k_manuel_ad", ""), ("k_manuel_ad", "Kargo Ücreti"),
    ("k_miktar", "1"), ("k_miktar", "1"),
    ("k_birim_fiyat", "1000"), ("k_birim_fiyat", "200"),
    ("k_iskonto", "0"), ("k_iskonto", "0"),
    ("k_kdv", "20"), ("k_kdv", "20"),
], allow_redirects=False)
fid = q1("SELECT id FROM fatura WHERE aciklama='TST-A manuel' ORDER BY id DESC")["id"]
f = q1("SELECT ara_toplam, kdv_toplam, genel_toplam, doviz_kur FROM fatura WHERE id=?", fid)
check("A1 fatura oluştu (TRY, doviz_kur=1)",
      fid and f["doviz_kur"] == 1.0, f"id={fid} kur={f['doviz_kur']}")
check("A2 toplamlar 1200/240/1440",
      (f["ara_toplam"], f["kdv_toplam"], f["genel_toplam"]) == (1200.0, 240.0, 1440.0),
      f"{f['ara_toplam']}/{f['kdv_toplam']}/{f['genel_toplam']}")
k = qall("SELECT stok_id, aciklama, tutar FROM fatura_kalem WHERE fatura_id=? ORDER BY id", fid)
check("A3 kalemler: stok(1)+manuel(NULL)",
      [x["stok_id"] for x in k] == [stok["id"], None] and k[1]["aciklama"] == "Kargo Ücreti",
      f"{[(x['stok_id'], x['aciklama']) for x in k]}")
# onay
admin.post(BASE + f"/fatura/{fid}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
yk = yevmiye("Fatura", fid)
altilar = [x for x in yk if x["hesap_kod"] == "600"]
check("A4 yevmiye: 600 tek satır = 1200 ALACAK (manuel dahil)",
      len(altilar) == 1 and altilar[0]["a"] == 1200.0, f"600 satırları: {altilar}")
yuz20 = [x for x in yk if x["hesap_kod"] == "120"]
yuz91 = [x for x in yk if x["hesap_kod"] == "391"]
check("A4b 120 borç=1440, 391 alacak=240",
      sum(x["b"] for x in yuz20) == 1440.0 and sum(x["a"] for x in yuz91) == 240.0,
      f"120={[x['b'] for x in yuz20]} 391={[x['a'] for x in yuz91]}")
borc = sum(x["b"] for x in yk); alacak = sum(x["a"] for x in yk)
check("A5 fiş dengeli", round(borc, 2) == round(alacak, 2), f"{borc}/{alacak}")
admin.post(BASE + f"/fatura/{fid}/durum", data={"durum": "İptal"}, allow_redirects=False)
check("A6 iptal sonrası yevmiye/cari hareket temiz",
      q1("SELECT COUNT(*) c FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?", fid)["c"] == 0
      and q1("SELECT COUNT(*) c FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)["c"] == 0)
temizle_fatura(fid)

# ======================================================================
print("\n" + "=" * 70)
print("TEST B — Alış faturası: stok + manuel satır (153 stok / 770 manuel)")
print("=" * 70)
r = admin.post(BASE + "/fatura/yeni", data=[
    ("tip", "Alis"), ("cari_id", str(tedarik["id"])), ("tarih", "2026-09-08"),
    ("para_birimi", "TRY"), ("doviz_kur", ""), ("vade", ""), ("aciklama", "TST-B manuel alis"),
    ("action", "kaydet"),
    ("k_stok_id", str(stok["id"])), ("k_stok_id", ""),
    ("k_varyant_id", "0"), ("k_varyant_id", "0"),
    ("k_manuel_ad", ""), ("k_manuel_ad", "Nakliye Bedeli"),
    ("k_miktar", "1"), ("k_miktar", "1"),
    ("k_birim_fiyat", "500"), ("k_birim_fiyat", "100"),
    ("k_iskonto", "0"), ("k_iskonto", "0"),
    ("k_kdv", "20"), ("k_kdv", "20"),
], allow_redirects=False)
fid = q1("SELECT id FROM fatura WHERE aciklama='TST-B manuel alis' ORDER BY id DESC")["id"]
admin.post(BASE + f"/fatura/{fid}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
yk = yevmiye("Fatura", fid)
g153 = [x for x in yk if x["hesap_kod"] == "153"]
g770 = [x for x in yk if x["hesap_kod"] == "770"]
g191 = [x for x in yk if x["hesap_kod"] == "191"]
g320 = [x for x in yk if x["hesap_kod"] == "320"]
check("B1 153=500 (stoklu), 770=100 (manuel)",
      (sum(x["b"] for x in g153), sum(x["b"] for x in g770)) == (500.0, 100.0),
      f"153={[x['b'] for x in g153]} 770={[x['b'] for x in g770]}")
check("B2 KDV 191=120", sum(x["b"] for x in g191) == 120.0, f"191={[x['b'] for x in g191]}")
borc = sum(x["b"] for x in yk); alacak = sum(x["a"] for x in yk)
check("B3 fiş dengeli (720/720)", round(borc, 2) == round(alacak, 2) == 720.0, f"{borc}/{alacak}")
admin.post(BASE + f"/fatura/{fid}/durum", data={"durum": "İptal"}, allow_redirects=False)
temizle_fatura(fid)

# ======================================================================
print("\n" + "=" * 70)
print("TEST C — İrsaliye: stok + manuel satır (stok_hareket yalnız stoklu satırda)")
print("=" * 70)
once = q1("SELECT miktar FROM stok_seviye WHERE stok_id=? AND varyant_id=0 AND depo_id=?",
          stok["id"], sev["depo_id"])["miktar"]
r = admin.post(BASE + "/irsaliye/yeni", data=[
    ("tip", "Satis"), ("cari_id", str(musteri["id"])), ("depo_id", str(sev["depo_id"])),
    ("tarih", "2026-09-08"), ("aciklama", "TST-C manuel irsaliye"), ("action", "kaydet"),
    ("k_stok_id", str(stok["id"])), ("k_stok_id", ""),
    ("k_varyant_id", "0"), ("k_varyant_id", "0"),
    ("k_manuel_ad", ""), ("k_manuel_ad", "Montaj Hizmeti"),
    ("k_miktar", "2"), ("k_miktar", "1"),
    ("k_birim_fiyat", "1000"), ("k_birim_fiyat", "50"),
    ("k_iskonto", "0"), ("k_iskonto", "0"),
    ("k_kdv", "20"), ("k_kdv", "20"),
], allow_redirects=False)
iid = q1("SELECT id FROM irsaliye WHERE aciklama='TST-C manuel irsaliye' ORDER BY id DESC")["id"]
k = qall("SELECT stok_id, aciklama FROM irsaliye_kalem WHERE irsaliye_id=?", iid)
check("C1 kalemler stok+manuel", [x["stok_id"] for x in k] == [stok["id"], None],
      f"{[(x['stok_id'], x['aciklama']) for x in k]}")
admin.post(BASE + f"/irsaliye/{iid}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
sh = qall("SELECT stok_id, miktar, islem_tipi FROM stok_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", iid)
check("C2 stok_hareket yalnız stoklu satır (1 kayıt, miktar -2)",
      len(sh) == 1 and sh[0]["stok_id"] == stok["id"] and sh[0]["miktar"] == -2.0,
      f"{[(x['stok_id'], x['miktar']) for x in sh]}")
sonra = q1("SELECT miktar FROM stok_seviye WHERE stok_id=? AND varyant_id=0 AND depo_id=?",
           stok["id"], sev["depo_id"])["miktar"]
check("C3 stok_seviye -2 (manuel dokunmadı)", sonra == once - 2.0, f"{once} → {sonra}")
admin.post(BASE + f"/irsaliye/{iid}/durum", data={"durum": "İptal"}, allow_redirects=False)
geri = q1("SELECT miktar FROM stok_seviye WHERE stok_id=? AND varyant_id=0 AND depo_id=?",
          stok["id"], sev["depo_id"])["miktar"]
check("C4 iptal sonrası seviye eskiye döndü", geri == once, f"{geri} (beklenen {once})")
temizle_irsaliye(iid)

# ======================================================================
print("\n" + "=" * 70)
print("TEST D — İrsaliye → Fatura: manuel satır taşınır")
print("=" * 70)
r = admin.post(BASE + "/irsaliye/yeni", data=[
    ("tip", "Satis"), ("cari_id", str(musteri["id"])), ("depo_id", str(sev["depo_id"])),
    ("tarih", "2026-09-08"), ("aciklama", "TST-D tasima"), ("action", "kaydet"),
    ("k_stok_id", str(stok["id"])), ("k_stok_id", ""),
    ("k_varyant_id", "0"), ("k_varyant_id", "0"),
    ("k_manuel_ad", ""), ("k_manuel_ad", "Montaj Hizmeti"),
    ("k_miktar", "1"), ("k_miktar", "1"),
    ("k_birim_fiyat", "1000"), ("k_birim_fiyat", "50"),
    ("k_iskonto", "0"), ("k_iskonto", "0"),
    ("k_kdv", "20"), ("k_kdv", "20"),
], allow_redirects=False)
iid = q1("SELECT id FROM irsaliye WHERE aciklama='TST-D tasima' ORDER BY id DESC")["id"]
once_d = q1("SELECT miktar FROM stok_seviye WHERE stok_id=? AND varyant_id=0 AND depo_id=?",
            stok["id"], sev["depo_id"])["miktar"]
admin.post(BASE + f"/irsaliye/{iid}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
form = admin.get(BASE + f"/fatura/yeni?kaynak_irsaliye={iid}").text
check("D1 fatura formunda manuel ad + rozet görünüyor",
      "Montaj Hizmeti" in form and "manuel" in form)
r = admin.post(BASE + "/fatura/yeni", data=[
    ("tip", "Satis"), ("cari_id", str(musteri["id"])), ("tarih", "2026-09-08"),
    ("para_birimi", "TRY"), ("doviz_kur", ""), ("vade", ""), ("aciklama", "TST-D irsaliyeden"),
    ("action", "kaydet"), ("kaynak_irsaliye", str(iid)),
    ("k_stok_id", str(stok["id"])), ("k_stok_id", ""),
    ("k_varyant_id", "0"), ("k_varyant_id", "0"),
    ("k_manuel_ad", ""), ("k_manuel_ad", "Montaj Hizmeti"),
    ("k_miktar", "1"), ("k_miktar", "1"),
    ("k_birim_fiyat", "1000"), ("k_birim_fiyat", "50"),
    ("k_iskonto", "0"), ("k_iskonto", "0"),
    ("k_kdv", "20"), ("k_kdv", "20"),
], allow_redirects=False)
fid = q1("SELECT id FROM fatura WHERE aciklama='TST-D irsaliyeden' ORDER BY id DESC")["id"]
fk = qall("SELECT stok_id, aciklama FROM fatura_kalem WHERE fatura_id=?", fid)
check("D2 fatura kalemlerinde manuel satır korundu",
      [x["stok_id"] for x in fk] == [stok["id"], None] and fk[1]["aciklama"] == "Montaj Hizmeti",
      f"{[(x['stok_id'], x['aciklama']) for x in fk]}")
temizle_fatura(fid)
# irsaliyeyi API ile iptal et (stok geri alınsın), sonra belgeyi sil
admin.post(BASE + f"/irsaliye/{iid}/durum", data={"durum": "İptal"}, allow_redirects=False)
sev_son = q1("SELECT miktar FROM stok_seviye WHERE stok_id=? AND varyant_id=0 AND depo_id=?",
             stok["id"], sev["depo_id"])["miktar"]
check("D3 irsaliye iptali stoğu geri aldı", sev_son == once_d, f"{sev_son} (beklenen {once_d})")
temizle_irsaliye(iid)

# ======================================================================
print("\n" + "=" * 70)
print("REGRESYON — ana sayfalar 200")
print("=" * 70)
for url in ["/", "/fatura", "/irsaliye", "/stok", "/muhasebe", "/kartoteks", "/ayarlar"]:
    st = admin.get(BASE + url, allow_redirects=False).status_code
    check(f"GET {url} → {st}", st == 200)

# ======================================================================
print("\n" + "=" * 70)
print("NİHAİ")
print("=" * 70)
m = q1("SELECT SUM(ROUND(k.borc,2)) b, SUM(ROUND(k.alacak,2)) a FROM yevmiye_kalem k "
       "JOIN yevmiye y ON y.id=k.yevmiye_id WHERE y.durum='Onaylandı'")
check("mizan dengeli", round(m["b"], 2) == round(m["a"], 2), f"{m['b']} / {m['a']}")
kalinti = q1("SELECT (SELECT COUNT(*) FROM fatura_kalem WHERE stok_id IS NULL) "
             "+ (SELECT COUNT(*) FROM irsaliye_kalem WHERE stok_id IS NULL) AS c")["c"]
check("test verisi temizlendi (NULL satır=0)", kalinti == 0, f"NULL satır: {kalinti}")
sev_son = q1("SELECT miktar FROM stok_seviye WHERE stok_id=? AND varyant_id=0 AND depo_id=?",
             stok["id"], sev["depo_id"])["miktar"]
check("stok seviyesi başlangıca döndü", sev_son == sev["miktar"],
      f"{sev_son} (beklenen {sev['miktar']})")
yetim = q1("SELECT COUNT(*) c FROM stok_hareket WHERE ilgili_modul='Irsaliye' "
           "AND ilgili_kayit_id NOT IN (SELECT id FROM irsaliye)")["c"]
check("yetim stok_hareket yok", yetim == 0, f"yetim: {yetim}")

print("\n" + "=" * 70)
print(f"SONUÇ: {len(ok)} ✅ / {len(fail)} ❌")
if fail:
    print("BAŞARISIZ:", fail)
