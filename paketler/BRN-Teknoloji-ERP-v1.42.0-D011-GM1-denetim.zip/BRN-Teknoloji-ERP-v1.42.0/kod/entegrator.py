# -*- coding: utf-8 -*-
"""Entegratör soyutlama katmanı (Faz 4 — e-Dönüşüm).

Gerçek bir GİB entegratörüne (İzibiz / EDM vb.) API anahtarıyla bağlanabilmek için TEK arayüz
tanımlar. Şu an `MockEntegrator` (sandbox) aktiftir; gerçek anahtar geldiğinde bu dosyaya yeni
bir sınıf eklenip config'ten seçilir — çağıran kod (edonusum.py) DEĞİŞMEZ.

Gelen/giden e-belge örnekleri burada üretilir; ham UBL-TR benzeri XML de buradan döner
(gerçek hayatta entegratörün imzalayıp ilettiği/iade ettiği zarfın karşılığı).
"""
import uuid

# Giden belge türleri (1.13)
TUR_LABEL = {"EFatura": "e-Fatura", "EArsiv": "e-Arşiv", "EIrsaliye": "e-İrsaliye"}
TUR_ON_EK = {"EFatura": "EF", "EArsiv": "EA", "EIrsaliye": "EI"}

# GİB belge durumları (CHECK ile sabit — mevcut durum alanı deseniyle tutarlı)
DURUMLAR = ["Taslak", "Gönderildi", "Onaylandı", "Reddedildi", "İptal"]
DURUM_BADGE = {"Taslak": "b-muted", "Gönderildi": "b-info", "Onaylandı": "b-ok",
               "Reddedildi": "b-danger", "İptal": "b-danger"}

# Gelen belge durumları (1.14: Kabul/Red/İtiraz)
GELEN_DURUMLAR = ["Okunmadi", "Kabul", "Red", "Itiraz"]
GELEN_BADGE = {"Okunmadi": "b-muted", "Kabul": "b-ok", "Red": "b-danger", "Itiraz": "b-warn"}


class Entegrator:
    """Soyut entegratör arayüzü — İzibiz/EDM uyumlu uygulama burayı doldurur."""

    ad = "soyut"
    test_modu = True

    def saglik(self):
        raise NotImplementedError

    def gonder(self, belge_xml, tur, senaryo):
        """e-belgeyi imzala + GİB'e ilet → {"ettn":..., "durum":..., "hata": None}"""
        raise NotImplementedError

    def durum_sorgula(self, ettn):
        """GİB'den belge durumunu çek → 'Gönderildi' | 'Onaylandı' | 'Reddedildi' | None"""
        raise NotImplementedError

    def gelen_kutusu(self, tarihten=None):
        """Gelen e-Fatura/e-İrsaliye listesini çek → [ {belge alanları..., "xml": "..."} ]"""
        raise NotImplementedError


class MockEntegrator(Entegrator):
    """Sandbox/test entegratörü — gerçek anahtar gelene kadar geçerli.

    - gonder(): belgeyi 'Gönderildi' yapar, sahte ETN üretir.
    - durum_sorgula(): her zaman 'Onaylandı' döner (mock GİB onayı).
    - gelen_kutusu(): sabit 2 örnek belge döner (Arçelik faturası + Vestel irsaliyesi);
      belge_no sabit olduğundan yeniden çekimde mükerrer kayıt oluşmaz (dedup).
    """

    ad = "Mock (Sandbox)"
    test_modu = True

    def __init__(self, test_modu=True):
        self.test_modu = bool(test_modu)

    def saglik(self):
        return {"ok": True, "saglayici": self.ad, "mod": "sandbox"}

    def gonder(self, belge_xml, tur, senaryo):
        return {"ettn": "ETTN-" + uuid.uuid4().hex[:12].upper(),
                "durum": "Gönderildi", "hata": None}

    def durum_sorgula(self, ettn):
        # F4 — test modu kapalıysa mock GİB gerçekçi davranır (%10 red, %5 hata);
        # test modu açıkken deterministik: hep Onaylandı.
        if self.test_modu:
            return "Onaylandı"
        h = abs(hash(ettn)) % 100
        if h < 10:
            return "Reddedildi"
        if h < 15:
            return "Gönderildi"   # GİB henüz işlemedi
        return "Onaylandı"

    def gelen_kutusu(self, tarihten=None):
        return [self._ornek_fatura(), self._ornek_irsaliye()]

    # --- örnek belgeler (deterministik: dedup belge_no üzerinden yapılır) ---

    @staticmethod
    def _ornek_fatura():
        xml = (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2">\n'
            '  <UUID>9f0c2b10-0001-4b00-8a00-000000000001</UUID>\n'
            '  <ID>GLN-FAT-2026-0001</ID>\n'
            '  <IssueDate>2026-09-05</IssueDate>\n'
            '  <AccountingSupplierParty><PartyName>Arçelik Pazarlama A.Ş.</PartyName>'
            '<PartyTaxScheme><CompanyID>7310002233</CompanyID></PartyTaxScheme></AccountingSupplierParty>\n'
            '  <AccountingCustomerParty><PartyTaxScheme><CompanyID>4810009988</CompanyID>'
            '</PartyTaxScheme></AccountingCustomerParty>\n'
            '  <DocumentCurrencyCode>TRY</DocumentCurrencyCode>\n'
            '  <InvoiceLine>\n'
            '    <SellersItemIdentification><ID>CM-9KG-ARC-004</ID></SellersItemIdentification>\n'
            '    <Item><Name>Arçelik 9kg 1400 Devir Çamaşır Makinesi</Name></Item>\n'
            '    <InvoicedQuantity>1</InvoicedQuantity>\n'
            '    <Price><PriceAmount>15000.00</PriceAmount></Price>\n'
            '    <ClassifiedTaxCategory><Percent>20</Percent></ClassifiedTaxCategory>\n'
            '  </InvoiceLine>\n'
            '  <InvoiceLine>\n'
            '    <SellersItemIdentification><ID>PAR-DRM-VST-007</ID></SellersItemIdentification>\n'
            '    <Item><Name>Vestel Çamaşır Makinesi Kayışı (Yedek Parça)</Name></Item>\n'
            '    <InvoicedQuantity>2</InvoicedQuantity>\n'
            '    <Price><PriceAmount>120.00</PriceAmount></Price>\n'
            '    <ClassifiedTaxCategory><Percent>20</Percent></ClassifiedTaxCategory>\n'
            '  </InvoiceLine>\n'
            '</Invoice>\n'
        )
        return {
            "belge_no": "GLN-FAT-2026-0001", "tur": "EFatura",
            "gonderen_vkn": "7310002233", "gonderen_unvan": "Arçelik Pazarlama A.Ş.",
            "alici_vkn": "4810009988", "belge_tarih": "2026-09-05",
            "tutar": 15240.00, "kdv": 3048.00, "para_birimi": "TRY",
            "aciklama": "Arçelik Pazarlama — mal alım faturası", "xml": xml,
        }

    @staticmethod
    def _ornek_irsaliye():
        xml = (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<DespatchAdvice xmlns="urn:oasis:names:specification:ubl:schema:xsd:DespatchAdvice-2">\n'
            '  <UUID>9f0c2b10-0002-4b00-8a00-000000000002</UUID>\n'
            '  <ID>GLN-IRS-2026-0001</ID>\n'
            '  <IssueDate>2026-09-04</IssueDate>\n'
            '  <DespatchSupplierParty><PartyName>Vestel Bölge Distribütörü A.Ş.</PartyName>'
            '<PartyTaxScheme><CompanyID>7310001122</CompanyID></PartyTaxScheme></DespatchSupplierParty>\n'
            '  <DespatchLine>\n'
            '    <SellersItemIdentification><ID>BUZ-510-VST-003</ID></SellersItemIdentification>\n'
            '    <Item><Name>Vestel 510L No-Frost Buzdolabı</Name></Item>\n'
            '    <DeliveredQuantity>2</DeliveredQuantity>\n'
            '    <Price><PriceAmount>16000.00</PriceAmount></Price>\n'
            '  </DespatchLine>\n'
            '  <DespatchLine>\n'
            '    <SellersItemIdentification><ID>KLM-12000-VST-005</ID></SellersItemIdentification>\n'
            '    <Item><Name>Vestel 12000 BTU Inverter Klima</Name></Item>\n'
            '    <DeliveredQuantity>1</DeliveredQuantity>\n'
            '    <Price><PriceAmount>17000.00</PriceAmount></Price>\n'
            '  </DespatchLine>\n'
            '</DespatchAdvice>\n'
        )
        return {
            "belge_no": "GLN-IRS-2026-0001", "tur": "EIrsaliye",
            "gonderen_vkn": "7310001122", "gonderen_unvan": "Vestel Bölge Distribütörü A.Ş.",
            "alici_vkn": "4810009988", "belge_tarih": "2026-09-04",
            "tutar": 49000.00, "kdv": 0.0, "para_birimi": "TRY",
            "aciklama": "Vestel — bölge sevkiyat irsaliyesi", "xml": xml,
        }


def _entegrator_uret(ayarlar):
    """Meta/entegrator_ayar değerlerine göre entegratör örneği döndürür (varsayılan: Mock)."""
    saglayici = (ayarlar.get("saglayici") or ayarlar.get("entegrator") or "Mock").strip()
    test_modu = str(ayarlar.get("test_modu", "1")) != "0"
    if saglayici in ("", "Mock", "Mock (Sandbox)"):
        return MockEntegrator(test_modu=test_modu)
    # Gerçek sağlayıcı sınıfları buraya eklenecek (ör. IzibizEntegrator(api_anahtari)).
    # API anahtarı olmadan gerçek sağlayıcıya geçilmez — mock'a düşer (güvenli varsayılan).
    return MockEntegrator(test_modu=test_modu)
