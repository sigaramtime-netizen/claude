# -*- coding: utf-8 -*-
"""F5-C — Beyanname Hazırlık Raporları Cilası v1.37.0 e2e testi.

GM D005 direktifindeki 18 senaryo, canlı sunucuya HTTP ile. Kurallar:
- YENİ TABLO YOK (mevcut fatura/yevmiye/gelen_belge/cari_hareket salt-okunur).
- K1: tüm sorgular sirket_id ile süzülür; Şirket B'de A verisi görünmez.
- KDV formülü değişmez (_devreden_satirlar/_gecici_vergi/_nakit_kdv korunur).
- CSV'ler yalnız Admin/Muhasebe (Depo → 403); ekran/API giriş yapmış herkes.
- GİB'e gönderim YOK (hazırlık raporu). F1/F5-A/F5-B bozulmaz.
- MARK="F5CTEST" ile kalıntı bırakılmaz.

Çalıştırma: sunucu 8080'de çalışırken  python3 test_f5c_beyanname.py
"""
import csv
import datetime
import io
import sqlite3

import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
MARK = "F5CTEST"

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print((("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else "")))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris(kadi="admin"):
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": kadi, "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, f"giriş başarısız: {kadi}"
    return s


def gec(s, sid):
    s.post(BASE + "/sirket/gec", data={"sirket_id": str(sid), "next": "/"},
           allow_redirects=False)


def fatura_temizle(fid):
    dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN "
        "(SELECT id FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?)", fid)
    dbx("DELETE FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?", fid)
    dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
    dbx("DELETE FROM stok_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
    dbx("DELETE FROM audit_log WHERE tablo='fatura' AND kayit_id=?", fid)
    dbx("DELETE FROM fatura_kalem WHERE fatura_id=?", fid)
    dbx("DELETE FROM fatura WHERE id=?", fid)


def temizle():
    for fid in [r["id"] for r in db("SELECT id FROM fatura WHERE aciklama LIKE ?", f"%{MARK}%")]:
        fatura_temizle(fid)
    for sid in [r["id"] for r in db("SELECT id FROM stok_kart WHERE kod LIKE ?", f"{MARK}%")]:
        dbx("DELETE FROM stok_hareket WHERE stok_id=?", sid)
        dbx("DELETE FROM audit_log WHERE tablo='stok_kart' AND kayit_id=?", sid)
        dbx("DELETE FROM stok_kart WHERE id=?", sid)
    for s2 in [r["id"] for r in db("SELECT id FROM sirket WHERE kod=?", f"{MARK}B")]:
        dbx("DELETE FROM kullanici_sirket WHERE sirket_id=?", s2)
        dbx("DELETE FROM entegrator_ayar WHERE sirket_id=?", s2)
        dbx("DELETE FROM sirket WHERE id=?", s2)


def fatura_kaydet(s, stok_id, fiyat, kdv="20"):
    satir = [("k_stok_id", stok_id), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
             ("k_birim", "Adet"), ("k_goruntu_ad", ""), ("k_miktar", "1"),
             ("k_birim_fiyat", fiyat), ("k_iskonto", "0"), ("k_kdv", kdv)]
    r = s.post(BASE + "/fatura/yeni",
               data=[("tip", "Satis"), ("cari_id", "1"),
                     ("tarih", datetime.date.today().isoformat()), ("para_birimi", "TRY"),
                     ("aciklama", MARK + " kdv testi"),
                     ("action", "kaydet")] + satir, allow_redirects=False)
    loc = (r.headers.get("Location") or "").rstrip("/")
    return int(loc.split("/")[-1])


def onayla(s, fid):
    s.post(BASE + f"/fatura/{fid}/durum", data={"durum": "Onaylandı"},
           allow_redirects=False)


temizle()

# ============================================================================
print("=" * 72)
print("F5-C v1.37.0 — 18 kontrol (canlı sunucuya HTTP)")
print("=" * 72)
admin = giris("admin")
bugun = datetime.date.today()
ay = f"{bugun.year:04d}-{bugun.month:02d}"
ay_no = bugun.month
cari_once = db1("SELECT COUNT(*) c FROM cari_hareket")["c"]
yev_once = db1("SELECT COUNT(*) c FROM yevmiye")["c"]

# 1) test_kpi_kartlar ---------------------------------------------------------
html = admin.get(BASE + f"/beyanname?ay={ay}").text
kartlar = ["Hesaplanan KDV", "İndirilecek KDV", "Ödenecek KDV", "Devreden KDV"]
check("1. test_kpi_kartlar", all(k in html for k in kartlar),
      f"{sum(k in html for k in kartlar)}/4 kart etiketi")

# 2) test_grafik --------------------------------------------------------------
check("2. test_grafik", "<svg" in html, "KDV oran dağılımı bar grafiği (inline SVG)")

# 3) test_api_ozet ------------------------------------------------------------
d = admin.get(BASE + f"/api/beyanname/ozet?ay={ay}").json()
check("3. test_api_ozet",
      all(k in d for k in ("hesaplanan", "indirilecek", "odenecek", "devreden_tablo"))
      and len(d["devreden_tablo"]) == 12,
      f"devreden_tablo={len(d.get('devreden_tablo', []))} satır")

# 4) test_api_k1 --------------------------------------------------------------
dbx("INSERT INTO sirket(kod, unvan, aktif) VALUES(?,?,1)", f"{MARK}B", f"{MARK} İkinci Şirket")
s2 = db1("SELECT id FROM sirket WHERE kod=?", f"{MARK}B")["id"]
dbx("INSERT OR IGNORE INTO kullanici_sirket(kullanici_id, sirket_id) "
    "SELECT id, ? FROM kullanici WHERE kullanici_adi='admin'", s2)
gec(admin, s2)
db_b = admin.get(BASE + f"/api/beyanname/ozet?ay={ay}").json()
gec(admin, 1)
check("4. test_api_k1", db_b["hesaplanan"] == 0 and db_b["indirilecek"] == 0,
      f"B'de hesaplanan={db_b['hesaplanan']} (A'nınki görünmemeli)")

# 5) test_devreden_dogruluk ---------------------------------------------------
d = admin.get(BASE + f"/api/beyanname/ozet?ay={ay}").json()
aktif_satir = d["devreden_tablo"][ay_no - 1]
check("5. test_devreden_dogruluk",
      abs(d["odenecek"] - aktif_satir["odenecek"]) < 0.01,
      f"API odenecek={d['odenecek']} == tablo[{ay_no}]={aktif_satir['odenecek']}")

# 6) test_gecici_vergi --------------------------------------------------------
gv = d.get("gecici_vergi") or {}
check("6. test_gecici_vergi", "ceyrek" in gv and "odenecek" in gv and "matrah" in gv,
      f"ceyrek={gv.get('ceyrek')}, odenecek={gv.get('odenecek')}")

# 7) test_nakit ---------------------------------------------------------------
nk = d.get("nakit") or {}
check("7. test_nakit", "odenecek" in nk, f"nakit.odenecek={nk.get('odenecek')}")

# 8) test_eslesmemis_kart -----------------------------------------------------
html = admin.get(BASE + f"/beyanname?ay={ay}").text
check("8. test_eslesmemis_kart", "eşleşmemiş" in html,
      f"eslesmemis_adet={d.get('eslesmemis_adet')} rozeti HTML'de")

# 9) test_kdv_csv -------------------------------------------------------------
r = admin.get(BASE + "/beyanname/kdv/csv?yil=2026")
lines = r.text.replace("\ufeff", "").splitlines()
check("9. test_kdv_csv",
      r.status_code == 200 and "text/csv" in r.headers.get("Content-Type", "")
      and lines[0].startswith("Ay;Hesaplanan") and len(lines) >= 13,
      f"CT={r.headers.get('Content-Type')}, satır={len(lines)} (12 ay + başlık)")

# 10) test_kdv_csv_k1 ----------------------------------------------------------
gec(admin, s2)
r_b = admin.get(BASE + "/beyanname/kdv/csv?yil=2026")
gec(admin, 1)
rows_b = list(csv.reader(io.StringIO(r_b.text.replace("\ufeff", "")), delimiter=";"))
toplam_b = sum(float(row[1]) for row in rows_b[1:] if len(row) > 1)
check("10. test_kdv_csv_k1", toplam_b == 0.0,
      f"B CSV hesaplanan toplamı={toplam_b} (A verisi yok)")

# 11) test_denetim_korundu -----------------------------------------------------
r_d = admin.get(BASE + f"/beyanname/denetim?ay={ay}")
check("11. test_denetim_korundu", r_d.status_code == 200,
      f"/beyanname/denetim → {r_d.status_code}")

# 12) test_denetim_csv_korundu -------------------------------------------------
r_dc = admin.get(BASE + f"/beyanname/denetim/csv?ay={ay}")
check("12. test_denetim_csv_korundu",
      r_dc.status_code == 200 and "text/csv" in r_dc.headers.get("Content-Type", "")
      and r_dc.text.replace("\ufeff", "").startswith("Tip;Belge No"),
      f"CT={r_dc.headers.get('Content-Type')}")

# 13) test_yeni_fatura_kdv_yansidi ---------------------------------------------
dbx("INSERT INTO stok_kart(kod, ad, birim, kdv_orani, otv_orani, alis_fiyat, satis_fiyat, "
    "para_birimi, iskonto_orani, kritik_stok, seri_lot_takibi, varyant_takibi, aktif, "
    "created_at, tip, garanti_suresi_ay, sirket_id) "
    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now','localtime'),?,?,1)",
    f"{MARK}-STK-001", f"{MARK} Test Ürünü", "Adet", 20, 0, 700, 1000, "TRY", 0, 0, 0, 0, 1,
    "Urun", 0)
stok_id = db1("SELECT id FROM stok_kart WHERE kod=?", f"{MARK}-STK-001")["id"]
once = admin.get(BASE + f"/api/beyanname/ozet?ay={ay}").json()["hesaplanan"]
fid = fatura_kaydet(admin, str(stok_id), "1000", "20")
onayla(admin, fid)
sonra = admin.get(BASE + f"/api/beyanname/ozet?ay={ay}").json()["hesaplanan"]
check("13. test_yeni_fatura_kdv_yansidi", sonra - once >= 199.99,
      f"hesaplanan {once} → {sonra} (KDV 200 beklenir)")

# 14) test_fatura_sil_kdv_dustu ------------------------------------------------
fatura_temizle(fid)
geri = admin.get(BASE + f"/api/beyanname/ozet?ay={ay}").json()["hesaplanan"]
check("14. test_fatura_sil_kdv_dustu", abs(geri - once) < 0.01,
      f"hesaplanan {sonra} → {geri} (başlangıç {once})")

# 15) test_yetki_csv -----------------------------------------------------------
depo = giris("depo")
r1 = depo.get(BASE + "/beyanname/kdv/csv?yil=2026", allow_redirects=False)
r2 = depo.get(BASE + f"/beyanname/denetim/csv?ay={ay}", allow_redirects=False)
check("15. test_yetki_csv", r1.status_code == 403 and r2.status_code == 403,
      f"kdv/csv={r1.status_code}, denetim/csv={r2.status_code}")

# 16) test_f1_korundu -----------------------------------------------------------
cari_sonra = db1("SELECT COUNT(*) c FROM cari_hareket")["c"]
yev_sonra = db1("SELECT COUNT(*) c FROM yevmiye")["c"]
check("16. test_f1_korundu", cari_once == cari_sonra and yev_once == yev_sonra,
      f"cari_hareket {cari_once}→{cari_sonra}, yevmiye {yev_once}→{yev_sonra}")

# 17) test_f5a_f5b_korundu -------------------------------------------------------
r_b = admin.get(BASE + "/finansal/butce", allow_redirects=False)
r_d2 = admin.get(BASE + "/api/demirbas/ozet", allow_redirects=False)
check("17. test_f5a_f5b_korundu", r_b.status_code == 200 and r_d2.status_code == 200,
      f"/finansal/butce={r_b.status_code}, /api/demirbas/ozet={r_d2.status_code}")

# ---- temizlik + 18) kalıntı kontrolü ------------------------------------------
dbx("DELETE FROM stok_hareket WHERE stok_id=?", stok_id)
dbx("DELETE FROM audit_log WHERE tablo='stok_kart' AND kayit_id=?", stok_id)
dbx("DELETE FROM stok_kart WHERE id=?", stok_id)
dbx("DELETE FROM kullanici_sirket WHERE sirket_id=?", s2)
dbx("DELETE FROM entegrator_ayar WHERE sirket_id=?", s2)
dbx("DELETE FROM sirket WHERE id=?", s2)

fk_check = db("PRAGMA foreign_key_check")
kalinti = {
    "fatura": db("SELECT COUNT(*) c FROM fatura WHERE aciklama LIKE ?", f"%{MARK}%")[0]["c"],
    "stok": db("SELECT COUNT(*) c FROM stok_kart WHERE kod LIKE ?", f"{MARK}%")[0]["c"],
    "sirket": db("SELECT COUNT(*) c FROM sirket WHERE kod=?", f"{MARK}B")[0]["c"],
}
temiz_mi = len(fk_check) == 0 and all(v == 0 for v in kalinti.values())
check("18. test_fk_kalinti", temiz_mi,
      f"foreign_key_check={len(fk_check)} satır, kalıntı={kalinti}")

print("=" * 72)
print(f"SONUÇ: {len(ok)}/18 geçti, {len(fail)} başarısız")
if fail:
    print("BAŞARISIZ:", fail)
    raise SystemExit(1)
print("TÜM KONTROLLER GEÇTİ ✅")
