# -*- coding: utf-8 -*-
"""İstek 3 — Çoklu Şirket testleri (Adım 1: DDL/migrasyon + Adım 2: oturum & geçiş).

Çalıştırma: sunucu 8080'de çalışırken  python3 test_coklu_sirket.py
"""
import sqlite3
import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"


def q1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def db_exec(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else ""))


def giris(kadi):
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": kadi, "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, f"giriş başarısız: {kadi}"
    return s


def aktif_sirket():
    return q1("SELECT sirket_id FROM sessionler ORDER BY rowid DESC LIMIT 1")["sirket_id"]


# ============ Adım 1: DDL/migrasyon değişmezleri ============
print("=" * 70)
print("ADIM 1 — DDL / migrasyon")
print("=" * 70)
tabs = {r[0] for r in sqlite3.connect(DB).execute("SELECT name FROM sqlite_master WHERE type='table'")}
check("1.1 sirket tablosu var", "sirket" in tabs)
check("1.2 kullanici_sirket tablosu var", "kullanici_sirket" in tabs)
check("1.3 firma tablosu kaldırıldı (→ sirket)", "firma" not in tabs)
check("1.4 sirket.id=1 firma verisini taşıyor",
      q1("SELECT vergi_no FROM sirket WHERE id=1")["vergi_no"] == "4810001234")
check("1.5 tüm kullanıcılar 1. şirkete üye (N-N backfill)",
      q1("SELECT COUNT(*) c FROM kullanici_sirket WHERE sirket_id=1")["c"]
      == q1("SELECT COUNT(*) c FROM kullanici")["c"])

uniq = {"teklif": "teklif_no", "fatura": "fatura_no", "cari_kart": "kod",
        "stok_kart": "kod", "yevmiye": "fis_no", "hesap": "kod"}
c = sqlite3.connect(DB)
bad = []
for t, ucol in uniq.items():
    sql = c.execute("SELECT sql FROM sqlite_master WHERE name=?", (t,)).fetchone()[0]
    if f"UNIQUE(sirket_id, {ucol})" not in sql:
        bad.append(t)
c.close()
check("1.6 composite UNIQUE(sirket_id, kolon) (örneklem 6 tablo)", not bad, str(bad))
check("1.7 integrity_check", q1("PRAGMA integrity_check")[0] == "ok")

# ============ Adım 2: oturum & geçiş ============
print("\n" + "=" * 70)
print("ADIM 2 — oturum & şirket geçişi")
print("=" * 70)
admin = giris("admin")
check("2.1 girişte oturum sirket_id=1 atandı", aktif_sirket() == 1)
check("2.2 ana sayfa aktif şirket adını gösteriyor",
      "Brn Teknoloji" in admin.get(BASE + "/").text)

# 2. şirket + admin üyeliği
db_exec("INSERT INTO sirket(kod, unvan, aktif) VALUES('IKI','İkinci Şirket A.Ş.',1)")
s2 = q1("SELECT id FROM sirket WHERE kod='IKI'")["id"]
db_exec("INSERT OR IGNORE INTO kullanici_sirket(kullanici_id, sirket_id) "
        "SELECT id, ? FROM kullanici WHERE kullanici_adi='admin'", s2)

admin.post(BASE + "/sirket/gec", data={"sirket_id": str(s2), "next": "/"}, allow_redirects=False)
check("2.3 /sirket/gec oturumu 2. şirkete taşıdı", aktif_sirket() == s2)
r = admin.get(BASE + "/")
check("2.4 geçiş sonrası aktif şirket adı güncellendi", "İkinci Şirket A.Ş." in r.text)
check("2.5 üst bara şirket seçici geldi (2+ şirket)", 'name="sirket_id"' in r.text)

# üye olmayan şirkete geçiş engeli (muhasebe yalnız 1. şirkette)
db_exec("INSERT INTO sirket(kod, unvan, aktif) VALUES('UC','Yetkisiz Şirket',1)")
s3 = q1("SELECT id FROM sirket WHERE kod='UC'")["id"]
m = giris("muhasebe")
mtok = q1("SELECT token FROM sessionler ORDER BY rowid DESC LIMIT 1")["token"]
m.post(BASE + "/sirket/gec", data={"sirket_id": str(s3), "next": "/"}, allow_redirects=False)
check("2.6 üye olmayan şirkete geçiş engellendi",
      q1("SELECT sirket_id FROM sessionler WHERE token=?", mtok)["sirket_id"] != s3)

# muhasebe yalnız kendi şirketini görür (2. şirkete üye değil)
r = m.get(BASE + "/")
check("2.7 muhasebe üst barda yalnız yetkili şirketleri görür", "İkinci Şirket A.Ş." not in r.text)

# ayarlar/firma aktif şirkete yazar
r = admin.get(BASE + "/ayarlar/firma")
check("2.8 /ayarlar/firma aktif şirketi gösteriyor", "İkinci Şirket A.Ş." in r.text)
admin.post(BASE + "/ayarlar/firma", data={"unvan": "İkinci Şirket A.Ş.", "kisa_ad": "İkinci",
            "vergi_dairesi": "İstanbul", "vergi_no": "9990009990", "adres": "X", "telefon": "Y",
            "email": "z@z.com", "logo": ""}, allow_redirects=False)
check("2.9 /ayarlar/firma sirket tablosuna yazıyor",
      q1("SELECT vergi_no FROM sirket WHERE id=?", s2)["vergi_no"] == "9990009990")

# temizlik
db_exec("DELETE FROM kullanici_sirket WHERE sirket_id IN (?,?)", s2, s3)
db_exec("DELETE FROM sirket WHERE id IN (?,?)", s2, s3)
db_exec("DELETE FROM sessionler WHERE token=?", mtok)

print(f"\nSONUÇ: {len(ok)} başarılı / {len(fail)} başarısız")
if fail:
    print("BAŞARISIZ:", fail)
    raise SystemExit(1)
print("ÇOKLU ŞİRKET (ADIM 1+2) TESTLERİ GEÇTİ ✅")
