# -*- coding: utf-8 -*-
"""Seri No-Garanti modülü (Faz 3 — 1.16).

- `stok_seri` (Faz 1) üzerine garanti başlangıç/bitiş tarihi ekler (migrasyon).
- Seri no girildiğinde garanti durumu + satış/servis geçmişi görünür (Servis modülüyle entegre).
- Garanti bitişine ≤30 gün kalan / süresi dolan seriler için uyarı (bildirim + liste rozeti).
"""
import datetime

import db
from core import route, render_template, redirect, flash, audit

GARANTI_WRITE = ("Admin", "Muhasebe", "Servis")


def _ay_ekle(tarih, ay):
    """Tarihe ay ekle (garanti bitiş hesabı)."""
    try:
        d = datetime.date.fromisoformat(str(tarih)[:10])
    except (ValueError, TypeError):
        return None
    ay = int(ay or 0)
    m = d.month - 1 + ay
    y = d.year + m // 12
    m = m % 12 + 1
    gunler = [31, 29 if (y % 4 == 0 and y % 100 != 0) or y % 400 == 0 else 28,
              31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    gun = min(d.day, gunler[m - 1])
    return datetime.date(y, m, gun).isoformat()


def _garanti_durumu(bit, bugun):
    """(durum, kalan_gun): Aktif / Yaklaşıyor / Doldu / Yok."""
    if not bit:
        return "Yok", None
    if bit < bugun:
        return "Doldu", None
    kalan = (datetime.date.fromisoformat(bit) - datetime.date.fromisoformat(bugun)).days
    return ("Yaklaşıyor", kalan) if kalan <= 30 else ("Aktif", kalan)


def _seri_satir(conn, r, bugun):
    """stok_seri satırı -> garanti bilgileriyle zenginleştirilmiş dict."""
    r = dict(r)
    bas = r["garanti_baslangic"]
    bit = r["garanti_bitis"]
    ay = r["garanti_suresi_ay"] or 24
    if not bit and r["durum"] == "Satıldı":
        # satılmış ama garanti tarihi yazılmamış → satış tarihinden türet
        bas = (r["cikis_tarihi"] or r["giris_tarihi"] or "")[:10] or None
        if bas:
            bit = _ay_ekle(bas, ay)
    r["g_bas"] = bas
    r["g_bit"] = bit
    r["g_durum"], r["g_kalan"] = _garanti_durumu(bit, bugun)
    return r


@route(r"/garanti", roles=())
def garanti_liste(req):
    conn = db.get_conn()
    bugun = datetime.date.today().isoformat()
    where, params = ["s.sirket_id = ?"], [db.sirket_id(req)]
    q = (req.q("q") or "").strip()
    if q:
        where.append("(s.seri_no LIKE ? OR k.ad LIKE ? OR k.kod LIKE ?)")
        params += [f"%{q}%", f"%{q}%", f"%{q}%"]
    rows = conn.execute(
        "SELECT s.*, k.kod AS stok_kod, k.ad AS stok_ad, k.garanti_suresi_ay, "
        "m.ad AS marka_ad FROM stok_seri s "
        "JOIN stok_kart k ON k.id=s.stok_id LEFT JOIN marka m ON m.id=k.marka_id "
        "WHERE " + " AND ".join(where) + " ORDER BY s.seri_no",
        params,
    ).fetchall()
    sonuc = [_seri_satir(conn, r, bugun) for r in rows]
    filtre = req.q("filtre")
    if filtre in ("Aktif", "Yaklaşıyor", "Doldu", "Yok"):
        sonuc = [s for s in sonuc if s["g_durum"] == filtre]
    adet = {"Aktif": 0, "Yaklaşıyor": 0, "Doldu": 0, "Yok": 0}
    for s in sonuc:
        adet[s["g_durum"]] += 1
    conn.close()
    return render_template("garanti/liste.html", rows=sonuc, q=q, filtre=filtre, adet=adet,
                           bugun=bugun, durum_badge={"Aktif": "b-ok", "Yaklaşıyor": "b-info",
                                                     "Doldu": "b-danger", "Yok": "b-muted"})


@route(r"/garanti/(?P<sid>\d+)", roles=())
def garanti_detay(req, sid):
    conn = db.get_conn()
    bugun = datetime.date.today().isoformat()
    r = conn.execute(
        "SELECT s.*, k.kod AS stok_kod, k.ad AS stok_ad, k.garanti_suresi_ay, "
        "m.ad AS marka_ad FROM stok_seri s JOIN stok_kart k ON k.id=s.stok_id "
        "LEFT JOIN marka m ON m.id=k.marka_id WHERE s.id=? AND s.sirket_id=?",
        (int(sid), db.sirket_id(req))).fetchone()
    if not r:
        conn.close()
        return redirect("/garanti")
    satir = _seri_satir(conn, r, bugun)
    # satış geçmişi: bu seri numarasıyla eşleşen stok hareketleri (çıkış) + ilgili fatura
    satis = conn.execute(
        "SELECT h.*, k.ad AS stok_ad FROM stok_hareket h JOIN stok_kart k ON k.id=h.stok_id "
        "WHERE h.seri_nolar LIKE ? AND h.sirket_id=? ORDER BY h.id DESC LIMIT 10",
        (f"%{satir['seri_no']}%", db.sirket_id(req))).fetchall()
    # servis geçmişi (seri no ile eşleşen servis kayıtları)
    servisler = conn.execute(
        "SELECT v.*, c.unvan AS cari_unvan FROM servis_kayit v LEFT JOIN cari_kart c ON c.id=v.cari_id "
        "WHERE v.seri_no=? AND v.sirket_id=? ORDER BY v.id DESC",
        (satir["seri_no"], db.sirket_id(req))).fetchall()
    stoklar = conn.execute("SELECT id, ad FROM stok_kart WHERE aktif=1 AND sirket_id=? ORDER BY ad",
                           (db.sirket_id(req),)).fetchall()
    conn.close()
    return render_template("garanti/detay.html", s=satir, satis=satis, servisler=servisler,
                           stoklar=stoklar, bugun=bugun)


@route(r"/garanti/(?P<sid>\d+)/guncelle", methods=("POST",), roles=GARANTI_WRITE)
def garanti_guncelle(req, sid):
    conn = db.get_conn()
    r = conn.execute("SELECT * FROM stok_seri WHERE id=? AND sirket_id=?",
                     (int(sid), db.sirket_id(req))).fetchone()
    if not r:
        conn.close()
        return redirect("/garanti")
    bas = (req.form.get("garanti_baslangic") or "").strip() or None
    bit = (req.form.get("garanti_bitis") or "").strip() or None
    ay = (req.form.get("garanti_suresi_ay") or "").strip()
    if bas and not bit and ay.isdigit():
        bit = _ay_ekle(bas, int(ay))
    conn.execute("UPDATE stok_seri SET garanti_baslangic=?, garanti_bitis=? WHERE id=?",
                 (bas, bit, int(sid)))
    if bas and ay.isdigit():
        conn.execute("UPDATE stok_kart SET garanti_suresi_ay=? WHERE id=?",
                     (int(ay), r["stok_id"]))
    conn.commit()
    audit(req, "stok_seri", int(sid), "garanti_guncelle", {"bas": bas, "bit": bit})
    conn.close()
    flash(req, "Garanti bilgileri güncellendi.", "ok")
    return redirect(f"/garanti/{sid}")


@route(r"/garanti/yeni", methods=("GET", "POST"), roles=GARANTI_WRITE)
def garanti_yeni(req):
    conn = db.get_conn()
    if req.method == "POST":
        stok_id = req.form.get("stok_id")
        seri_no = (req.form.get("seri_no") or "").strip()
        bas = (req.form.get("garanti_baslangic") or "").strip() or datetime.date.today().isoformat()
        ay = (req.form.get("garanti_suresi_ay") or "").strip() or "24"
        if not stok_id or not seri_no:
            flash(req, "Ürün ve seri no zorunludur.", "danger")
            conn.close()
            return redirect("/garanti/yeni")
        var = conn.execute("SELECT id FROM stok_seri WHERE stok_id=? AND seri_no=? AND sirket_id=?",
                           (int(stok_id), seri_no, db.sirket_id(req))).fetchone()
        if var:
            flash(req, "Bu seri no zaten kayıtlı.", "danger")
            conn.close()
            return redirect("/garanti/yeni")
        bit = _ay_ekle(bas, int(ay))
        cur = conn.execute(
            "INSERT INTO stok_seri(stok_id, varyant_id, seri_no, durum, giris_tarihi, "
            "garanti_baslangic, garanti_bitis, sirket_id) VALUES(?,0,?,'Satıldı',date('now','localtime'),?,?,?)",
            (int(stok_id), seri_no, bas, bit, db.sirket_id(req)))
        conn.commit()
        audit(req, "stok_seri", cur.lastrowid, "garanti_yeni", {"seri_no": seri_no, "bit": bit})
        conn.close()
        flash(req, f"{seri_no} garanti kaydı eklendi (bitiş: {bit}).", "ok")
        return redirect("/garanti")
    stoklar = conn.execute("SELECT id, ad, garanti_suresi_ay FROM stok_kart WHERE aktif=1 AND sirket_id=? ORDER BY ad",
                           (db.sirket_id(req),)).fetchall()
    conn.close()
    return render_template("garanti/form.html", stoklar=stoklar,
                           bugun=datetime.date.today().isoformat())
