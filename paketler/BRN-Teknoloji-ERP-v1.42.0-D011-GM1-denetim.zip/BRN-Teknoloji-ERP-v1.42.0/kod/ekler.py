# -*- coding: utf-8 -*-
"""Ek dosya (attachment) altyapısı — tek tabloyla tüm modüllere hizmet eder.

`ek_dosya` tablosu Notlar'daki ilişkisel desenle birebir aynı çalışır:
    ilgili_modul + ilgili_kayit_id → herhangi bir kayda (Fatura, İrsaliye,
    Çek/Senet, Teklif, Sipariş, Cari …) dosya eklenebilir.

Desteklenen formatlar: jpg / jpeg / png / pdf. Bir kayda birden fazla dosya.
"""
import datetime
import os
import re
import secrets
import urllib.parse

import db
from config import UPLOAD_DIR
from core import route, Response, redirect, flash, audit

EK_WRITE = ("Admin", "Muhasebe", "Satis")


def ek_temizle(conn, modul, kayit_id):
    """Bir belge silinirken bağlı ek dosya kayıtlarını ve fiziksel dosyalarını temizler.

    (Yetim `ek_dosya` satırı / kayıp dosya kalmasın diye belge silme rotalarından çağrılır.)"""
    rows = conn.execute(
        "SELECT id, dosya_yolu FROM ek_dosya WHERE ilgili_modul=? AND ilgili_kayit_id=?",
        (modul, kayit_id),
    ).fetchall()
    for r in rows:
        yol = os.path.join(UPLOAD_DIR, r["dosya_yolu"])
        if os.path.isfile(yol):
            try:
                os.remove(yol)
            except OSError:
                pass
        conn.execute("DELETE FROM ek_dosya WHERE id=?", (r["id"],))

ALLOWED_EXT = {".jpg": "image/jpeg", ".jpeg": "image/jpeg",
               ".png": "image/png", ".pdf": "application/pdf"}
MAX_BYTES = 15 * 1024 * 1024  # 15 MB

MODULE_URL = {
    "Fatura": "/fatura",
    "Irsaliye": "/irsaliye",
    "CekSenet": "/cek_senet",
    "Teklif": "/teklif",
    "Siparis": "/siparis",
    "Cari": "/cari",
}

MODULE_LABEL = {
    "Fatura": "Fatura", "Irsaliye": "İrsaliye", "CekSenet": "Çek/Senet",
    "Teklif": "Teklif", "Siparis": "Sipariş", "Cari": "Cari",
}


def _güvenli_ad(ad):
    ad = os.path.basename((ad or "").replace("\\", "/"))
    ad = re.sub(r"[^\w.\-]+", "_", ad, flags=re.UNICODE)
    return ad[:120] or "dosya"


def ekler_for(conn, modul, kayit_id):
    return conn.execute(
        "SELECT e.*, u.kullanici_adi AS yukleyen FROM ek_dosya e "
        "LEFT JOIN kullanici u ON u.id=e.yukleyen_kullanici "
        "WHERE e.ilgili_modul=? AND e.ilgili_kayit_id=? ORDER BY e.id DESC",
        (modul, kayit_id),
    ).fetchall()


def _servis_icerik(path):
    ext = os.path.splitext(path)[1].lower()
    ctype = ALLOWED_EXT.get(ext, "application/octet-stream")
    inline = ctype.startswith("image/") or ctype == "application/pdf"
    disp = "inline" if inline else "attachment"
    return ctype, disp


@route(r"/ek/yukle", methods=("POST",), roles=EK_WRITE)
def ek_yukle(req):
    modul = req.form.get("modul") or ""
    kayit_id = req.form.get("kayit_id") or ""
    geri = req.form.get("geri") or ""
    if modul not in MODULE_URL or not kayit_id.isdigit():
        flash(req, "Geçersiz hedef kayıt.", "danger")
        return redirect(geri or "/")
    kayit_id = int(kayit_id)
    conn = db.get_conn()
    kaydedilen = 0
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    for f in req.files:
        ext = os.path.splitext(f["filename"])[1].lower()
        if ext not in ALLOWED_EXT:
            flash(req, f"'{f['filename']}' desteklenmeyen format (jpg/png/pdf).", "danger")
            continue
        if len(f["data"]) > MAX_BYTES:
            flash(req, f"'{f['filename']}' çok büyük (en fazla 15 MB).", "danger")
            continue
        if not f["data"]:
            continue
        yeni_ad = f"{modul}_{kayit_id}_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}_{secrets.token_hex(4)}{ext}"
        yol = os.path.join(UPLOAD_DIR, yeni_ad)
        with open(yol, "wb") as fh:
            fh.write(f["data"])
        conn.execute(
            "INSERT INTO ek_dosya(ilgili_modul, ilgili_kayit_id, dosya_adi, dosya_yolu, "
            "dosya_tipi, boyut, yukleyen_kullanici, sirket_id) VALUES(?,?,?,?,?,?,?,?)",
            (modul, kayit_id, _güvenli_ad(f["filename"]), yeni_ad, ext[1:], len(f["data"]),
             req.user["id"], db.sirket_id(req)),
        )
        kaydedilen += 1
    conn.commit()
    audit(req, "ek_dosya", kayit_id, "yukle",
          {"modul": modul, "adet": kaydedilen})
    conn.close()
    if kaydedilen:
        flash(req, f"{kaydedilen} dosya eklendi.", "ok")
    return redirect(geri or (MODULE_URL[modul] + "/" + str(kayit_id)))


@route(r"/ek/(?P<eid>\d+)", roles=())
def ek_indir(req, eid):
    conn = db.get_conn()
    r = conn.execute("SELECT * FROM ek_dosya WHERE id=? AND sirket_id=?",
                     (int(eid), db.sirket_id(req))).fetchone()
    conn.close()
    if not r:
        return Response("Dosya bulunamadı.", "404 Not Found")
    yol = os.path.join(UPLOAD_DIR, r["dosya_yolu"])
    if not os.path.isfile(yol):
        return Response("Dosya diskte bulunamadı.", "404 Not Found")
    with open(yol, "rb") as f:
        data = f.read()
    ctype, disp = _servis_icerik(yol)
    ad = r["dosya_adi"].replace('"', '')
    return Response(data, "200 OK", [
        ("Content-Type", ctype),
        ("Content-Length", str(len(data))),
        ("Content-Disposition", f'{disp}; filename="{ad}"'),
    ])


@route(r"/ek/(?P<eid>\d+)/sil", methods=("POST",), roles=EK_WRITE)
def ek_sil(req, eid):
    geri = req.form.get("geri") or "/"
    conn = db.get_conn()
    r = conn.execute("SELECT * FROM ek_dosya WHERE id=? AND sirket_id=?",
                     (int(eid), db.sirket_id(req))).fetchone()
    if r:
        yol = os.path.join(UPLOAD_DIR, r["dosya_yolu"])
        if os.path.isfile(yol):
            try:
                os.remove(yol)
            except OSError:
                pass
        conn.execute("DELETE FROM ek_dosya WHERE id=?", (int(eid),))
        conn.commit()
        audit(req, "ek_dosya", int(eid), "sil", {"dosya_adi": r["dosya_adi"]})
    conn.close()
    flash(req, "Dosya silindi.", "ok")
    return redirect(geri)


def register():
    return "ekler"
