# -*- coding: utf-8 -*-
"""İstek 3 — ek kanıt (1/3): Kasa / Banka + Genel Muhasebe izolasyonu (e2e).

Kapsam:
  1. A şirketinde kasa + banka + hareket (açılış) → yevmiye fişi A'ya damgalanır; A mizanı dengeli.
  2. B şirketinde A'nın kasa/banka listeleri BOŞ; banka ekstresi doğrudan erişimi ENGELLİ (302).
  3. B'den A'nın kasa/banka hesabına hareket yazma ENGELLENİR (403 — çapraz şirket hedef-ID koruması).
  4. B'nin mizanı A'nın fişlerinden bağımsız (100/102 sıfır); B kendi hareketini yazınca kendi mizanı dengelenir.
  5. Hesap planı her şirkette 27 kayıt.
  6. Temizlik (test verisi kaldırılır, A mizanı eski haline döner).

Çalıştırma: sunucu 8080'de çalışırken  python3 test_izolasyon_mali_e2e.py
"""
import datetime
import sqlite3
import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
KOD = "ISOM"
BUGUN = datetime.date.today().isoformat()

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else ""))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris():
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": "admin", "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, "giriş başarısız"
    return s


def aktif_sirket():
    return db1("SELECT sirket_id FROM sessionler ORDER BY rowid DESC LIMIT 1")["sirket_id"]


def mizan(sid):
    rows = db("""SELECT h.kod, COALESCE(t.b,0) b, COALESCE(t.a,0) a FROM hesap h
                 LEFT JOIN (SELECT k.hesap_id, SUM(k.borc) b, SUM(k.alacak) a
                            FROM yevmiye_kalem k JOIN yevmiye y ON y.id=k.yevmiye_id
                            WHERE y.durum='Onaylandı' AND y.sirket_id=?
                            GROUP BY k.hesap_id) t ON t.hesap_id=h.id
                 WHERE h.aktif=1 AND h.sirket_id=? ORDER BY h.kod""", sid, sid)
    return {r["kod"]: round(r["b"] - r["a"], 2) for r in rows}


def mizan_dengesi(sid):
    r = db("""SELECT COALESCE(SUM(k.borc),0) b, COALESCE(SUM(k.alacak),0) a
              FROM yevmiye_kalem k JOIN yevmiye y ON y.id=k.yevmiye_id
              WHERE y.durum='Onaylandı' AND y.sirket_id=?""", sid)[0]
    return round(r["b"], 2), round(r["a"], 2)


def main():
    admin = giris()
    # --- 0. Kalıntı temizliği ---
    eski = db1("SELECT id FROM sirket WHERE kod=?", KOD)
    if eski:
        sid = eski["id"]
        for t in ("kasa_hareket", "banka_hareket", "kasa", "banka_hesap", "yevmiye_kalem",
                  "yevmiye", "hesap", "demirbas_kategori", "depo", "kullanici_sirket"):
            dbx(f"DELETE FROM {t} WHERE sirket_id=?", sid)
        dbx("DELETE FROM sirket WHERE id=?", sid)
    dbx("DELETE FROM kasa WHERE kod IN ('ISO-KAS-A','ISO-KAS-B')")
    dbx("DELETE FROM banka_hesap WHERE kod='ISO-BNK-A'")

    # --- 1. Şirket B kur ---
    admin.post(BASE + "/ayarlar/sirketler",
               data={"kod": KOD, "unvan": "İzolasyon Mali A.Ş."}, allow_redirects=False)
    b_id = db1("SELECT id FROM sirket WHERE kod=?", KOD)["id"]

    # --- 2. A (şirket 1) — kasa + banka + hareket ---
    admin.post(BASE + "/sirket/gec", data={"sirket_id": "1", "next": "/"}, allow_redirects=False)
    onceki_100 = mizan(1).get("100", 0.0)
    onceki_102 = mizan(1).get("102", 0.0)
    admin.post(BASE + "/kasa/yeni", data={"ad": "ISO Kasa A", "kod": "ISO-KAS-A"},
               allow_redirects=False)
    admin.post(BASE + "/banka/yeni", data={"ad": "ISO Banka A", "kod": "ISO-BNK-A"},
               allow_redirects=False)
    a_kasa = db1("SELECT id FROM kasa WHERE kod='ISO-KAS-A'")["id"]
    a_banka = db1("SELECT id FROM banka_hesap WHERE kod='ISO-BNK-A'")["id"]

    r = admin.post(BASE + "/kasa/hareket", data={
        "kasa_id": str(a_kasa), "islem_tipi": "Açılış Bakiyesi", "tutar": "1000",
        "tarih": BUGUN, "aciklama": "ISO-A kasa açılış"}, allow_redirects=False)
    check("A kasa hareketi kaydedildi", r.status_code == 302, f"status={r.status_code}")
    r = admin.post(BASE + "/banka/hareket", data={
        "hesap_id": str(a_banka), "islem_tipi": "Açılış Bakiyesi", "tutar": "2000",
        "tarih": BUGUN, "aciklama": "ISO-A banka açılış"}, allow_redirects=False)
    check("A banka hareketi kaydedildi", r.status_code == 302, f"status={r.status_code}")

    # fiş + damga doğrulaması
    kh = db("SELECT id, sirket_id FROM kasa_hareket WHERE kasa_id=?", a_kasa)
    bh = db("SELECT id, sirket_id FROM banka_hareket WHERE banka_hesap_id=?", a_banka)
    yv = db("""SELECT id, sirket_id FROM yevmiye
               WHERE (kaynak_modul='Kasa' AND kaynak_id=?)
                  OR (kaynak_modul='Banka' AND kaynak_id=?)""", kh[0]["id"], bh[0]["id"])
    check("A kasa/banka hareketleri şirket 1'e damgalı",
          all(x["sirket_id"] == 1 for x in kh + bh), f"kasa={[x['sirket_id'] for x in kh]}")
    check("A yevmiye fişleri şirket 1'e damgalı",
          len(yv) >= 2 and all(x["sirket_id"] == 1 for x in yv), f"fiş={[x['sirket_id'] for x in yv]}")

    ma = mizan(1)
    tb, ta = mizan_dengesi(1)
    check("A mizanı: 100 KASA +1000 (açılış)", ma.get("100") == round(onceki_100 + 1000, 2),
          f"100={ma.get('100')} (önce {onceki_100})")
    check("A mizanı: 102 BANKALAR +2000 (açılış)", ma.get("102") == round(onceki_102 + 2000, 2),
          f"102={ma.get('102')} (önce {onceki_102})")
    check("A mizanı dengeli (borç=alacak)", tb == ta, f"{tb}/{ta}")

    # --- 3. B'ye geç — A verisi görünmemeli ---
    admin.post(BASE + "/sirket/gec", data={"sirket_id": str(b_id), "next": "/"},
               allow_redirects=False)
    check("B aktif şirket oldu", aktif_sirket() == b_id)

    r = admin.get(BASE + "/kasa")
    check("B kasa listesinde A kasası YOK", "ISO-KAS-A" not in r.text)
    r = admin.get(BASE + "/banka")
    check("B banka listesinde A hesabı YOK", "ISO-BNK-A" not in r.text)

    r = admin.get(BASE + f"/banka/hesap/{a_banka}", allow_redirects=False)
    check("B'de A banka ekstresi ENGELLİ (302)", r.status_code == 302, f"status={r.status_code}")

    r = admin.post(BASE + "/kasa/hareket", data={
        "kasa_id": str(a_kasa), "islem_tipi": "Nakit Girişi", "tutar": "9999",
        "tarih": BUGUN}, allow_redirects=False)
    check("B'den A kasasına hareket ENGELLİ (403)", r.status_code == 403, f"status={r.status_code}")

    r = admin.post(BASE + "/banka/hareket", data={
        "hesap_id": str(a_banka), "islem_tipi": "Havale/EFT Girişi", "tutar": "9999",
        "tarih": BUGUN}, allow_redirects=False)
    check("B'den A banka hesabına hareket ENGELLİ (403)", r.status_code == 403, f"status={r.status_code}")

    mb = mizan(b_id)
    check("B mizanı: 100 KASA = 0 (A fişleri görünmüyor)", mb.get("100") == 0.0, f"100={mb.get('100')}")
    check("B mizanı: 102 BANKALAR = 0", mb.get("102") == 0.0, f"102={mb.get('102')}")

    # --- 4. B kendi kasasını işletir ---
    admin.post(BASE + "/kasa/yeni", data={"ad": "ISO Kasa B", "kod": "ISO-KAS-B"},
               allow_redirects=False)
    b_kasa = db1("SELECT id FROM kasa WHERE kod='ISO-KAS-B'")["id"]
    admin.post(BASE + "/kasa/hareket", data={
        "kasa_id": str(b_kasa), "islem_tipi": "Açılış Bakiyesi", "tutar": "5000",
        "tarih": BUGUN, "aciklama": "ISO-B kasa açılış"}, allow_redirects=False)
    mb2 = mizan(b_id)
    tb2, ta2 = mizan_dengesi(b_id)
    check("B kendi hareketi sonrası 100 KASA = 5000", mb2.get("100") == 5000.0, f"100={mb2.get('100')}")
    check("B mizanı kendi başına dengeli", tb2 == ta2 and tb2 > 0, f"{tb2}/{ta2}")

    # --- 5. A'ya dön — B karışmamalı ---
    admin.post(BASE + "/sirket/gec", data={"sirket_id": "1", "next": "/"}, allow_redirects=False)
    ma2 = mizan(1)
    check("A mizanı B'den etkilenmedi (100/102 aynı)",
          ma2.get("100") == ma.get("100") and ma2.get("102") == ma.get("102"),
          f"100={ma2.get('100')} 102={ma2.get('102')}")

    # --- 6. Hesap planı 27/27 ---
    ha = db("SELECT COUNT(*) c FROM hesap WHERE sirket_id=1")[0]["c"]
    hb = db("SELECT COUNT(*) c FROM hesap WHERE sirket_id=?", b_id)[0]["c"]
    check("hesap planı A=27 / B=27", ha == 27 and hb == 27, f"A={ha} B={hb}")

    # --- 7. Temizlik ---
    for t in ("kasa_hareket", "banka_hareket", "kasa", "banka_hesap", "yevmiye_kalem",
              "yevmiye", "hesap", "demirbas_kategori", "depo", "kullanici_sirket"):
        dbx(f"DELETE FROM {t} WHERE sirket_id=?", b_id)
    dbx("DELETE FROM sirket WHERE id=?", b_id)
    dbx("UPDATE sessionler SET sirket_id=1 WHERE sirket_id=?", b_id)
    # A'daki test kalıntılarını geri al (kaynak-modül bazlı)
    for modul, kod in (("Kasa", "ISO-KAS-A"), ("Banka", "ISO-BNK-A")):
        hidler = [r["id"] for r in db(
            f"SELECT id FROM {'kasa_hareket' if modul=='Kasa' else 'banka_hareket'} "
            f"WHERE {'kasa_id' if modul=='Kasa' else 'banka_hesap_id'}=?",
            a_kasa if modul == "Kasa" else a_banka)]
        for hid in hidler:
            dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN "
                "(SELECT id FROM yevmiye WHERE kaynak_modul=? AND kaynak_id=?)", modul, hid)
            dbx("DELETE FROM yevmiye WHERE kaynak_modul=? AND kaynak_id=?", modul, hid)
            dbx(f"DELETE FROM {'kasa_hareket' if modul=='Kasa' else 'banka_hareket'} WHERE id=?", hid)
    dbx("DELETE FROM kasa WHERE kod='ISO-KAS-A'")
    dbx("DELETE FROM banka_hesap WHERE kod='ISO-BNK-A'")

    print(f"\nSONUÇ: {len(ok)} başarılı / {len(fail)} başarısız")
    if fail:
        print("BAŞARISIZ:", fail)
        raise SystemExit(1)
    print("KASA/BANKA + MUHASEBE İZOLASYON E2E TESTİ GEÇTİ ✅")


if __name__ == "__main__":
    main()
