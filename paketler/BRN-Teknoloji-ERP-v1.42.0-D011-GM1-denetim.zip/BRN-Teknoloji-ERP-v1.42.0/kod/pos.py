# -*- coding: utf-8 -*-
"""POS (Satış Noktası) modülü — C paketi.

POS satışı uçtan uca zinciri tek istekte kurar:
    Satış Faturası (Onaylandı) + cari BORÇ + stok çıkışı + yevmiye + tahsilat.
- Ödeme şekilleri: Nakit (kasaya) · Kart (bankaya net, komisyon kesintili) ·
  Havale (bankaya brüt) · Veresiye (açık hesap) · Çek/Senet (cek_senet + cek_senkron).
- Cari seçilmezse varsayılan "Peşin (Perakende) Müşteri" kullanılır.
- K1: şube izolasyonu; çoklu şirket (sirket_id); çapraz-şirket referans koruması.
- Tüm zincir `pos_satis_olustur` çekirdeğindedir: hem rota hem de seed (db.seed_pos)
  aynı kodu kullanır → tek doğru üretim yolu.
"""
import datetime

import db
import stok
import cari
import kasa
import banka
import muhasebe
import fatura as fatura_mod
from core import route, render_template, redirect, flash, audit, notify, \
    izole_sube, Response, kdv_ayikla

POS_SATIS = ("Admin", "Satis")
POS_YONETIM = ("Admin", "Muhasebe")

ODEME_TIPLERI = ["Nakit", "Kart", "Havale", "Veresiye", "Cek", "Senet"]
ODEME_BADGE = {
    "Nakit": "b-ok", "Kart": "b-info", "Havale": "b-info",
    "Veresiye": "b-warn", "Cek": "b-muted", "Senet": "b-muted",
}


class _BasitReq:
    """Seed/iç akışlar için minimal request benzeri nesne (yalnızca user gerekli)."""

    def __init__(self, user_id=1, sube_id=None, sirket_id=1):
        self.user = {"id": user_id, "rol": "Admin", "sube_id": sube_id,
                     "sirket_id": sirket_id}


def _f(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _i(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _terminaller(conn, sid=None, aktif=True):
    where, args = ["1=1"], []
    if aktif:
        where.append("t.aktif=1")
    if sid is not None:
        where.append("t.sirket_id=?")
        args.append(sid)
    return conn.execute(
        f"SELECT t.*, k.ad AS kasa_ad, b.ad AS banka_ad, d.ad AS depo_ad "
        f"FROM pos_terminal t LEFT JOIN kasa k ON k.id=t.kasa_id "
        f"LEFT JOIN banka_hesap b ON b.id=t.banka_id "
        f"LEFT JOIN depo d ON d.id=t.depo_id "
        f"WHERE {' AND '.join(where)} ORDER BY t.ad", args).fetchall()


def _perakende_cari(conn, sid):
    """Varsayılan peşin müşteri; yoksa sirket bazında oluştur."""
    r = conn.execute("SELECT id FROM cari_kart WHERE unvan='Peşin (Perakende) Müşteri' "
                     "AND sirket_id=? ORDER BY id LIMIT 1", (sid,)).fetchone()
    if r:
        return r["id"]
    cur = conn.execute(
        "INSERT INTO cari_kart(kod, unvan, tip, telefon, sirket_id) VALUES(?,?,?,?,?)",
        ("PER-001", "Peşin (Perakende) Müşteri", "Musteri", "", sid))
    return cur.lastrowid


def _sepet_from_form(req, kdv_dahil=0):
    stok_ids = req.form_list.get("k_stok_id", [])
    varyantlar = req.form_list.get("k_varyant_id", [])
    manuel_adlar = req.form_list.get("k_manuel_ad", [])
    miktarlar = req.form_list.get("k_miktar", [])
    bf = req.form_list.get("k_birim_fiyat", [])
    isk = req.form_list.get("k_iskonto", [])
    kdv = req.form_list.get("k_kdv", [])
    n = max(len(stok_ids), len(manuel_adlar), len(miktarlar))
    rows = []
    for i in range(n):
        sid_raw = (stok_ids[i] if i < len(stok_ids) else "").strip()
        sid = int(sid_raw) if sid_raw.isdigit() else None
        manuel_ad = (manuel_adlar[i] if i < len(manuel_adlar) else "").strip()
        kdv_orani = _f(kdv[i] if i < len(kdv) else 20, 20)
        birim_fiyat = _f(bf[i] if i < len(bf) else 0, 0)
        # F2 — KDV dahil girişte DB'ye NET yazılır (tek kaynak: core.kdv_ayikla).
        if kdv_dahil:
            birim_fiyat = kdv_ayikla(birim_fiyat, kdv_orani)
        rows.append({
            "stok_id": sid,
            "varyant_id": _i(varyantlar[i]) or 0 if i < len(varyantlar) else 0,
            "miktar": _f(miktarlar[i] if i < len(miktarlar) else 0, 0),
            "birim_fiyat": birim_fiyat,
            "iskonto_orani": _f(isk[i] if i < len(isk) else 0, 0),
            "kdv_orani": kdv_orani,
            "manuel_ad": manuel_ad,
        })
    return rows


def _sepet_toplam(rows):
    ara = kdv = isk = 0.0
    for r in rows:
        brut = (r["miktar"] or 0) * (r["birim_fiyat"] or 0)
        isk_t = brut * (r["iskonto_orani"] or 0) / 100
        net = brut - isk_t
        r["tutar"] = round(net, 2)
        ara += net
        isk += isk_t
        kdv += net * (r["kdv_orani"] or 0) / 100
    return {"ara_toplam": round(ara, 2), "iskonto_toplam": round(isk, 2),
            "kdv_toplam": round(kdv, 2), "genel_toplam": round(ara + kdv, 2)}


def pos_satis_olustur(conn, req, terminal_id, cari_id, satirlar, odemeler,
                      taksit=1, vade=None, tarih=None):
    """C — POS satış zincirini tek işlemde kurar (Onaylı Satış Faturası + cari + stok +
    kasa/banka + yevmiye + çek/senet). Başarıda (fid, None), hatada (None, mesaj).

    `conn` açık gelir; COMMIT bu fonksiyonun İŞİ DEĞİLDİR (çağıran yapar) — böylece rota
    ile seed aynı işlem kalıbını paylaşır ve yarım işlem kalmaz.
    """
    sid = db.sirket_id(req)
    term = conn.execute("SELECT * FROM pos_terminal WHERE id=? AND sirket_id=? AND aktif=1",
                        (terminal_id, sid)).fetchone() if terminal_id else None
    if not term:
        return None, "Aktif bir POS terminali seçin."

    satirlar = [s for s in satirlar
                if (s["stok_id"] or s["manuel_ad"]) and s["miktar"] > 0]
    if not satirlar:
        return None, "Sepette en az bir satır olmalı."
    top = _sepet_toplam(satirlar)

    cari_id = cari_id or _perakende_cari(conn, sid)
    if not conn.execute("SELECT id FROM cari_kart WHERE id=? AND sirket_id=?",
                        (cari_id, sid)).fetchone():
        return None, "Geçersiz müşteri seçimi."

    odemeler = [o for o in odemeler if o["tip"] in ODEME_TIPLERI and o["tutar"] > 0]
    odenen = round(sum(o["tutar"] for o in odemeler), 2)
    genel = top["genel_toplam"]
    veresiye = round(genel - odenen, 2)
    if veresiye < -0.005:
        return None, "Ödeme toplamı fatura tutarını aşamaz."
    if veresiye > 0.005:
        odemeler = odemeler + [{"tip": "Veresiye", "tutar": veresiye, "vade": ""}]
    for o in odemeler:
        if o["tip"] in ("Cek", "Senet") and not o["vade"]:
            return None, "Çek/senet ödemesi için vade girin."

    depo_id = term["depo_id"]
    for s in satirlar:
        if not s["stok_id"]:
            continue
        if not conn.execute("SELECT 1 FROM stok_kart WHERE id=? AND sirket_id=? AND aktif=1",
                            (s["stok_id"], sid)).fetchone():
            return None, "Sepette bu şirkete ait olmayan bir ürün var."
        sev = conn.execute(
            "SELECT miktar, rezerve FROM stok_seviye WHERE stok_id=? AND varyant_id=? AND depo_id=?",
            (s["stok_id"], s["varyant_id"] or 0, depo_id)).fetchone()
        eldeki = ((sev["miktar"] or 0) - (sev["rezerve"] or 0)) if sev else 0
        if eldeki < s["miktar"]:
            kart = conn.execute("SELECT kod, ad FROM stok_kart WHERE id=?", (s["stok_id"],)).fetchone()
            return None, f"Stok yetersiz: {kart['kod']} {kart['ad']} (eldeki: {eldeki:g})"

    bugun = tarih or datetime.date.today().isoformat()
    no = db.sonraki_belge_no(conn, "fatura", "fatura_no", "SF", bugun[:4], sid)
    vade = vade or None

    taksit = min(max(_i(taksit) or 1, 1), term["max_taksit"] or 1)

    # 1) Satış Faturası (doğrudan Onaylandı)
    cur = conn.execute(
        "INSERT INTO fatura(fatura_no, tip, cari_id, sube_id, tarih, vade, durum, "
        "para_birimi, doviz_kur, ara_toplam, iskonto_toplam, kdv_toplam, genel_toplam, "
        "aciklama, created_by, sirket_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (no, "Satis", cari_id, izole_sube(req), bugun, vade, "Onaylandı", "TRY", 1.0,
         top["ara_toplam"], top["iskonto_toplam"], top["kdv_toplam"], genel,
         f"POS satışı — {term['ad']}", req.user["id"], sid))
    fid = cur.lastrowid
    stok_birim = {}
    _stok_ids = {s["stok_id"] for s in satirlar if s["stok_id"]}
    if _stok_ids:
        ph = ",".join("?" * len(_stok_ids))
        stok_birim = {r["id"]: r["birim"] for r in conn.execute(
            f"SELECT id, birim FROM stok_kart WHERE id IN ({ph})", tuple(_stok_ids)).fetchall()}
    for s in satirlar:
        birim = (stok_birim.get(s["stok_id"]) or "Adet") if s["stok_id"] else "Adet"
        conn.execute(
            "INSERT INTO fatura_kalem(fatura_id, stok_id, varyant_id, miktar, birim_fiyat, "
            "iskonto_orani, kdv_orani, tutar, aciklama, birim, goruntu_adi, sirket_id) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (fid, s["stok_id"], s["varyant_id"] or 0, s["miktar"], s["birim_fiyat"],
             s["iskonto_orani"], s["kdv_orani"], s["tutar"],
             s["manuel_ad"] or None, birim, None, sid))

    # 2) Cari + yevmiye (fatura onay mekanizmasının aynısı)
    f = conn.execute("SELECT * FROM fatura WHERE id=?", (fid,)).fetchone()
    fatura_mod._cari_uygula(conn, req, dict(f), yon=1)
    muhasebe.fis_uret(conn, "Fatura", fid)

    # 3) Stok çıkışı
    for s in satirlar:
        if not s["stok_id"]:
            continue
        stok._hareket_olustur(conn, req, s["stok_id"], s["varyant_id"] or 0, depo_id,
                              "POS Çıkışı", -s["miktar"], aciklama=f"POS satışı {no}",
                              belge_no=no, ilgili_modul="Fatura", ilgili_kayit_id=fid,
                              tarih=bugun)

    # 4) Tahsilat + pos_satis + ödeme satırları
    komisyon_toplam = 0.0
    veresiye_tutar = 0.0
    cur2 = conn.execute(
        "INSERT INTO pos_satis(fatura_id, terminal_id, taksit, komisyon_toplam, veresiye_tutar, "
        "sube_id, created_by, sirket_id) VALUES(?,?,?,?,?,?,?,?)",
        (fid, term["id"], taksit, 0.0, 0.0, izole_sube(req), req.user["id"], sid))
    psid = cur2.lastrowid
    for o in odemeler:
        kom = 0.0
        cek_id = None
        if o["tip"] == "Nakit":
            if term["kasa_id"]:
                hid = kasa.kasa_hareket_olustur(
                    conn, term["kasa_id"], bugun, "Nakit Girişi", o["tutar"],
                    aciklama=f"POS satışı {no}", belge_no=no, cari_id=cari_id,
                    ilgili_modul="Fatura", ilgili_kayit_id=fid,
                    created_by=req.user["id"], sirket_id=sid)
                muhasebe.fis_uret(conn, "Kasa", hid)
                cari.hareket_ekle(conn, cari_id, bugun, "Tahsilat", no, f"POS nakit tahsilatı",
                                  borc=0.0, alacak=o["tutar"], ilgili_modul="Fatura",
                                  ilgili_kayit_id=fid, created_by=req.user["id"])
        elif o["tip"] in ("Kart", "Havale"):
            if term["banka_id"]:
                if o["tip"] == "Kart":
                    kom = round(o["tutar"] * (term["komisyon_orani"] or 0) / 100, 2)
                    komisyon_toplam += kom
                net = round(o["tutar"] - kom, 2)
                hid = banka.banka_hareket_olustur(
                    conn, term["banka_id"], bugun, "Havale/EFT Girişi", net,
                    aciklama=f"POS {'kart' if o['tip']=='Kart' else 'havale'} tahsilatı {no}",
                    belge_no=no, cari_id=cari_id, ilgili_modul="Fatura",
                    ilgili_kayit_id=fid, created_by=req.user["id"], sirket_id=sid)
                muhasebe.fis_uret(conn, "Banka", hid)
                cari.hareket_ekle(conn, cari_id, bugun, "Tahsilat", no,
                                  f"POS {'kart' if o['tip']=='Kart' else 'havale'} tahsilatı",
                                  borc=0.0, alacak=o["tutar"], ilgili_modul="Fatura",
                                  ilgili_kayit_id=fid, created_by=req.user["id"])
        elif o["tip"] == "Veresiye":
            veresiye_tutar += o["tutar"]
        elif o["tip"] in ("Cek", "Senet"):
            tur = "Cek" if o["tip"] == "Cek" else "Senet"
            cur3 = conn.execute(
                "INSERT INTO cek_senet(no, tip, tur, cari_id, banka, sube_ad, tutar, "
                "keside_tarihi, vade, durum, aciklama, sube_id, created_by, sirket_id) "
                "VALUES(?,?,?,?,?,?,?,?,?,'Bekliyor',?,?,?,?)",
                (f"POS-{no}", "Alinan", tur, cari_id, "", "", o["tutar"], bugun, o["vade"],
                 f"POS satışı {no}", izole_sube(req), req.user["id"], sid))
            cek_id = cur3.lastrowid
            muhasebe.cek_senkron(conn, cek_id, created_by=req.user["id"])
        conn.execute(
            "INSERT INTO pos_satis_odeme(pos_satis_id, tip, tutar, komisyon, cek_senet_id, sirket_id) "
            "VALUES(?,?,?,?,?,?)",
            (psid, o["tip"], o["tutar"], kom, cek_id, sid))

    conn.execute(
        "UPDATE pos_satis SET komisyon_toplam=?, veresiye_tutar=? WHERE id=?",
        (round(komisyon_toplam, 2), round(veresiye_tutar, 2), psid))
    return fid, None


@route(r"/pos", roles=POS_SATIS)
def pos_satis_ekrani(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    terminaller = _terminaller(conn, sid)
    cariler = conn.execute(
        "SELECT id, kod, unvan FROM cari_kart WHERE aktif=1 AND tip IN ('Musteri','HerIkisi') "
        "AND sirket_id=? ORDER BY unvan LIMIT 200", (sid,)).fetchall()
    conn.close()
    return render_template("pos/satis.html", terminaller=terminaller, cariler=cariler,
                           odeme_tipleri=ODEME_TIPLERI)


@route(r"/pos/satis", methods=("POST",), roles=POS_SATIS)
def pos_satis_yap(req):
    conn = db.get_conn()
    terminal_id = _i(req.form.get("terminal_id"))
    kdv_dahil = 1 if req.form.get("kdv_dahil") in ("1", "dahil", "on") else 0
    satirlar = _sepet_from_form(req, kdv_dahil)
    cari_id = _i(req.form.get("cari_id"))
    tipler = req.form_list.get("p_tip", [])
    tutarlar = req.form_list.get("p_tutar", [])
    vadeler = req.form_list.get("p_vade", [])
    odemeler = []
    for i in range(len(tipler)):
        tip = tipler[i].strip()
        if tip not in ODEME_TIPLERI:
            continue
        tutar = _f(tutarlar[i] if i < len(tutarlar) else 0)
        if tutar <= 0:
            continue
        odemeler.append({"tip": tip, "tutar": round(tutar, 2),
                         "vade": (vadeler[i] if i < len(vadeler) else "").strip()})

    fid, hata = pos_satis_olustur(
        conn, req, terminal_id, cari_id, satirlar, odemeler,
        taksit=_i(req.form.get("taksit")) or 1, vade=req.form.get("vade") or None)
    if hata:
        conn.close()
        flash(req, hata, "danger")
        return redirect("/pos")

    f = conn.execute("SELECT fatura_no, genel_toplam FROM fatura WHERE id=?", (fid,)).fetchone()
    term = conn.execute("SELECT ad FROM pos_terminal WHERE id=?", (terminal_id,)).fetchone()
    conn.commit()
    audit(req, "fatura", fid, "olustur", {"fatura_no": f["fatura_no"], "kaynak": "POS",
                                          "terminal": term["ad"] if term else "?"})
    audit(req, "pos_satis", conn.execute("SELECT id FROM pos_satis WHERE fatura_id=?",
                                         (fid,)).fetchone()["id"], "olustur",
          {"fatura_no": f["fatura_no"]})
    notify("bilgi", "POS satışı tamamlandı",
           f"{f['fatura_no']} nolu satış faturası kesildi ({f['genel_toplam']:,.2f} TL).",
           "fatura", fid, sirket_id=db.sirket_id(req))
    flash(req, f"Satış tamamlandı: {f['fatura_no']} — {f['genel_toplam']:,.2f} TL", "ok")
    conn.close()
    return redirect(f"/fatura/{fid}")


@route(r"/pos/satislar", roles=())
def pos_satis_liste(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    q = (req.q("q") or "").strip()
    where, params = ["p.sirket_id=?"], [sid]
    if q:
        where.append("(f.fatura_no LIKE ? OR c.unvan LIKE ?)")
        like = f"%{q}%"
        params += [like, like]
    w = " AND ".join(where)
    rows = conn.execute(
        f"SELECT p.*, f.fatura_no, f.genel_toplam, f.tarih, c.unvan AS cari_unvan, "
        f"t.ad AS terminal_ad, "
        f"(SELECT COUNT(*) FROM pos_satis_odeme o WHERE o.pos_satis_id=p.id) AS odeme_sayisi "
        f"FROM pos_satis p JOIN fatura f ON f.id=p.fatura_id "
        f"LEFT JOIN cari_kart c ON c.id=f.cari_id "
        f"LEFT JOIN pos_terminal t ON t.id=p.terminal_id "
        f"WHERE {w} ORDER BY p.id DESC LIMIT 200", params).fetchall()
    conn.close()
    return render_template("pos/satis_liste.html", rows=rows)


@route(r"/pos/satis/(?P<pid>\d+)", roles=())
def pos_satis_detay(req, pid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    p = conn.execute(
        "SELECT p.*, f.fatura_no, f.genel_toplam, f.tarih, c.unvan AS cari_unvan, c.kod AS cari_kod, "
        "t.ad AS terminal_ad FROM pos_satis p JOIN fatura f ON f.id=p.fatura_id "
        "LEFT JOIN cari_kart c ON c.id=f.cari_id "
        "LEFT JOIN pos_terminal t ON t.id=p.terminal_id "
        "WHERE p.id=? AND p.sirket_id=?", (int(pid), sid)).fetchone()
    if not p:
        conn.close()
        flash(req, "POS satışı bulunamadı.", "danger")
        return redirect("/pos/satislar")
    odemeler = conn.execute(
        "SELECT * FROM pos_satis_odeme WHERE pos_satis_id=? ORDER BY id", (int(pid),)).fetchall()
    conn.close()
    return render_template("pos/satis_detay.html", p=p, odemeler=odemeler, odeme_badge=ODEME_BADGE)


@route(r"/pos/terminaller", roles=POS_YONETIM)
def pos_terminal_liste(req):
    conn = db.get_conn()
    terminaller = _terminaller(conn, db.sirket_id(req), aktif=False)
    conn.close()
    return render_template("pos/terminal_liste.html", terminaller=terminaller)


@route(r"/pos/terminal/yeni", methods=("GET", "POST"), roles=POS_YONETIM)
def pos_terminal_yeni(req):
    conn = db.get_conn()
    if req.method == "POST":
        sid = db.sirket_id(req)
        ad = (req.form.get("ad") or "").strip()
        if not ad:
            conn.close()
            flash(req, "Terminal adı zorunludur.", "danger")
            return redirect("/pos/terminal/yeni")
        kasa_id = _i(req.form.get("kasa_id"))
        banka_id = _i(req.form.get("banka_id"))
        depo_id = _i(req.form.get("depo_id"))
        if not depo_id:
            conn.close()
            flash(req, "Stok düşümü için depo seçimi zorunludur.", "danger")
            return redirect("/pos/terminal/yeni")
        if not conn.execute("SELECT id FROM depo WHERE id=? AND sirket_id=?", (depo_id, sid)).fetchone():
            conn.close()
            flash(req, "Geçersiz depo.", "danger")
            return redirect("/pos/terminal/yeni")
        cur = conn.execute(
            "INSERT INTO pos_terminal(ad, kasa_id, banka_id, depo_id, komisyon_orani, max_taksit, "
            "aktif, sube_id, sirket_id) VALUES(?,?,?,?,?,?,1,?,?)",
            (ad, kasa_id, banka_id, depo_id, _f(req.form.get("komisyon_orani")),
             max(_i(req.form.get("max_taksit")) or 1, 1), izole_sube(req), sid))
        conn.commit()
        audit(req, "pos_terminal", cur.lastrowid, "olustur", {"ad": ad})
        flash(req, f"Terminal eklendi: {ad}", "ok")
        conn.close()
        return redirect("/pos/terminaller")
    conn.close()
    return _terminal_form(req, None)


@route(r"/pos/terminal/(?P<tid>\d+)/duzenle", methods=("GET", "POST"), roles=POS_YONETIM)
def pos_terminal_duzenle(req, tid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    t = conn.execute("SELECT * FROM pos_terminal WHERE id=? AND sirket_id=?",
                     (int(tid), sid)).fetchone()
    if not t:
        conn.close()
        flash(req, "Terminal bulunamadı.", "danger")
        return redirect("/pos/terminaller")
    if req.method == "POST":
        ad = (req.form.get("ad") or "").strip()
        depo_id = _i(req.form.get("depo_id"))
        if not ad or not depo_id:
            conn.close()
            flash(req, "Ad ve depo zorunludur.", "danger")
            return redirect(f"/pos/terminal/{t['id']}/duzenle")
        conn.execute(
            "UPDATE pos_terminal SET ad=?, kasa_id=?, banka_id=?, depo_id=?, komisyon_orani=?, "
            "max_taksit=? WHERE id=?",
            (ad, _i(req.form.get("kasa_id")), _i(req.form.get("banka_id")), depo_id,
             _f(req.form.get("komisyon_orani")), max(_i(req.form.get("max_taksit")) or 1, 1),
             t["id"]))
        conn.commit()
        audit(req, "pos_terminal", t["id"], "guncelle", {"ad": ad})
        flash(req, "Terminal güncellendi.", "ok")
        conn.close()
        return redirect("/pos/terminaller")
    conn.close()
    return _terminal_form(req, t)


@route(r"/pos/terminal/(?P<tid>\d+)/durum", methods=("POST",), roles=POS_YONETIM)
def pos_terminal_durum(req, tid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    t = conn.execute("SELECT * FROM pos_terminal WHERE id=? AND sirket_id=?",
                     (int(tid), sid)).fetchone()
    if t:
        yeni = 0 if t["aktif"] else 1
        conn.execute("UPDATE pos_terminal SET aktif=? WHERE id=?", (yeni, t["id"]))
        conn.commit()
        audit(req, "pos_terminal", t["id"], "durum", {"aktif": yeni})
        flash(req, "Terminal " + ("aktifleştirildi." if yeni else "pasifleştirildi."), "ok")
    conn.close()
    return redirect("/pos/terminaller")


@route(r"/pos/rapor", roles=())
def pos_rapor(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    bugun = datetime.date.today().isoformat()
    tarih = req.q("tarih") or bugun
    rows = conn.execute(
        "SELECT o.tip, SUM(o.tutar) AS tutar, SUM(o.komisyon) AS komisyon, COUNT(*) AS adet "
        "FROM pos_satis_odeme o JOIN pos_satis p ON p.id=o.pos_satis_id "
        "JOIN fatura f ON f.id=p.fatura_id "
        "WHERE f.tarih=? AND p.sirket_id=? GROUP BY o.tip ORDER BY o.tip",
        (tarih, sid)).fetchall()
    terminaller = conn.execute(
        "SELECT t.ad, COUNT(DISTINCT p.id) AS satis, COALESCE(SUM(f.genel_toplam),0) AS ciro, "
        "COALESCE(SUM(p.komisyon_toplam),0) AS komisyon "
        "FROM pos_terminal t LEFT JOIN pos_satis p ON p.terminal_id=t.id "
        "LEFT JOIN fatura f ON f.id=p.fatura_id AND f.tarih=? "
        "WHERE t.sirket_id=? GROUP BY t.id ORDER BY t.ad",
        (tarih, sid)).fetchall()
    toplam_ciro = sum(r["ciro"] for r in terminaller)
    toplam_kom = sum(r["komisyon"] for r in terminaller)
    conn.close()
    return render_template("pos/rapor.html", rows=rows, terminaller=terminaller,
                           tarih=tarih, toplam_ciro=toplam_ciro, toplam_kom=toplam_kom,
                           odeme_badge=ODEME_BADGE)


def _terminal_form(req, mevcut):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    kasalar = conn.execute("SELECT id, ad FROM kasa WHERE aktif=1 AND sirket_id=? ORDER BY ad",
                           (sid,)).fetchall()
    bankalar = conn.execute("SELECT id, ad FROM banka_hesap WHERE aktif=1 AND sirket_id=? ORDER BY ad",
                            (sid,)).fetchall()
    depolar = conn.execute("SELECT id, ad FROM depo WHERE sirket_id=? ORDER BY ad",
                           (sid,)).fetchall()
    conn.close()
    return render_template("pos/terminal_form.html", mevcut=mevcut, kasalar=kasalar,
                           bankalar=bankalar, depolar=depolar)


def register():
    pass
