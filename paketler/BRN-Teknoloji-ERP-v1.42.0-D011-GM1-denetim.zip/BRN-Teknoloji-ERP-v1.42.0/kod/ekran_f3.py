# -*- coding: utf-8 -*-
"""F3 — Ortak arama / type-ahead ekran görüntüleri.

Çıktı: docs/ekran-goruntuleri/yeni-tema/f3-*.png
Çalıştırma: sunucu 8080'de çalışırken  python3 ekran_f3.py
"""
import os
import requests
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8080"
OUT = "docs/ekran-goruntuleri/yeni-tema"


def main():
    os.makedirs(OUT, exist_ok=True)
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": "admin", "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, "giriş başarısız"
    cookies = {c.name: c.value for c in s.cookies}

    with sync_playwright() as p:
        browser = p.chromium.launch()
        ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        ctx.add_cookies([{"name": k, "value": v, "url": BASE} for k, v in cookies.items()])
        page = ctx.new_page()

        # 1) Fatura — Cari type-ahead: "Bat" yaz → Batman Çarşı Elektronik dropdown'da
        page.goto(BASE + "/fatura/yeni", wait_until="networkidle")
        page.wait_for_timeout(500)
        cari = page.query_selector('.typeahead[data-target="cari-id"] .ta-input')
        cari.click()
        cari.fill("Bat")
        page.wait_for_timeout(700)
        page.screenshot(path=f"{OUT}/f3-cari-typeahead.png", full_page=False)
        print("çekildi: f3-cari-typeahead")

        # 2) Fatura — Stok satırı: "Vestel" yaz → filtreli ürün listesi
        page.click("#satir-ekle")
        page.wait_for_timeout(300)
        satir_input = page.query_selector("tr.satir .stok-ara")
        satir_input.click()
        satir_input.fill("Vestel")
        page.wait_for_timeout(700)
        page.screenshot(path=f"{OUT}/f3-stok-typeahead.png", full_page=False)
        print("çekildi: f3-stok-typeahead")

        # 3) POS — ürün arama: "Vestel" yaz → adla arama dropdown'ı
        page.goto(BASE + "/pos", wait_until="networkidle")
        page.wait_for_timeout(500)
        page.fill("#urun-ara", "Vestel")
        page.wait_for_timeout(700)
        page.screenshot(path=f"{OUT}/f3-pos-typeahead.png", full_page=False)
        print("çekildi: f3-pos-typeahead")

        # 4) Satın Alma Talebi — tedarikçi widget: "Vestel" yaz → TED-001
        page.goto(BASE + "/satin-alma/talepler/yeni", wait_until="networkidle")
        page.wait_for_timeout(500)
        ted = page.query_selector('.typeahead[data-target="tedarikci-id"] .ta-input')
        ted.click()
        ted.fill("Vestel")
        page.wait_for_timeout(700)
        page.screenshot(path=f"{OUT}/f3-tedarikci-typeahead.png", full_page=False)
        print("çekildi: f3-tedarikci-typeahead")

        browser.close()
    print("F3 ekran görüntüleri tamam.")


if __name__ == "__main__":
    main()
