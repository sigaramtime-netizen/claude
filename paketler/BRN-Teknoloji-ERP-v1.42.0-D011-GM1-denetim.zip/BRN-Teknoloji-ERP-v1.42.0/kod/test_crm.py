# -*- coding: utf-8 -*-
"""E — CRM (Aktivite/Görev takibi) e2e testi.

Kapsam:
  1. Liste render (demo aktiviteler).
  2. Aktivite oluştur + doğrulamalar (boş başlık, hatırlatma > tarih, geçersiz cari/sorumlu).
  3. Düzenle.
  4. Durum geçişi: Planlandı ↔ Tamamlandı; İptal.
  5. Hatırlatma → bildirim (dashboard taraması) + mükerrer üretim engeli.
  6. Sil + bildirim temizliği.
  7. Rapor render.
  8. Yetki: Depo/Muhasebe 403, Satis izinli.
  9. Şirket izolasyonu: 2. şirkette liste boş, çapraz erişim engelli.
  10. Bütünlük: FK boş, yetim bildirim yok.

Çalıştırma: sunucu 8080'de çalışırken  python3 test_crm.py
"""
import datetime
import sqlite3
import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
BUGUN = datetime.date.today()

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else ""))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris(kullanici="admin"):
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": kullanici, "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, f"giriş başarısız ({kullanici})"
    return s


def yeni(s, baslik, tarih, hatirlatma="", cari="", sorumlu="", tip="Gorev",
         durum="Planlandı", oncelik="Normal"):
    return s.post(BASE + "/crm/yeni",
                  data={"tip": tip, "baslik": baslik, "cari_id": cari, "sorumlu_id": sorumlu,
                        "tarih": tarih, "hatirlatma_tarihi": hatirlatma, "durum": durum,
                        "oncelik": oncelik},
                  allow_redirects=False)


print("== E / CRM (Aktivite-Görev) — e2e testi ==")
s = giris("admin")

# --- Kurulum: kalıntı temizliği (idempotent) ---
for r in db("SELECT id FROM crm_aktivite WHERE baslik LIKE 'TEST%'"):
    dbx("DELETE FROM bildirim_gonderim WHERE ilgili_tablo='crm_aktivite' AND ilgili_id=?", r["id"])
    dbx("DELETE FROM bildirimler WHERE ilgili_tablo='crm_aktivite' AND ilgili_id=?", r["id"])
    dbx("DELETE FROM crm_aktivite WHERE id=?", r["id"])
dbx("DELETE FROM cari_kart WHERE kod='CRMTST'")
dbx("DELETE FROM kullanici_sirket WHERE sirket_id IN (SELECT id FROM sirket WHERE kod='CRMIKI')")
dbx("DELETE FROM sirket WHERE kod='CRMIKI'")
dbx("INSERT INTO cari_kart(kod, unvan, tip, aktif, sirket_id) VALUES('CRMTST','CRM Test Müşteri','Musteri',1,1)")
cid = db1("SELECT id FROM cari_kart WHERE kod='CRMTST'")["id"]

bugun = BUGUN.isoformat()
yarin = (BUGUN + datetime.timedelta(days=1)).isoformat()

# 1. Liste render
r = s.get(BASE + "/crm")
check("1.1 liste 200", r.status_code == 200 and "AKT-2026-001" in r.text)
check("1.2 tip/durum etiketleri", "Toplantı" in r.text and "Yüksek" in r.text)

# 2. Oluştur
r = yeni(s, "TEST Arama", yarin, cari=str(cid), sorumlu="1", tip="Arama", oncelik="Yuksek")
check("2.1 oluşturuldu", r.status_code == 302 and "/crm/" in (r.headers.get("Location") or ""))
aid = int(r.headers["Location"].rstrip("/").split("/")[-1])
a = db1("SELECT * FROM crm_aktivite WHERE id=?", aid)
check("2.2 kayıt doğru", a is not None and a["aktivite_no"].startswith("AKT-") and a["tip"] == "Arama"
      and a["durum"] == "Planlandı" and a["oncelik"] == "Yuksek" and a["cari_id"] == cid)

# 3. Doğrulamalar
once = db1("SELECT COUNT(*) c FROM crm_aktivite")["c"]
r = yeni(s, "", yarin)
check("3.1 boş başlık engellendi", r.status_code == 302 and r.headers.get("Location") == "/crm/yeni"
      and db1("SELECT COUNT(*) c FROM crm_aktivite")["c"] == once)
r = yeni(s, "TEST", yarin, hatirlatma=(BUGUN + datetime.timedelta(days=9)).isoformat())
check("3.2 hatırlatma > tarih engellendi", r.status_code == 302 and r.headers.get("Location") == "/crm/yeni"
      and db1("SELECT COUNT(*) c FROM crm_aktivite")["c"] == once)
r = yeni(s, "TEST", yarin, cari="999999")
check("3.3 geçersiz cari engellendi", r.status_code == 302 and r.headers.get("Location") == "/crm/yeni"
      and db1("SELECT COUNT(*) c FROM crm_aktivite")["c"] == once)
r = yeni(s, "TEST", yarin, sorumlu="999999")
check("3.4 geçersiz sorumlu engellendi", r.status_code == 302 and r.headers.get("Location") == "/crm/yeni"
      and db1("SELECT COUNT(*) c FROM crm_aktivite")["c"] == once)

# 4. Düzenle
r = s.post(BASE + f"/crm/{aid}/duzenle",
           data={"tip": "Gorev", "baslik": "TEST Güncellendi", "cari_id": str(cid),
                 "sorumlu_id": "1", "tarih": yarin, "hatirlatma_tarihi": yarin,
                 "durum": "Planlandı", "oncelik": "Normal"}, allow_redirects=False)
check("4.1 düzenlendi", db1("SELECT baslik, tip FROM crm_aktivite WHERE id=?", aid)["baslik"] == "TEST Güncellendi"
      and db1("SELECT tip FROM crm_aktivite WHERE id=?", aid)["tip"] == "Gorev")

# 5. Durum geçişleri
s.post(BASE + f"/crm/{aid}/durum", allow_redirects=False)
check("5.1 tamamlandı", db1("SELECT durum FROM crm_aktivite WHERE id=?", aid)["durum"] == "Tamamlandı")
s.post(BASE + f"/crm/{aid}/durum", allow_redirects=False)
check("5.2 yeniden planlandı", db1("SELECT durum FROM crm_aktivite WHERE id=?", aid)["durum"] == "Planlandı")
s.post(BASE + f"/crm/{aid}/iptal", allow_redirects=False)
check("5.3 iptal edildi", db1("SELECT durum FROM crm_aktivite WHERE id=?", aid)["durum"] == "İptal")

# 6. Hatırlatma → bildirim + mükerrer engeli
r = yeni(s, "TEST Hatırlatma", bugun, hatirlatma=bugun, cari=str(cid))
hid = int(r.headers["Location"].rstrip("/").split("/")[-1])
s.get(BASE + "/")  # dashboard → _crm_aktivite_tarama tetiklenir
n = db1("SELECT COUNT(*) c FROM bildirimler WHERE ilgili_tablo='crm_aktivite' AND ilgili_id=?", hid)["c"]
check("6.1 hatırlatma bildirimi üretildi", n == 1)
s.get(BASE + "/")  # ikinci ziyaret → mükerrer üretmemeli (hatirlatildi=1)
check("6.2 mükerrer bildirim yok", db1("SELECT COUNT(*) c FROM bildirimler WHERE ilgili_tablo='crm_aktivite' AND ilgili_id=?", hid)["c"] == 1)

# 7. Sil + bildirim temizliği
s.post(BASE + f"/crm/{hid}/sil", allow_redirects=False)
check("7.1 aktivite silindi", db1("SELECT COUNT(*) c FROM crm_aktivite WHERE id=?", hid)["c"] == 0)
check("7.2 bildirimi de temizlendi", db1("SELECT COUNT(*) c FROM bildirimler WHERE ilgili_tablo='crm_aktivite' AND ilgili_id=?", hid)["c"] == 0)

# 8. Rapor
r = s.get(BASE + "/crm/rapor")
check("8.1 rapor 200", r.status_code == 200 and "Yaklaşan" in r.text and "Günü Geçen" in r.text)

# 9. Yetki
for ku, izin in (("depo", False), ("muhasebe", False), ("satis", True)):
    ss = giris(ku)
    rr = ss.get(BASE + "/crm/yeni")
    if izin:
        check(f"9.{ku} yeni izinli (200)", rr.status_code == 200)
    else:
        check(f"9.{ku} yeni 403", rr.status_code == 403)

# 10. Şirket izolasyonu
dbx("INSERT INTO sirket(kod, unvan, aktif) VALUES('CRMIKI','CRM İkinci Şirket',1)")
s2 = db1("SELECT id FROM sirket WHERE kod='CRMIKI'")["id"]
s.post(BASE + "/sirket/gec", data={"sirket_id": str(s2), "next": "/"}, allow_redirects=False)
r = s.get(BASE + "/crm")
check("10.1 2. şirkette liste boş", r.status_code == 200 and "Aktivite bulunamadı" in r.text)
r = s.get(BASE + f"/crm/{aid}", allow_redirects=False)
check("10.2 çapraz şirket detay engellendi", r.status_code == 302 and r.headers.get("Location") == "/crm")
s.post(BASE + "/sirket/gec", data={"sirket_id": "1", "next": "/"}, allow_redirects=False)

# --- Temizlik ---
for r in db("SELECT id FROM crm_aktivite WHERE baslik LIKE 'TEST%'"):
    dbx("DELETE FROM bildirim_gonderim WHERE ilgili_tablo='crm_aktivite' AND ilgili_id=?", r["id"])
    dbx("DELETE FROM bildirimler WHERE ilgili_tablo='crm_aktivite' AND ilgili_id=?", r["id"])
    dbx("DELETE FROM crm_aktivite WHERE id=?", r["id"])
dbx("DELETE FROM cari_kart WHERE kod='CRMTST'")
dbx("DELETE FROM kullanici_sirket WHERE sirket_id IN (SELECT id FROM sirket WHERE kod='CRMIKI')")
dbx("DELETE FROM sirket WHERE kod='CRMIKI'")

# --- Bütünlük ---
fk = db("PRAGMA foreign_key_check")
check("11.1 FK bütünlüğü", len(fk) == 0, str([tuple(r) for r in fk][:5]))
check("11.2 yetim crm bildirimi yok",
      db1("SELECT COUNT(*) c FROM bildirimler b WHERE b.ilgili_tablo='crm_aktivite' AND b.ilgili_id>0 "
          "AND NOT EXISTS (SELECT 1 FROM crm_aktivite a WHERE a.id=b.ilgili_id)")["c"] == 0)
check("11.3 POSTEST cari kalmadı", db1("SELECT COUNT(*) c FROM cari_kart WHERE kod LIKE '%TEST%'")["c"] == 0)

print(f"\n=== SONUÇ: {len(ok)} başarılı / {len(fail)} başarısız ===")
if fail:
    print("BAŞARISIZ:", fail)
    raise SystemExit(1)
print("TÜM CRM TESTLERİ GEÇTİ ✅")
