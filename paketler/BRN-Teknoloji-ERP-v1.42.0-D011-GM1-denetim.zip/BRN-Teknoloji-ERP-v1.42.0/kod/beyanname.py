# -*- coding: utf-8 -*-
"""Beyanname (1.21) — Faz 5.

KDV (tahakkuk + nakit esaslı), Geçici Vergi ve Muhtasar **hazırlık raporları** +
**vergi denetim raporu** (bir kalemin nasıl hesaplandığını kaynak belgelerle görme).

TASARIM (K4/K6): Salt-okunur — GM (`yevmiye`/`hesap`), `fatura`(+kalem), `cari_hareket` ve
`gelen_belge`'den türetilir; **GİB'e gönderim YAPILMAZ**, mali müşavire aktarılabilecek çıktı
(ekran + yazdırma + CSV) üretilir.

- KDV (tahakkuk): 391 Hesaplanan / 191 İndirilecek — fatura kaynaklı, GM ile çapraz doğrulamalı.
  Devreden KDV aylar arası kümülatif taşınır (standart formül).
- KDV (nakit esaslı): cari bazında tahsilat/ödeme oranıyla ölçeklenir (basitleştirilmiş; fatura
  bazlı kesin eşleştirme mali müşavir onayı gerektirir).
- Geçici Vergi: çeyrek dönemler; matrah = **Tahmini Brüt Kâr (COGS dahil)** — Finansal Analiz'in
  "En Kârlı Ürün" yöntemi (fatura_kalem cirosu − adet × güncel alış) çeyrek ayları kümülatifi ×
  oran − önceki çeyrek mahsubu. GM net kârı (620 SMM kapanışa kadar devretmediği için maliyeti
  içermez) YERİNE bu rakam kullanılır; TAHMİNİDİR, kesin matrah dönem kapanışında netleşir.
- Muhtasar: stopaj kaynak modeli olmadığından boş durum + açıklama.
- Gelen belge işaretleme: `donusum_fatura_id` boş (eşleştirilmemiş) gelen belgeler mali müşavire
  ayrı liste olarak işaretlenir (Faz 4 açık noktası 2 — HZM-GLN-ESLESME fallback).
"""
import csv
import datetime
import io
import json

import db
from core import route, render_template, Response
from finansal import _cogs_aylik  # Tahmini brüt kâr (COGS) — Geçici Vergi matrahıyla ortak kaynak (K28)

GECICI_VERGI_ORAN = 0.25   # 2026 kurumlar vergisi / geçici vergi oranı (rapor üstünde not düşülür)
AY_AD = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran",
         "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]
CEYREKLER = ((1, 2, 3), (4, 5, 6), (7, 8, 9), (10, 11, 12))
CEYREK_AD = ("1. Dönem (Oca–Mar)", "2. Dönem (Nis–Haz)",
             "3. Dönem (Tem–Eyl)", "4. Dönem (Eki–Ara)")


def _f(v, default=0.0):
    try:
        return float(v if v not in (None, "") else default)
    except (TypeError, ValueError):
        return default


def _kdv_aylik(conn, sid=None):
    """Aylık tahakkuk KDV: {ym: {'hesaplanan','indirilecek','matrah_s','matrah_a'}} (fatura kaynağı)."""
    extra = " AND sirket_id=?" if sid is not None else ""
    args = [sid] if sid is not None else []
    rows = conn.execute(
        "SELECT substr(tarih,1,7) ym, "
        "SUM(CASE WHEN tip='Satis' THEN kdv_toplam*COALESCE(doviz_kur,1) ELSE 0 END) h, "
        "SUM(CASE WHEN tip='Alis' THEN kdv_toplam*COALESCE(doviz_kur,1) ELSE 0 END) i, "
        "SUM(CASE WHEN tip='Satis' THEN ara_toplam*COALESCE(doviz_kur,1) ELSE 0 END) ms, "
        "SUM(CASE WHEN tip='Alis' THEN ara_toplam*COALESCE(doviz_kur,1) ELSE 0 END) ma "
        "FROM fatura WHERE durum='Onaylandı'" + extra + " GROUP BY ym", args
    ).fetchall()
    return {r["ym"]: {"hesaplanan": r["h"] or 0.0, "indirilecek": r["i"] or 0.0,
                      "matrah_s": r["ms"] or 0.0, "matrah_a": r["ma"] or 0.0} for r in rows}


def _kdv_oranlar(conn, sid=None):
    """KDV oranı bazında dağılım (matrah + KDV) — satış ve alış ayrı."""
    def _q(tip):
        extra = " AND f.sirket_id=?" if sid is not None else ""
        args = [tip] + ([sid] if sid is not None else [])
        return conn.execute(
            "SELECT fk.kdv_orani o, "
            "SUM(fk.tutar*COALESCE(f.doviz_kur,1)) matrah, "
            "SUM(fk.tutar*COALESCE(f.doviz_kur,1)*fk.kdv_orani/100) kdv "
            "FROM fatura_kalem fk JOIN fatura f ON f.id=fk.fatura_id "
            "WHERE f.durum='Onaylandı' AND f.tip=?" + extra +
            " GROUP BY fk.kdv_orani ORDER BY fk.kdv_orani", args).fetchall()
    return [dict(r) for r in _q("Satis")], [dict(r) for r in _q("Alis")]


def _devreden_satirlar(kdv, yil, aktif_ay):
    """12 aylık devredenli KDV tablosu (saf fonksiyon — birim test edilebilir).

    kdv: {ym: {hesaplanan, indirilecek, ...}} aylık fatura kaynağı.
    Formül: Ödenecek = Hesaplanan − İndirilecek − Devreden(önceki); negatif sonuç bir sonraki
    aya **kümülatif devreder** (İndirilecek > Hesaplanan olan ay devreden doğurur).
    """
    satirlar = []
    devreden = 0.0
    for m in range(1, 13):
        d = kdv.get(f"{yil:04d}-{m:02d}",
                    {"hesaplanan": 0.0, "indirilecek": 0.0, "matrah_s": 0.0, "matrah_a": 0.0})
        net = d["hesaplanan"] - d["indirilecek"] - devreden
        if net >= 0:
            odenecek, yeni_dev = net, 0.0
        else:
            odenecek, yeni_dev = 0.0, -net
        satirlar.append({"ay": m, "hesaplanan": d["hesaplanan"], "indirilecek": d["indirilecek"],
                         "devreden_on": devreden, "odenecek": odenecek,
                         "devreden_son": yeni_dev, "aktif": m == aktif_ay})
        devreden = yeni_dev
    return satirlar


def _gecici_vergi(conn, yil, ay, sid=None):
    """Çeyrek dönemli geçici vergi — matrah **TAHMİNİ BRÜT KÂR (COGS dahil)**.

    Finansal Analiz'in "Tahmini Brüt Kâr" yöntemiyle (fatura_kalem cirosu − adet × güncel alış
    fiyatı) yılbaşından dönem sonuna kümülatif toplanır; × oran − önceki dönem mahsubu. GM net kârı
    (620/SMM kapanışa kadar devretmediği için maliyeti içermez) yerine bu rakam kullanılır —
    TAHMİNİDİR; kesin matrah dönem kapanışında netleşir.

    Zarar kuralı: vergiye tabi matrah **0'ın altına inemez** (max(0, matrah)); asla negatif "vergi"
    üretilmez. Zarar yıl içindeki kümülatif matrahtan otomatik düşer (yıl içi zarar mahsubu
    kendiliğinden işler); yıllar arası zarar devri dönem kapanışında / mali müşavirce netleşir.
    """
    qidx = next(i for i, q in enumerate(CEYREKLER) if ay in q)
    q = CEYREKLER[qidx]
    cogs = _cogs_aylik(conn, sid)

    def _cum(son_ay):
        if son_ay < 1:
            return 0.0
        return sum(ci - ma for ym, (ci, ma) in cogs.items()
                   if int(ym[:4]) == yil and 1 <= int(ym[5:7]) <= son_ay)

    matrah = _cum(q[2])
    onceki_matrah = _cum(q[0] - 1) if q[0] > 1 else 0.0
    taban = max(0.0, matrah)              # vergiye tabi matrah — 0'ın altına inemez
    vergi = taban * GECICI_VERGI_ORAN
    mahsup = max(0.0, onceki_matrah) * GECICI_VERGI_ORAN
    return {"ceyrek": CEYREK_AD[qidx], "matrah": matrah, "vergiye_tabi_matrah": taban,
            "zarar": max(0.0, -matrah), "oran": GECICI_VERGI_ORAN * 100,
            "hesaplanan": vergi, "mahsup": mahsup, "odenecek": max(0.0, vergi - mahsup)}


def _nakit_kdv(conn, yil, sid=None):
    """Nakit esaslı KDV (basitleştirilmiş): cari bazında tahsilat/ödeme oranıyla ölçeklenir.

    Satış KDV/geneli ve Alış KDV/geneli → onaylı faturalardan (tek kaynak).
    Tahsilat/ödeme → cari_hareket (belge_tipi Tahsilat alacak / Ödeme borç, TL karşılık);
    çek/senet kaynaklı tahsilat/ödeme (ilgili_modul='CekSenet') HARİÇ tutulur.
    """
    donem_bas = f"{yil:04d}-01-01"
    fextra = " AND sirket_id=?" if sid is not None else ""
    fargs = [donem_bas] + ([sid] if sid is not None else [])
    satis = {r["cari_id"]: (r["g"], r["k"]) for r in conn.execute(
        "SELECT cari_id, SUM(genel_toplam*COALESCE(doviz_kur,1)) g, "
        "SUM(kdv_toplam*COALESCE(doviz_kur,1)) k FROM fatura "
        "WHERE durum='Onaylandı' AND tip='Satis' AND cari_id IS NOT NULL "
        "AND tarih>=?" + fextra + " GROUP BY cari_id", fargs).fetchall()}
    alis = {r["cari_id"]: (r["g"], r["k"]) for r in conn.execute(
        "SELECT cari_id, SUM(genel_toplam*COALESCE(doviz_kur,1)) g, "
        "SUM(kdv_toplam*COALESCE(doviz_kur,1)) k FROM fatura "
        "WHERE durum='Onaylandı' AND tip='Alis' AND cari_id IS NOT NULL "
        "AND tarih>=?" + fextra + " GROUP BY cari_id", fargs).fetchall()}

    def _oran(cari_id, belge, kolon):
        # Çek/Senet (ilgili_modul='CekSenet') HARİÇ: alınan/verilen çek-senet henüz nakde
        # dönüşmemiştir; nakit esaslı KDV'de yalnızca gerçek nakit tahsilat/ödeme sayılır.
        extra = " AND sirket_id=?" if sid is not None else ""
        args = [cari_id, belge, donem_bas] + ([sid] if sid is not None else [])
        r = conn.execute(
            f"SELECT COALESCE(SUM({kolon}),0) s FROM cari_hareket "
            "WHERE cari_id=? AND belge_tipi=? AND tarih>=? "
            "AND COALESCE(ilgili_modul,'') != 'CekSenet'" + extra, args).fetchone()
        return r["s"] or 0.0

    rows = []
    toplam_s_k = toplam_t_k = toplam_a_k = toplam_o_k = 0.0
    for cari_id, (genel, kdv) in sorted(satis.items()):
        tahsilat = _oran(cari_id, "Tahsilat", "alacak")
        oran = min(1.0, tahsilat / genel) if genel > 0 else 0.0
        tk = kdv * oran
        car = conn.execute("SELECT unvan, kod FROM cari_kart WHERE id=?", (cari_id,)).fetchone()
        rows.append({"kod": car["kod"] if car else "?", "unvan": car["unvan"] if car else "?",
                     "taraf": "Satış", "genel": genel, "kdv": kdv,
                     "tahsilat_odeme": tahsilat, "oran": oran * 100, "kdv_tahsil": tk})
        toplam_s_k += kdv
        toplam_t_k += tk
    for cari_id, (genel, kdv) in sorted(alis.items()):
        odeme = _oran(cari_id, "Ödeme", "borc")
        oran = min(1.0, odeme / genel) if genel > 0 else 0.0
        ok = kdv * oran
        car = conn.execute("SELECT unvan, kod FROM cari_kart WHERE id=?", (cari_id,)).fetchone()
        rows.append({"kod": car["kod"] if car else "?", "unvan": car["unvan"] if car else "?",
                     "taraf": "Alış", "genel": genel, "kdv": kdv,
                     "tahsilat_odeme": odeme, "oran": oran * 100, "kdv_tahsil": ok})
        toplam_a_k += kdv
        toplam_o_k += ok
    return {"rows": rows, "tahsil_edilen": toplam_t_k, "odenen": toplam_o_k,
            "odenecek": toplam_t_k - toplam_o_k}


def _gelen_eslesmemis(conn, sid=None):
    extra = " AND sirket_id=?" if sid is not None else ""
    args = [sid] if sid is not None else []
    return [dict(r) for r in conn.execute(
        "SELECT * FROM gelen_belge WHERE donusum_fatura_id IS NULL " + extra +
        " ORDER BY belge_tarih DESC, id DESC", args).fetchall()]


# --------------------------------------------------------------------------
# F5-C (v1.37.0) — özet kart / API / CSV / SVG yardımcıları
# --------------------------------------------------------------------------
def _sayk(v):
    """Grafik etiketi için kompakt: 12345 -> 12k."""
    a = abs(v)
    if a >= 1_000_000:
        return f"{v/1_000_000:.1f}M".replace(".", ",")
    if a >= 1000:
        return f"{v/1000:.0f}k"
    return f"{v:.0f}"


def _kdv_oran_svg(rows, color_m="#4f8cff", color_k="#f0a34a", width=640, height=200):
    """KDV oran dağılımı: her oran için matrah + KDV ikili bar (inline SVG)."""
    if not rows:
        return '<div class="empty">Bu dönemde veri yok.</div>'
    vals = [r["matrah"] for r in rows] + [r["kdv"] for r in rows]
    vmax = max(max(vals), 0.0001)
    left, right, top, bottom = 10, width - 10, 16, height - 26
    plot_h = bottom - top
    n = len(rows)
    bw = (right - left) / n
    bar_w = max(6.0, bw * 0.32)
    p = [f'<svg viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg" '
         f'role="img" style="width:100%;height:auto;display:block;">']
    for i in range(4):
        y = top + plot_h * i / 3
        p.append(f'<line x1="{left}" y1="{y:.1f}" x2="{right}" y2="{y:.1f}" '
                 f'stroke="#273042" stroke-width="1"/>')
    for i, r in enumerate(rows):
        cx = left + bw * i + bw / 2
        for j, (key, color) in enumerate((("matrah", color_m), ("kdv", color_k))):
            v = r[key]
            x = cx - bar_w + j * (bar_w + 2)
            h = v / vmax * plot_h
            y = bottom - h
            p.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{bar_w:.1f}" '
                     f'height="{max(h, 0.5):.1f}" rx="1.5" fill="{color}"/>')
        p.append(f'<text x="{cx:.1f}" y="{height - 8}" fill="#8b95a7" '
                 f'font-size="9" text-anchor="middle">%{int(r["o"])}</text>')
    p.append('</svg>')
    return "".join(p)


def _json(data):
    return Response(json.dumps(data, ensure_ascii=False), "200 OK",
                    [("Content-Type", "application/json; charset=utf-8")])


@route(r"/beyanname", roles=())
def beyanname_index(req):
    conn = db.get_conn()
    bugun = datetime.date.today()
    ay = req.q("ay") or f"{bugun.year:04d}-{bugun.month:02d}"
    if len(ay) != 7 or ay[4] != "-":
        ay = f"{bugun.year:04d}-{bugun.month:02d}"
    yil, ay_no = int(ay[:4]), int(ay[5:7])

    sid = db.sirket_id(req)
    kdv = _kdv_aylik(conn, sid)
    # 12 aylık devredenli KDV tablosu (kümülatif devreden — saf fonksiyon)
    satirlar = _devreden_satirlar(kdv, yil, ay_no)

    oran_s, oran_a = _kdv_oranlar(conn, sid)
    gv = _gecici_vergi(conn, yil, ay_no, sid)
    nakit = _nakit_kdv(conn, yil, sid)
    eslesmemis = _gelen_eslesmemis(conn, sid)
    # GM çapraz doğrulama
    gm_hesaplanan = conn.execute(
        "SELECT COALESCE(SUM(k.alacak-k.borc),0) s FROM yevmiye_kalem k JOIN hesap h ON h.id=k.hesap_id "
        "JOIN yevmiye y ON y.id=k.yevmiye_id WHERE y.durum='Onaylandı' AND h.kod='391' "
        "AND y.sirket_id=?", (sid,)).fetchone()["s"]
    gm_indirilecek = conn.execute(
        "SELECT COALESCE(SUM(k.borc-k.alacak),0) s FROM yevmiye_kalem k JOIN hesap h ON h.id=k.hesap_id "
        "JOIN yevmiye y ON y.id=k.yevmiye_id WHERE y.durum='Onaylandı' AND h.kod='191' "
        "AND y.sirket_id=?", (sid,)).fetchone()["s"]

    # F5-C (v1.37.0) — üst özet kartlar + KDV oran grafikleri + eşleşmemiş vurgusu
    aktif = satirlar[ay_no - 1]
    oran_s_svg = _kdv_oran_svg(oran_s, color_m="#4f8cff", color_k="#f0a34a")
    oran_a_svg = _kdv_oran_svg(oran_a, color_m="#4f8cff", color_k="#f0a34a")

    conn.close()
    return render_template(
        "beyanname/index.html", ay=ay, yil=yil, ay_no=ay_no,
        satirlar=satirlar, oran_s=oran_s, oran_a=oran_a, gv=gv, nakit=nakit,
        eslesmemis=eslesmemis, eslesmemis_adet=len(eslesmemis),
        aktif=aktif, oran_s_svg=oran_s_svg, oran_a_svg=oran_a_svg,
        gm_hesaplanan=gm_hesaplanan, gm_indirilecek=gm_indirilecek,
        AY_AD=AY_AD,
    )


@route(r"/beyanname/denetim", roles=())
def beyanname_denetim(req):
    conn = db.get_conn()
    bugun = datetime.date.today()
    ay = req.q("ay") or f"{bugun.year:04d}-{bugun.month:02d}"
    if len(ay) != 7 or ay[4] != "-":
        ay = f"{bugun.year:04d}-{bugun.month:02d}"

    satis = [dict(r) for r in conn.execute(
        "SELECT f.fatura_no, f.tarih, c.unvan, f.ara_toplam matrah, f.kdv_toplam kdv, "
        "f.genel_toplam genel, f.para_birimi pb, f.doviz_kur kur "
        "FROM fatura f LEFT JOIN cari_kart c ON c.id=f.cari_id "
        "WHERE f.durum='Onaylandı' AND f.tip='Satis' AND substr(f.tarih,1,7)=? AND f.sirket_id=? "
        "ORDER BY f.tarih, f.id", (ay, db.sirket_id(req))).fetchall()]
    alislar = [dict(r) for r in conn.execute(
        "SELECT f.fatura_no, f.tarih, c.unvan, f.ara_toplam matrah, f.kdv_toplam kdv, "
        "f.genel_toplam genel, f.para_birimi pb, f.doviz_kur kur "
        "FROM fatura f LEFT JOIN cari_kart c ON c.id=f.cari_id "
        "WHERE f.durum='Onaylandı' AND f.tip='Alis' AND substr(f.tarih,1,7)=? AND f.sirket_id=? "
        "ORDER BY f.tarih, f.id", (ay, db.sirket_id(req))).fetchall()]

    def _tl(r):
        return round((r["matrah"] or 0) * (r["kur"] or 1), 2), \
               round((r["kdv"] or 0) * (r["kur"] or 1), 2)

    for r in satis:
        r["matrah_tl"], r["kdv_tl"] = _tl(r)
    for r in alislar:
        r["matrah_tl"], r["kdv_tl"] = _tl(r)
    t_hesaplanan = round(sum(r["kdv_tl"] for r in satis), 2)
    t_indirilecek = round(sum(r["kdv_tl"] for r in alislar), 2)

    # GM aylık çapraz doğrulama
    gm = conn.execute(
        "SELECT h.kod, COALESCE(SUM(k.borc),0) borc, COALESCE(SUM(k.alacak),0) alacak "
        "FROM yevmiye_kalem k JOIN hesap h ON h.id=k.hesap_id JOIN yevmiye y ON y.id=k.yevmiye_id "
        "WHERE y.durum='Onaylandı' AND substr(y.tarih,1,7)=? AND h.kod IN ('391','191') "
        "AND y.sirket_id=? GROUP BY h.kod", (ay, db.sirket_id(req))).fetchall()
    gm_map = {r["kod"]: round(r["alacak"] - r["borc"], 2) if r["kod"] == "391"
              else round(r["borc"] - r["alacak"], 2) for r in gm}
    conn.close()
    return render_template(
        "beyanname/denetim.html", ay=ay, satis=satis, alislar=alislar,
        t_hesaplanan=t_hesaplanan, t_indirilecek=t_indirilecek,
        gm_391=gm_map.get("391", 0.0), gm_191=gm_map.get("191", 0.0),
    )


@route(r"/beyanname/denetim/csv", roles=("Admin", "Muhasebe"))
def beyanname_denetim_csv(req):
    conn = db.get_conn()
    bugun = datetime.date.today()
    ay = req.q("ay") or f"{bugun.year:04d}-{bugun.month:02d}"
    if len(ay) != 7 or ay[4] != "-":
        ay = f"{bugun.year:04d}-{bugun.month:02d}"
    rows = conn.execute(
        "SELECT f.tip, f.fatura_no, f.tarih, c.unvan, c.kod, f.ara_toplam matrah, "
        "f.kdv_toplam kdv, f.genel_toplam genel, f.para_birimi pb, f.doviz_kur kur "
        "FROM fatura f LEFT JOIN cari_kart c ON c.id=f.cari_id "
        "WHERE f.durum='Onaylandı' AND substr(f.tarih,1,7)=? AND f.sirket_id=? "
        "ORDER BY f.tarih, f.id", (ay, db.sirket_id(req))).fetchall()
    conn.close()
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";", lineterminator="\r\n")
    w.writerow(["Tip", "Belge No", "Tarih", "Cari Kod", "Cari Unvan", "Matrah",
                "KDV", "Genel Toplam", "Para Birimi", "Kur", "Matrah TL", "KDV TL"])
    for r in rows:
        kur = r["kur"] or 1
        w.writerow([r["tip"], r["fatura_no"], r["tarih"], r["kod"], r["unvan"],
                    round(r["matrah"] or 0, 2), round(r["kdv"] or 0, 2),
                    round(r["genel"] or 0, 2), r["pb"], kur,
                    round((r["matrah"] or 0) * kur, 2), round((r["kdv"] or 0) * kur, 2)])
    data = "\ufeff" + buf.getvalue()
    return Response(data, "200 OK",
                    [("Content-Type", "text/csv; charset=utf-8"),
                     ("Content-Disposition", f'attachment; filename="beyanname-kdv-{ay}.csv"')])


# --------------------------------------------------------------------------
# F5-C (v1.37.0) — API özet ucu + KDV devreden CSV cetveli
# --------------------------------------------------------------------------
@route(r"/api/beyanname/ozet", roles=())
def api_beyanname_ozet(req):
    conn = db.get_conn()
    bugun = datetime.date.today()
    ay = req.q("ay") or f"{bugun.year:04d}-{bugun.month:02d}"
    if len(ay) != 7 or ay[4] != "-":
        ay = f"{bugun.year:04d}-{bugun.month:02d}"
    yil, ay_no = int(ay[:4]), int(ay[5:7])
    sid = db.sirket_id(req)
    kdv = _kdv_aylik(conn, sid)
    satirlar = _devreden_satirlar(kdv, yil, ay_no)
    aktif = satirlar[ay_no - 1]
    gv = _gecici_vergi(conn, yil, ay_no, sid)
    nakit = _nakit_kdv(conn, yil, sid)
    eslesmemis_adet = len(_gelen_eslesmemis(conn, sid))
    conn.close()
    return _json({
        "ay": ay,
        "hesaplanan": aktif["hesaplanan"],
        "indirilecek": aktif["indirilecek"],
        "odenecek": aktif["odenecek"],
        "devreden_sonraki": aktif["devreden_son"],
        "devreden_tablo": satirlar,
        "gecici_vergi": {"ceyrek": gv["ceyrek"], "matrah": gv["matrah"],
                         "odenecek": gv["odenecek"]},
        "nakit": {"odenecek": nakit["odenecek"]},
        "eslesmemis_adet": eslesmemis_adet,
    })


@route(r"/beyanname/kdv/csv", roles=("Admin", "Muhasebe"))
def beyanname_kdv_csv(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    yil = (req.q("yil") or "").strip()
    if not (len(yil) == 4 and yil.isdigit()):
        yil = str(datetime.date.today().year)
    kdv = _kdv_aylik(conn, sid)
    satirlar = _devreden_satirlar(kdv, int(yil), 0)
    conn.close()
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";", lineterminator="\r\n")
    w.writerow(["Ay", "Hesaplanan KDV", "Indirilecek KDV", "Devreden (Onceki)",
                "Odenecek", "Devreden (Sonraki)"])
    for s in satirlar:
        w.writerow([s["ay"], round(s["hesaplanan"], 2), round(s["indirilecek"], 2),
                    round(s["devreden_on"], 2), round(s["odenecek"], 2),
                    round(s["devreden_son"], 2)])
    data = "\ufeff" + buf.getvalue()
    return Response(data, "200 OK",
                    [("Content-Type", "text/csv; charset=utf-8"),
                     ("Content-Disposition", f'attachment; filename="kdv-devreden-{yil}.csv"')])


def register():
    return "beyanname"
