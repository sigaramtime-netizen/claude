# -*- coding: utf-8 -*-
"""Teklif/Sipariş manuel (serbest metin) satır testleri (İstek 1).

Çalıştırma: sunucu 8080'de çalışırken  python3 test_teklif_siparis_manuel.py
"""
import sqlite3
import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"


def q1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def qall(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def temizle_teklif(tid):
    c = sqlite3.connect(DB)
    c.execute("DELETE FROM audit_log WHERE tablo='teklif' AND kayit_id=?", (tid,))
    c.execute("DELETE FROM teklif_kalem WHERE teklif_id=?", (tid,))
    c.execute("DELETE FROM teklif WHERE id=?", (tid,))
    c.commit(); c.close()


def temizle_siparis(sid, stok_id, depo_id, rezerve_geri):
    c = sqlite3.connect(DB)
    c.execute("DELETE FROM audit_log WHERE tablo='siparis' AND kayit_id=?", (sid,))
    c.execute("DELETE FROM siparis_kalem WHERE siparis_id=?", (sid,))
    c.execute("DELETE FROM siparis WHERE id=?", (sid,))
    if rezerve_geri:
        c.execute("UPDATE stok_seviye SET rezerve = MAX(rezerve - ?, 0) WHERE stok_id=? AND varyant_id=0 AND depo_id=?",
                  (rezerve_geri, stok_id, depo_id))
    c.commit(); c.close()


def giris():
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": "admin", "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302 and "erp_session" in s.cookies.get_dict(), "giriş başarısız"
    return s


ok = []
fail = []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else ""))


admin = giris()

musteri = q1("SELECT id, unvan FROM cari_kart WHERE aktif=1 AND tip IN ('Musteri','HerIkisi') ORDER BY id LIMIT 1")
stok = q1("SELECT id, ad, satis_fiyat, birim FROM stok_kart WHERE aktif=1 ORDER BY id LIMIT 1")
sev = q1("SELECT depo_id, miktar, rezerve FROM stok_seviye WHERE stok_id=? AND varyant_id=0 ORDER BY depo_id LIMIT 1", stok["id"])
print(f"Kaynaklar: müşteri={musteri['id']} {musteri['unvan']} | stok={stok['id']} {stok['ad']} ({stok['birim']}) | depo={sev['depo_id']}")

# ======================================================================
print("\n" + "=" * 70)
print("TEST T — Teklif: stok + manuel satır (birim + görünen ad taşınır)")
print("=" * 70)
r = admin.post(BASE + "/teklif/yeni", data=[
    ("cari_id", str(musteri["id"])), ("tarih", "2026-09-08"), ("gecerlilik_tarihi", "2026-10-08"),
    ("aciklama", "TST-T manuel"), ("action", "kaydet"),
    ("k_stok_id", str(stok["id"])), ("k_stok_id", ""),
    ("k_varyant_id", "0"), ("k_varyant_id", "0"),
    ("k_manuel_ad", ""), ("k_manuel_ad", "Kargo Ücreti"),
    ("k_birim", stok["birim"]), ("k_birim", "Adet"),
    ("k_goruntu_ad", "Özel Tanıtım Adı"), ("k_goruntu_ad", ""),
    ("k_miktar", "2"), ("k_miktar", "1"),
    ("k_birim_fiyat", str(stok["satis_fiyat"])), ("k_birim_fiyat", "200"),
    ("k_iskonto", "0"), ("k_iskonto", "0"),
    ("k_kdv", "20"), ("k_kdv", "20"),
], allow_redirects=False)
tid = q1("SELECT id FROM teklif WHERE aciklama='TST-T manuel' ORDER BY id DESC")["id"]
k = qall("SELECT stok_id, varyant_id, aciklama, birim, goruntu_adi, tutar FROM teklif_kalem WHERE teklif_id=? ORDER BY id", tid)
check("T1 teklif oluştu", bool(tid), f"id={tid}")
check("T2 kalemler: stok + manuel(NULL stok_id)",
      [x["stok_id"] for x in k] == [stok["id"], None],
      f"{[(x['stok_id'], x['aciklama']) for x in k]}")
check("T3 manuel açıklama korundu", k[1]["aciklama"] == "Kargo Ücreti", k[1]["aciklama"])
check("T4 stoklu satırda birim + görünen ad korundu",
      k[0]["birim"] == stok["birim"] and k[0]["goruntu_adi"] == "Özel Tanıtım Adı",
      f"birim={k[0]['birim']} ga={k[0]['goruntu_adi']}")
check("T5 manuel satırda birim korundu", k[1]["birim"] == "Adet", k[1]["birim"])
check("T6 tutarlar: stok net + manuel net", (k[0]["tutar"], k[1]["tutar"]) ==
      (round(2 * stok["satis_fiyat"], 2), 200.0), f"{k[0]['tutar']}/{k[1]['tutar']}")
# teklif stoğa dokunmaz
hk = q1("SELECT COUNT(*) c FROM stok_hareket WHERE ilgili_modul='Teklif' AND ilgili_kayit_id=?", tid)
check("T7 teklif stok hareketi üretmez", hk["c"] == 0)
# teklif → sipariş kaynak taşıma
r = admin.get(BASE + f"/siparis/yeni?kaynak_teklif={tid}")
check("T8 teklif→sipariş manuel satırı taşır", "Kargo Ücreti" in r.text and "Özel Tanıtım Adı" in r.text)

# ======================================================================
print("\n" + "=" * 70)
print("TEST S — Sipariş (Müşteri): stok + manuel; onay K11 manueli atlar")
print("=" * 70)
rezer_bas = (sev["rezerve"] or 0)
r = admin.post(BASE + "/siparis/yeni", data=[
    ("tip", "Musteri"), ("cari_id", str(musteri["id"])), ("depo_id", str(sev["depo_id"])),
    ("tarih", "2026-09-08"), ("teslim_tarihi", ""), ("aciklama", "TST-S manuel"),
    ("action", "kaydet"),
    ("k_stok_id", str(stok["id"])), ("k_stok_id", ""),
    ("k_varyant_id", "0"), ("k_varyant_id", "0"),
    ("k_manuel_ad", ""), ("k_manuel_ad", "Montaj Hizmeti"),
    ("k_birim", stok["birim"]), ("k_birim", "Adet"),
    ("k_goruntu_ad", ""), ("k_goruntu_ad", ""),
    ("k_miktar", "1"), ("k_miktar", "1"),
    ("k_birim_fiyat", str(stok["satis_fiyat"])), ("k_birim_fiyat", "300"),
    ("k_iskonto", "0"), ("k_iskonto", "0"),
    ("k_kdv", "20"), ("k_kdv", "20"),
], allow_redirects=False)
sid = q1("SELECT id FROM siparis WHERE aciklama='TST-S manuel' ORDER BY id DESC")["id"]
k = qall("SELECT stok_id, aciklama, birim, teslim_edilen FROM siparis_kalem WHERE siparis_id=? ORDER BY id", sid)
check("S1 sipariş oluştu", bool(sid), f"id={sid}")
check("S2 kalemler: stok + manuel", [x["stok_id"] for x in k] == [stok["id"], None],
      f"{[(x['stok_id'], x['aciklama']) for x in k]}")
check("S3 manuel açıklama + birim", k[1]["aciklama"] == "Montaj Hizmeti" and k[1]["birim"] == "Adet")
# onay — manuel satır stok yeterlilik kontrolüne girmez (K11)
r = admin.post(BASE + f"/siparis/{sid}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
durum = q1("SELECT durum FROM siparis WHERE id=?", sid)["durum"]
sev2 = q1("SELECT rezerve FROM stok_seviye WHERE stok_id=? AND varyant_id=0 AND depo_id=?", stok["id"], sev["depo_id"])
check("S4 onay başarılı", durum == "Onaylandı", durum)
check("S5 rezervasyon yalnız stoklu satır için (1 adet)",
      (sev2["rezerve"] or 0) == rezer_bas + 1, f"{rezer_bas} → {sev2['rezerve']}")
# irsaliye → sipariş manuel satırı taşır
r = admin.get(BASE + f"/irsaliye/yeni?kaynak_siparis={sid}")
check("S6 sipariş→irsaliye manuel satırı taşır", "Montaj Hizmeti" in r.text)
# iptal — manuel rezervasyonu etkilememeli
admin.post(BASE + f"/siparis/{sid}/durum", data={"durum": "İptal"}, allow_redirects=False)
sev3 = q1("SELECT rezerve FROM stok_seviye WHERE stok_id=? AND varyant_id=0 AND depo_id=?", stok["id"], sev["depo_id"])
check("S7 iptal rezervasyonu geri alır", (sev3["rezerve"] or 0) == rezer_bas, f"{sev3['rezerve']}")

# ---- temizlik ----
temizle_teklif(tid)
temizle_siparis(sid, stok["id"], sev["depo_id"], 0)
print("\nTemizlik tamam.")

print("\n" + "=" * 70)
print(f"SONUÇ: {len(ok)} başarılı / {len(fail)} başarısız")
if fail:
    print("BAŞARISIZ:", fail)
    raise SystemExit(1)
print("TÜM TESTLER GEÇTİ ✅")
