# -*- coding: utf-8 -*-
"""F5-A — Finansal Analiz & Dashboard Cilası v1.35.0 e2e testi.

GM D003 direktifindeki 18 senaryo, canlı sunucuya HTTP ile. Kurallar:
- Yeni tablo yalnız `butce_hedef`; UNIQUE(sirket_id, yil, ay).
- Kar = fatura kalem tutar (TL) − (stok.alis_fiyat × miktar)  [satış fiyatı DEĞİL].
- Bütçe kaydı mali tabloya dokunmaz (cari_hareket / yevmiye artmaz).
- K1: bütçe şirket izolasyonu.
- Finansal Analiz yalnız Admin + Muhasebe (Depo → 403).
- F1/F4 bozulmaz; MARK="F5ATEST" ile kalıntı bırakılmaz.

Çalıştırma: sunucu 8080'de çalışırken  python3 test_f5a_finansal.py
"""
import datetime
import sqlite3

import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
MARK = "F5ATEST"

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print((("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else "")))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris(kadi="admin"):
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": kadi, "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, f"giriş başarısız: {kadi}"
    return s


def butce_kaydet(s, yil, ay, hs, hk):
    return s.post(BASE + "/finansal/butce/kaydet",
                  data={"yil": yil, "ay": ay, "hedef_satis": hs, "hedef_kar": hk},
                  allow_redirects=False)


# ---- idempotent temizlik (önceki koşulardan kalıntı varsa) -----------------
def temizle():
    # test faturaları + kalem + hareket + yevmiye + audit
    for fid in [r["id"] for r in db("SELECT id FROM fatura WHERE aciklama LIKE ?", f"%{MARK}%")]:
        dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN "
            "(SELECT id FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?)", fid)
        dbx("DELETE FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?", fid)
        dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
        dbx("DELETE FROM stok_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
        dbx("DELETE FROM audit_log WHERE tablo='fatura' AND kayit_id=?", fid)
        dbx("DELETE FROM fatura_kalem WHERE fatura_id=?", fid)
        dbx("DELETE FROM fatura WHERE id=?", fid)
    # test stokları
    for sid in [r["id"] for r in db("SELECT id FROM stok_kart WHERE kod LIKE ?", f"{MARK}%")]:
        dbx("DELETE FROM stok_hareket WHERE stok_id=?", sid)
        dbx("DELETE FROM audit_log WHERE tablo='stok_kart' AND kayit_id=?", sid)
        dbx("DELETE FROM stok_kart WHERE id=?", sid)
    # test kasa hareketleri
    dbx("DELETE FROM kasa_hareket WHERE aciklama LIKE ?", f"%{MARK}%")
    dbx("DELETE FROM banka_hareket WHERE aciklama LIKE ?", f"%{MARK}%")
    # test bütçe hedefleri (2026-09/10)
    dbx("DELETE FROM butce_hedef WHERE yil=2026 AND ay IN (9,10)")
    # test şirketi (K1)
    for s2 in [r["id"] for r in db("SELECT id FROM sirket WHERE kod=?", f"{MARK}B")]:
        dbx("DELETE FROM butce_hedef WHERE sirket_id=?", s2)
        dbx("DELETE FROM kullanici_sirket WHERE sirket_id=?", s2)
        dbx("DELETE FROM entegrator_ayar WHERE sirket_id=?", s2)
        dbx("DELETE FROM sirket WHERE id=?", s2)


def fatura_kaydet(s, stok_id, fiyat, miktar="1", kdv="20"):
    satir = [("k_stok_id", stok_id), ("k_varyant_id", "0"), ("k_manuel_ad", ""),
             ("k_birim", "Adet"), ("k_goruntu_ad", ""), ("k_miktar", miktar),
             ("k_birim_fiyat", fiyat), ("k_iskonto", "0"), ("k_kdv", kdv)]
    r = s.post(BASE + "/fatura/yeni",
               data=[("tip", "Satis"), ("cari_id", "1"),
                     ("tarih", datetime.date.today().isoformat()), ("para_birimi", "TRY"),
                     ("aciklama", MARK + " kar testi"),
                     ("action", "kaydet")] + satir, allow_redirects=False)
    loc = (r.headers.get("Location") or "").rstrip("/")
    return int(loc.split("/")[-1])


def onayla(s, fid):
    s.post(BASE + f"/fatura/{fid}/durum", data={"durum": "Onaylandı"},
           allow_redirects=False)


temizle()

# ============================================================================
print("=" * 72)
print("F5-A v1.35.0 — 18 kontrol (canlı sunucuya HTTP)")
print("=" * 72)
admin = giris("admin")

# 1) test_butce_olustur -------------------------------------------------------
butce_kaydet(admin, "2026", "9", "100000", "20000")
r = db1("SELECT * FROM butce_hedef WHERE sirket_id=1 AND yil=2026 AND ay=9")
check("1. test_butce_olustur", r and abs(r["hedef_satis"] - 100000) < 0.01
      and abs(r["hedef_kar"] - 20000) < 0.01,
      f"hedef_satis={r['hedef_satis'] if r else None}, hedef_kar={r['hedef_kar'] if r else None}")

# 2) test_butce_guncelle -------------------------------------------------------
butce_kaydet(admin, "2026", "9", "120000", "25000")
sat = db("SELECT * FROM butce_hedef WHERE sirket_id=1 AND yil=2026 AND ay=9")
check("2. test_butce_guncelle", len(sat) == 1 and abs(sat[0]["hedef_satis"] - 120000) < 0.01
      and abs(sat[0]["hedef_kar"] - 25000) < 0.01,
      f"satır={len(sat)}, hedef_satis={sat[0]['hedef_satis'] if sat else None} (UNIQUE upsert)")

# 3) test_butce_k1 (Şirket B'de A bütçesi görünmez) ---------------------------
dbx("INSERT INTO sirket(kod, unvan, aktif) VALUES(?,?,1)", f"{MARK}B", f"{MARK} İkinci Şirket")
s2 = db1("SELECT id FROM sirket WHERE kod=?", f"{MARK}B")["id"]
dbx("INSERT OR IGNORE INTO kullanici_sirket(kullanici_id, sirket_id) "
    "SELECT id, ? FROM kullanici WHERE kullanici_adi='admin'", s2)
admin.post(BASE + "/sirket/gec", data={"sirket_id": str(s2), "next": "/"}, allow_redirects=False)
api_b = admin.get(BASE + "/api/finansal/ozet?donem=aylik").json()
sayfa_b = admin.get(BASE + "/finansal/butce?yil=2026").text
gorunmez = (api_b["butce"]["hedef_satis"] == 0.0) and ("100.000,00" not in sayfa_b)
admin.post(BASE + "/sirket/gec", data={"sirket_id": "1", "next": "/"}, allow_redirects=False)
check("3. test_butce_k1", gorunmez,
      f"B'de hedef_satis={api_b['butce']['hedef_satis']} (A'nın 100000'i görünmemeli)")

# 4) test_butce_sil ------------------------------------------------------------
bid = db1("SELECT id FROM butce_hedef WHERE sirket_id=1 AND yil=2026 AND ay=9")["id"]
admin.post(BASE + f"/finansal/butce/{bid}/sil", allow_redirects=False)
check("4. test_butce_sil",
      db1("SELECT COUNT(*) c FROM butce_hedef WHERE id=?", bid)["c"] == 0, "DB'den silindi")

# 5) test_api_ozet_aylik --------------------------------------------------------
d = admin.get(BASE + "/api/finansal/ozet?donem=aylik").json()
check("5. test_api_ozet_aylik", all(k in d for k in ("satis", "alis", "kar"))
      and isinstance(d["satis"], (int, float)),
      f"satis={d.get('satis')}, alis={d.get('alis')}, kar={d.get('kar')}")

# 6) test_api_ozet_haftalik -----------------------------------------------------
d = admin.get(BASE + "/api/finansal/ozet?donem=haftalik").json()
check("6. test_api_ozet_haftalik", d.get("donem") == "haftalik"
      and all(k in d for k in ("satis", "alis", "kar")),
      f"donem={d.get('donem')}")

# 7) test_kar_hesabi (satış 1000, alış 700, %20 KDV → kar 300) -----------------
dbx("INSERT INTO stok_kart(kod, ad, birim, kdv_orani, otv_orani, alis_fiyat, satis_fiyat, "
    "para_birimi, iskonto_orani, kritik_stok, seri_lot_takibi, varyant_takibi, aktif, "
    "created_at, tip, garanti_suresi_ay, sirket_id) "
    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now','localtime'),?,?,1)",
    f"{MARK}-STK-001", f"{MARK} Test Ürünü", "Adet", 20, 0, 700, 1000, "TRY", 0, 0, 0, 0, 1,
    "Urun", 0)
stok_id = db1("SELECT id FROM stok_kart WHERE kod=?", f"{MARK}-STK-001")["id"]
fid = fatura_kaydet(admin, str(stok_id), "1000", "1", "20")
onayla(admin, fid)
kar_sql = db1("SELECT (fk.birim_fiyat*COALESCE(f.doviz_kur,1)-s.alis_fiyat)*fk.miktar k "
              "FROM fatura_kalem fk JOIN fatura f ON f.id=fk.fatura_id "
              "JOIN stok_kart s ON s.id=fk.stok_id WHERE f.id=?", fid)
genel = db1("SELECT genel_toplam g FROM fatura WHERE id=?", fid)
check("7. test_kar_hesabi", kar_sql and abs(kar_sql["k"] - 300.0) < 0.01,
      f"kar={kar_sql['k'] if kar_sql else None} (1000-700), genel_toplam={genel['g'] if genel else None}")

# 8) test_nakit_akis ------------------------------------------------------------
bugun = datetime.date.today().isoformat()
dbx("INSERT INTO kasa_hareket(kasa_id, tarih, islem_tipi, tutar, aciklama, para_birimi, "
    "doviz_kur, created_at, sirket_id) VALUES(1,?,?,?,?,?,?,datetime('now','localtime'),1)",
    bugun, "Nakit Girişi", 5000, f"{MARK} nakit testi", "TRY", 1)
d = admin.get(BASE + "/api/finansal/ozet?donem=aylik").json()
gun_bugun = next((g for g in d["nakit_akis"] if g["tarih"] == bugun), None)
check("8. test_nakit_akis", gun_bugun is not None and gun_bugun["giris"] >= 5000,
      f"bugün giriş={gun_bugun['giris'] if gun_bugun else None}")

# 9) test_dashboard_kartlar ------------------------------------------------------
html = admin.get(BASE + "/").text
kartlar = ["Bugün Satış", "Bu Ay Satış", "Bu Ay Kâr", "Kasa Toplam", "Banka Toplam", "Açık Servis"]
check("9. test_dashboard_kartlar", all(k in html for k in kartlar),
      f"{sum(k in html for k in kartlar)}/6 kart mevcut")

# 10) test_dashboard_butce_sapma -------------------------------------------------
butce_kaydet(admin, "2026", "9", "100000", "20000")
ay_satis = db1("SELECT COALESCE(SUM(borc),0) s FROM cari_hareket "
               "WHERE belge_tipi IN ('Satış Faturası','Satış İrsaliyesi') "
               "AND tarih>=? AND sirket_id=1", "2026-09-01")["s"]
beklenen = round((ay_satis - 100000) / 100000 * 100, 1)
rozet = f"{'+' if beklenen > 0 else ''}{beklenen}%"
html = admin.get(BASE + "/").text
check("10. test_dashboard_butce_sapma", rozet in html,
      f"hedef 100.000, gerçekleşen {ay_satis:,.2f} → rozet '{rozet}'")

# 11) test_en_cok_satan -----------------------------------------------------------
d = admin.get(BASE + "/api/finansal/ozet?donem=aylik").json()
satan = d["en_cok_satan"]
sirali = all(satan[i]["adet"] >= satan[i + 1]["adet"] for i in range(len(satan) - 1))
check("11. test_en_cok_satan", len(satan) >= 1 and satan[0]["adet"] > 0 and sirali,
      f"{len(satan)} ürün, top miktar={satan[0]['adet'] if satan else None}")

# 12) test_en_karli ----------------------------------------------------------------
karlilar = d["en_karli"]
kar_dogruluk = True
if karlilar:
    en_k = karlilar[0]
    kar_sql2 = db1("SELECT (fk.birim_fiyat*COALESCE(f.doviz_kur,1)-s.alis_fiyat)*fk.miktar k "
                   "FROM fatura_kalem fk JOIN fatura f ON f.id=fk.fatura_id "
                   "JOIN stok_kart s ON s.id=fk.stok_id WHERE s.kod=?", en_k["kod"])
    kar_dogruluk = kar_sql2 is None or abs(kar_sql2["k"] - en_k["kar"]) < 0.01
check("12. test_en_karli", len(karlilar) >= 1 and kar_dogruluk,
      f"{len(karlilar)} ürün; kar = satış − maliyet doğrulandı mı: {kar_dogruluk}")

# 13) test_en_cok_ciro_cari ---------------------------------------------------------
cariler = d["en_cok_ciro_cari"]
sirali2 = all(cariler[i]["ciro"] >= cariler[i + 1]["ciro"] for i in range(len(cariler) - 1))
check("13. test_en_cok_ciro_cari", len(cariler) >= 1 and cariler[0]["ciro"] > 0 and sirali2,
      f"{len(cariler)} cari, top ciro={cariler[0]['ciro'] if cariler else None}")

# 14) test_donem_karsilastirma --------------------------------------------------------
kk = d.get("donem_karsilastirma") or {}
check("14. test_donem_karsilastirma", all(k in kk for k in ("bu_ay", "gecen_ay", "gecen_yil")),
      f"anahtarlar={sorted(kk.keys())}")

# 15) test_yetki (depo → 403) ----------------------------------------------------------
depo = giris("depo")
r = depo.get(BASE + "/finansal/butce", allow_redirects=False)
r2 = depo.get(BASE + "/api/finansal/ozet?donem=aylik", allow_redirects=False)
check("15. test_yetki", r.status_code == 403 and r2.status_code == 403,
      f"/finansal/butce={r.status_code}, /api/finansal/ozet={r2.status_code}")

# 16) test_f1_korundu (bütçe kaydı mali etki üretmez) ----------------------------------
cari_once = db1("SELECT COUNT(*) c FROM cari_hareket")["c"]
yev_once = db1("SELECT COUNT(*) c FROM yevmiye")["c"]
butce_kaydet(admin, "2026", "10", "50000", "8000")
cari_sonra = db1("SELECT COUNT(*) c FROM cari_hareket")["c"]
yev_sonra = db1("SELECT COUNT(*) c FROM yevmiye")["c"]
check("16. test_f1_korundu", cari_once == cari_sonra and yev_once == yev_sonra,
      f"cari_hareket {cari_once}→{cari_sonra}, yevmiye {yev_once}→{yev_sonra}")

# 17) test_f4_korundu (e-Dönüşüm + typeahead) -------------------------------------------
r_edo = admin.get(BASE + "/edonusum", allow_redirects=False)
r_ara = admin.get(BASE + "/api/ara", params={"q": "TV"}, allow_redirects=False)
check("17. test_f4_korundu", r_edo.status_code == 200 and r_ara.status_code == 200
      and isinstance(r_ara.json(), list),
      f"/edonusum={r_edo.status_code}, /api/ara={r_ara.status_code}")

# ---- temizlik + 18) kalıntı kontrolü ------------------------------------------------
# test faturası sil
for fid2 in [r["id"] for r in db("SELECT id FROM fatura WHERE aciklama LIKE ?", f"%{MARK}%")]:
    dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN "
        "(SELECT id FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?)", fid2)
    dbx("DELETE FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?", fid2)
    dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid2)
    dbx("DELETE FROM stok_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid2)
    dbx("DELETE FROM audit_log WHERE tablo='fatura' AND kayit_id=?", fid2)
    dbx("DELETE FROM fatura_kalem WHERE fatura_id=?", fid2)
    dbx("DELETE FROM fatura WHERE id=?", fid2)
dbx("DELETE FROM stok_hareket WHERE stok_id=?", stok_id)
dbx("DELETE FROM audit_log WHERE tablo='stok_kart' AND kayit_id=?", stok_id)
dbx("DELETE FROM stok_kart WHERE id=?", stok_id)
dbx("DELETE FROM kasa_hareket WHERE aciklama LIKE ?", f"%{MARK}%")
dbx("DELETE FROM butce_hedef WHERE yil=2026 AND ay IN (9,10)")
dbx("DELETE FROM butce_hedef WHERE sirket_id=?", s2)
dbx("DELETE FROM kullanici_sirket WHERE sirket_id=?", s2)
dbx("DELETE FROM entegrator_ayar WHERE sirket_id=?", s2)
dbx("DELETE FROM sirket WHERE id=?", s2)

fk_check = db("PRAGMA foreign_key_check")
kalinti = {
    "fatura": db("SELECT COUNT(*) c FROM fatura WHERE aciklama LIKE ?", f"%{MARK}%")[0]["c"],
    "stok": db("SELECT COUNT(*) c FROM stok_kart WHERE kod LIKE ?", f"{MARK}%")[0]["c"],
    "kasa": db("SELECT COUNT(*) c FROM kasa_hareket WHERE aciklama LIKE ?", f"%{MARK}%")[0]["c"],
    "butce": db("SELECT COUNT(*) c FROM butce_hedef WHERE yil=2026 AND ay IN (9,10)")[0]["c"],
    "sirket": db("SELECT COUNT(*) c FROM sirket WHERE kod=?", f"{MARK}B")[0]["c"],
}
temiz_mi = len(fk_check) == 0 and all(v == 0 for v in kalinti.values())
check("18. test_fk_kalinti", temiz_mi,
      f"foreign_key_check={len(fk_check)} satır, kalıntı={kalinti}")

print("=" * 72)
print(f"SONUÇ: {len(ok)}/18 geçti, {len(fail)} başarısız")
if fail:
    print("BAŞARISIZ:", fail)
    raise SystemExit(1)
print("TÜM KONTROLLER GEÇTİ ✅")
