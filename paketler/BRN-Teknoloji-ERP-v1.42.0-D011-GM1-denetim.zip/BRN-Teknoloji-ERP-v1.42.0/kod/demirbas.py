# -*- coding: utf-8 -*-
"""Demirbaş (1.22) — Faz 5. Sabit kıymet/demirbaş kaydı + amortisman + zimmet takibi.

TASARIM (şartname 1.22 + kullanıcı kararları):
- Yeni veri modeli (4 tablo): demirbas_kategori, demirbas, demirbas_amortisman, demirbas_zimmet.
  Demirbaş daha önce hiçbir yerde tutulmadığından yeni tablolar gereklidir (K4/K6'nın "ikinci
  doğruluk kaynağı açma" kuralı ihlal edilmez — mevcut veri çoğaltılmaz).
- Amortisman: NORMAL (eşit paylı, VUK). Aylık pay = (maliyet − hurda) / (ömür_yıl × 12).
  Ömür: kategori varsayılanı + kart bazlı düzeltme (omur_yil NULL = kategori).
- GM entegrasyonu (K26): her aylık amortisman 770 (borç) / 257 (alacak) yevmiye fişi üretir —
  kaynak_modul='Demirbas', kaynak_id=demirbas.id, kaynak_sahne=donem (idempotent).
- Tetik: (1) elle "Amortisman Üret" (POST, seçilen aya kadar) + (2) aylık otomatik — Admin/Muhasebe
  /demirbas'ı açtığında eksik aylar üretilir (kapanış akışı; cron yok).
- Zimmet: kartta güncel (zimmetli_kullanici_id + sube_id, K1) + demirbas_zimmet geçmişi
  (Teslim/Devir/İade). Çıkış (Satıldı/Hurda) amortismanı durdurur; net değer mahsubu manueldir.
"""
import datetime
import io
import json

from core import route, render_template, redirect, flash, audit, izole_sube, sube_koruma, Response
import db
import muhasebe

DEMIRBAS_WRITE = ("Admin", "Muhasebe")
AY_AD = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran",
         "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]
DURUM_BADGE = {"Aktif": "b-ok", "Satıldı": "b-warn", "Hurda": "b-danger"}


def _f(v, default=0.0):
    try:
        return float(v if v not in (None, "") else default)
    except (TypeError, ValueError):
        return default


def _i(v):
    try:
        return int(v) if v not in (None, "") else None
    except (TypeError, ValueError):
        return None


def _omur(conn, d):
    """Etkin ömür (yıl): kart bazlı düzeltme, yoksa kategori varsayılanı; hiçbiri yoksa 5."""
    if d.get("omur_yil") and float(d["omur_yil"]) > 0:
        return float(d["omur_yil"])
    k = conn.execute("SELECT omur_yil FROM demirbas_kategori WHERE id=?",
                     (d.get("kategori_id"),)).fetchone()
    if k and k["omur_yil"] and float(k["omur_yil"]) > 0:
        return float(k["omur_yil"])
    return 5.0


def _taban(d):
    return max(0.0, _f(d.get("maliyet")) - _f(d.get("hurda_degeri")))


def _ozet(conn, did):
    r = conn.execute(
        "SELECT COALESCE(SUM(tutar),0) b, COUNT(*) n, MAX(donem) son FROM demirbas_amortisman "
        "WHERE demirbas_id=?", (int(did),)).fetchone()
    return (r["b"] or 0.0), (r["n"] or 0), r["son"]


def _amortisman_uret(conn, demirbas_id=None, donem_son=None, sube_id=None, sid=None):
    """Eksik aylık amortismanları + GM fişlerini üret (idempotent). Dönüş: üretilen satır adedi."""
    if donem_son is None:
        donem_son = datetime.date.today().strftime("%Y-%m")
    where = "WHERE durum='Aktif'" + (" AND id=?" if demirbas_id else "")
    args = (int(demirbas_id),) if demirbas_id else ()
    if sube_id:
        where += " AND sube_id=?"
        args = args + (sube_id,)
    if sid is not None:
        where += " AND sirket_id=?"
        args = args + (sid,)
    rows = conn.execute(f"SELECT * FROM demirbas {where} ORDER BY alis_tarihi, id", args).fetchall()
    adet = 0
    for d in rows:
        d = dict(d)
        omur = _omur(conn, d)
        taban = _taban(d)
        alis = (d.get("alis_tarihi") or "")[:7]
        if taban <= 0.005 or omur <= 0 or len(alis) != 7:
            continue
        aylik = taban / (omur * 12.0)
        mevcut = {r["donem"] for r in conn.execute(
            "SELECT donem FROM demirbas_amortisman WHERE demirbas_id=?", (d["id"],)).fetchall()}
        birikmis = conn.execute(
            "SELECT COALESCE(SUM(tutar),0) s FROM demirbas_amortisman WHERE demirbas_id=?",
            (d["id"],)).fetchone()["s"]
        yil, ay = int(alis[:4]), int(alis[5:7])
        for k in range(int(round(omur * 12)) + 2):
            ym = f"{yil + (ay - 1 + k) // 12:04d}-{(ay - 1 + k) % 12 + 1:02d}"
            if ym > donem_son:
                break
            if ym in mevcut:
                continue
            kalan = round(taban - birikmis, 2)
            if kalan <= 0.005:
                break
            tutar = round(min(aylik, kalan), 2)
            if tutar <= 0:
                break
            birikmis = round(birikmis + tutar, 2)
            net = round(taban - birikmis, 2)
            conn.execute(
                "INSERT INTO demirbas_amortisman(demirbas_id, donem, tutar, birikmis, net_deger, sirket_id) "
                "VALUES(?,?,?,?,?, (SELECT sirket_id FROM demirbas WHERE id=?))",
                (d["id"], ym, tutar, birikmis, net, d["id"]))
            muhasebe.fis_uret(conn, "Demirbas", d["id"], sahne=ym)
            mevcut.add(ym)
            adet += 1
    return adet


# --------------------------------------------------------------------------
# F5-B (v1.36.0) — plan / kategori özet / API / CSV / SVG yardımcıları
# --------------------------------------------------------------------------
def _ym_ekle(ym, k):
    """'YYYY-MM' + k ay."""
    y, m = int(ym[:4]), int(ym[5:7])
    idx = y * 12 + (m - 1) + k
    return f"{idx // 12:04d}-{idx % 12 + 1:02d}"


def _ay_fark(ym1, ym2):
    """ym1 - ym2 ay farkı (int)."""
    y1, m1 = int(ym1[:4]), int(ym1[5:7])
    y2, m2 = int(ym2[:4]), int(ym2[5:7])
    return (y1 - y2) * 12 + (m1 - m2)


def _amortisman_plan(conn, d, ay=12):
    """Gelecek `ay` aylık plan: üretilmiş dönemler GERÇEK, üretilmemişler TAHMİNİ.

    Dönüş: [{"donem", "tutar", "birikmis", "net", "gercek":bool}, ...] — başlangıç
    son üretilen dönem (yoksa içinde bulunulan ay), kalan bakiye bitince durur.
    """
    omur = _omur(conn, d)
    taban = _taban(d)
    aylik = taban / (omur * 12.0) if (taban > 0 and omur > 0) else 0.0
    rows = conn.execute(
        "SELECT donem, tutar, birikmis, net_deger FROM demirbas_amortisman "
        "WHERE demirbas_id=? ORDER BY donem", (d["id"],)).fetchall()
    uretilmis = {r["donem"]: r for r in rows}
    bugun_ym = datetime.date.today().strftime("%Y-%m")
    bas = rows[-1]["donem"] if rows else bugun_ym
    birikmis = (rows[-1]["birikmis"] or 0.0) if rows else 0.0
    kalan = round(taban - birikmis, 2)
    plan = []
    for i in range(ay):
        ym = _ym_ekle(bas, i)
        r = uretilmis.get(ym)
        if r:
            plan.append({"donem": ym, "tutar": r["tutar"] or 0.0,
                         "birikmis": r["birikmis"] or 0.0,
                         "net": r["net_deger"] or 0.0, "gercek": True})
            birikmis = r["birikmis"] or 0.0
            kalan = round(taban - birikmis, 2)
            continue
        if kalan <= 0.005:
            break
        tutar = round(min(aylik, kalan), 2)
        birikmis = round(birikmis + tutar, 2)
        kalan = round(taban - birikmis, 2)
        plan.append({"donem": ym, "tutar": tutar, "birikmis": birikmis,
                     "net": round(taban - birikmis, 2), "gercek": False})
    return plan


def _kategori_ozet(conn, sid=None):
    """Kategori bazlı özet: kategori → adet / maliyet / birikmiş / net (K1)."""
    where, args = ["1=1"], []
    if sid is not None:
        where.append("d.sirket_id=?")
        args.append(sid)
    rows = conn.execute(
        "SELECT COALESCE(k.ad,'(Kategorisiz)') kat, COUNT(*) adet, "
        "SUM(d.maliyet) maliyet, "
        "COALESCE((SELECT SUM(a.birikmis) FROM demirbas_amortisman a "
        "          JOIN demirbas d2 ON d2.id=a.demirbas_id "
        "          WHERE d2.kategori_id=d.kategori_id "
        "          AND a.id=(SELECT MAX(id) FROM demirbas_amortisman WHERE demirbas_id=d2.id)),0) birk "
        "FROM demirbas d LEFT JOIN demirbas_kategori k ON k.id=d.kategori_id "
        "WHERE " + " AND ".join(where) + " GROUP BY k.id, k.ad ORDER BY maliyet DESC",
        args).fetchall()
    out = []
    for r in rows:
        maliyet = r["maliyet"] or 0.0
        birk = r["birk"] or 0.0
        out.append({"kategori": r["kat"], "adet": r["adet"] or 0,
                    "maliyet": round(maliyet, 2), "birikmis": round(birk, 2),
                    "net": round(maliyet - birk, 2)})
    return out


def _birikmis_son(conn, did):
    """Demirbaşın SON dönem birikmiş amortismanı (yoksa 0)."""
    r = conn.execute(
        "SELECT birikmis FROM demirbas_amortisman WHERE demirbas_id=? "
        "ORDER BY donem DESC LIMIT 1", (int(did),)).fetchone()
    return (r["birikmis"] or 0.0) if r else 0.0


def _say_k(v):
    """Grafik etiketi için kompakt: 45000 -> 45k."""
    a = abs(v)
    if a >= 1_000_000:
        return f"{v/1_000_000:.1f}M".replace(".", ",")
    if a >= 1000:
        return f"{v/1000:.0f}k"
    return f"{v:.0f}"


def _line_svg(points, width=640, height=230, color="#8b5cf6"):
    """Çizgi grafik (inline SVG). points: [(etiket, değer), ...]."""
    if not points:
        return '<div class="empty">Bu aralıkta veri yok.</div>'
    vals = [p[1] for p in points]
    vmax = max(max(vals), 0.0001)
    left, right, top, bottom = 10, width - 10, 16, height - 30
    plot_w = right - left
    plot_h = bottom - top
    n = len(points)

    def X(i):
        return left + (plot_w * i / (n - 1)) if n > 1 else left + plot_w / 2

    def Y(v):
        return bottom - (v / vmax) * plot_h

    p = [f'<svg viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg" '
         f'role="img" style="width:100%;height:auto;display:block;">']
    for i in range(4):
        y = top + plot_h * i / 3
        p.append(f'<line x1="{left}" y1="{y:.1f}" x2="{right}" y2="{y:.1f}" '
                 f'stroke="#273042" stroke-width="1"/>')
        p.append(f'<text x="{left - 2}" y="{y + 3:.1f}" fill="#8b95a7" font-size="8" '
                 f'text-anchor="end">{_say_k(vmax * (1 - i / 3))}</text>')
    coords = " ".join(f"{X(i):.1f},{Y(v):.1f}" for i, (_, v) in enumerate(points))
    p.append(f'<polyline points="{coords}" fill="none" stroke="{color}" '
             f'stroke-width="2.2" stroke-linejoin="round"/>')
    for i, (_, v) in enumerate(points):
        p.append(f'<circle cx="{X(i):.1f}" cy="{Y(v):.1f}" r="2.6" fill="{color}"/>')
    step = max(1, n // 6)
    for i, (lab, _) in enumerate(points):
        if i % step == 0 or i == n - 1:
            p.append(f'<text x="{X(i):.1f}" y="{height - 10}" fill="#8b95a7" '
                     f'font-size="8" text-anchor="middle">{lab}</text>')
    p.append('</svg>')
    return "".join(p)


def _json(data):
    return Response(json.dumps(data, ensure_ascii=False), "200 OK",
                    [("Content-Type", "application/json; charset=utf-8")])


@route(r"/demirbas", roles=())
def demirbas_index(req):
    conn = db.get_conn()
    yazma = bool(req.user and req.user["rol"] in DEMIRBAS_WRITE)
    donem_son = datetime.date.today().strftime("%Y-%m")
    # Aylık otomatik (kapanış akışı): Admin/Muhasebe açtığında eksik amortismanları üret.
    if yazma:
        try:
            adet = _amortisman_uret(conn, donem_son=donem_son, sube_id=izole_sube(req),
                                    sid=db.sirket_id(req))
            conn.commit()
            if adet:
                flash(req, f"Aylık amortisman otomatik üretildi: {adet} kayıt + GM fişi.", "info")
        except Exception:
            conn.rollback()

    kategoriler = conn.execute("SELECT * FROM demirbas_kategori WHERE aktif=1 AND sirket_id=? ORDER BY ad",
                               (db.sirket_id(req),)).fetchall()
    kullanicilar = conn.execute(
        "SELECT id, ad_soyad, kullanici_adi, rol FROM kullanici WHERE aktif=1 ORDER BY ad_soyad").fetchall()
    subeler = conn.execute("SELECT id, ad FROM sube WHERE aktif=1 AND sirket_id=? ORDER BY ad",
                           (db.sirket_id(req),)).fetchall()
    iz = izole_sube(req)
    demirbas_where = ["d.sirket_id=?"]
    demirbas_args = [db.sirket_id(req)]
    if iz:
        demirbas_where.append("d.sube_id=?")
        demirbas_args.append(iz)
    demirbaslar = conn.execute(
        "SELECT d.*, k.ad AS kategori_ad, k.omur_yil AS kategori_omur, "
        "u.ad_soyad AS zimmet_ad, s.ad AS sube_ad "
        "FROM demirbas d LEFT JOIN demirbas_kategori k ON k.id=d.kategori_id "
        "LEFT JOIN kullanici u ON u.id=d.zimmetli_kullanici_id "
        "LEFT JOIN sube s ON s.id=d.sube_id "
        "WHERE " + " AND ".join(demirbas_where) + " ORDER BY d.kod",
        demirbas_args).fetchall()

    toplam_maliyet = toplam_birikmis = toplam_net = 0.0
    aktif_adet = 0
    satirlar = []
    for d in demirbaslar:
        d = dict(d)
        omur = _omur(conn, d)
        taban = _taban(d)
        birk, n, _son = _ozet(conn, d["id"])
        d["omur"] = omur
        d["oran"] = round(100.0 / omur, 2) if omur > 0 else 0.0
        d["taban"] = taban
        d["birikmis"] = birk
        d["net"] = round(taban - birk, 2)
        d["adet"] = n
        toplam_maliyet += _f(d["maliyet"])
        toplam_birikmis += birk
        toplam_net += round(taban - birk, 2)
        if d["durum"] == "Aktif":
            aktif_adet += 1
        # F5-B durum rozeti: 🟢 Aktif / 🟡 Tamamlandı / 🔴 Durdu (Satıldı/Hurda)
        if d["durum"] in ("Satıldı", "Hurda"):
            d["durum_etiket"] = d["durum"]
            d["durum_rozet"] = "b-danger"
        elif d["taban"] > 0.005 and d["birikmis"] >= d["taban"] - 0.005:
            d["durum_etiket"] = "Tamamlandı"
            d["durum_rozet"] = "b-warn"
        else:
            d["durum_etiket"] = "Aktif"
            d["durum_rozet"] = "b-ok"
        satirlar.append(d)

    kategori_ozet = _kategori_ozet(conn, db.sirket_id(req))

    conn.close()
    return render_template(
        "demirbas/index.html", satirlar=satirlar, kategoriler=kategoriler,
        kullanicilar=kullanicilar, subeler=subeler, yazma=yazma,
        donem_son=donem_son, AY_AD=AY_AD, DURUM_BADGE=DURUM_BADGE,
        kategori_ozet=kategori_ozet,
        kpi={"maliyet": toplam_maliyet, "birikmis": toplam_birikmis,
             "net": toplam_net, "aktif": aktif_adet},
    )


@route(r"/demirbas/(?P<did>\d+)", roles=())
def demirbas_detay(req, did):
    conn = db.get_conn()
    yazma = bool(req.user and req.user["rol"] in DEMIRBAS_WRITE)
    d = conn.execute(
        "SELECT d.*, k.ad AS kategori_ad, k.omur_yil AS kategori_omur, "
        "u.ad_soyad AS zimmet_ad, s.ad AS sube_ad "
        "FROM demirbas d LEFT JOIN demirbas_kategori k ON k.id=d.kategori_id "
        "LEFT JOIN kullanici u ON u.id=d.zimmetli_kullanici_id "
        "LEFT JOIN sube s ON s.id=d.sube_id WHERE d.id=? AND d.sirket_id=?",
        (int(did), db.sirket_id(req))).fetchone()
    if not d:
        conn.close()
        flash(req, "Demirbaş bulunamadı.", "danger")
        return redirect("/demirbas")
    if not sube_koruma(req, d["sube_id"]):
        conn.close()
        return Response("Bu kayıt başka bir şubeye aittir.", "403 Forbidden")
    d = dict(d)
    omur = _omur(conn, d)
    taban = _taban(d)
    birk, n, _son = _ozet(conn, int(did))
    d["omur"] = omur
    d["oran"] = round(100.0 / omur, 2) if omur > 0 else 0.0
    d["taban"] = taban
    d["aylik"] = round(taban / (omur * 12.0), 2) if taban > 0 and omur > 0 else 0.0
    d["birikmis"] = birk
    d["net"] = round(taban - birk, 2)
    amor = conn.execute(
        "SELECT * FROM demirbas_amortisman WHERE demirbas_id=? ORDER BY donem", (int(did),)).fetchall()
    zimmetler = conn.execute(
        "SELECT z.*, u.ad_soyad, u.kullanici_adi, s.ad AS sube_ad FROM demirbas_zimmet z "
        "LEFT JOIN kullanici u ON u.id=z.kullanici_id LEFT JOIN sube s ON s.id=z.sube_id "
        "WHERE z.demirbas_id=? ORDER BY z.tarih DESC, z.id DESC", (int(did),)).fetchall()
    kategoriler = conn.execute("SELECT * FROM demirbas_kategori WHERE aktif=1 AND sirket_id=? ORDER BY ad",
                               (db.sirket_id(req),)).fetchall()
    kullanicilar = conn.execute(
        "SELECT id, ad_soyad, kullanici_adi, rol FROM kullanici WHERE aktif=1 ORDER BY ad_soyad").fetchall()
    subeler = conn.execute("SELECT id, ad FROM sube WHERE aktif=1 AND sirket_id=? ORDER BY ad",
                           (db.sirket_id(req),)).fetchall()

    # F5-B (v1.36.0) — gelecek 12 ay plan + birikmiş çizgi grafiği
    plan = _amortisman_plan(conn, d)
    seri = [(r["donem"], (r["birikmis"] or 0.0)) for r in amor]  # üretilmiş geçmiş
    for p in plan:
        if not p["gercek"]:
            seri.append((p["donem"], p["birikmis"]))
    birikmis_svg = _line_svg(
        [(f"{dm[5:7]}/{dm[2:4]}", v) for dm, v in seri],
        color="#8b5cf6")

    conn.close()
    return render_template(
        "demirbas/detay.html", d=d, amor=amor, zimmetler=zimmetler, yazma=yazma,
        kategoriler=kategoriler, kullanicilar=kullanicilar, subeler=subeler,
        AY_AD=AY_AD, DURUM_BADGE=DURUM_BADGE,
        plan=plan, birikmis_svg=birikmis_svg,
    )


@route(r"/demirbas/ekle", methods=("POST",), roles=DEMIRBAS_WRITE)
def demirbas_ekle(req):
    conn = db.get_conn()
    ad = (req.form.get("ad") or "").strip()
    kategori_id = _i(req.form.get("kategori_id"))
    alis = (req.form.get("alis_tarihi") or "").strip() or datetime.date.today().isoformat()
    maliyet = _f(req.form.get("maliyet"))
    hurda = _f(req.form.get("hurda_degeri"), 0.0)
    omur = _f(req.form.get("omur_yil"), 0.0)
    sube_id = izole_sube(req) or _i(req.form.get("sube_id"))
    zimmet = _i(req.form.get("zimmetli_kullanici_id"))
    aciklama = (req.form.get("aciklama") or "").strip()
    if not ad or maliyet <= 0:
        flash(req, "Ad ve pozitif maliyet zorunludur.", "danger")
        conn.close()
        return redirect("/demirbas")
    if omur <= 0:
        omur = None
    kod = db.sonraki_belge_no(conn, "demirbas", "kod", "DBR", datetime.date.today().year,
                               db.sirket_id(req))
    cur = conn.execute(
        "INSERT INTO demirbas(kod, ad, kategori_id, alis_tarihi, maliyet, hurda_degeri, omur_yil, "
        "sube_id, zimmetli_kullanici_id, aciklama, created_by, sirket_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        (kod, ad, kategori_id, alis, maliyet, hurda, omur, sube_id, zimmet, aciklama,
         req.user["id"] if req.user else None, db.sirket_id(req)))
    did = cur.lastrowid
    if zimmet:
        conn.execute(
            "INSERT INTO demirbas_zimmet(demirbas_id, kullanici_id, sube_id, islem, aciklama, "
            "created_by, sirket_id) VALUES(?,?,?,?,?,?,?)",
            (did, zimmet, sube_id, "Teslim", "İlk zimmet", req.user["id"] if req.user else None,
             db.sirket_id(req)))
    conn.commit()
    audit(req, "demirbas", did, "olustur", {"kod": kod, "ad": ad, "maliyet": maliyet})
    flash(req, f"{kod} demirbaşı eklendi.", "ok")
    conn.close()
    return redirect("/demirbas")


@route(r"/demirbas/(?P<did>\d+)/guncelle", methods=("POST",), roles=DEMIRBAS_WRITE)
def demirbas_guncelle(req, did):
    conn = db.get_conn()
    d = conn.execute("SELECT * FROM demirbas WHERE id=? AND sirket_id=?",
                     (int(did), db.sirket_id(req))).fetchone()
    if not d:
        conn.close()
        flash(req, "Demirbaş bulunamadı.", "danger")
        return redirect("/demirbas")
    ad = (req.form.get("ad") or "").strip()
    kategori_id = _i(req.form.get("kategori_id"))
    alis = (req.form.get("alis_tarihi") or "").strip() or (d["alis_tarihi"] or "")
    maliyet = _f(req.form.get("maliyet"))
    hurda = _f(req.form.get("hurda_degeri"), 0.0)
    omur = _f(req.form.get("omur_yil"), 0.0)
    sube_id = _i(req.form.get("sube_id"))
    aciklama = (req.form.get("aciklama") or "").strip()
    if not ad or maliyet <= 0:
        flash(req, "Ad ve pozitif maliyet zorunludur.", "danger")
        conn.close()
        return redirect(f"/demirbas/{did}")
    if omur <= 0:
        omur = None
    var_amor = conn.execute(
        "SELECT COUNT(*) c FROM demirbas_amortisman WHERE demirbas_id=?", (int(did),)).fetchone()["c"]
    if var_amor > 0:
        degisti = (
            (kategori_id or 0) != (d["kategori_id"] or 0)
            or alis != (d["alis_tarihi"] or "")
            or abs(maliyet - _f(d["maliyet"])) > 0.005
            or abs(hurda - _f(d["hurda_degeri"])) > 0.005
            or (omur is not None) != (d["omur_yil"] is not None)
            or (omur is not None and d["omur_yil"] is not None and abs(omur - _f(d["omur_yil"])) > 0.005)
        )
        if degisti:
            flash(req, "Bu demirbaş için amortisman üretilmiş — maliyet/ömür/alış tarihi/kategori "
                       "değiştirilemez (GM fişleriyle çelişir). Yalnızca ad, açıklama ve şube "
                       "güncellenebilir.", "danger")
            conn.close()
            return redirect(f"/demirbas/{did}")
    conn.execute(
        "UPDATE demirbas SET ad=?, kategori_id=?, alis_tarihi=?, maliyet=?, hurda_degeri=?, "
        "omur_yil=?, sube_id=?, aciklama=?, updated_at=datetime('now','localtime') WHERE id=?",
        (ad, kategori_id, alis, maliyet, hurda, omur, sube_id, aciklama, int(did)))
    conn.commit()
    audit(req, "demirbas", int(did), "guncelle", {"ad": ad, "maliyet": maliyet})
    flash(req, "Demirbaş güncellendi.", "ok")
    conn.close()
    return redirect(f"/demirbas/{did}")


@route(r"/demirbas/(?P<did>\d+)/zimmet", methods=("POST",), roles=DEMIRBAS_WRITE)
def demirbas_zimmet(req, did):
    conn = db.get_conn()
    d = conn.execute("SELECT * FROM demirbas WHERE id=? AND sirket_id=?",
                     (int(did), db.sirket_id(req))).fetchone()
    if not d:
        conn.close()
        flash(req, "Demirbaş bulunamadı.", "danger")
        return redirect("/demirbas")
    kullanici_id = _i(req.form.get("kullanici_id"))
    sube_id = _i(req.form.get("sube_id"))
    islem = req.form.get("islem") or "Devir"
    aciklama = (req.form.get("aciklama") or "").strip()
    if islem not in ("Teslim", "Devir", "İade"):
        islem = "Devir"
    if islem == "İade":
        kullanici_id = None
    if kullanici_id is None and islem != "İade":
        flash(req, "Zimmet için kullanıcı seçin.", "danger")
        conn.close()
        return redirect(f"/demirbas/{did}")
    conn.execute(
        "UPDATE demirbas SET zimmetli_kullanici_id=?, "
        "sube_id=COALESCE(?, sube_id), updated_at=datetime('now','localtime') WHERE id=?",
        (kullanici_id, sube_id, int(did)))
    conn.execute(
        "INSERT INTO demirbas_zimmet(demirbas_id, kullanici_id, sube_id, islem, aciklama, "
        "created_by, sirket_id) VALUES(?,?,?,?,?,?,?)",
        (int(did), kullanici_id, sube_id, islem, aciklama, req.user["id"] if req.user else None,
         db.sirket_id(req)))
    conn.commit()
    audit(req, "demirbas", int(did), "zimmet", {"islem": islem, "kullanici_id": kullanici_id})
    flash(req, "Zimmet güncellendi." if islem != "İade" else "Demirbaş iade alındı.", "ok")
    conn.close()
    return redirect(f"/demirbas/{did}")


@route(r"/demirbas/(?P<did>\d+)/durum", methods=("POST",), roles=DEMIRBAS_WRITE)
def demirbas_durum(req, did):
    conn = db.get_conn()
    d = conn.execute("SELECT * FROM demirbas WHERE id=? AND sirket_id=?",
                     (int(did), db.sirket_id(req))).fetchone()
    if not d:
        conn.close()
        flash(req, "Demirbaş bulunamadı.", "danger")
        return redirect("/demirbas")
    durum = req.form.get("durum") or ""
    if durum not in ("Aktif", "Satıldı", "Hurda"):
        flash(req, "Geçersiz durum.", "danger")
        conn.close()
        return redirect(f"/demirbas/{did}")
    conn.execute("UPDATE demirbas SET durum=?, updated_at=datetime('now','localtime') WHERE id=?",
                 (durum, int(did)))
    conn.commit()
    audit(req, "demirbas", int(did), "durum", {"durum": durum})
    notu = "Amortisman durduruldu; net değer mahsubu manuel GM fişiyle yapılır." \
        if durum in ("Satıldı", "Hurda") else "Demirbaş yeniden aktif."
    flash(req, f"Durum: {durum}. {notu}", "ok")
    conn.close()
    return redirect(f"/demirbas/{did}")


@route(r"/demirbas/(?P<did>\d+)/sil", methods=("POST",), roles=DEMIRBAS_WRITE)
def demirbas_sil(req, did):
    conn = db.get_conn()
    d = conn.execute("SELECT * FROM demirbas WHERE id=? AND sirket_id=?",
                     (int(did), db.sirket_id(req))).fetchone()
    if not d:
        conn.close()
        flash(req, "Demirbaş bulunamadı.", "danger")
        return redirect("/demirbas")
    # K32: amortisman (mali iz) veya zimmet (teslim geçmişi) varsa silme engellenir.
    am = conn.execute("SELECT COUNT(*) c FROM demirbas_amortisman WHERE demirbas_id=?",
                      (int(did),)).fetchone()["c"]
    zim = conn.execute("SELECT COUNT(*) c FROM demirbas_zimmet WHERE demirbas_id=?",
                       (int(did),)).fetchone()["c"]
    if am or zim:
        conn.close()
        flash(req, "Bu demirbaşta amortisman/zimmet kaydı var — silinemez. Durumunu değiştirebilirsiniz.",
              "danger")
        return redirect(f"/demirbas/{did}")
    conn.execute("DELETE FROM demirbas WHERE id=?", (int(did),))
    conn.commit()
    audit(req, "demirbas", int(did), "sil", {"kod": d["kod"], "ad": d["ad"]})
    flash(req, f"{d['kod']} silindi.", "ok")
    conn.close()
    return redirect("/demirbas")


@route(r"/demirbas/amortisman-uret", methods=("POST",), roles=DEMIRBAS_WRITE)
def demirbas_amortisman_uret(req):
    conn = db.get_conn()
    donem = (req.form.get("donem") or "").strip()
    bugun_ym = datetime.date.today().strftime("%Y-%m")
    if not (len(donem) == 7 and donem[4] == "-"):
        donem = bugun_ym
    adet = _amortisman_uret(conn, donem_son=donem, sid=db.sirket_id(req))
    conn.commit()
    if adet:
        flash(req, f"{donem} dahil {adet} adet amortisman kaydı + GM fişi üretildi.", "ok")
    else:
        flash(req, "Üretilecek yeni amortisman yok (tüm dönemler üretilmiş).", "info")
    conn.close()
    return redirect("/demirbas")


@route(r"/demirbas/kategori-ekle", methods=("POST",), roles=DEMIRBAS_WRITE)
def demirbas_kategori_ekle(req):
    conn = db.get_conn()
    ad = (req.form.get("ad") or "").strip()
    omur = _f(req.form.get("omur_yil"), 0.0)
    if not ad or omur <= 0:
        flash(req, "Kategori adı ve pozitif ömür (yıl) zorunludur.", "danger")
        conn.close()
        return redirect("/demirbas")
    cur = conn.execute("INSERT INTO demirbas_kategori(ad, omur_yil, sirket_id) VALUES(?,?,?)",
                        (ad, omur, db.sirket_id(req)))
    conn.commit()
    audit(req, "demirbas_kategori", cur.lastrowid, "olustur", {"ad": ad, "omur_yil": omur})
    flash(req, f"Kategori '{ad}' eklendi (%{round(100.0 / omur, 2)} / {omur} yıl).", "ok")
    conn.close()
    return redirect("/demirbas")


# --------------------------------------------------------------------------
# F5-B (v1.36.0) — API özet ucu + yıl bazlı amortisman CSV cetveli
# --------------------------------------------------------------------------
@route(r"/api/demirbas/ozet", roles=())
def api_demirbas_ozet(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    bugun_ym = datetime.date.today().strftime("%Y-%m")
    rows = conn.execute("SELECT * FROM demirbas WHERE sirket_id=?", (sid,)).fetchall()
    toplam_maliyet = toplam_birikmis = 0.0
    aktif_adet = 0
    yaklasan = []
    for r in rows:
        r = dict(r)
        toplam_maliyet += _f(r["maliyet"])
        birk = _birikmis_son(conn, r["id"])
        toplam_birikmis += birk
        if r["durum"] == "Aktif":
            aktif_adet += 1
        omur = _omur(conn, r)
        alis = (r["alis_tarihi"] or "")[:7]
        if alis and omur > 0 and r["durum"] == "Aktif":
            bitis = _ym_ekle(alis, int(round(omur * 12)))
            kalan = _ay_fark(bitis, bugun_ym)
            if 0 <= kalan <= 3:
                yaklasan.append({"kod": r["kod"], "ad": r["ad"],
                                 "bitis": bitis, "kalan_ay": kalan})
    kategori_ozet = _kategori_ozet(conn, sid)
    conn.close()
    return _json({
        "toplam_maliyet": round(toplam_maliyet, 2),
        "toplam_birikmis": round(toplam_birikmis, 2),
        "toplam_net": round(toplam_maliyet - toplam_birikmis, 2),
        "aktif_adet": aktif_adet,
        "kategori_ozet": kategori_ozet,
        "yaklasan_bitis": yaklasan,
    })


@route(r"/demirbas/amortisman/csv", roles=("Admin", "Muhasebe"))
def demirbas_amortisman_csv(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    yil = (req.q("yil") or "").strip()
    if not (len(yil) == 4 and yil.isdigit()):
        yil = str(datetime.date.today().year)
    rows = conn.execute(
        "SELECT d.kod, d.ad, COALESCE(k.ad,'(Kategorisiz)') kategori, "
        "a.donem, a.tutar, a.birikmis, a.net_deger, d.durum "
        "FROM demirbas_amortisman a "
        "JOIN demirbas d ON d.id=a.demirbas_id "
        "LEFT JOIN demirbas_kategori k ON k.id=d.kategori_id "
        "WHERE a.donem LIKE ? AND d.sirket_id=? "
        "ORDER BY d.kod, a.donem", (yil + "-%", sid)).fetchall()
    conn.close()

    buf = io.StringIO()
    buf.write("\ufeff")  # UTF-8 BOM — Excel Türkçe karakterler
    buf.write(";".join(["Demirbas Kod", "Demirbas Ad", "Kategori", "Donem",
                        "Tutar", "Birikmis", "Net Deger", "Durum"]) + "\r\n")
    for r in rows:
        def _n(v):
            return f"{v:.2f}".replace(".", ",")
        buf.write(";".join([
            r["kod"] or "", r["ad"] or "", r["kategori"] or "", r["donem"] or "",
            _n(r["tutar"] or 0.0), _n(r["birikmis"] or 0.0),
            _n(r["net_deger"] or 0.0), r["durum"] or "",
        ]) + "\r\n")
    return Response(buf.getvalue(), "200 OK", [
        ("Content-Type", "text/csv; charset=utf-8"),
        ("Content-Disposition", f'attachment; filename="amortisman-{yil}.csv"'),
    ])


def register():
    return "demirbas"
