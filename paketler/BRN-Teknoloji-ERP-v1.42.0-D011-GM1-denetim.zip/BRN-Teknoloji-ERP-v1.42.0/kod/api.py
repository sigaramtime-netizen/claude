# -*- coding: utf-8 -*-
"""Hafif JSON arama uçları — formlardaki canlı arama (autocomplete) için.

F3 (v1.33.0) — TEK KAYNAK endpoint:
- GET /api/ara?tip=stok|cari&q=...&cari_tip=Alis|Satis
    tip=stok  → stok kartlarında kod / ad / barkod (ve varyant) araması.
    tip=cari  → cari kartlarında kod / unvan araması (cari_tip filtresiyle).
    q boşsa → ilk 20 aktif kayıt döner ("yazmaya başlayın" yerine).
    Limit 20 (en fazla 20 satır). K1: her sorgu sirket_id ile süzülür.

Geriye dönük uyumluluk (eski testler/arayüzler için ince sarmalayıcılar — aynı iç
fonksiyonları çağırır, ayrı sorgu YOK):
- GET /api/stok/ara?q=  (q boşsa [])
- GET /api/cari/ara?q=&tip=Alis|Satis  (q boşsa [])

Salt-okunur; veri kaynağı yalnız stok_kart / stok_varyant / cari_kart (K4).
"""
import json

import db
from core import route, Response


def _json(data):
    return Response(json.dumps(data, ensure_ascii=False), "200 OK",
                    [("Content-Type", "application/json; charset=utf-8")])


def _stok_ara(sid, q, limit=20):
    """Stok araması (kod/ad/barkod + varyant). q boşsa ilk `limit` aktif kart."""
    conn = db.get_conn()
    if not q:
        rows = conn.execute(
            """SELECT s.id AS id, 0 AS varyant_id, s.kod AS kod, s.ad AS ad, '' AS varyant_ad,
                      s.barkod AS barkod, s.birim AS birim, s.kdv_orani AS kdv_orani,
                      s.alis_fiyat AS alis_fiyat, s.satis_fiyat AS satis_fiyat,
                      s.iskonto_orani AS iskonto_orani,
                      s.seri_lot_takibi AS seri_lot_takibi, s.varyant_takibi AS varyant_takibi
               FROM stok_kart s
               WHERE s.aktif=1 AND s.sirket_id=?
               ORDER BY s.kod
               LIMIT ?""",
            (sid, limit),
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    like = f"%{q}%"
    # Önce tam kod eşleşmesi, sonra kod ile başlayanlar, sonra ad içerenler (D007 TTEC fix).
    rows = conn.execute(
        """
        SELECT * FROM (
            SELECT s.id AS id, 0 AS varyant_id, s.kod AS kod, s.ad AS ad, '' AS varyant_ad,
                   s.barkod AS barkod, s.birim AS birim, s.kdv_orani AS kdv_orani,
                   s.alis_fiyat AS alis_fiyat, s.satis_fiyat AS satis_fiyat,
                   s.iskonto_orani AS iskonto_orani,
                   s.seri_lot_takibi AS seri_lot_takibi, s.varyant_takibi AS varyant_takibi
            FROM stok_kart s
            WHERE s.aktif=1 AND s.sirket_id=?
              AND (s.ad LIKE ? OR s.kod LIKE ? OR s.barkod LIKE ?)
            UNION ALL
            SELECT s.id AS id, v.id AS varyant_id, s.kod AS kod, s.ad AS ad, v.ad AS varyant_ad,
                   v.barkod AS barkod, s.birim AS birim, s.kdv_orani AS kdv_orani,
                   COALESCE(v.alis_fiyat, s.alis_fiyat) AS alis_fiyat,
                   COALESCE(v.satis_fiyat, s.satis_fiyat) AS satis_fiyat,
                   s.iskonto_orani AS iskonto_orani,
                   s.seri_lot_takibi AS seri_lot_takibi, s.varyant_takibi AS varyant_takibi
            FROM stok_varyant v JOIN stok_kart s ON s.id = v.stok_id
            WHERE v.aktif=1 AND s.aktif=1 AND s.sirket_id=?
              AND (v.ad LIKE ? OR v.barkod LIKE ? OR v.varyant_kodu LIKE ?)
        )
        ORDER BY
            CASE WHEN lower(kod)=lower(?) THEN 0
                 WHEN lower(kod) LIKE lower(?) THEN 1
                 WHEN lower(ad) LIKE lower(?) THEN 2
                 ELSE 3 END,
            varyant_id, ad
        LIMIT ?
        """,
        (sid, like, like, like, sid, like, like, like, q, f"{q}%", f"{q}%", limit),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _cari_ara(sid, q, tip="", limit=20):
    """Cari araması (kod/unvan). tip=Alis → tedarikçi, Satis → müşteri. q boşsa ilk 20."""
    conn = db.get_conn()
    where = "aktif=1 AND sirket_id=?"
    params = [sid]
    if q:
        like = f"%{q}%"
        where += " AND (unvan LIKE ? OR kod LIKE ?)"
        params += [like, like]
    if tip == "Alis":
        where += " AND tip IN ('Tedarikci','HerIkisi')"
    elif tip == "Satis":
        where += " AND tip IN ('Musteri','HerIkisi')"
    if q:
        rows = conn.execute(
            f"SELECT id, kod, unvan, il, iskonto_orani FROM cari_kart WHERE {where} "
            f"ORDER BY (CASE WHEN lower(kod)=lower(?) THEN 0 ELSE 1 END), unvan LIMIT ?",
            params + [q, limit],
        ).fetchall()
    else:
        rows = conn.execute(
            f"SELECT id, kod, unvan, il, iskonto_orani FROM cari_kart WHERE {where} "
            f"ORDER BY unvan LIMIT ?",
            params + [limit],
        ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# F3 — TEK KAYNAK
# ---------------------------------------------------------------------------
@route(r"/api/ara", roles=())
def api_ara(req):
    tip = (req.q("tip") or "stok").strip().lower()
    q = (req.q("q") or "").strip()
    sid = db.sirket_id(req)
    if tip == "cari":
        cari_tip = (req.q("cari_tip") or "").strip()
        return _json(_cari_ara(sid, q, cari_tip, 20))
    return _json(_stok_ara(sid, q, 20))


# ---------------------------------------------------------------------------
# Geriye dönük uyumluluk sarmalayıcıları (tek kaynak: _stok_ara / _cari_ara)
# ---------------------------------------------------------------------------
@route(r"/api/stok/ara", roles=())
def api_stok_ara(req):
    q = (req.q("q") or "").strip()
    if not q:
        return _json([])
    return _json(_stok_ara(db.sirket_id(req), q, 20))


@route(r"/api/cari/ara", roles=())
def api_cari_ara(req):
    q = (req.q("q") or "").strip()
    tip = (req.q("tip") or "").strip()
    if not q:
        return _json([])
    return _json(_cari_ara(db.sirket_id(req), q, tip, 20))


def register():
    pass
