# -*- coding: utf-8 -*-
"""Şube / Depo modülü (Faz 1'in son modülü).

- Şube tanımı (çok şubeli yapı) + CRUD
- Depoları şubeye bağlama (depo.sube_id), kullanıcıyı şubeye bağlama (kullanici.sube_id)
- Şube bazlı raporlama: depo listesi, toplam stok, kullanıcılar
- Şube bazlı görünürlük: kullanıcı bir şubeyle sınırlıysa stok listesi o şubenin depolarıyla sınırlanır.

NOT (kapsam): Veri satırı düzeyinde tam şube izolasyonu (her tabloda sube_id) işletme fiilen
çok şubeye geçtiğinde devreye alınacak; şimdilik depo + kullanıcı bağlantısı ve şube raporu hazır.
"""
import datetime

import db
from core import route, render_template, redirect, flash, audit

SUBE_WRITE = ("Admin",)


def _f(v, default=0.0):
    try:
        return float(v if v not in (None, "") else default)
    except (TypeError, ValueError):
        return default


def _i(v):
    try:
        return int(v) if v not in (None, "") else None
    except (TypeError, ValueError):
        return None


def _subeler(conn, sid=None):
    where, params = "", []
    if sid is not None:
        where, params = " WHERE s.sirket_id = ?", [sid]
    return conn.execute(
        "SELECT s.*, "
        "(SELECT COUNT(*) FROM depo d WHERE d.sube_id=s.id) AS depo_sayisi, "
        "(SELECT COALESCE(SUM(sv.miktar),0) FROM stok_seviye sv JOIN depo d ON d.id=sv.depo_id "
        "  WHERE d.sube_id=s.id) AS stok_toplam, "
        "(SELECT COUNT(*) FROM kullanici k WHERE k.sube_id=s.id) AS kullanici_sayisi "
        "FROM sube s" + where + " ORDER BY s.id", params
    ).fetchall()


@route(r"/sube", roles=())
def sube_liste(req):
    conn = db.get_conn()
    subeler = _subeler(conn, db.sirket_id(req))
    # Şube bazlı izolasyon: şubeye atanmış, Admin olmayan kullanıcı yalnızca kendi şubesini görür.
    if req.user.get("rol") != "Admin" and req.user.get("sube_id"):
        subeler = [s for s in subeler if s["id"] == req.user["sube_id"]]
    # F6 (v1.38.0) — şube özet rozetleri: fatura / irsaliye adetleri.
    sid = db.sirket_id(req)
    ozetli = []
    for s in subeler:
        s = dict(s)
        s["fatura_adet"] = conn.execute(
            "SELECT COUNT(*) c FROM fatura WHERE sube_id=? AND sirket_id=?",
            (s["id"], sid)).fetchone()["c"]
        s["irsaliye_adet"] = conn.execute(
            "SELECT COUNT(*) c FROM irsaliye WHERE sube_id=? AND sirket_id=?",
            (s["id"], sid)).fetchone()["c"]
        ozetli.append(s)
    conn.close()
    return render_template("sube/liste.html", subeler=ozetli)


@route(r"/sube/yeni", methods=("GET", "POST"), roles=SUBE_WRITE)
def sube_yeni(req):
    conn = db.get_conn()
    if req.method == "POST":
        ad = (req.form.get("ad") or "").strip()
        if not ad:
            flash(req, "Şube adı zorunludur.", "danger")
            conn.close()
            return redirect("/sube/yeni")
        kod = (req.form.get("kod") or "").strip()
        sid = db.sirket_id(req)
        if not kod:
            nxt = conn.execute(
                "SELECT COALESCE(MAX(CAST(substr(kod,5) AS INTEGER)),0)+1 AS n FROM sube WHERE sirket_id=?",
                (sid,)).fetchone()["n"]
            kod = f"SUB-{nxt:02d}"
            while conn.execute("SELECT 1 FROM sube WHERE sirket_id=? AND kod=?", (sid, kod)).fetchone():
                nxt += 1
                kod = f"SUB-{nxt:02d}"
        cur = conn.execute(
            "INSERT INTO sube(kod, ad, il, ilce, adres, telefon, sirket_id) VALUES(?,?,?,?,?,?,?)",
            (kod, ad, (req.form.get("il") or "").strip(), (req.form.get("ilce") or "").strip(),
             (req.form.get("adres") or "").strip(), (req.form.get("telefon") or "").strip(), sid),
        )
        conn.commit()
        audit(req, "sube", cur.lastrowid, "olustur", {"ad": ad, "kod": kod})
        conn.close()
        flash(req, f"Şube oluşturuldu: {ad} ({kod})", "ok")
        return redirect("/sube")
    conn.close()
    return render_template("sube/form.html", sube=None)


@route(r"/sube/(?P<sid>\d+)", roles=())
def sube_detay(req, sid):
    # Şube bazlı izolasyon: Admin olmayan, şubeye atanmış kullanıcı başka şubeyi açamaz.
    if req.user.get("rol") != "Admin" and req.user.get("sube_id") and req.user["sube_id"] != int(sid):
        flash(req, "Bu şubeyi görüntüleme yetkiniz yok.", "danger")
        return redirect("/sube")
    conn = db.get_conn()
    sube = conn.execute("SELECT * FROM sube WHERE id=? AND sirket_id=?",
                        (int(sid), db.sirket_id(req))).fetchone()
    if not sube:
        conn.close()
        flash(req, "Şube bulunamadı.", "danger")
        return redirect("/sube")
    sube = dict(sube)
    depolar = conn.execute(
        "SELECT d.*, (SELECT COALESCE(SUM(miktar),0) FROM stok_seviye sv WHERE sv.depo_id=d.id) AS stok_toplam, "
        "(SELECT COUNT(*) FROM stok_seviye sv WHERE sv.depo_id=d.id) AS kalem_sayisi "
        "FROM depo d WHERE d.sube_id=? ORDER BY d.id",
        (sube["id"],),
    ).fetchall()
    kullanicilar = conn.execute(
        "SELECT id, kullanici_adi, ad_soyad, rol, aktif FROM kullanici WHERE sube_id=? ORDER BY ad_soyad",
        (sube["id"],),
    ).fetchall()
    # şube bazlı en çok stok tutan ürünler
    top_urunler = conn.execute(
        "SELECT s.kod, s.ad, SUM(sv.miktar) AS miktar FROM stok_seviye sv "
        "JOIN stok_kart s ON s.id=sv.stok_id JOIN depo d ON d.id=sv.depo_id "
        "WHERE d.sube_id=? GROUP BY s.id ORDER BY miktar DESC LIMIT 10",
        (sube["id"],),
    ).fetchall()
    conn.close()
    return render_template("sube/detay.html", sube=sube, depolar=depolar,
                           kullanicilar=kullanicilar, top_urunler=top_urunler)


@route(r"/sube/(?P<sid>\d+)/duzenle", methods=("GET", "POST"), roles=SUBE_WRITE)
def sube_duzenle(req, sid):
    conn = db.get_conn()
    sube = conn.execute("SELECT * FROM sube WHERE id=? AND sirket_id=?",
                        (int(sid), db.sirket_id(req))).fetchone()
    if not sube:
        conn.close()
        return redirect("/sube")
    if req.method == "POST":
        conn.execute(
            "UPDATE sube SET ad=?, il=?, ilce=?, adres=?, telefon=? WHERE id=?",
            ((req.form.get("ad") or "").strip(), (req.form.get("il") or "").strip(),
             (req.form.get("ilce") or "").strip(), (req.form.get("adres") or "").strip(),
             (req.form.get("telefon") or "").strip(), int(sid)),
        )
        conn.commit()
        audit(req, "sube", int(sid), "guncelle", {"ad": (req.form.get("ad") or "").strip()})
        conn.close()
        flash(req, "Şube güncellendi.", "ok")
        return redirect(f"/sube/{sid}")
    conn.close()
    return render_template("sube/form.html", sube=sube)


@route(r"/sube/kullanicilar", methods=("GET", "POST"), roles=SUBE_WRITE)
def sube_kullanicilar(req):
    conn = db.get_conn()
    if req.method == "POST":
        kullanici_id = _i(req.form.get("kullanici_id"))
        sube_id = _i(req.form.get("sube_id"))
        if kullanici_id:
            conn.execute("UPDATE kullanici SET sube_id=? WHERE id=?", (sube_id, kullanici_id))
            conn.commit()
            audit(req, "kullanici", kullanici_id, "sube_atama", {"sube_id": sube_id})
            flash(req, "Kullanıcının şubesi güncellendi (boş = tüm şubeler).", "ok")
        conn.close()
        return redirect("/sube/kullanicilar")
    kullanicilar = conn.execute(
        "SELECT k.*, sb.ad AS sube_ad FROM kullanici k LEFT JOIN sube sb ON sb.id=k.sube_id ORDER BY k.ad_soyad"
    ).fetchall()
    subeler = conn.execute("SELECT id, ad, kod FROM sube WHERE sirket_id=? ORDER BY ad",
                           (db.sirket_id(req),)).fetchall()
    conn.close()
    return render_template("sube/kullanicilar.html", kullanicilar=kullanicilar, subeler=subeler)


def register():
    return "sube"
