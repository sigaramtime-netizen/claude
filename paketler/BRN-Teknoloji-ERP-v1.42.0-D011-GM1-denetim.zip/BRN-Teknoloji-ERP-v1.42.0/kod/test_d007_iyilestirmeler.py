# -*- coding: utf-8 -*-
"""D007 — Kullanıcı Geri Bildirimleri & UX/İş Mantığı İyileştirmeleri (v1.39.0) e2e testi.

22 kontrol (GM direktifi B bölümü D tablosu). Sunucu 8080'de çalışırken:
    python3 test_d007_iyilestirmeler.py

Kapsam:
  1-3  KDV dahil/hariç select (fatura/irsaliye/teklif/sipariş/pos)
  4    Stok marka inline ekleme (POST /api/marka/ekle)
  5-6  Stok kart 8 ek alan (kayıt + güncelleme)
  7-8  Typeahead TTEC filtre bug
  9-10 İrsaliye döviz (USD) + muhasebe TL çeviri
  11-12 Eksi stok izni (irsaliye + fatura)
  13   Cari kartoteks typeahead
  14-15 Cari ekstre/kartoteks 2 irsaliye (MÜŞTERİ-A, HerIkisi)
  16   Detay sayfalarında Sil butonu
  17-18 Tüm cari/stok select'leri typeahead (grep)
  19   F6 korundu (bildirim/yetki/yazdır/sube/sağlık)
  20   F5c/F5b/F1 korundu
  21   K1 şirket izolasyonu korundu
  22   FK bütünlüğü + D007 kalıntısı yok
"""
import datetime
import sqlite3

import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
MARK = "D007TEST"

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print((("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else "")))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris():
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": "admin", "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, "giriş başarısız"
    return s


def aktif_sirket():
    return db1("SELECT sirket_id FROM sessionler ORDER BY rowid DESC LIMIT 1")["sirket_id"]


def satir(stok_id, miktar="1", fiyat="100", kdv="0", manuel=""):
    return [("k_stok_id", stok_id), ("k_varyant_id", "0"), ("k_manuel_ad", manuel),
            ("k_birim", "Adet"), ("k_goruntu_ad", ""), ("k_miktar", miktar),
            ("k_birim_fiyat", fiyat), ("k_iskonto", "0"), ("k_kdv", kdv)]


def temizle_irsaliye(iid):
    dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN "
        "(SELECT id FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id=?)", iid)
    dbx("DELETE FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id=?", iid)
    dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", iid)
    dbx("DELETE FROM stok_hareket WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", iid)
    dbx("DELETE FROM audit_log WHERE tablo='irsaliye' AND kayit_id=?", iid)
    dbx("DELETE FROM irsaliye_kalem WHERE irsaliye_id=?", iid)
    dbx("DELETE FROM irsaliye WHERE id=?", iid)


def temizle_fatura(fid):
    dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN "
        "(SELECT id FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?)", fid)
    dbx("DELETE FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?", fid)
    dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
    dbx("DELETE FROM stok_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
    dbx("DELETE FROM audit_log WHERE tablo='fatura' AND kayit_id=?", fid)
    dbx("DELETE FROM fatura_kalem WHERE fatura_id=?", fid)
    dbx("DELETE FROM fatura WHERE id=?", fid)


def temizle_stok(sid):
    dbx("DELETE FROM stok_seviye WHERE stok_id=?", sid)
    dbx("DELETE FROM stok_hareket WHERE stok_id=?", sid)
    dbx("DELETE FROM audit_log WHERE tablo='stok_kart' AND kayit_id=?", sid)
    dbx("DELETE FROM stok_kart WHERE id=?", sid)


def temizle_cari(cid):
    dbx("DELETE FROM cari_hareket WHERE cari_id=?", cid)
    dbx("DELETE FROM audit_log WHERE tablo='cari_kart' AND kayit_id=?", cid)
    dbx("DELETE FROM cari_kart WHERE id=?", cid)


def dosya_icerir(path, frag):
    try:
        return frag in open(path, encoding="utf-8").read()
    except OSError:
        return False


# ---------------------------------------------------------------------------
print("== D007 / Kullanıcı Bildirimleri İyileştirmeleri (v1.39.0) — e2e testi ==")
s = giris()
sid = aktif_sirket()

# --- idempotent başlangıç temizliği (önceki koşulardan kalıntı) ---
for kod in ("D007-TTEC-STK", "D007-STK-ALAN"):
    r = db1("SELECT id FROM stok_kart WHERE kod=?", kod)
    if r:
        temizle_stok(r["id"])
dbx("DELETE FROM marka WHERE ad LIKE 'D007%'")
yak = db1("SELECT id FROM cari_kart WHERE kod='D007-MUSTERIA'")
if yak:
    temizle_cari(yak["id"])
for tbl, col in (("fatura", "aciklama"), ("irsaliye", "aciklama"),
                 ("siparis", "aciklama"), ("teklif", "aciklama")):
    dbx(f"DELETE FROM {tbl} WHERE {col} LIKE ?", MARK + "%")

# --- test verisi kur ---
r = s.post(BASE + "/stok/yeni", data=[
    ("ad", "TTEC 40\" Full HD TV"), ("kod", "D007-TTEC-STK"),
    ("barkod", "8690000000101"), ("kategori_id", "1"), ("birim", "Adet"),
    ("kdv_orani", "20"), ("alis_fiyat", "9000"), ("satis_fiyat", "11999"),
    ("para_birimi", "TRY"), ("kritik_stok", "0"),
], allow_redirects=False)
tt_stok = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])

r = s.post(BASE + "/cari/yeni", data=[
    ("kod", "D007-MUSTERIA"), ("unvan", "MÜŞTERİ-A"), ("tip", "HerIkisi"),
], allow_redirects=False)
yakup = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])

# ===========================================================================
print("=" * 70); print("BÖLÜM A — KDV dahil/hariç select (madde 1)")
print("=" * 70)
# F2 kuralı: kdv_dahil=1 + bf=118 + KDV%18 → DB'ye net 100 yazılır.
r = s.post(BASE + "/fatura/yeni", data=[
    ("tip", "Satis"), ("cari_id", "1"), ("tarih", datetime.date.today().isoformat()),
    ("para_birimi", "TRY"), ("doviz_kur", ""), ("vade", ""),
    ("kdv_dahil", "1"), ("aciklama", MARK + " fatura kdv-dahil"), ("action", "kaydet"),
] + satir("", fiyat="118", kdv="18", manuel=MARK + " manuel"), allow_redirects=False)
fid = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
fkal = db1("SELECT birim_fiyat FROM fatura_kalem WHERE fatura_id=?", fid)
check("1. test_kdv_select_fatura: kdv_dahil=1 → net 100",
      fkal and abs(fkal["birim_fiyat"] - 100.0) < 1e-6, str(dict(fkal) if fkal else None))
check("1b. fatura formunda kdv_dahil <select> var",
      dosya_icerir("templates/fatura/form.html", 'name="kdv_dahil"') and
      dosya_icerir("templates/fatura/form.html", "<select"))
temizle_fatura(fid)

r = s.post(BASE + "/irsaliye/yeni", data=[
    ("tip", "Satis"), ("cari_id", "1"), ("depo_id", "1"),
    ("tarih", datetime.date.today().isoformat()), ("aciklama", MARK + " irsaliye kdv-dahil"),
    ("kdv_dahil", "1"), ("action", "kaydet"),
] + satir("", fiyat="118", kdv="18", manuel=MARK + " manuel"), allow_redirects=False)
iid = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
ikal = db1("SELECT birim_fiyat FROM irsaliye_kalem WHERE irsaliye_id=?", iid)
check("2. test_kdv_select_irsaliye: kdv_dahil=1 → net 100",
      ikal and abs(ikal["birim_fiyat"] - 100.0) < 1e-6, str(dict(ikal) if ikal else None))
check("2b. irsaliye formunda kdv_dahil <select> var",
      dosya_icerir("templates/irsaliye/form.html", 'name="kdv_dahil"') and
      dosya_icerir("templates/irsaliye/form.html", "<select"))
temizle_irsaliye(iid)

uc_sablon = all(
    dosya_icerir(f"templates/{t}/form.html", 'name="kdv_dahil"') and
    dosya_icerir(f"templates/{t}/form.html", "<select")
    for t in ("teklif", "siparis"))
pos_sablon = (dosya_icerir("templates/pos/satis.html", 'name="kdv_dahil"') and
              dosya_icerir("templates/pos/satis.html", "<select"))
check("3. test_kdv_select_teklif_siparis_pos: 3 şablon daha select", uc_sablon and pos_sablon,
      f"teklif/siparis={uc_sablon}, pos={pos_sablon}")

# ===========================================================================
print("=" * 70); print("BÖLÜM B — Stok marka inline ekleme (madde 2, KRİTİK)")
print("=" * 70)
r = s.post(BASE + "/api/marka/ekle", data={"ad": "D007TTECMARKA"}, allow_redirects=False)
mj = r.json() if r.headers.get("Content-Type", "").startswith("application/json") else {}
check("4. test_marka_inline_ekle: POST /api/marka/ekle → 200 + id",
      r.status_code == 200 and isinstance(mj.get("id"), int) and mj.get("ad") == "D007TTECMARKA",
      str(mj))
check("4b. stok formunda + Marka butonu var",
      dosya_icerir("templates/stok/form.html", 'id="marka-ekle"') and
      dosya_icerir("templates/stok/form.html", "/api/marka/ekle"))
# marka inline ile stok kaydet → detayda marka görünür
r = s.post(BASE + "/stok/yeni", data=[
    ("ad", "D007 Markalı Ürün"), ("kod", "D007-STK-ALAN"), ("marka_id", str(mj["id"])),
    ("birim", "Adet"), ("kdv_orani", "20"),
], allow_redirects=False)
sid2 = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
kart = db1("SELECT marka_id FROM stok_kart WHERE id=?", sid2)
check("4c. inline marka ile stok kaydedildi → marka_id set",
      kart and kart["marka_id"] == mj["id"], str(dict(kart) if kart else None))

# ===========================================================================
print("=" * 70); print("BÖLÜM C — Stok kart 8 ek alan (madde 3)")
print("=" * 70)
r = s.post(BASE + f"/stok/{sid2}/duzenle", data=[
    ("ad", "D007 Markalı Ürün"), ("kod", "D007-STK-ALAN"), ("marka_id", str(mj["id"])),
    ("birim", "Adet"), ("kdv_orani", "20"),
    ("model", "GH6"), ("tevkifat_orani", "50"), ("istisna_kodu", "351"),
    ("grubu", "Elektronik"), ("ana_grup", "Beyaz Eşya"), ("alt_grup", "TV"),
    ("ozel_kod1", "BRN-1"), ("ozel_kod2", "BRN-2"), ("ozel_kod3", "BRN-3"),
], allow_redirects=False)
k = db1("SELECT * FROM stok_kart WHERE id=?", sid2)
check("5. test_stok_ek_alanlar_kayit: 8 alan + model doğru",
      k and k["model"] == "GH6" and abs(k["tevkifat_orani"] - 50.0) < 1e-9
      and k["istisna_kodu"] == "351" and k["grubu"] == "Elektronik"
      and k["ana_grup"] == "Beyaz Eşya" and k["alt_grup"] == "TV"
      and k["ozel_kod1"] == "BRN-1" and k["ozel_kod2"] == "BRN-2" and k["ozel_kod3"] == "BRN-3",
      str({x: k[x] for x in ("model", "tevkifat_orani", "grubu", "ozel_kod1")} if k else None))
r = s.post(BASE + f"/stok/{sid2}/duzenle", data=[
    ("ad", "D007 Markalı Ürün"), ("kod", "D007-STK-ALAN"), ("marka_id", str(mj["id"])),
    ("birim", "Adet"), ("kdv_orani", "20"),
    ("model", "GH6-v2"), ("tevkifat_orani", "50"), ("istisna_kodu", "351"),
    ("grubu", "Elektronik"), ("ana_grup", "Beyaz Eşya"), ("alt_grup", "TV"),
    ("ozel_kod1", "BRN-1"), ("ozel_kod2", "BRN-2"), ("ozel_kod3", "BRN-3"),
], allow_redirects=False)
k2 = db1("SELECT * FROM stok_kart WHERE id=?", sid2)
check("6. test_stok_ek_alanlar_guncelle: değerler korunur + model güncellenir",
      k2 and k2["model"] == "GH6-v2" and k2["grubu"] == "Elektronik"
      and abs(k2["tevkifat_orani"] - 50.0) < 1e-9 and k2["ozel_kod1"] == "BRN-1",
      str(dict(k2) if k2 else None))

# ===========================================================================
print("=" * 70); print("BÖLÜM D — Typeahead TTEC filtre bug (madde 4)")
print("=" * 70)
st, data = s.get(BASE + "/api/ara", params={"tip": "stok", "q": "TTEC"}).status_code, \
    s.get(BASE + "/api/ara", params={"tip": "stok", "q": "TTEC"}).json()
tt = [d for d in data if d["kod"] == "D007-TTEC-STK"]
check("7. test_api_ara_TTEC: q=TTEC → tam 1 kayıt (TTEC)",
      st == 200 and len(tt) == 1 and all("TTEC" in d["ad"] or "TTEC" in d["kod"] for d in data),
      f"{len(data)} kayıt")
st2, data2 = s.get(BASE + "/api/ara", params={"tip": "stok", "q": "T"}).status_code, \
    s.get(BASE + "/api/ara", params={"tip": "stok", "q": "T"}).json()
check("7b. q=T → 1'den fazla kayıt (geniş liste)", st2 == 200 and len(data2) > 1,
      f"{len(data2)} kayıt")
check("8. test_typeahead_irsaliye: form-satir.js /api/ara?tip=stok kullanıyor",
      dosya_icerir("static/js/form-satir.js", "/api/ara?tip=stok"))

# ===========================================================================
print("=" * 70); print("BÖLÜM E — İrsaliye döviz USD + TL çeviri (madde 5)")
print("=" * 70)
r = s.post(BASE + "/irsaliye/yeni", data=[
    ("tip", "Satis"), ("cari_id", "1"), ("depo_id", "1"),
    ("tarih", datetime.date.today().isoformat()), ("aciklama", MARK + " usd irsaliye"),
    ("para_birimi", "USD"), ("doviz_kur", "30"), ("action", "kaydet"),
] + satir(str(tt_stok), fiyat="100", kdv="0"), allow_redirects=False)
usd_id = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
usd = db1("SELECT para_birimi, doviz_kur, genel_toplam FROM irsaliye WHERE id=?", usd_id)
check("9. test_irsaliye_doviz_usd: para_birimi=USD kur=30 kaydedildi",
      usd and usd["para_birimi"] == "USD" and abs(usd["doviz_kur"] - 30.0) < 1e-9,
      str(dict(usd) if usd else None))
s.post(BASE + f"/irsaliye/{usd_id}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)
ch = db1("SELECT borc, para_birimi, doviz_kur FROM cari_hareket "
         "WHERE ilgili_modul='Irsaliye' AND ilgili_kayit_id=?", usd_id)
check("9b. cari hareket TL çevrilmiş (100 USD × 30 = 3000 TL)",
      ch and abs(ch["borc"] - 3000.0) < 1e-6 and ch["para_birimi"] == "USD"
      and abs(ch["doviz_kur"] - 30.0) < 1e-9, str(dict(ch) if ch else None))
yv = db("SELECT hesap_id, borc, alacak FROM yevmiye_kalem WHERE yevmiye_id IN "
        "(SELECT id FROM yevmiye WHERE kaynak_modul='Irsaliye' AND kaynak_id=?)", usd_id)
top_b = sum((r["borc"] or 0) for r in yv); top_a = sum((r["alacak"] or 0) for r in yv)
check("10. test_irsaliye_doviz_tl_ceviri_muhasebe: yevmiye TL dengeli (borç=alacak)",
      abs(top_b - top_a) < 1e-6 and abs(top_b - 3000.0) < 1e-6,
      f"borç={top_b}, alacak={top_a}")
temizle_irsaliye(usd_id)

# ===========================================================================
print("=" * 70); print("BÖLÜM F — Eksi stok izni (madde 6)")
print("=" * 70)
dbx("INSERT OR REPLACE INTO stok_seviye(stok_id, varyant_id, depo_id, miktar, rezerve, "
    "min_stok, max_stok, sirket_id) VALUES(?,0,1,8,0,0,0,?)", tt_stok, sid)
r = s.post(BASE + "/irsaliye/yeni", data=[
    ("tip", "Satis"), ("cari_id", "1"), ("depo_id", "1"),
    ("tarih", datetime.date.today().isoformat()), ("aciklama", MARK + " eksi stok"),
    ("action", "kaydet"),
] + satir(str(tt_stok), miktar="10", fiyat="100", kdv="0"), allow_redirects=False)
eksi_id = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
rr = s.post(BASE + f"/irsaliye/{eksi_id}/durum", data={"durum": "Onaylandı"},
            allow_redirects=False)
sev = db1("SELECT miktar FROM stok_seviye WHERE stok_id=? AND varyant_id=0 AND depo_id=1",
          tt_stok)
check("11. test_eksi_stok_izin: stok 8 → satış 10 onay BAŞARILI → seviye -2",
      rr.status_code in (200, 302) and sev and abs(sev["miktar"] - (-2.0)) < 1e-9,
      f"sev={sev['miktar'] if sev else None}")
s.post(BASE + f"/irsaliye/{eksi_id}/durum", data={"durum": "İptal"}, allow_redirects=False)
sev2 = db1("SELECT miktar FROM stok_seviye WHERE stok_id=? AND varyant_id=0 AND depo_id=1",
           tt_stok)
check("11b. iptal → seviye 8'e geri döner",
      sev2 and abs(sev2["miktar"] - 8.0) < 1e-9, str(dict(sev2) if sev2 else None))
temizle_irsaliye(eksi_id)

r = s.post(BASE + "/fatura/yeni", data=[
    ("tip", "Satis"), ("cari_id", "1"), ("tarih", datetime.date.today().isoformat()),
    ("para_birimi", "TRY"), ("doviz_kur", ""), ("vade", ""),
    ("aciklama", MARK + " fatura eksi stok"), ("action", "kaydet"),
] + satir(str(tt_stok), miktar="99", fiyat="100", kdv="0"), allow_redirects=False)
fid2 = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
fk2 = db1("SELECT COUNT(*) c FROM fatura_kalem WHERE fatura_id=?", fid2)
check("12. test_eksi_stok_fatura: fatura stok 99 isterken oluşur (stok engeli yok)",
      fk2["c"] == 1)
temizle_fatura(fid2)

# ===========================================================================
print("=" * 70); print("BÖLÜM G — Cari kartoteks typeahead + MÜŞTERİ-A 2 irsaliye (madde 7-8)")
print("=" * 70)
st, cdata = s.get(BASE + "/api/ara", params={"tip": "cari", "q": "MÜŞTERİ-A"}).status_code, \
    s.get(BASE + "/api/ara", params={"tip": "cari", "q": "MÜŞTERİ-A"}).json()
yk = [c for c in cdata if c["kod"] == "D007-MUSTERIA"]
check("13. test_kartoteks_cari_typeahead: /api/ara cari MÜŞTERİ-A filtresi + typeahead UI",
      st == 200 and len(yk) == 1 and
      dosya_icerir("templates/kartoteks/cari.html", 'data-tip="cari"') and
      dosya_icerir("templates/kartoteks/cari.html", "typeahead"),
      f"{len(cdata)} kayıt")

# satış 1000 TL (borç) + alış 500 TL (alacak)
r = s.post(BASE + "/irsaliye/yeni", data=[
    ("tip", "Satis"), ("cari_id", str(yakup)), ("depo_id", "1"),
    ("tarih", datetime.date.today().isoformat()), ("aciklama", MARK + " yakup satis"),
    ("action", "kaydet"),
] + satir("", fiyat="1000", kdv="0", manuel=MARK + " yakup satis manuel"),
    allow_redirects=False)
yak_sat = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
s.post(BASE + f"/irsaliye/{yak_sat}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)

r = s.post(BASE + "/irsaliye/yeni", data=[
    ("tip", "Alis"), ("cari_id", str(yakup)), ("depo_id", "1"),
    ("tarih", datetime.date.today().isoformat()), ("aciklama", MARK + " yakup alis"),
    ("action", "kaydet"),
] + satir("", fiyat="500", kdv="0", manuel=MARK + " yakup alis manuel"),
    allow_redirects=False)
yak_alis = int((r.headers.get("Location") or "").rstrip("/").split("/")[-1])
s.post(BASE + f"/irsaliye/{yak_alis}/durum", data={"durum": "Onaylandı"}, allow_redirects=False)

ch_rows = db("SELECT belge_tipi, borc, alacak FROM cari_hareket WHERE cari_id=? "
             "AND ilgili_modul='Irsaliye' ORDER BY id", yakup)
tb = sum((r["borc"] or 0) for r in ch_rows); ta = sum((r["alacak"] or 0) for r in ch_rows)
check("14. test_cari_ekstre_2_irsaliye: MÜŞTERİ-A'ta 2 irsaliye satırı (borç 1000 + alacak 500)",
      len(ch_rows) == 2 and abs(tb - 1000.0) < 1e-6 and abs(ta - 500.0) < 1e-6,
      f"{len(ch_rows)} satır, borç={tb}, alacak={ta}")
bakiye = round(tb - ta, 2)
check("15. test_kartoteks_cari_2_irsaliye: kartoteks toplamı + bakiye 500",
      abs(bakiye - 500.0) < 1e-6, f"bakiye={bakiye}")
temizle_irsaliye(yak_sat); temizle_irsaliye(yak_alis)

# ===========================================================================
print("=" * 70); print("BÖLÜM H — Detay Sil butonu + typeahead genelleme (madde 9-10)")
print("=" * 70)
sil_ok = all(dosya_icerir(f"templates/{t}/detay.html", "/sil")
             for t in ("fatura", "irsaliye", "teklif", "siparis"))
check("16. test_sil_butonu_detay: 4 detay sayfada Sil formu", sil_ok)
check("17. test_typeahead_genel_cari: select name=cari_id → 0",
      not any('select name="cari_id"' in open(f"templates/{t}", encoding="utf-8").read()
              for t in ("kasa/hareket_form.html", "banka/hareket_form.html",
                        "cek_senet/form.html", "kartoteks/cari.html")))
check("18. test_typeahead_genel_stok: select name=stok_id → 0 (bakim dahil)",
      not any('select name="stok_id"' in open(f"templates/{t}", encoding="utf-8").read()
              for t in ("stok/hareket_form.html", "stok/sayim_detay.html",
                        "stok/transfer_detay.html", "garanti/form.html",
                        "bakim/detay.html")))
check("18b. bakim/detay.html cihaz ekleme typeahead (sayısal stok_id inputu yok)",
      dosya_icerir("templates/bakim/detay.html", 'data-tip="stok"') and
      '<input type="number" name="stok_id"' not in
      open("templates/bakim/detay.html", encoding="utf-8").read())

# ===========================================================================
print("=" * 70); print("BÖLÜM I — Regresyon: F6 / F5c / F5b / F1 / K1 (madde 19-21)")
print("=" * 70)
f6_ok = True
for ep in ("/api/saglik", "/api/bildirimler", "/yetkiler", "/saglik", "/edonusum"):
    try:
        rc = s.get(BASE + ep, allow_redirects=False).status_code
        if rc not in (200, 302):
            f6_ok = False; print(f"    {ep} → {rc}")
    except requests.RequestException:
        f6_ok = False
check("19. test_f6_korundu: bildirim/yetki/saglik/edonusum 200", f6_ok)

f5_ok = True
for ep in ("/beyanname", "/demirbas", "/finansal/butce", "/fatura", "/irsaliye"):
    try:
        rc = s.get(BASE + ep, allow_redirects=False).status_code
        if rc not in (200, 302):
            f5_ok = False; print(f"    {ep} → {rc}")
    except requests.RequestException:
        f5_ok = False
check("20. test_f5c_f5b_f1_korundu: beyanname/demirbas/butce/fatura/irsaliye 200", f5_ok)

k1_baska = db1("SELECT COUNT(*) c FROM stok_kart WHERE kod IN ('D007-TTEC-STK','D007-STK-ALAN') "
               "AND sirket_id != ?", sid)
check("21. test_k1_korundu: D007 verisi başka şirkette yok", k1_baska["c"] == 0,
      str(k1_baska["c"]))

# ===========================================================================
print("=" * 70); print("BÖLÜM J — FK bütünlüğü + kalıntı (madde 22)")
print("=" * 70)
fk = db("PRAGMA foreign_key_check")
check("22.1 test_fk_kalinti: FK bütünlüğü (foreign_key_check = 0)", len(fk) == 0,
      str([tuple(r) for r in fk][:5]))
kalinti = db1("SELECT COUNT(*) c FROM (SELECT id FROM fatura WHERE aciklama LIKE ? "
              "UNION ALL SELECT id FROM irsaliye WHERE aciklama LIKE ? "
              "UNION ALL SELECT id FROM teklif WHERE aciklama LIKE ? "
              "UNION ALL SELECT id FROM siparis WHERE aciklama LIKE ?)",
              MARK + "%", MARK + "%", MARK + "%", MARK + "%")
check("22.2 D007TEST kalıntısı yok", kalinti["c"] == 0, str(kalinti["c"]))

# --- son temizlik ---
for kod in ("D007-TTEC-STK", "D007-STK-ALAN"):
    r = db1("SELECT id FROM stok_kart WHERE kod=?", kod)
    if r:
        temizle_stok(r["id"])
dbx("DELETE FROM marka WHERE ad LIKE 'D007%'")
yak = db1("SELECT id FROM cari_kart WHERE kod='D007-MUSTERIA'")
if yak:
    temizle_cari(yak["id"])

print(f"\n=== SONUÇ: {len(ok)} başarılı / {len(fail)} başarısız (toplam {len(ok)+len(fail)}) ===")
if fail:
    print("BAŞARISIZ:", fail)
    raise SystemExit(1)
print("TÜM D007 İYİLEŞTİRME TESTLERİ GEÇTİ ✅")
