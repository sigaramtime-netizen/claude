# -*- coding: utf-8 -*-
"""F5-B — Demirbaş & Amortisman Raporlama Cilası v1.36.0 e2e testi.

GM D004 direktifindeki 18 senaryo, canlı sunucuya HTTP ile. Kurallar:
- YENİ TABLO YOK (mevcut 4 tablo: kategori/demirbas/amortisman/zimmet).
- K1: tüm sorgular sirket_id ile süzülür; Şirket B'de A demirbaşı görünmez.
- Amortisman formülü değişmez: aylık = (maliyet − hurda) / (ömür × 12).
- CSV yalnız Admin/Muhasebe (Depo → 403); API/liste/detay giriş yapmış herkes.
- F1/F5-A bozulmaz; MARK="F5BTEST" ile kalıntı bırakılmaz.

Çalıştırma: sunucu 8080'de çalışırken  python3 test_f5b_demirbas.py
"""
import datetime
import sqlite3

import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
MARK = "F5BTEST"

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print((("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else "")))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris(kadi="admin"):
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": kadi, "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, f"giriş başarısız: {kadi}"
    return s


def aktif_sirket():
    return db1("SELECT sirket_id FROM sessionler ORDER BY rowid DESC LIMIT 1")["sirket_id"]


def gec(s, sid):
    s.post(BASE + "/sirket/gec", data={"sirket_id": str(sid), "next": "/"},
           allow_redirects=False)


def demirbas_ekle(s, ad, maliyet, kategori_id="1", omur="", hurda="0", aciklama=""):
    r = s.post(BASE + "/demirbas/ekle",
               data={"ad": ad, "kategori_id": kategori_id,
                     "alis_tarihi": datetime.date.today().isoformat(),
                     "maliyet": maliyet, "hurda_degeri": hurda, "omur_yil": omur,
                     "sube_id": "1", "zimmetli_kullanici_id": "", "aciklama": aciklama},
               allow_redirects=False)
    row = db1("SELECT id FROM demirbas WHERE ad=? ORDER BY id DESC LIMIT 1", ad)
    return row["id"] if row else None


def demirbas_temizle(did):
    """Test demirbaşına ait amortisman/zimmet/yevmiye/audit satırlarını sil."""
    dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN "
        "(SELECT id FROM yevmiye WHERE kaynak_modul='Demirbas' AND kaynak_id=?)", did)
    dbx("DELETE FROM yevmiye WHERE kaynak_modul='Demirbas' AND kaynak_id=?", did)
    dbx("DELETE FROM demirbas_amortisman WHERE demirbas_id=?", did)
    dbx("DELETE FROM demirbas_zimmet WHERE demirbas_id=?", did)
    dbx("DELETE FROM audit_log WHERE tablo='demirbas' AND kayit_id=?", did)
    dbx("DELETE FROM demirbas WHERE id=?", did)


def temizle():
    # önceki koşulardan kalan test demirbaşları
    for did in [r["id"] for r in db("SELECT id FROM demirbas WHERE ad LIKE ? OR aciklama LIKE ?",
                                    f"%{MARK}%", f"%{MARK}%")]:
        demirbas_temizle(did)
    # test şirketi
    for s2 in [r["id"] for r in db("SELECT id FROM sirket WHERE kod=?", f"{MARK}B")]:
        dbx("DELETE FROM kullanici_sirket WHERE sirket_id=?", s2)
        dbx("DELETE FROM entegrator_ayar WHERE sirket_id=?", s2)
        dbx("DELETE FROM sirket WHERE id=?", s2)


temizle()

# ============================================================================
print("=" * 72)
print("F5-B v1.36.0 — 18 kontrol (canlı sunucuya HTTP)")
print("=" * 72)
admin = giris("admin")
bugun_ym = datetime.date.today().strftime("%Y-%m")
cari_once = db1("SELECT COUNT(*) c FROM cari_hareket")["c"]

# 1) test_kategori_ozet --------------------------------------------------------
html = admin.get(BASE + "/demirbas").text
check("1. test_kategori_ozet",
      "Bilgisayar" in html and "Ekipman" in html and "45.000,00" in html,
      "Bilgisayar kategorisi maliyet 45.000 görünüyor (autoescape &amp;)")

# 2) test_kpi_kartlar ----------------------------------------------------------
kartlar = ["Toplam Maliyet", "Toplam Birikmiş Amortisman", "Net Defter Değeri", "Aktif Adet"]
check("2. test_kpi_kartlar", all(k in html for k in kartlar),
      f"{sum(k in html for k in kartlar)}/4 kart mevcut")

# 3) test_api_ozet --------------------------------------------------------------
d = admin.get(BASE + "/api/demirbas/ozet").json()
check("3. test_api_ozet",
      all(k in d for k in ("toplam_maliyet", "kategori_ozet", "yaklasan_bitis"))
      and d["toplam_maliyet"] == 89000,
      f"toplam_maliyet={d.get('toplam_maliyet')} (seed 45000+28000+16000)")

# 4) test_api_k1 ----------------------------------------------------------------
dbx("INSERT INTO sirket(kod, unvan, aktif) VALUES(?,?,1)", f"{MARK}B", f"{MARK} İkinci Şirket")
s2 = db1("SELECT id FROM sirket WHERE kod=?", f"{MARK}B")["id"]
dbx("INSERT OR IGNORE INTO kullanici_sirket(kullanici_id, sirket_id) "
    "SELECT id, ? FROM kullanici WHERE kullanici_adi='admin'", s2)
gec(admin, s2)
db_b = admin.get(BASE + "/api/demirbas/ozet").json()
gec(admin, 1)
check("4. test_api_k1", db_b["toplam_maliyet"] == 0 and db_b["aktif_adet"] == 0,
      f"B'de toplam_maliyet={db_b['toplam_maliyet']} (A'nın 89000'i görünmemeli)")

# 5) test_plan_tablo -------------------------------------------------------------
h1 = admin.get(BASE + "/demirbas/1").text
check("5. test_plan_tablo",
      "Amortisman Planı" in h1 and "üretilmiş" in h1 and "tahmini" in h1,
      "gelecek 12 ay plan tablosu (donem + gerçek/tahmini) mevcut")

# 6) test_grafik ------------------------------------------------------------------
check("6. test_grafik", "<svg" in h1, "birikmiş amortisman çizgi grafiği (inline SVG)")

# 7) test_csv ----------------------------------------------------------------------
r = admin.get(BASE + "/demirbas/amortisman/csv?yil=2026")
satirlar = r.text.replace("\ufeff", "").splitlines()
check("7. test_csv",
      r.status_code == 200
      and "text/csv" in r.headers.get("Content-Type", "")
      and satirlar[0].startswith("Demirbas Kod")
      and len(satirlar) >= 2,
      f"CT={r.headers.get('Content-Type')}, satır={len(satirlar)}")

# 8) test_csv_k1 -------------------------------------------------------------------
gec(admin, s2)
r_b = admin.get(BASE + "/demirbas/amortisman/csv?yil=2026")
gec(admin, 1)
check("8. test_csv_k1", r_b.status_code == 200 and "DBR-2026-001" not in r_b.text,
      "B CSV'si A satırını içermez")

# 9) test_durum_rozeti ----------------------------------------------------------------
xid = demirbas_ekle(admin, f"{MARK} Satıldı Demirbaş", "5000")
yid = demirbas_ekle(admin, f"{MARK} Tamamlandı Demirbaş", "6000")
admin.post(BASE + f"/demirbas/{xid}/durum", data={"durum": "Satıldı"}, allow_redirects=False)
dbx("INSERT INTO demirbas_amortisman(demirbas_id, donem, tutar, birikmis, net_deger, sirket_id) "
    "VALUES(?,?,?,?,?,1)", yid, bugun_ym, 6000, 6000, 0)
h_list = admin.get(BASE + "/demirbas").text
check("9. test_durum_rozeti",
      all(c in h_list for c in ("b-ok", "b-warn", "b-danger"))
      and "Tamamlandı" in h_list and "Satıldı" in h_list,
      "🟢 Aktif / 🟡 Tamamlandı / 🔴 Satıldı rozetleri mevcut")

# 10) test_yeni_demirbas_ekle ----------------------------------------------------------
zid = demirbas_ekle(admin, f"{MARK} Test Demirbaşı", "10000", omur="4", aciklama=MARK)
z = db1("SELECT * FROM demirbas WHERE id=?", zid)
check("10. test_yeni_demirbas_ekle", z is not None and abs(z["maliyet"] - 10000) < 0.01,
      f"kod={z['kod'] if z else None}")

# 11) test_amortisman_uret_yeni ----------------------------------------------------------
once_amor = db1("SELECT COUNT(*) c FROM demirbas_amortisman WHERE demirbas_id=?", zid)["c"]
admin.post(BASE + "/demirbas/amortisman-uret", data={"donem": bugun_ym}, allow_redirects=False)
sonra_amor = db1("SELECT COUNT(*) c FROM demirbas_amortisman WHERE demirbas_id=?", zid)["c"]
gm = db1("SELECT COUNT(*) c FROM yevmiye WHERE kaynak_modul='Demirbas' AND kaynak_id=?", zid)["c"]
check("11. test_amortisman_uret_yeni", sonra_amor > once_amor and gm >= 1,
      f"amortisman {once_amor}→{sonra_amor}, GM fişi={gm}")

# 12) test_cifte_uretim_engeli ------------------------------------------------------------
admin.post(BASE + "/demirbas/amortisman-uret", data={"donem": bugun_ym}, allow_redirects=False)
sonra2 = db1("SELECT COUNT(*) c FROM demirbas_amortisman WHERE demirbas_id=?", zid)["c"]
check("12. test_cifte_uretim_engeli", sonra2 == sonra_amor,
      f"{sonra_amor}→{sonra2} (idempotent — aynı dönem 2 kez üretilmez)")

# 13) test_zimmet_korundu ------------------------------------------------------------------
admin.post(BASE + f"/demirbas/{zid}/zimmet",
           data={"islem": "Teslim", "kullanici_id": "3", "sube_id": "1", "aciklama": MARK},
           allow_redirects=False)
zim = db1("SELECT COUNT(*) c FROM demirbas_zimmet WHERE demirbas_id=?", zid)["c"]
zimli = db1("SELECT zimmetli_kullanici_id z FROM demirbas WHERE id=?", zid)["z"]
check("13. test_zimmet_korundu", zim >= 1 and zimli == 3,
      f"zimmet satırı={zim}, zimmetli={zimli}")

# 14) test_sil_engeli_korundu ---------------------------------------------------------------
admin.post(BASE + f"/demirbas/{zid}/sil", allow_redirects=False)
kaldi = db1("SELECT COUNT(*) c FROM demirbas WHERE id=?", zid)["c"]
check("14. test_sil_engeli_korundu", kaldi == 1,
      "amortisman/zimmet olan demirbaş silinemedi")

# 15) test_yetki_csv ------------------------------------------------------------------------
depo = giris("depo")
r_depo = depo.get(BASE + "/demirbas/amortisman/csv?yil=2026", allow_redirects=False)
check("15. test_yetki_csv", r_depo.status_code == 403, f"Depo → {r_depo.status_code}")

# 16) test_f1_korundu (cari_hareket artmadı) ------------------------------------------------
cari_sonra = db1("SELECT COUNT(*) c FROM cari_hareket")["c"]
check("16. test_f1_korundu", cari_sonra == cari_once,
      f"cari_hareket {cari_once}→{cari_sonra} (amortisman GM fişi cariye dokunmaz)")

# 17) test_f5a_korundu ----------------------------------------------------------------------
r_b = admin.get(BASE + "/finansal/butce", allow_redirects=False)
r_o = admin.get(BASE + "/api/finansal/ozet?donem=aylik", allow_redirects=False)
check("17. test_f5a_korundu", r_b.status_code == 200 and r_o.status_code == 200,
      f"/finansal/butce={r_b.status_code}, /api/finansal/ozet={r_o.status_code}")

# ---- temizlik + 18) kalıntı kontrolü ------------------------------------------------------
for did in (xid, yid, zid):
    demirbas_temizle(did)
dbx("DELETE FROM kullanici_sirket WHERE sirket_id=?", s2)
dbx("DELETE FROM entegrator_ayar WHERE sirket_id=?", s2)
dbx("DELETE FROM sirket WHERE id=?", s2)

fk_check = db("PRAGMA foreign_key_check")
kalinti = {
    "demirbas": db("SELECT COUNT(*) c FROM demirbas WHERE ad LIKE ? OR aciklama LIKE ?",
                   f"%{MARK}%", f"%{MARK}%")[0]["c"],
    "amortisman": db("SELECT COUNT(*) c FROM demirbas_amortisman WHERE demirbas_id IN (?,?,?)",
                     xid, yid, zid)[0]["c"],
    "sirket": db("SELECT COUNT(*) c FROM sirket WHERE kod=?", f"{MARK}B")[0]["c"],
}
temiz_mi = len(fk_check) == 0 and all(v == 0 for v in kalinti.values())
check("18. test_fk_kalinti", temiz_mi,
      f"foreign_key_check={len(fk_check)} satır, kalıntı={kalinti}")

print("=" * 72)
print(f"SONUÇ: {len(ok)}/18 geçti, {len(fail)} başarısız")
if fail:
    print("BAŞARISIZ:", fail)
    raise SystemExit(1)
print("TÜM KONTROLLER GEÇTİ ✅")
