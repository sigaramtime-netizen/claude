# -*- coding: utf-8 -*-
"""F2 — KDV dahil/hariç ekran görüntüleri.

Çıktı: docs/ekran-goruntuleri/yeni-tema/f2-*.png
Çalıştırma: sunucu 8080'de çalışırken  python3 ekran_f2.py
"""
import os
import requests
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8080"
OUT = "docs/ekran-goruntuleri/yeni-tema"


def main():
    os.makedirs(OUT, exist_ok=True)
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": "admin", "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, "giriş başarısız"
    cookies = {c.name: c.value for c in s.cookies}

    with sync_playwright() as p:
        browser = p.chromium.launch()
        ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        ctx.add_cookies([{"name": k, "value": v, "url": BASE} for k, v in cookies.items()])
        page = ctx.new_page()

        # 1) Fatura formu — toggle görünür (varsayılan KDV hariç)
        page.goto(BASE + "/fatura/yeni", wait_until="networkidle")
        page.wait_for_timeout(600)
        page.screenshot(path=f"{OUT}/f2-fatura-toggle.png", full_page=True)
        print("çekildi: f2-fatura-toggle")

        # 2) KDV dahil + 120 TL → toplamlar net üzerinden (genel 120,00 ₺)
        page.check("#kdv-dahil")
        page.click("#satir-ekle")
        page.wait_for_timeout(300)
        row = page.query_selector("tr.satir")
        row.query_selector(".stok-ara").fill("F2 Demo Hizmeti")
        row.query_selector(".stok-ara").press("Enter")
        page.wait_for_timeout(400)
        row.query_selector("input[name=k_birim_fiyat]").fill("120")
        row.query_selector("input[name=k_miktar]").fill("1")
        page.wait_for_timeout(400)
        genel = (page.text_content("#t-genel") or "").strip()
        kdv = (page.text_content("#t-kdv") or "").strip()
        ara = (page.text_content("#t-ara") or "").strip()
        page.screenshot(path=f"{OUT}/f2-fatura-kdv-dahil-120.png", full_page=True)
        print(f"çekildi: f2-fatura-kdv-dahil-120  → ara={ara} kdv={kdv} genel={genel}")

        # 3) POS — toggle görünür
        page.goto(BASE + "/pos", wait_until="networkidle")
        page.wait_for_timeout(600)
        page.screenshot(path=f"{OUT}/f2-pos-toggle.png", full_page=True)
        print("çekildi: f2-pos-toggle")

        # 4) İrsaliye formu — toggle görünür
        page.goto(BASE + "/irsaliye/yeni", wait_until="networkidle")
        page.wait_for_timeout(600)
        page.screenshot(path=f"{OUT}/f2-irsaliye-toggle.png", full_page=True)
        print("çekildi: f2-irsaliye-toggle")

        browser.close()
    print("F2 ekran görüntüleri tamam.")


if __name__ == "__main__":
    main()
