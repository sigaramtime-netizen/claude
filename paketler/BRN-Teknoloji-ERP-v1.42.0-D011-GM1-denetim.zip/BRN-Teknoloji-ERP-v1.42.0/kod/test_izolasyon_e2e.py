# -*- coding: utf-8 -*-
"""İstek 3 — Adım 3 kanıtı: Cari / Fatura / Stok izolasyonu (e2e).

Kullanıcı şartı: "A şirketinde oluşturulan kayıt B şirketinde görünmüyor."

Akış:
  1. İkinci şirket (ISOB) kurulur; admin üye yapılır.
  2. Şirket A (id=1) ile cari + stok + fatura (Taslak) oluşturulur.
  3. /sirket/gec ile B'ye geçilir; liste sayfaları + JSON API'de A kayıtları aranır.
  4. B'de cari oluşturulur; A'ya dönüp görünmediği doğrulanır.
  5. Temizlik.

Çalıştırma: sunucu 8080'de çalışırken  python3 test_izolasyon_e2e.py
"""
import sqlite3
import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else ""))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def giris():
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": "admin", "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, "giriş başarısız"
    return s


def aktif_sirket():
    return db1("SELECT sirket_id FROM sessionler ORDER BY rowid DESC LIMIT 1")["sirket_id"]


def temiz(html):
    """Flash bildirim bloklarını ayıkla — önceki işlemin kalıntı flash'ı şirket geçişinde
    sonraki sayfada görünebildiği için liste içeriği doğrulamasında gürültü oluşturur."""
    import re
    return re.sub(r'<div class="flash[^"]*">.*?</div>', "", html, flags=re.DOTALL)


def gec(s, sid):
    s.post(BASE + "/sirket/gec", data={"sirket_id": str(sid), "next": "/"},
           allow_redirects=False)


print("=" * 70)
print("KURULUM — ikinci şirket (ISOB)")
print("=" * 70)
if db1("SELECT id FROM sirket WHERE kod='ISOB'"):
    dbx("DELETE FROM kullanici_sirket WHERE sirket_id=(SELECT id FROM sirket WHERE kod='ISOB')")
    dbx("DELETE FROM sirket WHERE kod='ISOB'")
dbx("INSERT INTO sirket(kod, unvan, aktif) VALUES('ISOB','İzolasyon Test Şirketi B',1)")
s_b = db1("SELECT id FROM sirket WHERE kod='ISOB'")["id"]
dbx("INSERT OR IGNORE INTO kullanici_sirket(kullanici_id, sirket_id) "
    "SELECT id, ? FROM kullanici WHERE kullanici_adi='admin'", s_b)

print("=" * 70)
print("A ŞİRKETİ (id=1) — kayıt oluşturma")
print("=" * 70)
a = giris()
check("K1 girişte aktif şirket = 1", aktif_sirket() == 1)

# --- Cari A ---
r = a.post(BASE + "/cari/yeni",
           data={"kod": "ISO-A-CARI", "unvan": "İzolasyon Müşterisi A", "tip": "Musteri"},
           allow_redirects=False)
cari_a = db1("SELECT id FROM cari_kart WHERE kod='ISO-A-CARI'")
check("K2 cari A oluştu (HTTP)", r.status_code == 302 and cari_a is not None)
check("K3 cari A sirket_id=1", cari_a is not None and db1(
    "SELECT sirket_id FROM cari_kart WHERE id=?", cari_a["id"])["sirket_id"] == 1)

# --- Stok A ---
r = a.post(BASE + "/stok/yeni",
           data={"kod": "ISO-A-STOK", "ad": "İzolasyon Ürünü A", "birim": "Adet",
                 "kdv_orani": "20", "satis_fiyat": "100"},
           allow_redirects=False)
stok_a = db1("SELECT id FROM stok_kart WHERE kod='ISO-A-STOK'")
check("K4 stok A oluştu (HTTP)", r.status_code == 302 and stok_a is not None)
check("K5 stok A sirket_id=1", stok_a is not None and db1(
    "SELECT sirket_id FROM stok_kart WHERE id=?", stok_a["id"])["sirket_id"] == 1)

# --- Fatura A (Taslak) ---
r = a.post(BASE + "/fatura/yeni",
           data={"tip": "Satis", "cari_id": str(cari_a["id"]),
                 "tarih": "2026-09-09", "para_birimi": "TRY",
                 "k_stok_id": str(stok_a["id"]), "k_miktar": "2",
                 "k_birim_fiyat": "100", "k_iskonto": "0", "k_kdv": "20",
                 "k_birim": "Adet"},
           allow_redirects=False)
fat_a = db1("SELECT * FROM fatura WHERE cari_id=? AND durum='Taslak' "
            "ORDER BY id DESC LIMIT 1", cari_a["id"])
check("K6 fatura A oluştu (Taslak, HTTP)", r.status_code == 302 and fat_a is not None)
check("K7 fatura A sirket_id=1", fat_a is not None and fat_a["sirket_id"] == 1)

print("=" * 70)
print("B ŞİRKETİNE GEÇİŞ — izolasyon doğrulaması")
print("=" * 70)
gec(a, s_b)
check("K8 B'ye geçildi (oturum sirket_id)", aktif_sirket() == s_b)

html_cari = temiz(a.get(BASE + "/cari").text)
html_stok = temiz(a.get(BASE + "/stok").text)
html_fatura = temiz(a.get(BASE + "/fatura").text)
check("K9 cari A, B'nin cari listesinde görünmüyor", "ISO-A-CARI" not in html_cari
      and "İzolasyon Müşterisi A" not in html_cari)
check("K10 stok A, B'nin stok listesinde görünmüyor", "ISO-A-STOK" not in html_stok
      and "İzolasyon Ürünü A" not in html_stok)
check("K11 fatura A, B'nin fatura listesinde görünmüyor",
      fat_a["fatura_no"] not in html_fatura)

api_c = a.get(BASE + "/api/cari/ara", params={"q": "ISO-A"}).json()
api_s = a.get(BASE + "/api/stok/ara", params={"q": "ISO-A"}).json()
check("K12 /api/cari/ara B'de A cari dönmüyor", api_c == [])
check("K13 /api/stok/ara B'de A stok dönmüyor", api_s == [])

# doğrudan detay erişimi engeli (hedef ID koruması — redirect izlenmez)
check("K14 B, A cari detayını göremiyor",
      a.get(BASE + f"/cari/{cari_a['id']}", allow_redirects=False).status_code == 302)
check("K15 B, A stok detayını göremiyor",
      a.get(BASE + f"/stok/{stok_a['id']}", allow_redirects=False).status_code == 302)
check("K16 B, A faturasını göremiyor",
      a.get(BASE + f"/fatura/{fat_a['id']}", allow_redirects=False).status_code == 302)

print("=" * 70)
print("B ŞİRKETİNDE KAYIT — ters yön izolasyonu")
print("=" * 70)
r = a.post(BASE + "/cari/yeni",
           data={"kod": "ISO-B-CARI", "unvan": "İzolasyon Müşterisi B", "tip": "Musteri"},
           allow_redirects=False)
cari_b = db1("SELECT id FROM cari_kart WHERE kod='ISO-B-CARI'")
check("K17 cari B oluştu", r.status_code == 302 and cari_b is not None)
check("K18 cari B sirket_id=2", cari_b is not None and db1(
    "SELECT sirket_id FROM cari_kart WHERE id=?", cari_b["id"])["sirket_id"] == s_b)

gec(a, 1)
check("K19 A'ya geri dönüldü", aktif_sirket() == 1)
html_cari_a = temiz(a.get(BASE + "/cari").text)
check("K20 cari B, A'nın listesinde görünmüyor", "ISO-B-CARI" not in html_cari_a
      and "İzolasyon Müşterisi B" not in html_cari_a)
check("K21 cari A, A'nın listesinde görünüyor", "ISO-A-CARI" in html_cari_a)

print("=" * 70)
print("TEMİZLİK")
print("=" * 70)
dbx("DELETE FROM fatura_kalem WHERE fatura_id=?", fat_a["id"])
dbx("DELETE FROM fatura WHERE id=?", fat_a["id"])
dbx("DELETE FROM stok_kart WHERE id=?", stok_a["id"])
dbx("DELETE FROM cari_kart WHERE id=?", cari_a["id"])
dbx("DELETE FROM cari_kart WHERE id=?", cari_b["id"])
dbx("DELETE FROM kullanici_sirket WHERE sirket_id=?", s_b)
dbx("DELETE FROM sirket WHERE id=?", s_b)
check("K22 temizlik sonrası ISO kaydı kalmadı",
      db1("SELECT COUNT(*) c FROM cari_kart WHERE kod LIKE 'ISO-%'")["c"] == 0
      and db1("SELECT COUNT(*) c FROM stok_kart WHERE kod LIKE 'ISO-%'")["c"] == 0)

print(f"\nSONUÇ: {len(ok)} başarılı / {len(fail)} başarısız")
if fail:
    print("BAŞARISIZ:", fail)
    raise SystemExit(1)
print("İZOLASYON (CARİ / FATURA / STOK) E2E TESTİ GEÇTİ ✅")
