# Brn Teknoloji ERP — İşletme Yönetim Sistemi

Elektronik / beyaz eşya / teknik servis satan bir işletme için geliştirilen, web tabanlı
mini-ERP (ön muhasebe) sistemi. Türkçe arayüz, TL varsayılan para birimi, çok şubeye
büyüyebilecek modüler mimari.

## Teknoloji

- **Python 3** (standart kütüphane) — harici bağımlılık yok
- **SQLite** — tek dosyalık veritabanı (`data/erp.db`)
- **Jinja2** — sunucu taraflı şablon motoru
- **Kendi WSGI çekirdeği** (`core.py`) — yönlendirici, oturum, rol denetimi, flash mesaj, audit log

## Çalıştırma

```bash
cd erp
python3 app.py
# → http://localhost:8080
```

İlk açılışta örnek veriler otomatik yüklenir (seed).

## Demo Kullanıcılar (şifre: `1234`)

| Kullanıcı | Rol |
|---|---|
| `admin` | Yönetici |
| `muhasebe` | Muhasebe |
| `satis` | Satış |
| `servis` | Servis Teknisyeni |
| `depo` | Depo |

## Proje Yapısı

```
erp/
├── app.py               # Giriş noktası + auth + dashboard + bildirimler
├── core.py              # WSGI çekirdeği, yönlendirici, oturum, şablon yardımcıları
├── db.py                # Şema + migrasyon + seed (örnek) veriler
├── config.py            # Yollar ve ayarlar
├── cari.py              # MODÜL: Cari Hesap Yönetimi (Faz 1)
├── stok.py              # MODÜL: Stok + Stok2 (Faz 1)
├── kasa.py              # MODÜL: Kasa (Faz 1)
├── banka.py             # MODÜL: Banka (Faz 1)
├── sube.py              # MODÜL: Depo/Şube (Faz 1)
├── teklif.py            # MODÜL: Teklif (Faz 2)
├── siparis.py           # MODÜL: Sipariş (Faz 2)
├── data/erp.db          # SQLite veritabanı (otomatik oluşur)
├── templates/           # Jinja2 şablonları
│   ├── base.html        # Ana yerleşim (sidebar + topbar)
│   ├── dashboard.html
│   ├── giris.html       # Giriş ekranı
│   ├── bildirimler.html
│   └── cari/            # Cari modülü şablonları
└── static/style.css     # Tema (koyu, responsive)
```

## Modül Eklemek

Her modül ayrı bir Python dosyasıdır (`cari.py` gibi). Rotalar `core.route` dekoratörüyle
kaydedilir; `app.py` modülü import ederek etkinleştirir:

```python
# yeni_modul.py
from core import route, render_template, redirect, flash, audit

@route(r"/modul", roles=())                     # her giriş yapmış kullanıcı
@route(r"/modul/yeni", methods=("GET","POST"), roles=("Admin","Muhasebe"))
```

- `roles=None` → herkese açık
- `roles=()` → giriş zorunlu, her rol
- `roles=(...)` → belirtilen roller (+Admin her zaman)

## Yol Haritası (Fazlar)

| Faz | Kapsam | Durum |
|---|---|---|
| 1 | Çekirdek: Cari, Stok/Stok2, Kasa, Banka, Depo/Şube | ✅ TAMAMLANDI |
| 2 | Satış Döngüsü: Teklif, Sipariş, İrsaliye, Fatura, Çek/Senet, Döviz | ✅ Teklif + Sipariş hazır |
| 3 | Servis & Garanti: Servis Takip, Seri No-Garanti, Notlar | planlandı |
| 4 | e-Dönüşüm: e-Fatura/e-Arşiv/e-İrsaliye + Gelen Kutuları | planlandı |
| 5 | Mali/Analitik: Genel Muhasebe, Beyanname, Demirbaş, Analiz, Kartoteks, Transfer | planlandı |
| 6 | Cila: yetki, bildirim, PDF şablonları, tablet uyumu | planlandı |
