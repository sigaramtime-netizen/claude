# -*- coding: utf-8 -*-
"""D — Bakım Sözleşmesi e2e testi.

Kapsam:
  1. Sözleşme oluştur + listele (durum türetimi: Aktif/Yaklaşıyor/Süresi Doldu).
  2. Doğrulama: bitiş ≤ başlangıç ve geçersiz cari engeli.
  3. Cihaz ekle / sil.
  4. Periyodik fatura: Onaylı SF + cari borç + yevmiye + dönem kaydı; mükerrer engeli.
  5. İş emri: sözleşme kapsamında servis kaydı (garanti_kapsami=1, ücretsiz).
  6. Yenileme: yeni dönem sözleşmesi + cihaz kopyalama.
  7. Durum: İptal / Aktif geçişi.
  8. Rapor + yaklaşan sözleşme sayımı.
  9. Yetki: Depo 403.
  10. Şirket izolasyonu.
  11. Temizlik: yetim yevmiye / FK / yetim bakim_fatura kontrolü.

Çalıştırma: sunucu 8080'de çalışırken  python3 test_bakim.py
"""
import datetime
import sqlite3
import requests

BASE = "http://127.0.0.1:8080"
DB = "data/erp.db"
BUGUN = datetime.date.today()

ok, fail = [], []


def check(name, cond, detay=""):
    (ok if cond else fail).append(name)
    print(("  ✅ " if cond else "  ❌ ") + name + (f"  → {detay}" if detay else ""))


def db(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchall(); c.close(); return r


def db1(q, *a):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(q, a).fetchone(); c.close(); return r


def dbx(q, *a):
    c = sqlite3.connect(DB); c.execute(q, a); c.commit(); c.close()


def yetim_fisler():
    src = {"Fatura": "fatura", "Kasa": "kasa_hareket", "Banka": "banka_hareket",
           "CekSenet": "cek_senet", "Demirbas": "demirbas"}
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    bad = []
    for r in c.execute("SELECT id, fis_no, kaynak_modul, kaynak_id FROM yevmiye"):
        t = src.get(r["kaynak_modul"])
        if t and not c.execute(f"SELECT 1 FROM {t} WHERE id=?", (r["kaynak_id"],)).fetchone():
            bad.append((r["id"], r["fis_no"], r["kaynak_modul"], r["kaynak_id"]))
    c.close()
    return bad


def giris(kullanici="admin"):
    s = requests.Session()
    r = s.post(BASE + "/giris", data={"kullanici_adi": kullanici, "sifre": "1234"},
               allow_redirects=False)
    assert r.status_code == 302, f"giriş başarısız ({kullanici})"
    return s


def soz_yeni(s, bas, bit, bedel="1200", periyot="Aylik", cari="BKMUS"):
    cid = db1("SELECT id FROM cari_kart WHERE kod=?", cari)["id"]
    return s.post(BASE + "/bakim/sozlesme/yeni",
                  data={"cari_id": str(cid), "baslangic": bas, "bitis": bit,
                        "periyot": periyot, "bedel": bedel, "aciklama": "TEST"},
                  allow_redirects=False)


print("== D / Bakım Sözleşmesi — e2e testi ==")
s = giris("admin")

# --- Kurulum: kalıntı temizliği (idempotent) ---
for soz in [r["id"] for r in db("SELECT id FROM bakim_sozlesme WHERE sozlesme_no LIKE 'BKM-TST-%'")]:
    for f in db("SELECT fatura_id FROM bakim_sozlesme_fatura WHERE sozlesme_id=?", soz):
        fid = f["fatura_id"]
        dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN (SELECT id FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?)", fid)
        dbx("DELETE FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?", fid)
        dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
        dbx("DELETE FROM fatura_kalem WHERE fatura_id=?", fid)
        dbx("DELETE FROM fatura WHERE id=?", fid)
    dbx("DELETE FROM bakim_sozlesme_fatura WHERE sozlesme_id=?", soz)
    dbx("DELETE FROM servis_kayit WHERE bakim_sozlesme_id=?", soz)
    dbx("DELETE FROM bakim_sozlesme_cihaz WHERE sozlesme_id=?", soz)
    dbx("DELETE FROM bakim_sozlesme WHERE id=?", soz)
dbx("DELETE FROM cari_kart WHERE kod='BKMUS'")
dbx("DELETE FROM kullanici_sirket WHERE sirket_id IN (SELECT id FROM sirket WHERE kod='BKMIKI')")
dbx("DELETE FROM sirket WHERE kod='BKMIKI'")
dbx("INSERT INTO cari_kart(kod, unvan, tip, aktif, sirket_id) VALUES('BKMUS','Bakım Test Müşteri','Musteri',1,1)")

bas = (BUGUN - datetime.timedelta(days=30)).isoformat()
bit = (BUGUN + datetime.timedelta(days=60)).isoformat()
yaklas_bit = (BUGUN + datetime.timedelta(days=10)).isoformat()

# 1. Sözleşme oluştur + liste
r = soz_yeni(s, bas, bit)
check("1.1 sözleşme oluşturuldu", r.status_code == 302 and "/bakim/sozlesme/" in (r.headers.get("Location") or ""))
sid = int(r.headers["Location"].rstrip("/").split("/")[-1])
soz = db1("SELECT * FROM bakim_sozlesme WHERE id=?", sid)
check("1.2 kayıt doğru", soz is not None and soz["sozlesme_no"].startswith("BKM-")
      and abs(soz["bedel"] - 1200.0) < 1e-9 and soz["durum"] == "Aktif")
r = s.get(BASE + "/bakim/sozlesmeler")
check("1.3 liste render", r.status_code == 200 and soz["sozlesme_no"] in r.text)

# 2. Doğrulamalar
once = db1("SELECT COUNT(*) c FROM bakim_sozlesme")["c"]
r = soz_yeni(s, bit, bas)  # bitis < baslangic
check("2.1 bitiş ≤ başlangıç engellendi", r.status_code == 302 and r.headers.get("Location") == "/bakim/sozlesme/yeni"
      and db1("SELECT COUNT(*) c FROM bakim_sozlesme")["c"] == once)
r = s.post(BASE + "/bakim/sozlesme/yeni",
           data={"cari_id": "999999", "baslangic": bas, "bitis": bit, "periyot": "Aylik", "bedel": "1200"},
           allow_redirects=False)
check("2.2 geçersiz cari engellendi", r.status_code == 302 and r.headers.get("Location") == "/bakim/sozlesme/yeni"
      and db1("SELECT COUNT(*) c FROM bakim_sozlesme")["c"] == once)

# 3. Cihaz ekle / sil
r = s.post(BASE + f"/bakim/sozlesme/{sid}/cihaz",
           data={"stok_id": "1", "seri_no": "SN-BKM-TST-1", "cihaz_aciklama": "Test TV"}, allow_redirects=False)
z = db1("SELECT * FROM bakim_sozlesme_cihaz WHERE sozlesme_id=? AND seri_no='SN-BKM-TST-1'", sid)
check("3.1 cihaz eklendi", z is not None and z["stok_id"] == 1)
r = s.post(BASE + f"/bakim/sozlesme/cihaz/{z['id']}/sil", allow_redirects=False)
check("3.2 cihaz silindi", db1("SELECT COUNT(*) c FROM bakim_sozlesme_cihaz WHERE id=?", z["id"])["c"] == 0)
s.post(BASE + f"/bakim/sozlesme/{sid}/cihaz",
       data={"stok_id": "1", "seri_no": "SN-BKM-TST-1", "cihaz_aciklama": "Test TV"}, allow_redirects=False)
z = db1("SELECT * FROM bakim_sozlesme_cihaz WHERE sozlesme_id=? AND seri_no='SN-BKM-TST-1'", sid)

# 4. Periyodik fatura
r = s.post(BASE + f"/bakim/sozlesme/{sid}/fatura-uret", allow_redirects=False)
bf = db1("SELECT * FROM bakim_sozlesme_fatura WHERE sozlesme_id=?", sid)
check("4.1 fatura dönem kaydı", bf is not None and bf["donem"] == f"{BUGUN.year}-{BUGUN.month:02d}")
f = db1("SELECT * FROM fatura WHERE id=?", bf["fatura_id"])
beklenen = round(1200 * 1.2, 2)
check("4.2 Onaylı SF + tutar", f is not None and f["durum"] == "Onaylandı" and f["tip"] == "Satis"
      and abs(f["genel_toplam"] - beklenen) < 1e-9, f"genel={f['genel_toplam']}")
ch = db("SELECT borc, alacak FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", f["id"])
check("4.3 cariye borç yazıldı", len(ch) == 1 and abs(ch[0]["borc"] - beklenen) < 1e-9)
yf = db1("SELECT COUNT(*) c FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?", f["id"])
check("4.4 yevmiye fişi üretildi", yf["c"] == 1)
r = s.post(BASE + f"/bakim/sozlesme/{sid}/fatura-uret", allow_redirects=False)
r2 = s.get(BASE + f"/bakim/sozlesme/{sid}")
check("4.5 mükerrer fatura engellendi", "zaten üretildi" in r2.text
      and db1("SELECT COUNT(*) c FROM bakim_sozlesme_fatura WHERE sozlesme_id=?", sid)["c"] == 1)

# 5. İş emri
r = s.post(BASE + f"/bakim/sozlesme/{sid}/is-emri",
           data={"cihaz_id": str(z["id"]), "ariza": "Test arıza", "teknisyen_id": ""}, allow_redirects=False)
w = db1("SELECT * FROM servis_kayit WHERE bakim_sozlesme_id=? ORDER BY id DESC LIMIT 1", sid)
check("5.1 iş emri açıldı", w is not None and w["durum"] == "Alındı" and w["garanti_kapsami"] == 1
      and w["seri_no"] == "SN-BKM-TST-1")
r = s.post(BASE + f"/bakim/sozlesme/{sid}/is-emri", data={"cihaz_id": str(z["id"]), "ariza": ""},
           allow_redirects=False)
check("5.2 arızasız iş emri engellendi", db1("SELECT COUNT(*) c FROM servis_kayit WHERE bakim_sozlesme_id=?", sid)["c"] == 1)

# 6. Yenileme
r = s.post(BASE + f"/bakim/sozlesme/{sid}/yenile", allow_redirects=False)
yeni_id = int(r.headers["Location"].rstrip("/").split("/")[-1])
yeni = db1("SELECT * FROM bakim_sozlesme WHERE id=?", yeni_id)
check("6.1 yeni sözleşme oluştu", yeni is not None and yeni["id"] != sid)
bek_bas = (datetime.date.fromisoformat(bit) + datetime.timedelta(days=1)).isoformat()
check("6.2 yeni dönem başlangıcı", yeni["baslangic"] == bek_bas and yeni["bedel"] == soz["bedel"]
      and yeni["cari_id"] == soz["cari_id"])
check("6.3 cihazlar kopyalandı", db1("SELECT COUNT(*) c FROM bakim_sozlesme_cihaz WHERE sozlesme_id=?", yeni_id)["c"] == 1)

# 7. Durum toggle
s.post(BASE + f"/bakim/sozlesme/{sid}/durum", allow_redirects=False)
check("7.1 iptal edildi", db1("SELECT durum FROM bakim_sozlesme WHERE id=?", sid)["durum"] == "İptal")
s.post(BASE + f"/bakim/sozlesme/{sid}/durum", allow_redirects=False)
check("7.2 aktifleştirildi", db1("SELECT durum FROM bakim_sozlesme WHERE id=?", sid)["durum"] == "Aktif")

# 8. Yaklaşan sözleşme + rapor
r = soz_yeni(s, bas, yaklas_bit, bedel="900")
yak_id = int(r.headers["Location"].rstrip("/").split("/")[-1])
r = s.get(BASE + "/bakim/sozlesmeler")
check("8.1 yaklaşıyor rozeti", "Yaklaşıyor" in r.text)
r = s.get(BASE + "/bakim/rapor")
check("8.2 rapor render", r.status_code == 200 and "Yaklaşan" in r.text)

# 9. Yetki
sd = giris("depo")
r = sd.get(BASE + "/bakim/sozlesme/yeni")
check("9.1 depo → yeni 403", r.status_code == 403)
r = sd.post(BASE + f"/bakim/sozlesme/{sid}/fatura-uret", allow_redirects=False)
check("9.2 depo → fatura 403", r.status_code == 403)

# 10. Şirket izolasyonu
dbx("INSERT INTO sirket(kod, unvan, aktif) VALUES('BKMIKI','Bakım İkinci Şirket',1)")
s2 = db1("SELECT id FROM sirket WHERE kod='BKMIKI'")["id"]
s.post(BASE + "/sirket/gec", data={"sirket_id": str(s2), "next": "/"}, allow_redirects=False)
r = s.get(BASE + "/bakim/sozlesmeler")
check("10.1 2. şirkette liste boş", r.status_code == 200 and "Sözleşme bulunamadı" in r.text)
r = s.post(BASE + f"/bakim/sozlesme/{sid}/fatura-uret", allow_redirects=False)
check("10.2 çapraz şirket fatura engellendi", r.status_code == 302 and "/bakim/sozlesmeler" in (r.headers.get("Location") or ""))
s.post(BASE + "/sirket/gec", data={"sirket_id": "1", "next": "/"}, allow_redirects=False)

# --- Temizlik ---
for soz in [sid, yeni_id, yak_id]:
    for f in db("SELECT fatura_id FROM bakim_sozlesme_fatura WHERE sozlesme_id=?", soz):
        fid = f["fatura_id"]
        dbx("DELETE FROM yevmiye_kalem WHERE yevmiye_id IN (SELECT id FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?)", fid)
        dbx("DELETE FROM yevmiye WHERE kaynak_modul='Fatura' AND kaynak_id=?", fid)
        dbx("DELETE FROM cari_hareket WHERE ilgili_modul='Fatura' AND ilgili_kayit_id=?", fid)
        dbx("DELETE FROM fatura_kalem WHERE fatura_id=?", fid)
        dbx("DELETE FROM fatura WHERE id=?", fid)
    dbx("DELETE FROM bakim_sozlesme_fatura WHERE sozlesme_id=?", soz)
    dbx("DELETE FROM servis_kayit WHERE bakim_sozlesme_id=?", soz)
    dbx("DELETE FROM bakim_sozlesme_cihaz WHERE sozlesme_id=?", soz)
    dbx("DELETE FROM bakim_sozlesme WHERE id=?", soz)
dbx("DELETE FROM cari_kart WHERE kod='BKMUS'")
dbx("DELETE FROM kullanici_sirket WHERE sirket_id IN (SELECT id FROM sirket WHERE kod='BKMIKI')")
dbx("DELETE FROM sirket WHERE kod='BKMIKI'")

# --- Bütünlük ---
fk = db("PRAGMA foreign_key_check")
check("11.1 FK bütünlüğü", len(fk) == 0, str([tuple(r) for r in fk][:5]))
yf = yetim_fisler()
check("11.2 yetim yevmiye fişi yok", len(yf) == 0, str(yf[:5]))
check("11.3 yetim bakim_fatura yok",
      db1("SELECT COUNT(*) c FROM bakim_sozlesme_fatura bf LEFT JOIN fatura f ON f.id=bf.fatura_id WHERE f.id IS NULL")["c"] == 0)
check("11.4 yetim servis->sözleşme yok",
      db1("SELECT COUNT(*) c FROM servis_kayit sk LEFT JOIN bakim_sozlesme b ON b.id=sk.bakim_sozlesme_id WHERE sk.bakim_sozlesme_id IS NOT NULL AND b.id IS NULL")["c"] == 0)

print(f"\n=== SONUÇ: {len(ok)} başarılı / {len(fail)} başarısız ===")
if fail:
    print("BAŞARISIZ:", fail)
    raise SystemExit(1)
print("TÜM BAKIM SÖZLEŞMESİ TESTLERİ GEÇTİ ✅")
