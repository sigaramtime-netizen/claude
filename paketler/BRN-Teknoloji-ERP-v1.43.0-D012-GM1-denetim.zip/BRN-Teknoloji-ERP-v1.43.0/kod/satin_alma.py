# -*- coding: utf-8 -*-
"""Satın Alma Talebi modülü (B1 — Satın Alma Yönetimi giriş noktası).

Akış: Taslak → Onay Bekliyor → Onaylandı / Reddedildi → (Onaylandı'dan) Siparişe Dönüştü.
- K8: satin_alma_talebi.donusen_siparis_id → siparis.id (nullable); onaylı talepten
  tek seferlik Satın Alma Siparişi (SAP) üretilir (K10 deseni: yalnız Onaylandı kaynaktan).
- K13: talep_no = "SAT-{YYYY}-{NNN}", şirket başına bağımsız sayaç.
- Talep mali etki üretmez (yalnız iç talep); bildirim + audit izlenir.
- K1: şube izolasyonu (sube_id); çoklu şirket (sirket_id).
"""
import datetime
import urllib.parse

import db
import stok
from core import route, render_template, redirect, flash, audit, notify, \
    izole_sube, sube_koruma, Response

TALEP_WRITE = ("Admin", "Muhasebe", "Satis", "Depo")
TALEP_ONAY = ("Admin", "Muhasebe")

DURUMLAR = ["Taslak", "Onay Bekliyor", "Onaylandı", "Reddedildi", "Siparişe Dönüştü"]
DURUM_BADGE = {
    "Taslak": "b-muted",
    "Onay Bekliyor": "b-warn",
    "Onaylandı": "b-ok",
    "Reddedildi": "b-danger",
    "Siparişe Dönüştü": "b-info",
}
KAYNAKLAR = ["Yurt İçi", "Yurt Dışı"]
ONCELIKLER = ["Normal", "Acil"]


def _f(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _i(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _stoklar(conn, sid=None):
    where, args = ["aktif=1"], []
    if sid is not None:
        where.append("sirket_id=?")
        args.append(sid)
    rows = conn.execute(
        f"SELECT * FROM stok_kart WHERE {' AND '.join(where)} ORDER BY ad", args).fetchall()
    return {r["id"]: dict(r) for r in rows}


def _tedarikciler(conn, sid=None):
    where, args = ["aktif=1 AND tip IN ('Tedarikci','HerIkisi')"], []
    if sid is not None:
        where.append("sirket_id=?")
        args.append(sid)
    return conn.execute(
        f"SELECT id, kod, unvan FROM cari_kart WHERE {' AND '.join(where)} ORDER BY unvan",
        args).fetchall()


def _depolar(conn, sid=None):
    where, args = ["1=1"], []
    if sid is not None:
        where.append("sirket_id=?")
        args.append(sid)
    return conn.execute(
        f"SELECT id, ad FROM depo WHERE {' AND '.join(where)} ORDER BY ad", args).fetchall()


def _satirlar_from_form(req):
    stok_ids = req.form_list.get("k_stok_id", [])
    varyantlar = req.form_list.get("k_varyant_id", [])
    manuel_adlar = req.form_list.get("k_manuel_ad", [])
    birimler = req.form_list.get("k_birim", [])
    miktarlar = req.form_list.get("k_miktar", [])
    bf = req.form_list.get("k_birim_fiyat", [])
    oncelikler = req.form_list.get("k_oncelik", [])
    n = max(len(stok_ids), len(manuel_adlar), len(miktarlar))
    rows = []
    for i in range(n):
        sid_raw = (stok_ids[i] if i < len(stok_ids) else "").strip()
        sid = int(sid_raw) if sid_raw.isdigit() else None
        manuel_ad = (manuel_adlar[i] if i < len(manuel_adlar) else "").strip()
        oncelik = (oncelikler[i] if i < len(oncelikler) else "Normal").strip()
        if oncelik not in ("Normal", "Acil"):
            oncelik = "Normal"
        rows.append({
            "stok_id": sid,  # None → manuel (serbest metin) satır
            "varyant_id": _i(varyantlar[i]) or 0 if i < len(varyantlar) else 0,
            "miktar": _f(miktarlar[i] if i < len(miktarlar) else 0, 0),
            "tahmini_fiyat": _f(bf[i] if i < len(bf) else 0, 0),
            "manuel_ad": manuel_ad,
            "birim": (birimler[i] if i < len(birimler) else "").strip() or None,
            "oncelik": oncelik,
        })
    return rows


def _talep_detay(conn, tid, sirket_id=None):
    where = "t.id=?"
    args = [int(tid)]
    if sirket_id is not None:
        where += " AND t.sirket_id=?"
        args.append(sirket_id)
    t = conn.execute(
        f"SELECT t.*, c.unvan AS tedarikci_unvan, c.kod AS tedarikci_kod, "
        f"d.ad AS depo_ad, eu.kullanici_adi AS talep_eden_adi, "
        f"ou.kullanici_adi AS onaylayan_adi, sp.siparis_no AS donusen_siparis_no "
        f"FROM satin_alma_talebi t "
        f"LEFT JOIN cari_kart c ON c.id=t.tedarikci_id "
        f"LEFT JOIN depo d ON d.id=t.depo_id "
        f"LEFT JOIN kullanici eu ON eu.id=t.talep_eden_id "
        f"LEFT JOIN kullanici ou ON ou.id=t.onaylayan_id "
        f"LEFT JOIN siparis sp ON sp.id=t.donusen_siparis_id "
        f"WHERE {where}", args).fetchone()
    if not t:
        return None, []
    kalemler = conn.execute(
        "SELECT k.*, s.kod AS stok_kod, s.ad AS stok_ad FROM satin_alma_talebi_kalem k "
        "LEFT JOIN stok_kart s ON s.id=k.stok_id WHERE k.talep_id=? ORDER BY k.id",
        (int(tid),)).fetchall()
    return t, kalemler


@route(r"/satin-alma/talepler", roles=())
def talep_liste(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    durum = req.q("durum") if req.q("durum") in DURUMLAR else ""
    kaynak = req.q("kaynak") if req.q("kaynak") in KAYNAKLAR else ""
    q = (req.q("q") or "").strip()

    where, params = ["t.sirket_id=?"], [sid]
    if izole_sube(req):
        where.append("t.sube_id=?")
        params.append(izole_sube(req))
    if durum:
        where.append("t.durum=?")
        params.append(durum)
    if kaynak:
        where.append("t.kaynak=?")
        params.append(kaynak)
    if q:
        where.append("(t.talep_no LIKE ? OR t.gerekce LIKE ? OR c.unvan LIKE ? OR c.kod LIKE ?)")
        like = f"%{q}%"
        params += [like, like, like, like]
    w = " AND ".join(where)

    rows = conn.execute(
        f"SELECT t.*, c.unvan AS tedarikci_unvan, c.kod AS tedarikci_kod, "
        f"(SELECT COUNT(*) FROM satin_alma_talebi_kalem k WHERE k.talep_id=t.id) AS kalem_sayisi, "
        f"eu.kullanici_adi AS talep_eden_adi "
        f"FROM satin_alma_talebi t "
        f"LEFT JOIN cari_kart c ON c.id=t.tedarikci_id "
        f"LEFT JOIN kullanici eu ON eu.id=t.talep_eden_id "
        f"WHERE {w} ORDER BY t.id DESC LIMIT 200", params).fetchall()
    ozet = {d: conn.execute(
        "SELECT COUNT(*) c FROM satin_alma_talebi WHERE durum=? AND sirket_id=?",
        (d, sid)).fetchone()["c"] for d in DURUMLAR}
    conn.close()
    return render_template("satin_alma/liste.html", rows=rows, ozet=ozet,
                           durumlar=DURUMLAR, durum_badge=DURUM_BADGE,
                           kaynaklar=KAYNAKLAR, filtro={"durum": durum, "kaynak": kaynak, "q": q})


@route(r"/satin-alma/talepler/yeni", methods=("GET", "POST"), roles=TALEP_WRITE)
def talep_yeni(req):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    if req.method == "POST":
        satirlar, hata = _kaydet(req, conn, mevcut=None)
        if hata:
            conn.close()
            return _form_render(req, mevcut=None, satirlar=satirlar, hata=hata)
        conn.close()
        return redirect(f"/satin-alma/talepler/{satirlar}")
    conn.close()
    return _form_render(req, mevcut=None, satirlar=[], hata=None)


@route(r"/satin-alma/talepler/(?P<tid>\d+)", roles=())
def talep_detay(req, tid):
    conn = db.get_conn()
    t, kalemler = _talep_detay(conn, tid, db.sirket_id(req))
    conn.close()
    if not t:
        flash(req, "Talep bulunamadı.", "danger")
        return redirect("/satin-alma/talepler")
    rol_onay = req.user["rol"] in TALEP_ONAY
    return render_template("satin_alma/detay.html", talep=t, kalemler=kalemler,
                           durum_badge=DURUM_BADGE, rol_onay=rol_onay)


@route(r"/satin-alma/talepler/(?P<tid>\d+)/duzenle", methods=("GET", "POST"), roles=TALEP_WRITE)
def talep_duzenle(req, tid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    mevcut = conn.execute("SELECT * FROM satin_alma_talebi WHERE id=? AND sirket_id=?",
                          (int(tid), sid)).fetchone()
    if not mevcut:
        conn.close()
        flash(req, "Talep bulunamadı.", "danger")
        return redirect("/satin-alma/talepler")
    if not sube_koruma(req, mevcut["sube_id"]):
        conn.close()
        return Response("Bu kayıt başka bir şubeye aittir.", "403 Forbidden")
    if mevcut["durum"] != "Taslak":
        conn.close()
        flash(req, "Yalnızca 'Taslak' talepler düzenlenebilir.", "danger")
        return redirect(f"/satin-alma/talepler/{mevcut['id']}")
    if req.method == "POST":
        satirlar, hata = _kaydet(req, conn, mevcut=mevcut)
        if hata:
            conn.close()
            return _form_render(req, mevcut=mevcut, satirlar=satirlar, hata=hata)
        conn.close()
        return redirect(f"/satin-alma/talepler/{mevcut['id']}")
    kalemler = conn.execute("SELECT * FROM satin_alma_talebi_kalem WHERE talep_id=? ORDER BY id",
                            (mevcut["id"],)).fetchall()
    stok_map = _stoklar(conn, sid)
    satirlar = []
    for k in kalemler:
        d = dict(k)
        sk = stok_map.get(k["stok_id"])
        d["stok_ad"] = sk["ad"] if sk else None
        d["manuel_ad"] = k["aciklama"]
        satirlar.append(d)
    conn.close()
    return _form_render(req, mevcut=mevcut, satirlar=satirlar, hata=None)


@route(r"/satin-alma/talepler/(?P<tid>\d+)/sil", methods=("POST",), roles=TALEP_WRITE)
def talep_sil(req, tid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    t = conn.execute("SELECT * FROM satin_alma_talebi WHERE id=? AND sirket_id=?",
                     (int(tid), sid)).fetchone()
    if not t:
        conn.close()
        return redirect("/satin-alma/talepler")
    if not sube_koruma(req, t["sube_id"]):
        conn.close()
        return Response("Bu kayıt başka bir şubeye aittir.", "403 Forbidden")
    if t["durum"] != "Taslak":
        conn.close()
        flash(req, "Yalnızca 'Taslak' talepler silinebilir.", "danger")
        return redirect(f"/satin-alma/talepler/{t['id']}")
    audit(req, "satin_alma_talebi", t["id"], "sil", {"talep_no": t["talep_no"]})
    conn.execute("DELETE FROM satin_alma_talebi_kalem WHERE talep_id=?", (t["id"],))
    conn.execute("DELETE FROM satin_alma_talebi WHERE id=?", (t["id"],))
    conn.commit()
    conn.close()
    flash(req, "Talep silindi.", "ok")
    return redirect("/satin-alma/talepler")


@route(r"/satin-alma/talepler/(?P<tid>\d+)/durum", methods=("POST",), roles=TALEP_WRITE)
def talep_durum(req, tid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    t = conn.execute("SELECT * FROM satin_alma_talebi WHERE id=? AND sirket_id=?",
                     (int(tid), sid)).fetchone()
    if not t:
        conn.close()
        return redirect("/satin-alma/talepler")
    if not sube_koruma(req, t["sube_id"]):
        conn.close()
        return Response("Bu kayıt başka bir şubeye aittir.", "403 Forbidden")
    hedef = (req.form.get("hedef") or "").strip()
    bugun = datetime.date.today().isoformat()

    if hedef == "gonder" and t["durum"] == "Taslak":
        n = conn.execute("SELECT COUNT(*) c FROM satin_alma_talebi_kalem WHERE talep_id=?",
                         (t["id"],)).fetchone()["c"]
        if n == 0:
            conn.close()
            flash(req, "Kalemsiz talep onaya gönderilemez.", "danger")
            return redirect(f"/satin-alma/talepler/{t['id']}")
        conn.execute("UPDATE satin_alma_talebi SET durum='Onay Bekliyor', updated_at=datetime('now','localtime') WHERE id=?",
                     (t["id"],))
        conn.commit()
        audit(req, "satin_alma_talebi", t["id"], "gonder", {"talep_no": t["talep_no"]})
        notify("uyari", "Satın alma talebi onay bekliyor",
               f"{t['talep_no']} nolu satın alma talebi onay bekliyor.",
               "satin_alma_talebi", t["id"], sirket_id=sid)
        flash(req, "Talep onaya gönderildi.", "ok")
    elif hedef == "geri_cek" and t["durum"] == "Onay Bekliyor":
        conn.execute("UPDATE satin_alma_talebi SET durum='Taslak', updated_at=datetime('now','localtime') WHERE id=?",
                     (t["id"],))
        conn.commit()
        audit(req, "satin_alma_talebi", t["id"], "geri_cek", {"talep_no": t["talep_no"]})
        flash(req, "Talep taslağa geri çekildi.", "ok")
    elif hedef == "onayla" and t["durum"] == "Onay Bekliyor":
        if req.user["rol"] not in TALEP_ONAY:
            conn.close()
            flash(req, "Onay yetkiniz yok.", "danger")
            return redirect(f"/satin-alma/talepler/{t['id']}")
        conn.execute(
            "UPDATE satin_alma_talebi SET durum='Onaylandı', onaylayan_id=?, onay_tarihi=?, "
            "red_nedeni=NULL, updated_at=datetime('now','localtime') WHERE id=?",
            (req.user["id"], bugun, t["id"]))
        conn.commit()
        audit(req, "satin_alma_talebi", t["id"], "onayla", {"talep_no": t["talep_no"]})
        notify("bilgi", "Satın alma talebi onaylandı",
               f"{t['talep_no']} nolu satın alma talebi onaylandı; siparişe dönüştürülebilir.",
               "satin_alma_talebi", t["id"], sirket_id=sid)
        flash(req, "Talep onaylandı.", "ok")
    elif hedef == "reddet" and t["durum"] == "Onay Bekliyor":
        if req.user["rol"] not in TALEP_ONAY:
            conn.close()
            flash(req, "Onay yetkiniz yok.", "danger")
            return redirect(f"/satin-alma/talepler/{t['id']}")
        red = (req.form.get("red_nedeni") or "").strip()
        if not red:
            conn.close()
            flash(req, "Red nedeni zorunludur.", "danger")
            return redirect(f"/satin-alma/talepler/{t['id']}")
        conn.execute(
            "UPDATE satin_alma_talebi SET durum='Reddedildi', onaylayan_id=?, onay_tarihi=?, "
            "red_nedeni=?, updated_at=datetime('now','localtime') WHERE id=?",
            (req.user["id"], bugun, red, t["id"]))
        conn.commit()
        audit(req, "satin_alma_talebi", t["id"], "reddet", {"talep_no": t["talep_no"], "neden": red})
        notify("uyari", "Satın alma talebi reddedildi",
               f"{t['talep_no']} nolu talep reddedildi: {red}",
               "satin_alma_talebi", t["id"], sirket_id=sid)
        flash(req, "Talep reddedildi.", "ok")
    else:
        conn.close()
        flash(req, "Bu durum geçişine izin verilmiyor.", "danger")
        return redirect(f"/satin-alma/talepler/{t['id']}")
    conn.commit()
    conn.close()
    return redirect(f"/satin-alma/talepler/{t['id']}")


@route(r"/satin-alma/talepler/(?P<tid>\d+)/siparise-donustur", methods=("GET", "POST"), roles=TALEP_WRITE)
def talep_donustur(req, tid):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    t, kalemler = _talep_detay(conn, tid, sid)
    if not t:
        conn.close()
        flash(req, "Talep bulunamadı.", "danger")
        return redirect("/satin-alma/talepler")
    if not sube_koruma(req, t["sube_id"]):
        conn.close()
        return Response("Bu kayıt başka bir şubeye aittir.", "403 Forbidden")
    if t["durum"] != "Onaylandı" or t["donusen_siparis_id"]:
        conn.close()
        flash(req, "Yalnızca 'Onaylandı' durumundaki, dönüştürülmemiş talepler siparişe dönüştürülebilir.", "danger")
        return redirect(f"/satin-alma/talepler/{t['id']}")

    tedarikciler = _tedarikciler(conn, sid)
    if req.method == "POST":
        tedarikci_id = _i(req.form.get("tedarikci_id"))
        if not tedarikci_id:
            conn.close()
            flash(req, "Satın alma siparişi için tedarikçi seçmelisiniz.", "danger")
            return redirect(f"/satin-alma/talepler/{t['id']}/siparise-donustur")
        tedarikci = conn.execute(
            "SELECT * FROM cari_kart WHERE id=? AND sirket_id=? AND tip IN ('Tedarikci','HerIkisi')",
            (tedarikci_id, sid)).fetchone()
        if not tedarikci:
            conn.close()
            flash(req, "Geçerli bir tedarikçi seçin.", "danger")
            return redirect(f"/satin-alma/talepler/{t['id']}/siparise-donustur")
        hata = _sap_uret(conn, req, t, kalemler, tedarikci_id)
        if hata:
            conn.close()
            flash(req, hata, "danger")
            return redirect(f"/satin-alma/talepler/{t['id']}/siparise-donustur")
        conn.commit()
        conn.close()
        return redirect(f"/satin-alma/talepler/{t['id']}")

    stok_map = _stoklar(conn, sid)
    conn.close()
    return render_template("satin_alma/donustur.html", talep=t, kalemler=kalemler,
                           tedarikciler=tedarikciler, stok_map=stok_map)


# ---------------------------------------------------------------------------
# Yardımcılar (kaydetme + SAP üretimi)
# ---------------------------------------------------------------------------
def _sap_uret(conn, req, talep, kalemler, tedarikci_id):
    """Onaylı talepten 'Bekliyor' durumunda Satın Alma Siparişi (SAP) üretir."""
    if not kalemler:
        return "Kalemsiz talep siparişe dönüştürülemez."
    bugun = datetime.date.today().isoformat()
    no = db.sonraki_belge_no(conn, "siparis", "siparis_no", "SAP", bugun[:4], db.sirket_id(req))
    stok_map = _stoklar(conn, db.sirket_id(req))

    ara = kdv = 0.0
    hazir = []
    for k in kalemler:
        bf = k["tahmini_fiyat"] or 0.0
        sk = stok_map.get(k["stok_id"])
        kdv_oran = sk["kdv_orani"] if sk else 20.0
        if not bf and sk:
            bf = sk["alis_fiyat"] or 0.0
        brut = (k["miktar"] or 0.0) * bf
        ara += brut
        kdv += brut * kdv_oran / 100.0
        hazir.append({"stok_id": k["stok_id"], "varyant_id": k["varyant_id"] or 0,
                      "miktar": k["miktar"] or 0.0, "birim_fiyat": bf,
                      "kdv_orani": kdv_oran, "tutar": round(brut, 2),
                      "birim": k["birim"], "manuel_ad": k["aciklama"]})
    aciklama = (f"{talep['talep_no']} talebinden üretildi" +
                (f" — {talep['gerekce']}" if talep["gerekce"] else ""))
    cur = conn.execute(
        "INSERT INTO siparis(siparis_no, tip, cari_id, depo_id, kaynak_teklif_id, tarih, "
        "teslim_tarihi, durum, para_birimi, ara_toplam, iskonto_toplam, kdv_toplam, "
        "genel_toplam, aciklama, sube_id, created_by, sirket_id) "
        "VALUES(?,?,?,?,?,?,NULL,'Bekliyor','TRY',?,?,?,?,?,?,?,?)",
        (no, "Alis", tedarikci_id, talep["depo_id"], None, bugun,
         round(ara, 2), 0.0, round(kdv, 2), round(ara + kdv, 2),
         aciklama, talep["sube_id"], req.user["id"], db.sirket_id(req)))
    sid = cur.lastrowid
    for k in hazir:
        conn.execute(
            "INSERT INTO siparis_kalem(siparis_id, stok_id, varyant_id, miktar, teslim_edilen, "
            "birim_fiyat, iskonto_orani, kdv_orani, tutar, aciklama, birim, goruntu_adi, sirket_id) "
            "VALUES(?,?,?,?,0,?,?,?,?,?,?,NULL,?)",
            (sid, k["stok_id"], k["varyant_id"], k["miktar"], k["birim_fiyat"],
             0.0, k["kdv_orani"], k["tutar"], k["manuel_ad"], k["birim"],
             db.sirket_id(req)))
    conn.execute(
        "UPDATE satin_alma_talebi SET durum='Siparişe Dönüştü', donusen_siparis_id=?, "
        "updated_at=datetime('now','localtime') WHERE id=?", (sid, talep["id"]))
    conn.commit()
    audit(req, "satin_alma_talebi", talep["id"], "siparise_donustur",
          {"talep_no": talep["talep_no"], "siparis_no": no})
    audit(req, "siparis", sid, "olustur", {"siparis_no": no, "kaynak": talep["talep_no"]})
    notify("bilgi", "Talepten satın alma siparişi üretildi",
           f"{talep['talep_no']} talebinden {no} nolu satın alma siparişi üretildi.",
           "satin_alma_talebi", talep["id"], sirket_id=db.sirket_id(req))
    flash(req, f"Satın alma siparişi üretildi: {no}", "ok")
    return None


def _kaydet(req, conn, mevcut):
    """Talep kaydet (yeni/güncelle). Dönüş: (talep_id veya satır listesi, hata)."""
    satirlar = _satirlar_from_form(req)
    gecerli = []
    for s in satirlar:
        if s["stok_id"] or (s["manuel_ad"] and s["manuel_ad"].strip()):
            if (s["miktar"] or 0) <= 0:
                return satirlar, "Satır miktarları sıfırdan büyük olmalı."
            gecerli.append(s)
    if not gecerli:
        return satirlar, "En az bir kalem ekleyin."

    kaynak = req.form.get("kaynak") or "Yurt İçi"
    if kaynak not in KAYNAKLAR:
        kaynak = "Yurt İçi"
    depo_id = _i(req.form.get("depo_id")) or None
    tedarikci_id = _i(req.form.get("tedarikci_id")) or None
    gerekce = (req.form.get("gerekce") or "").strip() or None
    sid = db.sirket_id(req)

    # Çapraz şirket / geçersiz referans koruması
    for s in gecerli:
        if s["stok_id"] and not conn.execute(
                "SELECT 1 FROM stok_kart WHERE id=? AND sirket_id=? AND aktif=1",
                (s["stok_id"], sid)).fetchone():
            return satirlar, "Satırdaki bir stok kartı bu şirkete ait değil."
    if depo_id and not conn.execute("SELECT 1 FROM depo WHERE id=? AND sirket_id=?",
                                    (depo_id, sid)).fetchone():
        return satirlar, "Seçilen depo bu şirkete ait değil."
    if tedarikci_id and not conn.execute(
            "SELECT 1 FROM cari_kart WHERE id=? AND sirket_id=? AND tip IN ('Tedarikci','HerIkisi')",
            (tedarikci_id, sid)).fetchone():
        return satirlar, "Seçilen tedarikçi geçerli değil."

    if mevcut:
        conn.execute(
            "UPDATE satin_alma_talebi SET kaynak=?, depo_id=?, tedarikci_id=?, gerekce=?, "
            "updated_at=datetime('now','localtime') WHERE id=?",
            (kaynak, depo_id, tedarikci_id, gerekce, mevcut["id"]))
        conn.execute("DELETE FROM satin_alma_talebi_kalem WHERE talep_id=?", (mevcut["id"],))
        tid = mevcut["id"]
        islem = ("guncelle", {"talep_no": mevcut["talep_no"]}, "Talep güncellendi.")
    else:
        no = db.sonraki_belge_no(conn, "satin_alma_talebi", "talep_no", "SAT",
                                 datetime.date.today().strftime("%Y"), sid)
        cur = conn.execute(
            "INSERT INTO satin_alma_talebi(talep_no, sube_id, depo_id, tedarikci_id, kaynak, "
            "gerekce, durum, talep_eden_id, created_by, sirket_id) "
            "VALUES(?,?,?,?,?,?,'Taslak',?,?,?)",
            (no, izole_sube(req), depo_id, tedarikci_id, kaynak, gerekce,
             req.user["id"], req.user["id"], sid))
        tid = cur.lastrowid
        islem = ("olustur", {"talep_no": no}, f"Talep oluşturuldu: {no}")

    stok_birim = {}
    _stok_ids = {s["stok_id"] for s in gecerli if s["stok_id"]}
    if _stok_ids:
        ph = ",".join("?" * len(_stok_ids))
        stok_birim = {r["id"]: r["birim"] for r in conn.execute(
            f"SELECT id, birim FROM stok_kart WHERE id IN ({ph})", tuple(_stok_ids)).fetchall()}
    for s in gecerli:
        birim = s.get("birim") or None
        if not birim:
            birim = (stok_birim.get(s["stok_id"]) or "Adet") if s["stok_id"] else "Adet"
        conn.execute(
            "INSERT INTO satin_alma_talebi_kalem(talep_id, stok_id, varyant_id, miktar, birim, "
            "tahmini_fiyat, oncelik, aciklama, sirket_id) VALUES(?,?,?,?,?,?,?,?,?)",
            (tid, s["stok_id"], s["varyant_id"] or 0, s["miktar"], birim,
             s["tahmini_fiyat"], s["oncelik"],
             (s["manuel_ad"] or "").strip() or None, sid))
    conn.commit()
    audit(req, "satin_alma_talebi", tid, islem[0], islem[1])
    flash(req, islem[2], "ok")
    return tid, None


def _form_render(req, mevcut, satirlar, hata):
    conn = db.get_conn()
    sid = db.sirket_id(req)
    ctx = {
        "mevcut": mevcut,
        "satirlar": satirlar,
        "hata": hata,
        "tedarikciler": _tedarikciler(conn, sid),
        "depolar": _depolar(conn, sid),
        "birimler": db.birimler(sid=sid),
        "kaynaklar": KAYNAKLAR,
        "oncelikler": ONCELIKLER,
        "stoklar": [dict(s) for s in _stoklar(conn, sid).values()],
    }
    conn.close()
    return render_template("satin_alma/form.html", **ctx)


def register():
    pass
